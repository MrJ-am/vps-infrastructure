# Licence de Vision

Copyright (C) 2026 Jean-Christophe Jameux.

Le code original, la documentation et les visuels originaux de Vision sont
placés sous GNU Affero General Public License, version 3 ou, à votre choix,
toute version ultérieure publiée par la Free Software Foundation.
L’identifiant SPDX est `AGPL-3.0-or-later`.

Vision est un logiciel libre : vous pouvez le redistribuer et le modifier
selon les termes de cette licence. Il est distribué dans l’espoir d’être utile,
mais sans aucune garantie, y compris les garanties implicites de qualité
marchande ou d’adéquation à un usage particulier. Le texte intégral figure
dans [LICENSE](LICENSE).

## Identité et ressources externes

Le logo Echo, la signature MrJ.am, leurs dessins et leurs déclinaisons sont
exclus de cette concession de licence et restent d’utilisation strictement
réservée. Cette licence ne donne aucun droit d’usage des signes d’identité.
Pour diffuser une variante sans autorisation de leur titulaire, remplacez
ces éléments par votre propre identité.

La fonte Parisienne et les fontes dérivées conservent leur licence SIL Open
Font License 1.1, fournie dans
[Parisienne-OFL.txt](interface/identite/Parisienne-OFL.txt). Les droits sur les
fontes n’étendent pas les droits d’usage des signes d’identité qu’elles dessinent.

Les dépendances et ressources externes conservent leurs licences et avis propres.
La licence de Vision ne modifie pas celle des dépôts externes, notamment
`MrJ-am/style-mrjam` et `MrJ-am/Signature`.
