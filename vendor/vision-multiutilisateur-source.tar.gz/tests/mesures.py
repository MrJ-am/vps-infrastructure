#!/usr/bin/env python3
"""Mesures bornées dans PostgreSQL isolé ; aucun jeu fictif en production."""
import importlib.util,json,time
from pathlib import Path
s=importlib.util.spec_from_file_location('migration',Path(__file__).resolve().parents[1]/'scripts/refonte.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
mesures=[]
for fiches,items in [(5,40),(500,4000),(5000,10000)]:
 u='mesure_'+str(fiches)
 m.sql("""INSERT INTO vision_profils(utilisateur) VALUES (:'u');
 -- Allocation exceptionnelle du benchmark, jamais les limites d'un compte public.
 UPDATE vision_gestion.comptes SET quota_octets=1000000000,
   limites=jsonb_set(limites,'{fiches}','10000') WHERE utilisateur=:'u';
 INSERT INTO vision_fiches(utilisateur,titre,contenu) SELECT :'u','Fiche '||g,'Contenu.' FROM generate_series(1,:'fiches'::int) g;
 INSERT INTO vision_items(utilisateur,titre,contenu,objectifs,sens,reference_a,origine_reference)
 SELECT :'u','Connaissance '||g,'Référence disciplinaire '||g,ARRAY['Expliquer'],ARRAY['direct'],now()-interval '30 days','declaree' FROM generate_series(1,:'items'::int) g;
 WITH f AS (SELECT id,row_number() OVER(ORDER BY id)-1 n FROM vision_fiches WHERE utilisateur=:'u'),
 i AS (SELECT id,row_number() OVER(ORDER BY id)-1 n FROM vision_items WHERE utilisateur=:'u')
 INSERT INTO vision_liens(utilisateur,fiche_id,item_id)
 SELECT :'u',f.id,i.id FROM i JOIN f ON f.n IN(i.n%:'fiches'::int,(i.n+1)%:'fiches'::int,(i.n+2)%:'fiches'::int);
 ANALYZE vision_items; ANALYZE vision_liens; ANALYZE vision_fiches;
 SELECT '{}'::jsonb;""",dict(u=u,fiches=str(fiches),items=str(items)))
 debut=time.perf_counter();r=m.sql("SELECT vision_preparer(:'u','{\"limite\":8}'::jsonb)",dict(u=u));duree=(time.perf_counter()-debut)*1000
 plan=m.sql("EXPLAIN (ANALYZE,FORMAT JSON) SELECT * FROM vision_candidats(:'u') ORDER BY urgence DESC LIMIT 20",dict(u=u))
 recherche=m.sql("EXPLAIN (ANALYZE,FORMAT JSON) SELECT id FROM vision_items WHERE utilisateur=:'u' AND texte_recherche @@ websearch_to_tsquery('french','connaissance 499')",dict(u=u))
 mesures.append(dict(fiches=fiches,items_distincts=items,liens=items*3,suggestions_ms=round(duree,2),octets_reponse=len(json.dumps(r).encode()),plan_selection=plan,plan_recherche=recherche))
print(json.dumps(mesures,ensure_ascii=False,indent=2))
