"""Isolation et allocations réelles, avec les rôles HTTP non propriétaires."""
import hashlib
import json
import os
import threading
import unittest
import uuid

import psycopg

DSN = dict(host=os.environ.get('PGHOST','127.0.0.1'),
           dbname=os.environ.get('PGDATABASE','vision'),
           password=os.environ.get('PGPASSWORD',''))

class Comptes(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.root = psycopg.connect(**DSN, user='postgres', autocommit=True)
        for role in ('vision','vision_administration','vision_identite','vision_cycle','vision_admission','vision_fermeture'):
            # Secrets exclusivement synthétiques dans le cluster de test.
            cls.root.execute(psycopg.sql.SQL('ALTER ROLE {} PASSWORD {}').format(psycopg.sql.Identifier(role),
                             psycopg.sql.Literal('test-local-'+role)))
        cls.acteur = 'test-admin-'+uuid.uuid4().hex[:12]
        cls.root.execute('INSERT INTO vision_gestion.comptes(utilisateur,affichage,administrateur) VALUES(%s,%s,true)',
                         (cls.acteur,cls.acteur))
        cls.root.execute("UPDATE vision_gestion.configuration SET inscriptions_ouvertes=true,responsable='Test',contact='test@example.test',pays_hebergement='France',notice_version='test',budget_octets=100000000000")

    def connexion(self, role='vision', u=None):
        db=psycopg.connect(**{**DSN,'password':'test-local-'+role}, user=role)
        if u: db.execute("SELECT set_config('vision.utilisateur',%s,true)",(u,))
        return db

    def test_fermeture_commune_aveugle_et_identite_exacte(self):
        u=self.compte();tiers=self.compte();sujet=str(uuid.uuid4())
        self.root.execute("INSERT INTO vision_gestion.identites VALUES('https://compte.example.test',%s,%s)",(sujet,u))
        self.root.execute("INSERT INTO vision_gestion.identites VALUES('https://autre.example.test',%s,%s)",(sujet,tiers))
        with self.connexion(u=u) as db:
            db.execute("INSERT INTO vision_fiches(utilisateur,titre,contenu) VALUES(%s,'Privé','Aucun contenu à lire')",(u,))
        with self.connexion('vision_fermeture') as db:
            for table in ('public.vision_fiches','public.vision_items','vision_gestion.identites','vision_gestion.admissions'):
                with self.assertRaises(psycopg.errors.InsufficientPrivilege):
                    with db.transaction():db.execute('SELECT * FROM '+table)
            self.assertEqual(db.execute("SELECT vision_gestion.comptes_identite('https://compte.example.test',%s)",(sujet,)).fetchone()[0],[u])
            self.assertEqual(db.execute("SELECT vision_gestion.engager_fermeture_identite('https://compte.example.test',%s,'FERMER MON COMPTE')",(sujet,)).fetchone()[0],[u])
            with self.assertRaisesRegex(psycopg.errors.RaiseException,'confirmation_requise'):
                with db.transaction():db.execute("SELECT vision_gestion.effacer_identite_cycle('https://compte.example.test',%s,'oui')",(sujet,))
            for _ in range(2):
                self.assertTrue(db.execute("SELECT vision_gestion.effacer_identite_cycle('https://compte.example.test',%s,'FERMER MON COMPTE')",(sujet,)).fetchone()[0]['efface'])
        self.assertIsNone(self.root.execute('SELECT utilisateur FROM vision_gestion.comptes WHERE utilisateur=%s',(u,)).fetchone())
        self.assertIsNotNone(self.root.execute('SELECT utilisateur FROM vision_gestion.comptes WHERE utilisateur=%s',(tiers,)).fetchone())
        with self.connexion('vision_admission') as db:
            for sql,p in [("SELECT vision_gestion.activer('https://compte.example.test',%s,'x','test','Test')",(sujet,)),
                          ("SELECT vision_gestion.certifier_admission(%s,'https://compte.example.test',%s,'test')",(str(uuid.uuid4()),sujet))]:
                with self.assertRaisesRegex(psycopg.errors.RaiseException,'identite_fermee'):
                    with db.transaction():db.execute(sql,p)

    def compte(self, quota=10000000):
        u='test-'+uuid.uuid4().hex
        self.root.execute('INSERT INTO vision_gestion.comptes(utilisateur,affichage,quota_octets) VALUES(%s,%s,%s)',(u,u,quota))
        with self.connexion(u=u) as db:
            db.execute('INSERT INTO vision_profils(utilisateur) VALUES(%s)',(u,))
        return u

    def admin(self, op, p):
        with self.connexion('vision_administration') as db:
            return db.execute('SELECT vision_gestion.administrer(%s,%s,%s)',
                              (self.__class__.acteur,op,json.dumps(p))).fetchone()[0]

    def autoriser(self, sujet, condensat):
        identifiant=str(uuid.uuid4())
        with self.connexion('vision_admission') as db:
            db.execute("SELECT vision_gestion.reserver_admission(%s,%s,'test')",(identifiant,condensat))
            db.execute("SELECT vision_gestion.certifier_admission(%s,'https://compte.example.test',%s,'test')",(identifiant,sujet))
        return identifiant

    def test_admin_aucun_contenu_et_aucun_changement_identite(self):
        with self.connexion('vision_administration') as db:
            for table in ('vision_fiches','vision_items','vision_observations','vision_embeddings',
                          'vision_recherches','vision_journal','vision_migrations_metier','vision_memory_sheets'):
                with db.transaction():
                    with self.assertRaises(psycopg.errors.InsufficientPrivilege):
                        with db.transaction(): db.execute(psycopg.sql.SQL('SELECT * FROM public.{}').format(psycopg.sql.Identifier(table)))
            for sql in ("SELECT vision_gestion.identifier('x','y')", "UPDATE vision_gestion.identites SET sujet='vol'",
                        'SET ROLE vision_migration','ALTER ROLE vision SUPERUSER'):
                with self.assertRaises(psycopg.errors.InsufficientPrivilege):
                    with db.transaction(): db.execute(sql)
        result=self.admin('lister_comptes',{})
        self.assertTrue(result['comptes'])
        self.assertFalse({'titre','contenu','suivi','representation'} & set(result['comptes'][0]))

    def test_preavis_delai_envoi_annulation_et_effacement_aveugle(self):
        u=self.compte()
        self.root.execute("INSERT INTO vision_gestion.identites VALUES('https://compte.example.test',%s,%s)",(str(uuid.uuid4()),u))
        with self.connexion(u=u) as db:
            db.execute("INSERT INTO vision_fiches(utilisateur,titre,contenu) VALUES(%s,'Privé','Contenu invisible à la gestion')",(u,))
        c=self.root.execute('SELECT version FROM vision_gestion.comptes WHERE utilisateur=%s',(u,)).fetchone()[0]
        demande=self.admin('demander_suppression',dict(utilisateur=u,version=c))
        id=demande['suppression']['id']
        self.assertIsNone(demande['suppression']['echeance_a'])
        with self.connexion('vision_administration') as db:
            with self.assertRaises(psycopg.errors.InsufficientPrivilege):
                with db.transaction(): db.execute("SELECT vision_gestion.constater_preavis(%s,'accepte_relais')",(id,))
        with self.connexion('vision_cycle') as db:
            for table in ('public.vision_fiches','vision_gestion.identites','vision_gestion.preavis'):
                with self.assertRaises(psycopg.errors.InsufficientPrivilege):
                    with db.transaction(): db.execute('SELECT * FROM '+table)
            db.execute("SELECT vision_gestion.constater_preavis(%s,'erreur')",(id,))
            self.assertFalse(db.execute('SELECT vision_gestion.engager_effacement(%s,%s)',(u,id)).fetchone()[0])
            db.execute("SELECT vision_gestion.constater_preavis(%s,'accepte_relais')",(id,))
            self.assertFalse(db.execute('SELECT vision_gestion.engager_effacement(%s,%s)',(u,id)).fetchone()[0])
            with self.assertRaisesRegex(psycopg.errors.RaiseException,'preavis_non_exigible'):
                with db.transaction(): db.execute("SELECT vision_gestion.effacer_cycle(%s,'EFFACER VISION',%s)",(u,id))
        c=self.root.execute('SELECT version FROM vision_gestion.comptes WHERE utilisateur=%s',(u,)).fetchone()[0]
        with self.assertRaisesRegex(psycopg.errors.RaiseException,'export_a_preserver'):
            self.admin('modifier_compte',dict(utilisateur=u,version=c,actif=False))
        with self.connexion(u=u) as db:
            self.assertEqual(len(db.execute("SELECT vision_gestion.exporter(%s,'vision_fiches',0,NULL)",(u,)).fetchone()[0]['lignes']),1)
        annulation=self.admin('annuler_suppression',dict(utilisateur=u,version=c))
        self.assertIsNotNone(annulation['suppression']['annule_a'])
        with self.connexion('vision_cycle') as db:
            self.assertFalse(db.execute('SELECT vision_gestion.engager_effacement(%s,%s)',(u,id)).fetchone()[0])
        demande=self.admin('demander_suppression',dict(utilisateur=u,version=annulation['version']))
        id=demande['suppression']['id']
        with self.connexion('vision_cycle') as db: db.execute("SELECT vision_gestion.constater_preavis(%s,'accepte_relais')",(id,))
        self.root.execute("UPDATE vision_gestion.preavis SET envoye_a=now()-interval '31 days',echeance_a=now()-interval '1 day' WHERE id=%s",(id,))
        with self.connexion('vision_cycle') as db:
            self.assertTrue(db.execute('SELECT vision_gestion.engager_effacement(%s,%s)',(u,id)).fetchone()[0])
        c=self.root.execute('SELECT version FROM vision_gestion.comptes WHERE utilisateur=%s',(u,)).fetchone()[0]
        with self.assertRaisesRegex(psycopg.errors.RaiseException,'effacement_engage'):
            self.admin('annuler_suppression',dict(utilisateur=u,version=c))
        with self.connexion('vision_cycle') as db:
            self.assertTrue(db.execute("SELECT vision_gestion.effacer_cycle(%s,'EFFACER VISION',%s)",(u,id)).fetchone()[0]['efface'])
        self.assertEqual(self.root.execute('SELECT count(*) FROM vision_fiches WHERE utilisateur=%s',(u,)).fetchone()[0],0)

    def test_rls_et_creation_non_invitee(self):
        a=self.compte(); b=self.compte()
        with self.connexion(u=a) as db:
            db.execute("INSERT INTO vision_fiches(utilisateur,titre,contenu) VALUES(%s,'Secret','privé')",(a,))
        with self.connexion(u=b) as db:
            self.assertEqual(db.execute('SELECT count(*) FROM vision_fiches WHERE utilisateur=%s',(a,)).fetchone()[0],0)
            with self.assertRaises(psycopg.errors.InsufficientPrivilege):
                with db.transaction(): db.execute("INSERT INTO vision_fiches(utilisateur,titre) VALUES(%s,'Vol')",(a,))
        inconnu='inconnu-'+uuid.uuid4().hex
        with self.connexion(u=inconnu) as db:
            with self.assertRaisesRegex(psycopg.errors.RaiseException,'invitation_requise'):
                with db.transaction(): db.execute('INSERT INTO vision_profils(utilisateur) VALUES(%s)',(inconnu,))

    def test_comptage_unicode_historique_rollback_et_limites(self):
        u=self.compte()
        with self.connexion(u=u) as db:
            id=db.execute("INSERT INTO vision_fiches(utilisateur,titre,contenu) VALUES(%s,'École','été') RETURNING id",(u,)).fetchone()[0]
            usage=db.execute('SELECT vision_gestion.usage(%s)',(u,)).fetchone()[0]
            self.assertEqual(usage['fiches'],1)
            before=usage['utilise_octets']
            with self.assertRaisesRegex(psycopg.errors.RaiseException,'texte_trop_long'):
                with db.transaction():
                    db.execute('UPDATE vision_fiches SET contenu=%s WHERE id=%s',('été '*2001,id))
            self.assertEqual(db.execute('SELECT vision_gestion.usage(%s)',(u,)).fetchone()[0]['utilise_octets'],before)
            db.execute('INSERT INTO vision_observations(utilisateur,fiche_id,texte,source) VALUES(%s,%s,%s,%s)',(u,id,'note','explicite'))
        expected=0
        for (table,) in self.root.execute("SELECT table_name FROM information_schema.columns WHERE table_schema='public' AND column_name='utilisateur' AND table_name LIKE 'vision_%'"):
            expected+=self.root.execute(psycopg.sql.SQL('SELECT coalesce(sum(vision_gestion.poids_ligne(to_jsonb(t))),0) FROM {} t WHERE utilisateur=%s').format(psycopg.sql.Identifier(table)),(u,)).fetchone()[0]
        self.assertEqual(expected,self.root.execute('SELECT utilise_octets FROM vision_gestion.comptes WHERE utilisateur=%s',(u,)).fetchone()[0])
        self.root.execute('UPDATE vision_gestion.comptes SET quota_octets=1 WHERE utilisateur=%s',(u,))
        with self.connexion(u=u) as db:
            self.assertTrue(db.execute('SELECT vision_gestion.usage(%s)',(u,)).fetchone()[0]['depassement'])
            with self.assertRaisesRegex(psycopg.errors.RaiseException,'quota_depasse'):
                with db.transaction(): db.execute("INSERT INTO vision_fiches(utilisateur,titre,contenu) VALUES(%s,'Trop','texte')",(u,))
            db.execute('DELETE FROM vision_observations WHERE false')
            # Une lecture reste possible au-dessus du quota.
            self.assertEqual(db.execute('SELECT contenu FROM vision_fiches WHERE id=%s',(id,)).fetchone()[0],'été')

    def test_invitation_unicite_retroactivite_et_revocation(self):
        secret=uuid.uuid4().hex+uuid.uuid4().hex
        digest=hashlib.sha256(secret.encode()).hexdigest()
        i=self.admin('creer_invitation',dict(condensat=digest,intitule='Instagram',maximum=2,
                    quota_octets=15000000,expire_a='2027-01-01T00:00:00Z'))
        self.assertNotIn('condensat',i)
        subject=str(uuid.uuid4())
        self.autoriser(subject,digest)
        with self.connexion('vision_identite') as db:
            c=db.execute("SELECT vision_gestion.activer('https://compte.example.test',%s,%s,'test')",(subject,digest)).fetchone()[0]
            c2=db.execute("SELECT vision_gestion.activer('https://compte.example.test',%s,%s,'test')",(subject,digest)).fetchone()[0]
            self.assertEqual(c['utilisateur'],c2['utilisateur'])
        current=next(x for x in self.admin('lister_invitations',{})['invitations'] if x['id']==i['id'])
        self.assertEqual(current['utilise'],1)
        change=self.admin('modifier_invitation',dict(id=i['id'],version=current['version'],maximum=30,
                          quota_octets=10000000,retroactif=True))
        self.assertEqual(change['maximum'],30)
        self.assertEqual(self.root.execute('SELECT quota_octets FROM vision_gestion.comptes WHERE utilisateur=%s',(c['utilisateur'],)).fetchone()[0],10000000)
        with self.assertRaisesRegex(psycopg.errors.RaiseException,'administration_interdite'):
            with self.connexion('vision_administration') as db:
                db.execute("SELECT vision_gestion.administrer(%s,'lister_comptes','{}')",(c['utilisateur'],))
        self.admin('modifier_invitation',dict(id=i['id'],version=change['version'],revoquer=True))
        with self.connexion('vision_identite') as db:
            with self.assertRaisesRegex(psycopg.errors.RaiseException,'admission_requise'):
                with db.transaction(): db.execute("SELECT vision_gestion.activer('https://compte.example.test',%s,%s,'test')",(str(uuid.uuid4()),digest))

    def simultanes(self, actions):
        barriere=threading.Barrier(len(actions));resultats=[];verrou=threading.Lock()
        def executer(action):
            barriere.wait(timeout=10)
            try: action();resultat='ok'
            except psycopg.errors.RaiseException as erreur:resultat=erreur.diag.message_primary
            with verrou:resultats.append(resultat)
        fils=[threading.Thread(target=executer,args=(action,)) for action in actions]
        for fil in fils:fil.start()
        for fil in fils:fil.join(timeout=15)
        self.assertFalse(any(fil.is_alive() for fil in fils),'Transaction bloquée')
        self.assertEqual(len(resultats),len(actions))
        return sorted(resultats)

    def test_quota_concurrent_une_seule_ecriture(self):
        u=self.compte()
        # Mesurer le coût exact d'une ligne synthétique puis ne réserver qu'une
        # place. Deux transactions réelles tentent de la consommer simultanément.
        with self.connexion(u=u) as db:
            avant=db.execute('SELECT vision_gestion.usage(%s)',(u,)).fetchone()[0]['utilise_octets']
            identifiant=db.execute("INSERT INTO vision_fiches(utilisateur,titre,contenu) VALUES(%s,'A','texte') RETURNING id",(u,)).fetchone()[0]
            cout=db.execute('SELECT vision_gestion.usage(%s)',(u,)).fetchone()[0]['utilise_octets']-avant
            db.execute('DELETE FROM vision_fiches WHERE id=%s',(identifiant,))
        self.root.execute('UPDATE vision_gestion.comptes SET quota_octets=utilise_octets+%s+64 WHERE utilisateur=%s',(cout,u))
        def ajouter():
            with self.connexion(u=u) as db:
                db.execute("INSERT INTO vision_fiches(utilisateur,titre,contenu) VALUES(%s,'A','texte')",(u,))
        self.assertEqual(self.simultanes([ajouter,ajouter]),['ok','quota_depasse'])
        with self.connexion(u=u) as db:
            usage=db.execute('SELECT vision_gestion.usage(%s)',(u,)).fetchone()[0]
            self.assertEqual(usage['fiches'],1)
            self.assertLessEqual(usage['utilise_octets'],usage['quota_octets'])

    def test_derniere_place_invitation_concurrente(self):
        digest=hashlib.sha256(uuid.uuid4().bytes).hexdigest()
        invitation=self.admin('creer_invitation',dict(condensat=digest,intitule='Une place',maximum=1,expire_a='2027-01-01T00:00:00Z'))
        def activer():
            sujet=str(uuid.uuid4())
            self.autoriser(sujet,digest)
            with self.connexion('vision_identite') as db:
                db.execute("SELECT vision_gestion.activer('https://compte.example.test',%s,%s,'test')",(sujet,digest))
        self.assertEqual(self.simultanes([activer,activer]),['invitation_indisponible','ok'])
        self.assertEqual(self.root.execute('SELECT utilise FROM vision_gestion.invitations WHERE id=%s',(invitation['id'],)).fetchone()[0],1)

    def test_admission_obligatoire_reservation_et_aucun_pouvoir_admin(self):
        digest=hashlib.sha256(uuid.uuid4().bytes).hexdigest()
        i=self.admin('creer_invitation',dict(condensat=digest,intitule='Contrôle parental',maximum=1,expire_a='2027-01-01T00:00:00Z'))
        sujet=str(uuid.uuid4());demande=str(uuid.uuid4())
        with self.connexion('vision_identite') as db:
            with self.assertRaisesRegex(psycopg.errors.RaiseException,'admission_requise'):
                with db.transaction(): db.execute("SELECT vision_gestion.activer('https://compte.example.test',%s,%s,'test')",(sujet,digest))
        with self.connexion('vision_admission') as db:
            db.execute("SELECT vision_gestion.reserver_admission(%s,%s,'test')",(demande,digest))
            with self.assertRaisesRegex(psycopg.errors.RaiseException,'invitation_indisponible'):
                with db.transaction(): db.execute("SELECT vision_gestion.reserver_admission(%s,%s,'test')",(str(uuid.uuid4()),digest))
            with self.assertRaises(psycopg.errors.InsufficientPrivilege):
                with db.transaction(): db.execute('SELECT titre FROM public.vision_fiches')
            db.execute("SELECT vision_gestion.certifier_admission(%s,'https://compte.example.test',%s,'test')",(demande,sujet))
            with self.assertRaisesRegex(psycopg.errors.RaiseException,'identite_incompatible'):
                with db.transaction(): db.execute("SELECT vision_gestion.certifier_admission(%s,'https://compte.example.test',%s,'test')",(demande,str(uuid.uuid4())))
        for role in ('vision','vision_administration','vision_identite'):
            with self.connexion(role) as db:
                with self.assertRaises(psycopg.errors.InsufficientPrivilege):
                    with db.transaction(): db.execute("SELECT vision_gestion.certifier_admission(%s,'x','y','test')",(demande,))
                with self.assertRaises(psycopg.errors.InsufficientPrivilege):
                    with db.transaction(): db.execute("SELECT vision_gestion.activer_allocation('x','y',%s,'test',NULL)",(digest,))
        current=next(x for x in self.admin('lister_invitations',{})['invitations'] if x['id']==i['id'])
        self.assertEqual(current['en_attente'],1)
        with self.connexion('vision_identite') as db:
            c=db.execute("SELECT vision_gestion.activer('https://compte.example.test',%s,%s,'test')",(sujet,digest)).fetchone()[0]
            self.assertFalse(c['administrateur'])
        current=next(x for x in self.admin('lister_invitations',{})['invitations'] if x['id']==i['id'])
        self.assertEqual((current['en_attente'],current['utilise']),(0,1))

    def test_export_coherent_et_effacement_observations(self):
        u=self.compte();tiers=self.compte()
        with self.connexion(u=u) as db:
            fiche=db.execute("INSERT INTO vision_fiches(utilisateur,titre,contenu) VALUES(%s,'Privé','texte à exporter') RETURNING id",(u,)).fetchone()[0]
            db.execute("INSERT INTO vision_observations(utilisateur,fiche_id,texte,source) VALUES(%s,%s,'note immuable','explicite')",(u,fiche))
            export=db.execute("SELECT vision_gestion.exporter(%s,'vision_fiches',0,NULL)",(u,)).fetchone()[0]
            self.assertEqual(export['lignes'][0]['contenu'],'texte à exporter')
            with self.assertRaisesRegex(psycopg.errors.RaiseException,'identite_invalide'):
                with db.transaction():db.execute("SELECT vision_gestion.exporter(%s,'vision_fiches',0,NULL)",(tiers,))
            db.execute("UPDATE vision_fiches SET contenu='texte modifié' WHERE id=%s",(fiche,))
            with self.assertRaisesRegex(psycopg.errors.RaiseException,'export_modifie'):
                with db.transaction():db.execute("SELECT vision_gestion.exporter(%s,'vision_fiches',0,%s)",(u,export['donnees_version']))
            # Positionner soi-même le drapeau ne contourne pas l'immuabilité.
            db.execute("SELECT set_config('vision.effacement',%s,true)",(u,))
            with self.assertRaisesRegex(psycopg.errors.RaiseException,'observation_immuable'):
                with db.transaction():db.execute('DELETE FROM vision_observations WHERE utilisateur=%s',(u,))
            with self.assertRaisesRegex(psycopg.errors.RaiseException,'confirmation_requise'):
                with db.transaction():db.execute("SELECT vision_gestion.effacer(%s,'oui')",(u,))
            self.assertTrue(db.execute("SELECT vision_gestion.effacer(%s,'EFFACER VISION')",(u,)).fetchone()[0]['efface'])
        for (table,) in self.root.execute("SELECT table_name FROM information_schema.columns WHERE table_schema='public' AND column_name='utilisateur' AND table_name LIKE 'vision_%'"):
            self.assertEqual(self.root.execute(psycopg.sql.SQL('SELECT count(*) FROM {} WHERE utilisateur=%s').format(psycopg.sql.Identifier(table)),(u,)).fetchone()[0],0,table)
        self.assertIsNone(self.root.execute('SELECT utilisateur FROM vision_gestion.comptes WHERE utilisateur=%s',(u,)).fetchone())
        self.assertIsNotNone(self.root.execute('SELECT utilisateur FROM vision_gestion.effacements WHERE utilisateur=%s',(u,)).fetchone())
        self.assertIsNotNone(self.root.execute('SELECT utilisateur FROM vision_gestion.comptes WHERE utilisateur=%s',(tiers,)).fetchone())

if __name__=='__main__': unittest.main()
