#!/usr/bin/env python3
"""Le contrôle rejette une installation du connecteur restée sur Vision 1."""
import json
import unittest
from check_client_catalog import ATTENDUS, verifier


class CatalogueClient(unittest.TestCase):
    def test_contrat_actuel(self):
        verifier({'tools': ATTENDUS})

    def test_anciens_noms_refuses_meme_si_le_serveur_est_a_jour(self):
        avec_anciens = [dict(outil) for outil in ATTENDUS]
        avec_anciens[0]['name'] = 'search_memory_sheets'
        with self.assertRaisesRegex(AssertionError, 'Catalogue client périmé'):
            verifier({'tools': avec_anciens})

    def test_schema_perime_refuse(self):
        schema_perime = json.loads(json.dumps(ATTENDUS))
        next(o for o in schema_perime if o['name']=='rechercher')['inputSchema']['properties'].pop('preparer_creation')
        with self.assertRaisesRegex(AssertionError, 'inputSchema diffère'):
            verifier({'tools': schema_perime})


if __name__ == '__main__':
    unittest.main()
