"""Routes publiques du véritable serveur Lisp, avec la cohérence PostgreSQL vérifiée au démarrage."""
import os
import json
from pathlib import Path
import socket
import subprocess
import tempfile
import time
from urllib.error import HTTPError
from urllib.request import Request, urlopen

RACINE = Path(__file__).resolve().parents[1]


def verifier():
    with socket.socket() as adresse:
        adresse.bind(('127.0.0.1', 0))
        port = adresse.getsockname()[1]
    with tempfile.TemporaryFile() as journal:
        serveur = subprocess.Popen([str(RACINE / 'vision')], cwd=RACINE,
            env={**os.environ, 'IP': '127.0.0.1', 'PORT': str(port),
                 'VISION_DOCUMENT_ROOT': str(RACINE / 'docs'),
                 'VISION_PUBLIC_MCP_URL': 'https://assistant.exemple.test/apprendre/outils/mcp',
                 'VISION_MCP_PATH': '/outils/mcp',
                 'VISION_PUBLIC_WEB_URL': 'https://cours.exemple.test/vision'}, stdout=journal, stderr=journal)
        try:
            base = f'http://127.0.0.1:{port}'
            for _ in range(50):
                try:
                    with urlopen(base + '/healthz', timeout=1): break
                except OSError:
                    if serveur.poll() is not None: raise RuntimeError('Serveur arrêté')
                    time.sleep(.1)
            for chemin in ['/', '/docs', '/docs/', '/privacy', '/connexion']:
                with urlopen(base + chemin, timeout=2) as reponse:
                    contenu = reponse.read()
                    assert reponse.status == 200 and b'id="application"' in contenu, chemin
                    assert contenu == (RACINE / 'interface/app.html').read_bytes(), chemin
                    assert "base-uri 'none'" in reponse.headers['Content-Security-Policy']
                    assert b'<base ' not in contenu
            for entetes in [{}, {'Host':'attaque.test', 'Forwarded':'proto=https;host=attaque.test', 'X-Forwarded-Host':'attaque.test'}]:
                with urlopen(Request(base+'/mcp-config.json', headers=entetes), timeout=2) as reponse:
                    assert reponse.status == 200
                    configuration = json.loads(reponse.read())
                    assert configuration == dict(url_mcp='https://assistant.exemple.test/apprendre/outils/mcp',
                        gestion_acces='https://cours.exemple.test/vision/auth/mcp'), configuration
                    assert reponse.headers['Cache-Control'] == 'no-store'
            try:
                urlopen(Request(base+'/mcp-config.json',data=b'{}',headers={'Content-Type':'application/json'}),timeout=2)
                raise AssertionError('La configuration publique ne doit accepter qu’une lecture GET.')
            except HTTPError as erreur:
                assert erreur.code == 404
            for chemin in ['/api/fiches', '/mcp']:
                try:
                    urlopen(base + chemin, timeout=2)
                    raise AssertionError('Refus anonyme absent : ' + chemin)
                except HTTPError as erreur:
                    assert erreur.code == 401
        finally:
            serveur.terminate()
            serveur.wait(timeout=5)
    print('Serveur Lisp : cinq routes ElmUI publiques, configuration multi-origines sans confiance aux en-têtes, CSP et refus anonyme vérifiés.')


if __name__ == '__main__':
    verifier()

