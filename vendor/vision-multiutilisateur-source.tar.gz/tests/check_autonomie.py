"""Scénarios HTTP/SQL motivant la mission, exclusivement sur les fixtures de la CI."""
import datetime as dt
import json
import subprocess
import unittest
from check_refonte import appel, fiche, item, lire, requete, identifiant, maintenant


def snapshot(i):
    return {k:v for k,v in lire(i).items() if k!='fenetre'}


def sql(commande):
    return subprocess.check_output(['psql','-XAtq','-v','ON_ERROR_STOP=1','-c',commande], text=True).strip()


class Autonomie(unittest.TestCase):
    def preparer(self, nombre=2, longue=False):
        f = fiche('Mission ' + identifiant()[:8])
        items = [item('Connaissance ' + str(n), reference_a=maintenant(-10)) for n in range(nombre)]
        for i in items:
            f = appel('lier_item',dict(fiche_id=f['id'],item_id=i['id'],version_fiche=f['version'],action='rattacher'),ecriture=True)['fiche']
        s = appel('ouvrir_seance',dict(fiche_id=f['id'],nouvelle_seance=True,nombre_questions=nombre),ecriture=True)
        if longue:
            sql("UPDATE vision_seances SET cree_a=now()-interval '6 days' WHERE id='"+s['seance_id']+"'")
        return f, items, s

    def fermer(self, items, s, **champs):
        p = dict(cle=identifiant(),emise_a=maintenant(),seance_id=s['seance_id'],
            evaluations=[dict(item_id=i['id'],q=0,aide='aucune') for i in items], **champs)
        return p, requete('/api/v1/clore_seance',p)

    def test_contrat_effectif_ouverture_et_reprise(self):
        f,items,s = self.preparer()
        r = appel('lire_seance',dict(seance_id=s['seance_id']))
        self.assertEqual(s['contrat_pedagogique'],r['contrat_pedagogique'])
        self.assertEqual(s['consigne'],s['contrat_pedagogique'])
        self.assertEqual(r['usage_assistant']['fiche']['contenu'],f['contenu'])
        self.assertEqual({i['id'] for i in r['usage_assistant']['items']},{i['id'] for i in items})
        self.assertIn('observations',r['usage_assistant']['items'][0])

    def test_courte_dates_explicites_et_approximation(self):
        f,items,s = self.preparer()
        date = maintenant()
        p,_ = self.fermer([],s)
        # Refaire une séance avec de vrais rappels : la première clôture vide est indépendante.
        s = appel('ouvrir_seance',dict(fiche_id=f['id'],nouvelle_seance=True),ecriture=True)
        p = dict(cle=identifiant(),emise_a=maintenant(),seance_id=s['seance_id'],evaluations=[
            dict(item_id=items[0]['id'],q=0,aide='aucune',evenement_a=maintenant(),provenance='metadata_client'),
            dict(item_id=items[1]['id'],q=0,aide='aucune')])
        r = appel('clore_seance',p)['rapport']
        self.assertTrue(r['datation_seance']['seance_courte'])
        self.assertEqual(r['evaluations'][1]['datation']['provenance'],'approximation_seance_courte')
        self.assertEqual(r['evaluations'][1]['horodatage'],'approximatif')
        self.assertEqual(dt.datetime.fromisoformat(r['evaluations'][0]['evenement_a']),dt.datetime.fromisoformat(p['evaluations'][0]['evenement_a']))

    def test_longue_manques_groupes_et_date_civile(self):
        f,items,s = self.preparer(longue=True)
        avant = [snapshot(i) for i in items]
        p,(code,r) = self.fermer(items,s)
        self.assertEqual(code,400)
        self.assertEqual(r['erreur'],'dates_rappel_manquantes')
        self.assertEqual(set(r['item_ids']),{i['id'] for i in items})
        self.assertEqual([snapshot(i) for i in items],avant)
        date = (dt.datetime.now(dt.timezone.utc)-dt.timedelta(days=3)).date().isoformat()
        p['datations_groupes']=[dict(item_ids=[i['id'] for i in items],date_rappel=date,fuseau='+02:00',provenance='utilisateur')]
        r = appel('clore_seance',p)['rapport']
        for e in r['evaluations']:
            self.assertEqual(e['datation']['precision'],'jour')
            self.assertEqual(dt.datetime.fromisoformat(e['evenement_a']).hour,10)

    def test_longue_accord_et_trace_non_datee(self):
        f,items,s = self.preparer(longue=True)
        p,_ = self.fermer(items,s)
        p['accepter_datation_cloture']=True
        p['evaluations'][0]['date_inconnue']=True
        reference = lire(items[0])['reference_a']
        r = appel('clore_seance',p)['rapport']
        self.assertEqual(lire(items[0])['reference_a'],reference)
        self.assertIsNone(lire(items[0])['evalue_a'])
        self.assertEqual(r['evaluations'][1]['datation']['provenance'],'cloture_acceptee_explicitement')

    def test_dates_refusees_atomiquement_et_questions(self):
        for champ,jours in [('evenement_a',-8),('evenement_a',2),('posee_a',-8),('posee_a',-1)]:
            f,items,s = self.preparer(longue=True)
            avant = [snapshot(i) for i in items]
            p,_ = self.fermer(items,s)
            p['evaluations'][0]['evenement_a']=maintenant(-3)
            p['evaluations'][1]['evenement_a']=maintenant(-2)
            if champ=='evenement_a': p['evaluations'][1][champ]=maintenant(jours)
            else: p['deroulement']=[dict(item_id=items[1]['id'],question='Question ?',etat='tente',posee_a=maintenant(jours))]
            code,r = requete('/api/v1/clore_seance',p)
            self.assertEqual(code,400,r)
            self.assertEqual(r['erreur'],'dates_hors_seance')
            self.assertEqual(r['tentatives'][0]['item_id'],items[1]['id'])
            self.assertEqual([snapshot(i) for i in items],avant)
            self.assertEqual(appel('lire_seance',dict(seance_id=s['seance_id']))['seance']['etat'],'ouverte')

    def test_seuil_exact_et_fuseaux(self):
        f,items,s = self.preparer()
        for minutes,courte in [(59,True),(60,False),(61,False)]:
            expression="SELECT vision_dater_seance(s, '{\"evaluations\":[{\"item_id\":"+str(items[0]['id'])+",\"q\":0}]}',s.cree_a+interval '"+str(minutes)+" minutes',60) FROM vision_seances s WHERE id='"+s['seance_id']+"'"
            r=json.loads(sql(expression))
            self.assertEqual(r.get('seance_courte'),courte)
            if not courte:self.assertEqual(r['erreur'],'dates_rappel_manquantes')
        self.assertEqual(sql("SELECT vision_instant('2026-10-04T23:30:00-02:00')=vision_instant('2026-10-05T01:30:00Z')"),'t')

    def test_aide_trace_rejeu_rectification(self):
        f,items,s = self.preparer(nombre=1)
        i=items[0]
        p,_ = self.fermer([],s)
        s=appel('ouvrir_seance',dict(fiche_id=f['id'],nouvelle_seance=True),ecriture=True)
        p=dict(cle=identifiant(),emise_a=maintenant(),seance_id=s['seance_id'],evaluations=[dict(item_id=i['id'],q=3,aide='aucune',production_initiale='incomplete')],
            deroulement=[dict(item_id=i['id'],question='Définir ?',etat='tente',reponse_initiale='Une partie',erreur_ou_manque='Élément requis absent',aides=['Chercher la relation'],reponse_finale='Sens complet',verification_effective='Lien conceptuel expliqué')])
        r=appel('clore_seance',p)['rapport']
        self.assertEqual(r['evaluations'][0]['q_cumulatif'],0)
        self.assertEqual(r['deroulement'],p['deroulement'])
        avant=snapshot(i);p.update(cle=identifiant(),emise_a=maintenant())
        self.assertTrue(appel('clore_seance',p)['rejeu'])
        self.assertEqual(snapshot(i),avant)
        e=r['evaluations'][0]
        correction=dict(item_id=i['id'],version=avant['version'],episode=e['episode'],version_episode=e['version_episode'],q=-1,aide='indice',sens='définition',evenement_a=e['evenement_a'])
        r2=appel('evaluer_items',dict(evaluations=[correction]),ecriture=True)['evaluations'][0]
        self.assertEqual(r2['evenement_a'],e['evenement_a'])
        self.assertEqual(lire(i)['reference_a'],avant['reference_a'])

    def test_rectification_dates_structurees_sans_ecriture_partielle(self):
        f,items,s = self.preparer(longue=True)
        p,_ = self.fermer(items,s)
        p['accepter_datation_cloture']=True
        r=appel('clore_seance',p)['rapport']
        avant=[snapshot(i) for i in items]
        evaluations=[]
        for i,e,a in zip(items,r['evaluations'],avant):
            evaluations.append(dict(item_id=i['id'],version=a['version'],episode=e['episode'],
                version_episode=e['version_episode'],q=-1,aide='aucune',sens='définition',evenement_a=e['evenement_a']))
        for champs in [dict(evenement_a=maintenant(-8)),dict(date_rappel=(dt.datetime.now(dt.timezone.utc)-dt.timedelta(days=8)).date().isoformat(),fuseau='+02:00',provenance='utilisateur')]:
            evaluations[1].pop('evenement_a',None)
            evaluations[1].pop('date_rappel',None)
            evaluations[1].update(champs)
            code,erreur=requete('/api/v1/evaluer_items',dict(cle=identifiant(),emise_a=maintenant(),evaluations=evaluations))
            self.assertEqual(code,400)
            self.assertEqual(erreur['erreur'],'dates_hors_seance')
            self.assertEqual(erreur['tentatives'][0]['item_id'],items[1]['id'])
            self.assertIn('ouverture_a',erreur['tentatives'][0])
            self.assertEqual([snapshot(i) for i in items],avant)

    def test_trace_ponctuelle_et_rectification_sans_gain_autonome(self):
        i=item('Trace ponctuelle '+identifiant()[:8],reference_a=maintenant(-10))
        trace=dict(reponse_initiale='Réponse partielle.',erreur_ou_manque='Relation manquante.',
            aides=['Relance sémantique.'],reponse_finale='Réponse complétée.',verification_effective='Relation comprise après aide.')
        e=dict(item_id=i['id'],version=i['version'],episode=identifiant(),version_episode=0,
            q=0,aide='indice',sens='relation',production_initiale='incomplete',deroulement=trace)
        r=appel('evaluer_items',dict(evaluations=[e]),ecriture=True)['evaluations'][0]
        self.assertEqual(r['delta_applique'],0)
        self.assertEqual(r['deroulement'],trace)
        avant=snapshot(i)
        gain=dict(e,version=avant['version'],version_episode=r['version_episode'],q=3,aide='aucune')
        gain.pop('production_initiale')
        gain.pop('deroulement')
        code,erreur=requete('/api/v1/evaluer_items',dict(cle=identifiant(),emise_a=maintenant(),evaluations=[gain]))
        self.assertEqual(code,400)
        self.assertEqual(erreur['erreur'],'gain_aide_excessif')
        self.assertEqual(snapshot(i),avant)
        e.update(version=avant['version'],version_episode=r['version_episode'],q=-1,aide='aucune')
        r2=appel('evaluer_items',dict(evaluations=[e]),ecriture=True)['evaluations'][0]
        self.assertEqual(r2['evenement_a'],r['evenement_a'])
        self.assertEqual(r2['aide'],'indice')
        self.assertEqual(lire(i)['reference_a'],avant['reference_a'])
        observations=lire(i)['observations']
        self.assertGreaterEqual(len(observations),2)
        self.assertTrue(all(o['details']['reponse_initiale']==trace['reponse_initiale'] for o in observations))

    def test_politique_partielle_et_versions(self):
        avant=appel('lire_politique',{})['politique']
        p=dict(version=avant['version'],duree_seance_courte_minutes=45)
        r=appel('regler_politique',p,ecriture=True)['politique']
        for k in ['intervalle_jours','budget','questions_typiques']: self.assertEqual(r[k],avant[k])
        self.assertEqual(r['duree_seance_courte_minutes'],45)
        self.assertEqual(requete('/api/v1/regler_politique',dict(cle=identifiant(),emise_a=maintenant(),**p))[0],409)
        appel('regler_politique',dict(version=r['version'],duree_seance_courte_minutes=60),ecriture=True)

    def test_exports_pages_et_acces(self):
        f,items,s = self.preparer(nombre=3)
        for i in items:
            appel('ajouter_observation',dict(objet='item',objet_id=i['id'],texte='Observation factuelle'),ecriture=True)
        p=dict(fiche_id=f['id'],limite=1)
        tous=[];segments=[]
        while p:
            r=appel('etat_fiche',p);tous+=r['items'];segments.append(r['markdown']);p=r['continuation']
        self.assertEqual({i['id'] for i in tous},{i['id'] for i in items})
        self.assertIn(f['contenu'],segments[0])
        self.assertIn('Export partiel',segments[0])
        self.assertTrue(all(i['dernier_rappel_connu'] is None and i['etat_evaluation']=='non_evalue' for i in tous))
        self.assertTrue(all(i['contenu'] in ''.join(segments) for i in items))
        self.assertEqual(requete('/api/v1/etat_fiche',dict(fiche_id=f['id']),'bob')[0],404)
        self.assertEqual(requete('/api/v1/lien_fiche',dict(fiche_id=f['id']),'bob')[0],404)
        self.assertEqual(appel('lien_fiche',dict(fiche_id=f['id']))['url'],'https://exemple.test/vision/#fiche/'+str(f['id']))
        obs=appel('etat_fiche',dict(fiche_id=f['id'],volet='observations_item',item_id=items[0]['id'],limite=1))
        self.assertGreaterEqual(obs['total'],1)
        self.assertEqual(len(obs['observations']),1)
        self.assertIn('etat',appel('bilan_fiches',dict(limite=1))['fiches'][0])

    def test_tutoriel_lecture_sans_ecriture(self):
        avant=appel('lire_politique',{})['politique']
        r=appel('tutoriel',{})
        self.assertGreaterEqual(len(r['sections']),11)
        self.assertEqual(r['connexion']['url_mcp'],'https://exemple.test/vision/mcp')
        guide=appel('tutoriel',dict(section='connexion-gemini'))['section']
        self.assertIn('gemini mcp add --transport http',guide['exemple'])
        self.assertIn('https://exemple.test/vision/mcp',guide['exemple'])
        self.assertNotIn('{{url_mcp}}',guide['exemple'])
        for s in r['sections']:
            self.assertIn('activite',appel('tutoriel',dict(section=s['id']))['section'])
        self.assertEqual(avant,appel('lire_politique',{})['politique'])


if __name__ == '__main__':unittest.main()
