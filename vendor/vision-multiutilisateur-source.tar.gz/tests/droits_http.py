"""Export et effacement HTTP réels avec rôle SQL non propriétaire et fsync."""
import http.client
import json
import os
from pathlib import Path
import socket
import subprocess
import tempfile
import time
import uuid
import psycopg

root=psycopg.connect(host=os.environ['PGHOST'],dbname=os.environ['PGDATABASE'],user='postgres',password=os.environ['PGPASSWORD'],autocommit=True)
u='http-'+uuid.uuid4().hex
root.execute('INSERT INTO vision_gestion.comptes(utilisateur,affichage) VALUES(%s,%s)',(u,u))
root.execute('INSERT INTO vision_profils(utilisateur) VALUES(%s)',(u,))
fiche=root.execute("INSERT INTO vision_fiches(utilisateur,titre,contenu) VALUES(%s,'Titre privé','Texte privé') RETURNING id",(u,)).fetchone()[0]
root.execute("INSERT INTO vision_observations(utilisateur,fiche_id,texte,source) VALUES(%s,%s,'Note immuable','explicite')",(u,fiche))
with tempfile.TemporaryDirectory() as temporaire:
    journal=Path(temporaire)/'effacements.jsonl'
    s=socket.socket();s.bind(('127.0.0.1',0));port=s.getsockname()[1];s.close()
    env={**os.environ,'PGUSER':'vision','PGPASSWORD':'test-local-vision','PORT':str(port),'IP':'127.0.0.1',
         'VISION_REGISTRE_EFFACEMENTS':str(journal),'VISION_DOCUMENT_ROOT':str(Path('docs').resolve())}
    with open(Path(temporaire)/'serveur.log','w') as log:
        serveur=subprocess.Popen(['./vision'],env=env,stdout=log,stderr=log)
    def appeler(op,p,auth=True):
        c=http.client.HTTPConnection('127.0.0.1',port,timeout=5)
        h={'Content-Type':'application/json'}
        if auth:h.update({'X-Mrj-User':u,'X-Vision-Authenticated':'1','X-Vision-Browser':'1'})
        c.request('POST','/api/web/'+op,json.dumps(p),h);r=c.getresponse();data=json.loads(r.read());c.close();return r.status,data
    try:
        for _ in range(50):
            try:status,_=appeler('lire_limites',{});break
            except (ConnectionRefusedError,ConnectionResetError):time.sleep(.1)
        assert status==200
        assert appeler('exporter_compte',{'table':'vision_fiches','debut':0},False)[0]==401
        status,export=appeler('exporter_compte',{'table':'vision_fiches','debut':0})
        assert status==200 and export['lignes'][0]['contenu']=='Texte privé'
        assert appeler('exporter_compte',{'table':'vision_fiches','debut':0,'utilisateur':'tiers'})[0]==400
        assert appeler('effacer_compte',{'confirmation':'oui'})[0]==400
        assert not journal.exists()
        status,reponse=appeler('effacer_compte',{'confirmation':'EFFACER VISION'})
        assert status==200 and reponse['efface']
        assert json.loads(journal.read_text())['utilisateur']==u
        assert journal.stat().st_mode&0o077==0
        assert root.execute('SELECT count(*) FROM vision_observations WHERE utilisateur=%s',(u,)).fetchone()[0]==0
        assert root.execute('SELECT count(*) FROM vision_gestion.comptes WHERE utilisateur=%s',(u,)).fetchone()[0]==0
        print('HTTP non propriétaire : export, refus anonyme, identité du corps refusée, effacement et registre durable réussis.')
    finally:serveur.terminate();serveur.wait(timeout=5)
root.close()
