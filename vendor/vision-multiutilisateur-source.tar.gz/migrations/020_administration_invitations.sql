BEGIN;

-- Ce schéma ne contient jamais de titre, de note ou de contenu pédagogique.
CREATE TABLE vision_gestion.identites (
 emetteur text NOT NULL CHECK (char_length(emetteur) BETWEEN 1 AND 300),
 sujet text NOT NULL CHECK (char_length(sujet) BETWEEN 1 AND 255),
 utilisateur text NOT NULL UNIQUE REFERENCES vision_gestion.comptes,
 PRIMARY KEY(emetteur,sujet)
);
CREATE TABLE vision_gestion.invitations (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 condensat text NOT NULL UNIQUE CHECK (condensat ~ '^[a-f0-9]{64}$'),
 intitule text NOT NULL CHECK (char_length(intitule) BETWEEN 1 AND 100),
 maximum integer NOT NULL CHECK (maximum BETWEEN 1 AND 100000),
 utilise integer NOT NULL DEFAULT 0 CHECK (utilise BETWEEN 0 AND maximum),
 quota_octets bigint NOT NULL CHECK (quota_octets BETWEEN 1 AND 1000000000),
 limites jsonb NOT NULL DEFAULT vision_gestion.limites_defaut(),
 cree_par text REFERENCES vision_gestion.comptes ON DELETE SET NULL,
 cree_a timestamptz NOT NULL DEFAULT now(),
 expire_a timestamptz NOT NULL,
 revoque_a timestamptz,
 version bigint NOT NULL DEFAULT 1
);
ALTER TABLE vision_gestion.comptes ADD COLUMN invitation_id uuid REFERENCES vision_gestion.invitations;
ALTER TABLE vision_gestion.comptes ADD COLUMN notice_version text;
ALTER TABLE vision_gestion.comptes ADD COLUMN notice_lue_a timestamptz;
CREATE TABLE vision_gestion.evenements (
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
 acteur text NOT NULL,
 action text NOT NULL,
 cible text NOT NULL,
 parametres jsonb NOT NULL,
 cree_a timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE vision_gestion.effacements (
 utilisateur text PRIMARY KEY,
 efface_a timestamptz NOT NULL DEFAULT now(),
 -- Registre séparé à rejouer après restauration ; aucun contenu conservé.
 purger_apres timestamptz NOT NULL
);

CREATE FUNCTION vision_gestion.verifier_limites(l jsonb) RETURNS void
LANGUAGE plpgsql IMMUTABLE AS $$
DECLARE k text; n numeric;
BEGIN
 IF jsonb_typeof(l)<>'object' OR (SELECT count(*) FROM jsonb_object_keys(l))<>8 THEN
   RAISE EXCEPTION 'limites_invalides';
 END IF;
 FOR k IN SELECT jsonb_object_keys(vision_gestion.limites_defaut()) LOOP
   IF jsonb_typeof(l->k) IS DISTINCT FROM 'number' THEN RAISE EXCEPTION 'limites_invalides'; END IF;
   n:=(l->>k)::numeric;
   IF n<>trunc(n) OR n<1 OR n>(vision_gestion.limites_defaut()->>k)::numeric*10 THEN
     RAISE EXCEPTION 'limites_invalides';
   END IF;
 END LOOP;
END $$;

CREATE FUNCTION vision_gestion.verifier_budget() RETURNS void
LANGUAGE plpgsql SET search_path=pg_catalog,vision_gestion,pg_temp AS $$
DECLARE budget bigint; reserve numeric;
BEGIN
 SELECT budget_octets INTO STRICT budget FROM configuration WHERE singleton FOR UPDATE;
 SELECT coalesce(sum(greatest(quota_octets,utilise_octets)),0) INTO reserve FROM comptes;
 SELECT reserve+coalesce(sum((maximum-utilise)::numeric*quota_octets),0) INTO reserve
   FROM invitations WHERE revoque_a IS NULL AND expire_a>now();
 IF reserve>budget THEN RAISE EXCEPTION 'budget_insuffisant'; END IF;
END $$;

CREATE FUNCTION vision_gestion.compte_public(c vision_gestion.comptes) RETURNS jsonb
LANGUAGE sql IMMUTABLE AS $$
 SELECT jsonb_build_object('utilisateur',c.utilisateur,'affichage',c.affichage,
   'administrateur',c.administrateur,'actif',c.actif,'quota_octets',c.quota_octets,
   'utilise_octets',c.utilise_octets,'fiches',c.fiches,'items',c.items,
   'fiches_archivees',c.fiches_archivees,'items_archives',c.items_archives,
   'limites',c.limites,'invitation_id',c.invitation_id,'version',c.version,
   'depassement',c.utilise_octets>c.quota_octets)
$$;
CREATE FUNCTION vision_gestion.invitation_publique(i vision_gestion.invitations) RETURNS jsonb
LANGUAGE sql IMMUTABLE AS $$
 SELECT to_jsonb(i)-'condensat'
$$;

CREATE FUNCTION vision_gestion.administrer(acteur text,op text,p jsonb) RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog,vision_gestion,pg_temp AS $$
#variable_conflict use_variable
DECLARE c comptes; i invitations; quota bigint; maximum integer; retro boolean;
  limites jsonb; resultat jsonb; cible text; cfg configuration;
BEGIN
 IF op NOT IN ('lister_comptes','lister_invitations') THEN
   -- Revalider l'acteur après le verrou commun : une révocation concurrente
   -- déjà acquise ne doit pas autoriser une mutation en attente.
   SELECT * INTO STRICT cfg FROM configuration WHERE singleton FOR UPDATE;
 END IF;
 -- L'acteur provient de la session vérifiée, jamais du corps HTTP.
 SELECT * INTO c FROM comptes WHERE utilisateur=acteur;
 IF NOT FOUND OR NOT c.actif OR NOT c.administrateur THEN RAISE EXCEPTION 'administration_interdite'; END IF;
 IF op='lister_comptes' THEN
   RETURN jsonb_build_object('comptes',coalesce((SELECT jsonb_agg(compte_public(ligne) ORDER BY ligne.affichage,ligne.utilisateur)
     FROM (SELECT * FROM comptes ORDER BY affichage,utilisateur LIMIT 100 OFFSET greatest(0,coalesce((p->>'debut')::integer,0))) ligne),'[]'::jsonb),
     'total',(SELECT count(*) FROM comptes));
 ELSIF op='lister_invitations' THEN
   RETURN jsonb_build_object('invitations',coalesce((SELECT jsonb_agg(invitation_publique(ligne) ORDER BY ligne.cree_a DESC)
     FROM (SELECT * FROM invitations ORDER BY cree_a DESC LIMIT 100 OFFSET greatest(0,coalesce((p->>'debut')::integer,0))) ligne),'[]'::jsonb),
     'total',(SELECT count(*) FROM invitations));
 END IF;
 -- Sérialiser les allocations et les promotions ; même ordre de verrous dans
 -- l'activation. Les écritures métier n'ont aucun accès à cette configuration.
 IF op='modifier_compte' THEN
   cible:=p->>'utilisateur';
   SELECT * INTO c FROM comptes WHERE utilisateur=cible FOR UPDATE;
   IF NOT FOUND THEN RAISE EXCEPTION 'compte_introuvable'; END IF;
   IF c.version IS DISTINCT FROM (p->>'version')::bigint THEN RAISE EXCEPTION 'conflit'; END IF;
   IF c.administrateur AND (coalesce((p->>'administrateur')::boolean,c.administrateur)=false
       OR coalesce((p->>'actif')::boolean,c.actif)=false)
       AND (SELECT count(*) FROM comptes WHERE actif AND administrateur)<=1 THEN
     RAISE EXCEPTION 'dernier_administrateur';
   END IF;
   limites:=coalesce(p->'limites',c.limites); PERFORM verifier_limites(limites);
   UPDATE comptes SET administrateur=coalesce((p->>'administrateur')::boolean,administrateur),
     actif=coalesce((p->>'actif')::boolean,actif), quota_octets=coalesce((p->>'quota_octets')::bigint,quota_octets),
     limites=limites,version=version+1,modifie_a=now() WHERE utilisateur=cible RETURNING * INTO c;
   resultat:=compte_public(c);
 ELSIF op='creer_invitation' THEN
   limites:=coalesce(p->'limites',vision_gestion.limites_defaut()); PERFORM verifier_limites(limites);
   INSERT INTO invitations(condensat,intitule,maximum,quota_octets,limites,cree_par,expire_a)
     VALUES(p->>'condensat',p->>'intitule',(p->>'maximum')::integer,
       coalesce((p->>'quota_octets')::bigint,10000000),limites,acteur,(p->>'expire_a')::timestamptz)
     RETURNING * INTO i;
   IF i.expire_a<=now() OR i.expire_a>now()+interval '365 days' THEN RAISE EXCEPTION 'expiration_invalide'; END IF;
   cible:=i.id::text; resultat:=invitation_publique(i);
 ELSIF op='modifier_invitation' THEN
   SELECT * INTO i FROM invitations WHERE id=(p->>'id')::uuid FOR UPDATE;
   IF NOT FOUND THEN RAISE EXCEPTION 'invitation_introuvable'; END IF;
   IF i.version IS DISTINCT FROM (p->>'version')::bigint THEN RAISE EXCEPTION 'conflit'; END IF;
   maximum:=coalesce((p->>'maximum')::integer,i.maximum);
   IF maximum<i.utilise THEN RAISE EXCEPTION 'maximum_inferieur_aux_inscriptions'; END IF;
   quota:=coalesce((p->>'quota_octets')::bigint,i.quota_octets);
   limites:=coalesce(p->'limites',i.limites); PERFORM verifier_limites(limites);
   retro:=coalesce((p->>'retroactif')::boolean,false);
   UPDATE invitations SET maximum=maximum,quota_octets=quota,limites=limites,
     intitule=coalesce(p->>'intitule',intitule),expire_a=coalesce((p->>'expire_a')::timestamptz,expire_a),
     revoque_a=CASE WHEN coalesce((p->>'revoquer')::boolean,false) THEN now() ELSE revoque_a END,
     version=version+1 WHERE id=i.id RETURNING * INTO i;
   IF i.expire_a>now()+interval '365 days' THEN RAISE EXCEPTION 'expiration_invalide'; END IF;
   IF retro THEN
     UPDATE comptes SET quota_octets=quota,limites=limites,version=version+1,modifie_a=now()
       WHERE invitation_id=i.id;
   END IF;
   cible:=i.id::text; resultat:=invitation_publique(i)||jsonb_build_object('retroactif',retro,
     'comptes_en_depassement',(SELECT count(*) FROM comptes WHERE invitation_id=i.id AND utilise_octets>quota_octets));
 ELSE RAISE EXCEPTION 'operation_inconnue'; END IF;
 PERFORM verifier_budget();
 -- Liste blanche : aucun secret, contenu ou paramètre d'identité dans l'audit.
 INSERT INTO evenements(acteur,action,cible,parametres) VALUES(acteur,op,cible,resultat);
 DELETE FROM evenements WHERE cree_a<now()-interval '30 days';
 RETURN resultat;
END $$;

CREATE FUNCTION vision_gestion.identifier(emetteur text,sujet text) RETURNS jsonb
LANGUAGE sql STABLE SECURITY DEFINER SET search_path=pg_catalog,vision_gestion,pg_temp AS $$
 SELECT coalesce((SELECT compte_public(c) FROM identites x JOIN comptes c USING(utilisateur)
   WHERE x.emetteur=$1 AND x.sujet=$2),jsonb_build_object('erreur','invitation_requise'))
$$;

CREATE FUNCTION vision_gestion.activer(emetteur text,sujet text,condensat text,notice text,affichage text DEFAULT NULL) RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog,vision_gestion,pg_temp AS $$
DECLARE i invitations; c comptes; cfg configuration; u text;
BEGIN
 SELECT * INTO STRICT cfg FROM configuration WHERE singleton FOR UPDATE;
 IF NOT cfg.inscriptions_ouvertes THEN RAISE EXCEPTION 'inscriptions_fermees'; END IF;
 IF notice IS DISTINCT FROM cfg.notice_version THEN RAISE EXCEPTION 'notice_a_relire'; END IF;
 -- Une identité déjà inscrite ne consomme jamais une deuxième place.
 SELECT compte.* INTO c FROM identites x JOIN comptes compte USING(utilisateur)
   WHERE x.emetteur=$1 AND x.sujet=$2;
 IF FOUND THEN RETURN compte_public(c); END IF;
 SELECT * INTO i FROM invitations WHERE invitations.condensat=$3 FOR UPDATE;
 IF NOT FOUND OR i.revoque_a IS NOT NULL OR i.expire_a<=now() OR i.utilise>=i.maximum THEN
   RAISE EXCEPTION 'invitation_indisponible';
 END IF;
 u:=gen_random_uuid()::text;
 INSERT INTO comptes(utilisateur,affichage,quota_octets,limites,invitation_id,notice_version,notice_lue_a)
   VALUES(u,coalesce(nullif(left($5,100),''),u),i.quota_octets,i.limites,i.id,cfg.notice_version,now()) RETURNING * INTO c;
 INSERT INTO identites VALUES($1,$2,u);
 UPDATE invitations SET utilise=utilise+1,version=version+1 WHERE id=i.id;
 PERFORM verifier_budget();
 RETURN compte_public(c);
END $$;

CREATE FUNCTION vision_gestion.notice() RETURNS jsonb
LANGUAGE sql STABLE SECURITY DEFINER SET search_path=pg_catalog,vision_gestion,pg_temp AS $$
 SELECT jsonb_build_object('responsable',responsable,'contact',contact,'pays_hebergement',pays_hebergement,
   'version',notice_version,'sauvegardes_jours',sauvegardes_jours,'inscriptions_ouvertes',inscriptions_ouvertes)
 FROM configuration WHERE singleton
$$;

-- Aperçu sans consommation : seulement les conditions du lien possédé,
-- jamais l'identité de sa création ou de ses bénéficiaires.
CREATE FUNCTION vision_gestion.apercu_invitation(condensat text) RETURNS jsonb
LANGUAGE sql STABLE SECURITY DEFINER SET search_path=pg_catalog,vision_gestion,pg_temp AS $$
 SELECT coalesce((SELECT jsonb_build_object('quota_octets',quota_octets,'limites',limites,
   'expire_a',expire_a,'disponible',revoque_a IS NULL AND expire_a>now() AND utilise<maximum)
   FROM invitations WHERE invitations.condensat=$1),jsonb_build_object('disponible',false))
$$;

REVOKE ALL ON ALL TABLES IN SCHEMA vision_gestion FROM PUBLIC;
REVOKE ALL ON ALL FUNCTIONS IN SCHEMA vision_gestion FROM PUBLIC;
INSERT INTO vision_schema_migrations(version) VALUES(20);
COMMIT;
