BEGIN;

-- Un sujet fermé ne peut être réadmis, même si son ancienne identité est
-- réintroduite par une copie. Un nouveau compte possède un autre sujet natif.
CREATE TABLE vision_gestion.fermetures_identite (
 emetteur text NOT NULL,sujet text NOT NULL,confirmee_a timestamptz NOT NULL DEFAULT clock_timestamp(),
 PRIMARY KEY(emetteur,sujet)
);

-- Métadonnées uniquement : le processus de fermeture ne lit pas les contenus.
CREATE FUNCTION vision_gestion.comptes_identite(emetteur text,sujet text) RETURNS jsonb
LANGUAGE sql STABLE SECURITY DEFINER SET search_path=pg_catalog,vision_gestion,pg_temp AS $$
 SELECT coalesce(jsonb_agg(utilisateur),'[]'::jsonb) FROM identites WHERE emetteur=$1 AND sujet=$2
$$;

CREATE FUNCTION vision_gestion.engager_fermeture_identite(emetteur text,sujet text,confirmation text) RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog,vision_gestion,pg_temp AS $$
BEGIN
 IF $3 IS DISTINCT FROM 'FERMER MON COMPTE' THEN RAISE EXCEPTION 'confirmation_requise'; END IF;
 PERFORM 1 FROM configuration FOR UPDATE;
 INSERT INTO fermetures_identite(emetteur,sujet) VALUES($1,$2) ON CONFLICT DO NOTHING;
 RETURN comptes_identite($1,$2);
END $$;

ALTER FUNCTION vision_gestion.activer(text,text,text,text,text) RENAME TO activer_admission;
CREATE FUNCTION vision_gestion.activer(emetteur text,sujet text,condensat text,notice text,affichage text DEFAULT NULL) RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog,vision_gestion,pg_temp AS $$
BEGIN
 PERFORM 1 FROM configuration FOR UPDATE;
 IF EXISTS(SELECT FROM fermetures_identite f WHERE f.emetteur=$1 AND f.sujet=$2) THEN RAISE EXCEPTION 'identite_fermee'; END IF;
 RETURN activer_admission($1,$2,$3,$4,$5);
END $$;

ALTER FUNCTION vision_gestion.certifier_admission(uuid,text,text,text) RENAME TO certifier_admission_origine;
CREATE FUNCTION vision_gestion.certifier_admission(demande uuid,emetteur text,sujet text,notice text) RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog,vision_gestion,pg_temp AS $$
BEGIN
 PERFORM 1 FROM configuration FOR UPDATE;
 IF EXISTS(SELECT FROM fermetures_identite f WHERE f.emetteur=$2 AND f.sujet=$3) THEN RAISE EXCEPTION 'identite_fermee'; END IF;
 PERFORM certifier_admission_origine($1,$2,$3,$4);
END $$;

CREATE FUNCTION vision_gestion.effacer_identite_cycle(emetteur text,sujet text,confirmation text) RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog,vision_gestion,pg_temp AS $$
DECLARE u text;
BEGIN
 IF $3 IS DISTINCT FROM 'FERMER MON COMPTE' THEN RAISE EXCEPTION 'confirmation_requise'; END IF;
 FOR u IN SELECT i.utilisateur FROM identites i WHERE i.emetteur=$1 AND i.sujet=$2 LOOP
   PERFORM effacer_cycle(u,'EFFACER VISION',NULL);
 END LOOP;
 DELETE FROM admissions a WHERE a.emetteur=$1 AND a.sujet=$2;
 RETURN jsonb_build_object('efface',true);
END $$;

REVOKE ALL ON FUNCTION vision_gestion.comptes_identite(text,text),
 vision_gestion.effacer_identite_cycle(text,text,text),vision_gestion.engager_fermeture_identite(text,text,text),
 vision_gestion.activer(text,text,text,text,text),vision_gestion.activer_admission(text,text,text,text,text),
 vision_gestion.certifier_admission(uuid,text,text,text),vision_gestion.certifier_admission_origine(uuid,text,text,text) FROM PUBLIC;
INSERT INTO vision_schema_migrations(version) VALUES(25);
COMMIT;
