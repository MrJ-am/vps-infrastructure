BEGIN;

-- Les contenus restent dans public ; la gestion ne contient que métadonnées
-- et compteurs. Le rôle HTTP d'administration n'a aucun droit sur les contenus.
CREATE SCHEMA IF NOT EXISTS vision_gestion;
REVOKE ALL ON SCHEMA vision_gestion FROM PUBLIC;

CREATE OR REPLACE FUNCTION vision_gestion.limites_defaut() RETURNS jsonb
LANGUAGE sql IMMUTABLE AS $$
 SELECT '{"fiches":1000,"items_par_fiche":500,"mots_item":500,"octets_item":8000,
   "mots_fiche":2000,"octets_fiche":32000,"mots_note":200,"octets_note":2000}'::jsonb
$$;

CREATE TABLE IF NOT EXISTS vision_gestion.comptes (
 utilisateur text PRIMARY KEY CHECK (utilisateur ~ '^[A-Za-z0-9_.-]{1,64}$'),
 id uuid NOT NULL DEFAULT gen_random_uuid() UNIQUE,
 affichage text NOT NULL CHECK (char_length(affichage) BETWEEN 1 AND 100),
 administrateur boolean NOT NULL DEFAULT false,
 actif boolean NOT NULL DEFAULT true,
 quota_octets bigint NOT NULL DEFAULT 10000000 CHECK (quota_octets BETWEEN 1 AND 1000000000),
 utilise_octets bigint NOT NULL DEFAULT 0 CHECK (utilise_octets >= 0),
 fiches bigint NOT NULL DEFAULT 0 CHECK (fiches >= 0),
 items bigint NOT NULL DEFAULT 0 CHECK (items >= 0),
 fiches_archivees bigint NOT NULL DEFAULT 0 CHECK (fiches_archivees >= 0),
 items_archives bigint NOT NULL DEFAULT 0 CHECK (items_archives >= 0),
 limites jsonb NOT NULL DEFAULT vision_gestion.limites_defaut(),
 cree_a timestamptz NOT NULL DEFAULT now(),
 modifie_a timestamptz NOT NULL DEFAULT now(),
 version bigint NOT NULL DEFAULT 1
);
INSERT INTO vision_gestion.comptes(utilisateur,affichage)
 SELECT utilisateur,utilisateur FROM vision_profils ON CONFLICT DO NOTHING;

CREATE TABLE IF NOT EXISTS vision_gestion.configuration (
 singleton boolean PRIMARY KEY DEFAULT true CHECK (singleton),
 budget_octets bigint NOT NULL DEFAULT 1000000000 CHECK (budget_octets > 0),
 inscriptions_ouvertes boolean NOT NULL DEFAULT false,
 responsable text NOT NULL DEFAULT '',
 contact text NOT NULL DEFAULT '',
 pays_hebergement text NOT NULL DEFAULT '',
 notice_version text NOT NULL DEFAULT '',
 sauvegardes_jours integer NOT NULL DEFAULT 30 CHECK (sauvegardes_jours BETWEEN 1 AND 90),
 CHECK (NOT inscriptions_ouvertes OR
   (responsable<>'' AND contact<>'' AND pays_hebergement<>'' AND notice_version<>''))
);
INSERT INTO vision_gestion.configuration(singleton) VALUES(true) ON CONFLICT DO NOTHING;

CREATE OR REPLACE FUNCTION vision_gestion.poids_ligne(ligne jsonb) RETURNS bigint
LANGUAGE sql IMMUTABLE STRICT AS $$
 -- UTF-8 non compressé, colonnes dérivées incluses, forfait de 256 octets
 -- par ligne. Le vecteur est compté dans son format float32, avec son en-tête.
 SELECT octet_length((ligne-'representation')::text)::bigint + 256 +
   CASE WHEN ligne ? 'representation' AND ligne->>'representation' IS NOT NULL
     THEN 8 + 4 * vector_dims((ligne->>'representation')::vector) ELSE 0 END
$$;

CREATE OR REPLACE FUNCTION vision_gestion.nombre_mots(texte text) RETURNS integer
LANGUAGE sql IMMUTABLE AS $$
 SELECT CASE WHEN btrim(coalesce(texte,''))='' THEN 0
   ELSE cardinality(regexp_split_to_array(btrim(texte), E'\\s+')) END
$$;

CREATE OR REPLACE FUNCTION vision_gestion.borner_texte(texte text,mots integer,octets integer)
RETURNS void LANGUAGE plpgsql IMMUTABLE AS $$
BEGIN
 IF octet_length(coalesce(texte,''))>octets OR vision_gestion.nombre_mots(texte)>mots THEN
   RAISE EXCEPTION USING ERRCODE='P0001',MESSAGE='texte_trop_long';
 END IF;
END $$;

CREATE OR REPLACE FUNCTION vision_gestion.verifier_ligne() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog,public,vision_gestion,pg_temp AS $$
DECLARE u text; compte vision_gestion.comptes; j jsonb; ancien jsonb;
BEGIN
 j:=to_jsonb(NEW); u:=j->>'utilisateur';
 IF TG_OP='UPDATE' THEN
   ancien:=to_jsonb(OLD);
   IF ancien->>'utilisateur' IS DISTINCT FROM u THEN RAISE EXCEPTION 'proprietaire_immuable'; END IF;
 END IF;
 SELECT * INTO compte FROM vision_gestion.comptes WHERE utilisateur=u FOR UPDATE;
 IF NOT FOUND THEN
   -- Les migrations et fixtures exécutées par le superuser peuvent attribuer
   -- des données historiques ; aucun rôle HTTP ne possède ce privilège.
   IF (SELECT rolsuper FROM pg_roles WHERE rolname=session_user) THEN
     INSERT INTO vision_gestion.comptes(utilisateur,affichage) VALUES(u,u) RETURNING * INTO compte;
   ELSE RAISE EXCEPTION USING ERRCODE='P0001',MESSAGE='invitation_requise'; END IF;
 END IF;
 IF NOT compte.actif THEN RAISE EXCEPTION USING ERRCODE='P0001',MESSAGE='compte_suspendu'; END IF;
 IF TG_TABLE_NAME='vision_fiches' THEN
   IF TG_OP='INSERT' AND compte.fiches >= (compte.limites->>'fiches')::bigint THEN
     RAISE EXCEPTION 'limite_fiches';
   END IF;
   IF TG_OP='INSERT' OR NEW.contenu IS DISTINCT FROM OLD.contenu THEN
     PERFORM vision_gestion.borner_texte(NEW.contenu,(compte.limites->>'mots_fiche')::integer,
       (compte.limites->>'octets_fiche')::integer);
   END IF;
 ELSIF TG_TABLE_NAME='vision_items' THEN
   IF TG_OP='INSERT' OR NEW.contenu IS DISTINCT FROM OLD.contenu THEN
     PERFORM vision_gestion.borner_texte(NEW.contenu,(compte.limites->>'mots_item')::integer,
       (compte.limites->>'octets_item')::integer);
   END IF;
 ELSIF TG_TABLE_NAME='vision_observations' THEN
   PERFORM vision_gestion.borner_texte(NEW.texte,(compte.limites->>'mots_note')::integer,
     (compte.limites->>'octets_note')::integer);
 ELSIF TG_TABLE_NAME='vision_liens' AND TG_OP='INSERT' THEN
   IF (SELECT count(*) FROM public.vision_liens WHERE utilisateur=u AND fiche_id=NEW.fiche_id)
      >= (compte.limites->>'items_par_fiche')::bigint THEN RAISE EXCEPTION 'limite_items_fiche'; END IF;
 END IF;
 -- Les anciennes données sont préservées ; les nouvelles notes sont bornées.
 IF TG_TABLE_NAME IN ('vision_fiches','vision_items') AND
   (TG_OP='INSERT' OR j->>'suivi' IS DISTINCT FROM ancien->>'suivi') THEN
   PERFORM vision_gestion.borner_texte(j->>'suivi',(compte.limites->>'mots_note')::integer,
     (compte.limites->>'octets_note')::integer);
 END IF;
 IF octet_length((j-'representation'-'recherche'-'texte_recherche')::text)>65536 AND
   TG_TABLE_NAME NOT IN ('vision_requetes','vision_seances','vision_journal','vision_migrations_metier') THEN
   RAISE EXCEPTION 'ligne_trop_longue';
 END IF;
 RETURN NEW;
END $$;

CREATE OR REPLACE FUNCTION vision_gestion.compter_ligne() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog,public,vision_gestion,pg_temp AS $$
DECLARE u text; precedent jsonb; suivant jsonb; delta bigint; compte vision_gestion.comptes;
  df integer:=0; di integer:=0; dfa integer:=0; dia integer:=0;
BEGIN
 IF TG_OP<>'INSERT' THEN precedent:=to_jsonb(OLD); END IF;
 IF TG_OP<>'DELETE' THEN suivant:=to_jsonb(NEW); END IF;
 u:=coalesce(suivant->>'utilisateur',precedent->>'utilisateur');
 delta:=coalesce(vision_gestion.poids_ligne(suivant),0)-coalesce(vision_gestion.poids_ligne(precedent),0);
 IF TG_TABLE_NAME='vision_fiches' THEN
   df:=(suivant IS NOT NULL)::integer-(precedent IS NOT NULL)::integer;
   dfa:=(suivant->>'archive_a' IS NOT NULL)::integer-(precedent->>'archive_a' IS NOT NULL)::integer;
 ELSIF TG_TABLE_NAME='vision_items' THEN
   di:=(suivant IS NOT NULL)::integer-(precedent IS NOT NULL)::integer;
   dia:=(suivant->>'archive_a' IS NOT NULL)::integer-(precedent->>'archive_a' IS NOT NULL)::integer;
 END IF;
 UPDATE vision_gestion.comptes SET utilise_octets=utilise_octets+delta,
   fiches=fiches+df,items=items+di,fiches_archivees=fiches_archivees+dfa,items_archives=items_archives+dia
   WHERE utilisateur=u RETURNING * INTO compte;
 IF NOT FOUND THEN RAISE EXCEPTION 'compte_introuvable'; END IF;
 -- Une baisse rétroactive autorise la réduction et l'effacement, jamais la
 -- croissance d'un compte déjà au-dessus de son plafond.
 IF delta>0 AND compte.utilise_octets>compte.quota_octets THEN
   RAISE EXCEPTION USING ERRCODE='P0001',MESSAGE='quota_depasse';
 END IF;
 RETURN NULL;
END $$;

CREATE OR REPLACE FUNCTION vision_gestion.usage(u text) RETURNS jsonb
LANGUAGE sql STABLE AS $$
 SELECT coalesce((SELECT jsonb_build_object('quota_octets',quota_octets,'utilise_octets',utilise_octets,
   'restant_octets',greatest(0,quota_octets-utilise_octets),'depassement',utilise_octets>quota_octets,
   'fiches',fiches,'items',items,'fiches_archivees',fiches_archivees,'items_archives',items_archives,
   'limites',limites,'unite','Mo = 1 000 000 octets',
   'calcul','UTF-8 non compressé, données dérivées et historiques ; 256 octets par ligne ; vecteurs float32',
   'archivage_libere_espace',false) FROM vision_gestion.comptes WHERE utilisateur=u),
   jsonb_build_object('erreur','invitation_requise'))
$$;

-- Inventaire intégral avant mise en place des triggers. Les anciennes copies
-- de migration sont incluses, sans lecture ou export de leur contenu.
DO $$
DECLARE t record; compte record; total bigint;
BEGIN
 FOR compte IN SELECT utilisateur FROM vision_gestion.comptes LOOP
   total:=0;
   FOR t IN SELECT table_name FROM information_schema.columns
     WHERE table_schema='public' AND column_name='utilisateur' AND table_name LIKE 'vision_%' LOOP
     EXECUTE format('SELECT coalesce(sum(vision_gestion.poids_ligne(to_jsonb(l))),0) FROM public.%I l WHERE utilisateur=$1',t.table_name)
       INTO STRICT total USING compte.utilisateur;
     UPDATE vision_gestion.comptes SET utilise_octets=utilise_octets+total WHERE utilisateur=compte.utilisateur;
   END LOOP;
 END LOOP;
 UPDATE vision_gestion.comptes c SET
   fiches=(SELECT count(*) FROM public.vision_fiches WHERE utilisateur=c.utilisateur),
   items=(SELECT count(*) FROM public.vision_items WHERE utilisateur=c.utilisateur),
   fiches_archivees=(SELECT count(*) FROM public.vision_fiches WHERE utilisateur=c.utilisateur AND archive_a IS NOT NULL),
   items_archives=(SELECT count(*) FROM public.vision_items WHERE utilisateur=c.utilisateur AND archive_a IS NOT NULL);
END $$;

-- Les politiques ne reposent pas sur un statut administrateur : le rôle
-- applicatif ne voit que le propriétaire authentifié de sa transaction.
DO $$
DECLARE t record;
BEGIN
 FOR t IN SELECT table_name FROM information_schema.columns
   WHERE table_schema='public' AND column_name='utilisateur' AND table_name LIKE 'vision_%' LOOP
   EXECUTE format('ALTER TABLE public.%I ENABLE ROW LEVEL SECURITY',t.table_name);
   EXECUTE format('ALTER TABLE public.%I FORCE ROW LEVEL SECURITY',t.table_name);
   EXECUTE format('CREATE POLICY proprietaire ON public.%I USING (utilisateur=current_setting(''vision.utilisateur'',true)) WITH CHECK (utilisateur=current_setting(''vision.utilisateur'',true))',t.table_name);
   EXECUTE format('CREATE TRIGGER a_vision_limites BEFORE INSERT OR UPDATE ON public.%I FOR EACH ROW EXECUTE FUNCTION vision_gestion.verifier_ligne()',t.table_name);
   EXECUTE format('CREATE TRIGGER z_vision_comptage AFTER INSERT OR UPDATE OR DELETE ON public.%I FOR EACH ROW EXECUTE FUNCTION vision_gestion.compter_ligne()',t.table_name);
 END LOOP;
END $$;
ALTER TABLE vision_gestion.comptes ENABLE ROW LEVEL SECURITY;
ALTER TABLE vision_gestion.comptes FORCE ROW LEVEL SECURITY;
CREATE POLICY compte_propre ON vision_gestion.comptes
 USING (utilisateur=current_setting('vision.utilisateur',true) OR current_user='vision_migration');

REVOKE ALL ON ALL TABLES IN SCHEMA vision_gestion FROM PUBLIC;
REVOKE ALL ON ALL FUNCTIONS IN SCHEMA vision_gestion FROM PUBLIC;
INSERT INTO vision_schema_migrations(version) VALUES(19) ON CONFLICT DO NOTHING;
COMMIT;
