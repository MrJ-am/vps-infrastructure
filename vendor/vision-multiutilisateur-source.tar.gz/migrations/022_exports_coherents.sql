BEGIN;
ALTER TABLE vision_gestion.comptes ADD COLUMN donnees_version bigint NOT NULL DEFAULT 1;
CREATE OR REPLACE FUNCTION vision_gestion.compter_ligne() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog,public,vision_gestion,pg_temp AS $$
DECLARE u text; precedent jsonb; suivant jsonb; delta bigint; compte vision_gestion.comptes;
  df integer:=0; di integer:=0; dfa integer:=0; dia integer:=0;
BEGIN
 IF TG_OP<>'INSERT' THEN precedent:=to_jsonb(OLD); END IF;
 IF TG_OP<>'DELETE' THEN suivant:=to_jsonb(NEW); END IF;
 u:=coalesce(suivant->>'utilisateur',precedent->>'utilisateur');
 delta:=coalesce(vision_gestion.poids_ligne(suivant),0)-coalesce(vision_gestion.poids_ligne(precedent),0);
 IF TG_TABLE_NAME='vision_fiches' THEN
   df:=(suivant IS NOT NULL)::integer-(precedent IS NOT NULL)::integer;
   dfa:=(suivant->>'archive_a' IS NOT NULL)::integer-(precedent->>'archive_a' IS NOT NULL)::integer;
 ELSIF TG_TABLE_NAME='vision_items' THEN
   di:=(suivant IS NOT NULL)::integer-(precedent IS NOT NULL)::integer;
   dia:=(suivant->>'archive_a' IS NOT NULL)::integer-(precedent->>'archive_a' IS NOT NULL)::integer;
 END IF;
 UPDATE vision_gestion.comptes SET utilise_octets=utilise_octets+delta,donnees_version=donnees_version+1,
   fiches=fiches+df,items=items+di,fiches_archivees=fiches_archivees+dfa,items_archives=items_archives+dia
   WHERE utilisateur=u RETURNING * INTO compte;
 IF NOT FOUND THEN RAISE EXCEPTION 'compte_introuvable'; END IF;
 -- Une baisse rétroactive autorise la réduction et l'effacement, jamais la
 -- croissance d'un compte déjà au-dessus de son plafond.
 IF delta>0 AND compte.utilise_octets>compte.quota_octets THEN
   RAISE EXCEPTION USING ERRCODE='P0001',MESSAGE='quota_depasse';
 END IF;
 RETURN NULL;
END $$;

CREATE OR REPLACE FUNCTION vision_gestion.usage(u text) RETURNS jsonb
LANGUAGE sql STABLE AS $$
 SELECT coalesce((SELECT jsonb_build_object('quota_octets',quota_octets,'utilise_octets',utilise_octets,
   'donnees_version',donnees_version,'restant_octets',greatest(0,quota_octets-utilise_octets),'depassement',utilise_octets>quota_octets,
   'fiches',fiches,'items',items,'fiches_archivees',fiches_archivees,'items_archives',items_archives,
   'limites',limites,'unite','Mo = 1 000 000 octets',
   'calcul','UTF-8 non compressé, données dérivées et historiques ; 256 octets par ligne ; vecteurs float32',
   'archivage_libere_espace',false) FROM vision_gestion.comptes WHERE utilisateur=u),
   jsonb_build_object('erreur','invitation_requise'))
$$;


DROP FUNCTION vision_gestion.exporter(text,text,integer);
CREATE FUNCTION vision_gestion.exporter(u text,tableau text,debut integer,attendu bigint DEFAULT NULL) RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog,public,vision_gestion,pg_temp AS $$
DECLARE resultat jsonb; sequence bigint;
BEGIN
 IF u IS DISTINCT FROM current_setting('vision.utilisateur',true) THEN RAISE EXCEPTION 'identite_invalide'; END IF;
 SELECT donnees_version INTO STRICT sequence FROM comptes WHERE utilisateur=u FOR SHARE;
 IF attendu IS NOT NULL AND attendu<>sequence THEN RAISE EXCEPTION 'export_modifie'; END IF;
 IF tableau NOT IN ('vision_profils','vision_fiches','vision_items','vision_liens','vision_episodes',
   'vision_journal','vision_requetes','vision_recherches','vision_contextes','vision_migrations_metier',
   'vision_seances','vision_observations','vision_embeddings','vision_preparations_items',
   'vision_memory_sheets','vision_memory_observations','vision_observation_corrections','vision_sheet_edits','vision_scheduler_settings',
   'comptes','identites') OR debut<0 THEN
   RAISE EXCEPTION 'export_invalide';
 END IF;
 -- Pagination stable par la représentation complète ; l'interface demande
 -- de suspendre les écritures pendant l'export et signale les modifications.
 IF tableau IN ('comptes','identites') THEN
   EXECUTE format('SELECT coalesce(jsonb_agg(ligne),''[]''::jsonb) FROM (SELECT to_jsonb(t) ligne FROM vision_gestion.%I t WHERE utilisateur=$1 ORDER BY to_jsonb(t)::text LIMIT 100 OFFSET $2) x',tableau) INTO resultat USING u,debut;
 ELSIF tableau IN ('vision_memory_sheets','vision_memory_observations','vision_observation_corrections','vision_sheet_edits','vision_scheduler_settings') THEN
   IF EXISTS(SELECT FROM historique_proprietaire WHERE utilisateur=u) THEN
     EXECUTE format('SELECT coalesce(jsonb_agg(ligne),''[]''::jsonb) FROM (SELECT to_jsonb(t) ligne FROM public.%I t ORDER BY to_jsonb(t)::text LIMIT 100 OFFSET $1) x',tableau) INTO resultat USING debut;
   ELSE resultat:='[]'::jsonb; END IF;
 ELSE
 EXECUTE format('SELECT coalesce(jsonb_agg(ligne),''[]''::jsonb) FROM (SELECT to_jsonb(t) ligne FROM public.%I t WHERE utilisateur=$1 ORDER BY to_jsonb(t)::text LIMIT 100 OFFSET $2) x',tableau)
   INTO resultat USING u,debut;
 END IF;
 RETURN jsonb_build_object('donnees_version',sequence,'table',tableau,'debut',debut,'lignes',resultat,'suite',jsonb_array_length(resultat)=100);
END $$;

-- Exploitation seulement : purge quotidienne, même pour les comptes inactifs.
-- Aucun rôle HTTP ne reçoit EXECUTE sur cette fonction.
CREATE FUNCTION vision_gestion.purger() RETURNS void LANGUAGE plpgsql SECURITY DEFINER
 SET search_path=pg_catalog,public,vision_gestion,pg_temp AS $$
DECLARE u text;
BEGIN
 FOR u IN SELECT utilisateur FROM comptes LOOP
   PERFORM set_config('vision.utilisateur',u,true);
   DELETE FROM vision_recherches WHERE utilisateur=u AND cree_a<now()-interval '30 minutes';
   DELETE FROM vision_preparations_items WHERE utilisateur=u AND cree_a<now()-interval '35 days';
   DELETE FROM vision_requetes WHERE utilisateur=u AND enregistre_a<now()-interval '35 days';
   DELETE FROM vision_episodes WHERE utilisateur=u AND enregistre_a<now()-interval '90 days';
   DELETE FROM vision_journal WHERE utilisateur=u AND enregistre_a<now()-interval '180 days';
   DELETE FROM vision_contextes WHERE utilisateur=u AND modifie_a<now()-interval '90 days';
 END LOOP;
 DELETE FROM evenements WHERE cree_a<now()-interval '30 days';
END $$;


REVOKE ALL ON ALL FUNCTIONS IN SCHEMA vision_gestion FROM PUBLIC;
INSERT INTO vision_schema_migrations(version) VALUES(22);
COMMIT;
