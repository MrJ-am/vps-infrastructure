BEGIN;
-- Métadonnées de procédure uniquement ; aucune donnée pédagogique.
CREATE TABLE vision_gestion.preavis (
 utilisateur text PRIMARY KEY REFERENCES vision_gestion.comptes ON DELETE CASCADE,
 id uuid NOT NULL UNIQUE DEFAULT gen_random_uuid(),
 demande_par text REFERENCES vision_gestion.comptes ON DELETE SET NULL,
 demande_a timestamptz NOT NULL DEFAULT now(),
 etat_courriel text NOT NULL DEFAULT 'attente' CHECK (etat_courriel IN ('attente','erreur','accepte_relais')),
 envoye_a timestamptz,
 echeance_a timestamptz,
 engage_a timestamptz,
 annule_a timestamptz,
 CHECK ((envoye_a IS NULL AND echeance_a IS NULL) OR echeance_a=envoye_a+interval '30 days')
);

CREATE OR REPLACE FUNCTION vision_gestion.compte_public(c vision_gestion.comptes) RETURNS jsonb
LANGUAGE sql STABLE SET search_path=pg_catalog,vision_gestion,pg_temp AS $$
 SELECT jsonb_build_object('utilisateur',c.utilisateur,'affichage',c.affichage,
   'administrateur',c.administrateur,'actif',c.actif,'quota_octets',c.quota_octets,
   'utilise_octets',c.utilise_octets,'fiches',c.fiches,'items',c.items,
   'fiches_archivees',c.fiches_archivees,'items_archives',c.items_archives,
   'limites',c.limites,'invitation_id',c.invitation_id,'version',c.version,
   'depassement',c.utilise_octets>c.quota_octets,
   'suppression',(SELECT jsonb_build_object('id',id,'demande_a',demande_a,
     'etat_courriel',etat_courriel,'envoye_a',envoye_a,'echeance_a',echeance_a,'annule_a',annule_a,'engage_a',engage_a)
     FROM preavis WHERE utilisateur=c.utilisateur))
$$;

ALTER FUNCTION vision_gestion.administrer(text,text,jsonb) RENAME TO administrer_allocations;
CREATE FUNCTION vision_gestion.administrer(acteur text,op text,p jsonb) RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog,vision_gestion,pg_temp AS $$
DECLARE c comptes; cfg configuration; resultat jsonb;
BEGIN
 IF op='modifier_compte' AND p->>'actif'='false' THEN
   PERFORM 1 FROM configuration WHERE singleton FOR UPDATE;
   IF EXISTS(SELECT FROM preavis WHERE utilisateur=p->>'utilisateur' AND annule_a IS NULL) THEN
     RAISE EXCEPTION 'export_a_preserver';
   END IF;
 END IF;
 IF op NOT IN ('demander_suppression','annuler_suppression') THEN
   RETURN administrer_allocations(acteur,op,p);
 END IF;
 IF NOT (p ?& ARRAY['utilisateur','version']) OR p-ARRAY['utilisateur','version']<>'{}'::jsonb THEN
   RAISE EXCEPTION 'parametres_invalides';
 END IF;
 SELECT * INTO STRICT cfg FROM configuration WHERE singleton FOR UPDATE;
 IF NOT EXISTS(SELECT FROM comptes WHERE utilisateur=acteur AND actif AND administrateur) THEN
   RAISE EXCEPTION 'administration_interdite';
 END IF;
 SELECT * INTO c FROM comptes WHERE utilisateur=p->>'utilisateur' FOR UPDATE;
 IF NOT FOUND THEN RAISE EXCEPTION 'compte_introuvable'; END IF;
 IF c.version IS DISTINCT FROM (p->>'version')::bigint THEN RAISE EXCEPTION 'conflit'; END IF;
 IF op='demander_suppression' THEN
   IF NOT c.actif THEN RAISE EXCEPTION 'compte_suspendu'; END IF;
   IF c.administrateur AND (SELECT count(*) FROM comptes WHERE administrateur AND actif)<=1 THEN
     RAISE EXCEPTION 'dernier_administrateur';
   END IF;
   IF EXISTS(SELECT FROM preavis WHERE utilisateur=c.utilisateur AND annule_a IS NULL) THEN
     RAISE EXCEPTION 'preavis_deja_engage';
   END IF;
   INSERT INTO preavis(utilisateur,demande_par) VALUES(c.utilisateur,acteur)
     ON CONFLICT(utilisateur) DO UPDATE SET id=gen_random_uuid(),demande_par=acteur,
       demande_a=now(),etat_courriel='attente',envoye_a=NULL,echeance_a=NULL,annule_a=NULL,engage_a=NULL;
 ELSE
   IF EXISTS(SELECT FROM preavis WHERE utilisateur=c.utilisateur AND engage_a IS NOT NULL) THEN
     RAISE EXCEPTION 'effacement_engage';
   END IF;
   UPDATE preavis SET annule_a=now() WHERE utilisateur=c.utilisateur AND annule_a IS NULL;
   IF NOT FOUND THEN RAISE EXCEPTION 'preavis_introuvable'; END IF;
 END IF;
 UPDATE comptes SET version=version+1,modifie_a=now() WHERE utilisateur=c.utilisateur RETURNING * INTO c;
 resultat:=compte_public(c);
 INSERT INTO evenements(acteur,action,cible,parametres) VALUES(acteur,op,c.utilisateur,resultat);
 RETURN resultat;
END $$;

-- Seul le processus privé de cycle de vie peut constater l'envoi et exécuter
-- un effacement aveugle. Le rôle administratif ne peut lire aucun contenu.
CREATE FUNCTION vision_gestion.preavis_a_traiter() RETURNS jsonb
LANGUAGE sql STABLE SECURITY DEFINER SET search_path=pg_catalog,vision_gestion,pg_temp AS $$
 SELECT coalesce(jsonb_agg(jsonb_build_object('id',p.id,'utilisateur',p.utilisateur,
   'emetteur',i.emetteur,'sujet',i.sujet,'etat_courriel',p.etat_courriel,
   'echeance_a',p.echeance_a,'annule_a',p.annule_a,
   'exigible',p.annule_a IS NULL AND p.echeance_a<=now()) ORDER BY p.demande_a),'[]'::jsonb)
 FROM preavis p JOIN identites i USING(utilisateur)
$$;

CREATE FUNCTION vision_gestion.engager_effacement(u text,demande uuid) RETURNS boolean
LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog,vision_gestion,pg_temp AS $$
BEGIN
 PERFORM 1 FROM configuration WHERE singleton FOR UPDATE;
 UPDATE preavis SET engage_a=coalesce(engage_a,now()) WHERE utilisateur=u AND id=demande
   AND annule_a IS NULL AND etat_courriel='accepte_relais' AND echeance_a<=now();
 RETURN FOUND;
END $$;

CREATE FUNCTION vision_gestion.constater_preavis(demande uuid,etat text) RETURNS boolean
LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog,vision_gestion,pg_temp AS $$
DECLARE u text;
BEGIN
 IF etat NOT IN ('attente','erreur','accepte_relais') THEN RAISE EXCEPTION 'parametres_invalides'; END IF;
 -- L'horloge de la base fixe le début du délai ; aucune date fournie par le navigateur.
 UPDATE preavis SET etat_courriel=etat,
   envoye_a=CASE WHEN etat='accepte_relais' THEN now() ELSE NULL END,
   echeance_a=CASE WHEN etat='accepte_relais' THEN now()+interval '30 days' ELSE NULL END
   WHERE id=demande AND annule_a IS NULL AND envoye_a IS NULL RETURNING utilisateur INTO u;
 IF FOUND THEN
   UPDATE comptes SET version=version+1,modifie_a=now() WHERE utilisateur=u;
   RETURN true;
 END IF;
 RETURN false;
END $$;

CREATE FUNCTION vision_gestion.effacer_cycle(u text,confirmation text,demande uuid DEFAULT NULL) RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog,public,vision_gestion,pg_temp AS $$
BEGIN
 -- Ordre de verrous commun avec l'administration, donc annulation sérialisée.
 PERFORM 1 FROM configuration WHERE singleton FOR UPDATE;
 IF demande IS NOT NULL AND NOT EXISTS(SELECT FROM preavis WHERE id=demande AND utilisateur=u
     AND annule_a IS NULL AND engage_a IS NOT NULL AND etat_courriel='accepte_relais' AND echeance_a<=now()) THEN
   RAISE EXCEPTION 'preavis_non_exigible';
 END IF;
 PERFORM set_config('vision.utilisateur',u,true);
 RETURN effacer(u,confirmation);
END $$;

REVOKE ALL ON vision_gestion.preavis FROM PUBLIC;
REVOKE ALL ON FUNCTION vision_gestion.administrer_allocations(text,text,jsonb),
 vision_gestion.administrer(text,text,jsonb),vision_gestion.preavis_a_traiter(),
 vision_gestion.constater_preavis(uuid,text),vision_gestion.engager_effacement(text,uuid),vision_gestion.effacer_cycle(text,text,uuid) FROM PUBLIC;
INSERT INTO vision_schema_migrations(version) VALUES(23);
COMMIT;
