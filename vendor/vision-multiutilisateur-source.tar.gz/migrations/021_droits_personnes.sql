BEGIN;

-- Le modèle 1.x était mono-utilisateur. Son attribution est explicite et
-- figée ; aucune déduction par nom de connexion ou adresse de courriel.
CREATE TABLE vision_gestion.historique_proprietaire (
 singleton boolean PRIMARY KEY CHECK(singleton),
 utilisateur text NOT NULL UNIQUE REFERENCES vision_gestion.comptes
);
INSERT INTO vision_gestion.historique_proprietaire
 SELECT true,utilisateur FROM vision_migrations_metier WHERE cle='fiches-items-v2';
DO $$
DECLARE t text; u text; total bigint;
BEGIN
 SELECT utilisateur INTO u FROM vision_gestion.historique_proprietaire WHERE singleton;
 IF u IS NOT NULL THEN
   FOREACH t IN ARRAY ARRAY['vision_memory_sheets','vision_memory_observations','vision_observation_corrections','vision_sheet_edits','vision_scheduler_settings'] LOOP
     EXECUTE format('SELECT coalesce(sum(vision_gestion.poids_ligne(to_jsonb(t))),0) FROM public.%I t',t) INTO total;
     UPDATE vision_gestion.comptes SET utilise_octets=utilise_octets+total WHERE utilisateur=u;
   END LOOP;
 END IF;
END $$;

-- L'effacement est un droit de la personne. Le garde-fou d'immuabilité reste
-- actif pour les API métier, même si elles positionnent la variable de session.
ALTER FUNCTION vision_observation_immuable() RENAME TO vision_observation_verifier;
CREATE FUNCTION vision_observation_immuable() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE precedente vision_observations;
BEGIN
 IF TG_OP='DELETE' AND current_user='vision_migration'
   AND current_setting('vision.effacement',true)=OLD.utilisateur
   AND current_setting('vision.utilisateur',true)=OLD.utilisateur THEN RETURN OLD; END IF;
 IF TG_OP<>'INSERT' THEN RAISE EXCEPTION 'observation_immuable'; END IF;
 IF NEW.rectifie_id IS NOT NULL THEN
   SELECT * INTO precedente FROM vision_observations WHERE id=NEW.rectifie_id;
   IF precedente.id IS NULL OR precedente.utilisateur<>NEW.utilisateur
     OR precedente.item_id IS DISTINCT FROM NEW.item_id
     OR precedente.fiche_id IS DISTINCT FROM NEW.fiche_id THEN RAISE EXCEPTION 'rectification_invalide'; END IF;
 END IF;
 IF NEW.evenement_a>now()+interval '5 minutes' THEN RAISE EXCEPTION 'date_future'; END IF;
 RETURN NEW;
END $$;
DROP TRIGGER vision_observation_immuable ON vision_observations;
CREATE TRIGGER vision_observation_immuable BEFORE INSERT OR UPDATE OR DELETE ON vision_observations
 FOR EACH ROW EXECUTE FUNCTION vision_observation_immuable();

CREATE OR REPLACE FUNCTION vision_legacy_fige() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 IF TG_OP='DELETE' AND current_user='vision_migration'
   AND current_setting('vision.effacement',true)=current_setting('vision.utilisateur',true)
   AND EXISTS(SELECT FROM vision_gestion.historique_proprietaire
     WHERE utilisateur=current_setting('vision.utilisateur',true)) THEN RETURN OLD; END IF;
 IF EXISTS(SELECT FROM vision_migrations_metier WHERE cle='fiches-items-v2') THEN
   RAISE EXCEPTION 'Modele historique archive : utiliser Vision 2. Aucune ecriture perdue.';
 END IF;
 RETURN coalesce(NEW,OLD);
END $$;

CREATE FUNCTION vision_gestion.exporter(u text,tableau text,debut integer) RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog,public,vision_gestion,pg_temp AS $$
DECLARE resultat jsonb;
BEGIN
 IF u IS DISTINCT FROM current_setting('vision.utilisateur',true) THEN RAISE EXCEPTION 'identite_invalide'; END IF;
 IF tableau NOT IN ('vision_profils','vision_fiches','vision_items','vision_liens','vision_episodes',
   'vision_journal','vision_requetes','vision_recherches','vision_contextes','vision_migrations_metier',
   'vision_seances','vision_observations','vision_embeddings','vision_preparations_items') OR debut<0 THEN
   RAISE EXCEPTION 'export_invalide';
 END IF;
 -- Pagination stable par la représentation complète ; l'interface demande
 -- de suspendre les écritures pendant l'export et signale les modifications.
 EXECUTE format('SELECT coalesce(jsonb_agg(ligne),''[]''::jsonb) FROM (SELECT to_jsonb(t) ligne FROM public.%I t WHERE utilisateur=$1 ORDER BY to_jsonb(t)::text LIMIT 100 OFFSET $2) x',tableau)
   INTO resultat USING u,debut;
 RETURN jsonb_build_object('table',tableau,'debut',debut,'lignes',resultat,'suite',jsonb_array_length(resultat)=100);
END $$;

CREATE FUNCTION vision_gestion.effacer(u text,confirmation text) RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog,public,vision_gestion,pg_temp AS $$
DECLARE t text; historique boolean; jours integer;
BEGIN
 IF confirmation IS DISTINCT FROM 'EFFACER VISION' OR u IS DISTINCT FROM current_setting('vision.utilisateur',true) THEN
   RAISE EXCEPTION 'confirmation_requise';
 END IF;
 PERFORM 1 FROM configuration WHERE singleton FOR UPDATE;
 PERFORM pg_advisory_xact_lock(hashtextextended(u,718));
 PERFORM 1 FROM comptes WHERE utilisateur=u FOR UPDATE;
 IF NOT FOUND THEN RAISE EXCEPTION 'compte_introuvable'; END IF;
 IF EXISTS(SELECT FROM comptes WHERE utilisateur=u AND administrateur AND actif)
   AND (SELECT count(*) FROM comptes WHERE administrateur AND actif)<=1 THEN
   -- Le droit d'effacement prime : fermeture des inscriptions et récupération
   -- de l'administration par le seul exploitant technique, sans rétention forcée.
   UPDATE configuration SET inscriptions_ouvertes=false WHERE singleton;
 END IF;
 PERFORM set_config('vision.effacement',u,true);
 SELECT EXISTS(SELECT FROM historique_proprietaire WHERE utilisateur=u) INTO historique;
 IF historique THEN
   DELETE FROM vision_observation_corrections;
   DELETE FROM vision_sheet_edits;
   DELETE FROM vision_memory_observations;
   DELETE FROM vision_memory_sheets;
   DELETE FROM vision_scheduler_settings;
   DELETE FROM historique_proprietaire WHERE utilisateur=u;
 END IF;
 -- Ordre des clés étrangères ; les triggers de compteur participent à la
 -- même transaction. Aucun compte tiers n'est parcouru ou effacé.
 FOREACH t IN ARRAY ARRAY['vision_observations','vision_episodes','vision_embeddings','vision_preparations_items',
   'vision_liens','vision_contextes','vision_seances','vision_journal','vision_requetes','vision_recherches',
   'vision_migrations_metier','vision_items','vision_fiches','vision_profils'] LOOP
   EXECUTE format('DELETE FROM public.%I WHERE utilisateur=$1',t) USING u;
 END LOOP;
 DELETE FROM identites WHERE utilisateur=u;
 UPDATE evenements SET acteur=CASE WHEN acteur=u THEN '[effacé]' ELSE acteur END,
   cible=CASE WHEN cible=u THEN '[effacé]' ELSE cible END,
   parametres=CASE WHEN parametres->>'utilisateur'=u THEN parametres-'utilisateur'-'affichage' ELSE parametres END
   WHERE acteur=u OR cible=u OR parametres->>'utilisateur'=u;
 DELETE FROM comptes WHERE utilisateur=u;
 SELECT sauvegardes_jours INTO STRICT jours FROM configuration WHERE singleton;
 INSERT INTO effacements(utilisateur,purger_apres) VALUES(u,now()+make_interval(days=>jours+7))
   ON CONFLICT(utilisateur) DO UPDATE SET efface_a=excluded.efface_a,purger_apres=excluded.purger_apres;
 RETURN jsonb_build_object('efface',true,'identite_commune_conservee',true,
   'sauvegardes_purgees_sous_jours',jours,'autres_outils_conserves',true);
END $$;

REVOKE ALL ON ALL TABLES IN SCHEMA vision_gestion FROM PUBLIC;
REVOKE ALL ON ALL FUNCTIONS IN SCHEMA vision_gestion FROM PUBLIC;
INSERT INTO vision_schema_migrations(version) VALUES(21);
COMMIT;
