BEGIN;

-- Aucun courriel, âge, document parental ou contenu métier dans ce schéma.
-- Le service privé d'admission conserve les preuves minimales séparément.
CREATE TABLE vision_gestion.admissions (
 id uuid PRIMARY KEY,
 invitation_id uuid NOT NULL REFERENCES vision_gestion.invitations,
 notice_version text NOT NULL,
 cree_a timestamptz NOT NULL DEFAULT now(),
 expire_a timestamptz NOT NULL DEFAULT now()+interval '7 days',
 emetteur text CHECK(char_length(emetteur) BETWEEN 1 AND 300),
 sujet text CHECK(char_length(sujet) BETWEEN 1 AND 255),
 validee_a timestamptz,
 consommee_a timestamptz,
 annulee_a timestamptz,
 CHECK ((emetteur IS NULL)=(sujet IS NULL)),
 CHECK (validee_a IS NULL OR emetteur IS NOT NULL)
);

CREATE FUNCTION vision_gestion.reserver_admission(demande uuid,condensat text,notice text) RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog,vision_gestion,pg_temp AS $$
DECLARE cfg configuration; i invitations; a admissions; occupe bigint;
BEGIN
 SELECT * INTO STRICT cfg FROM configuration WHERE singleton FOR UPDATE;
 IF NOT cfg.inscriptions_ouvertes THEN RAISE EXCEPTION 'inscriptions_fermees'; END IF;
 IF $3 IS DISTINCT FROM cfg.notice_version THEN RAISE EXCEPTION 'notice_a_relire'; END IF;
 SELECT * INTO i FROM invitations WHERE invitations.condensat=$2 FOR UPDATE;
 IF NOT FOUND OR i.revoque_a IS NOT NULL OR i.expire_a<=now() THEN RAISE EXCEPTION 'invitation_indisponible'; END IF;
 SELECT * INTO a FROM admissions WHERE id=$1;
 IF FOUND THEN
   IF a.invitation_id<>i.id OR a.notice_version<>$3 OR a.annulee_a IS NOT NULL
      OR a.expire_a<=now() THEN RAISE EXCEPTION 'admission_indisponible'; END IF;
 ELSE
   SELECT count(*) INTO occupe FROM admissions WHERE invitation_id=i.id AND expire_a>now()
     AND consommee_a IS NULL AND annulee_a IS NULL;
   IF i.utilise+occupe>=i.maximum THEN RAISE EXCEPTION 'invitation_indisponible'; END IF;
   INSERT INTO admissions(id,invitation_id,notice_version) VALUES($1,i.id,$3) RETURNING * INTO a;
 END IF;
 RETURN jsonb_build_object('id',a.id,'expire_a',a.expire_a,'notice',a.notice_version);
END $$;

CREATE FUNCTION vision_gestion.certifier_admission(demande uuid,emetteur text,sujet text,notice text) RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog,vision_gestion,pg_temp AS $$
DECLARE cfg configuration; a admissions; i invitations;
BEGIN
 SELECT * INTO STRICT cfg FROM configuration WHERE singleton FOR UPDATE;
 SELECT * INTO a FROM admissions WHERE id=$1 FOR UPDATE;
 IF FOUND AND a.consommee_a IS NOT NULL AND a.emetteur=$2 AND a.sujet=$3 AND a.notice_version=$4 THEN RETURN; END IF;
 IF NOT FOUND OR a.annulee_a IS NOT NULL OR a.expire_a<=now() OR NOT cfg.inscriptions_ouvertes
   THEN RAISE EXCEPTION 'admission_indisponible'; END IF;
 SELECT * INTO STRICT i FROM invitations WHERE id=a.invitation_id;
 IF i.revoque_a IS NOT NULL OR i.expire_a<=now() THEN RAISE EXCEPTION 'invitation_indisponible'; END IF;
 IF a.notice_version IS DISTINCT FROM $4 OR cfg.notice_version IS DISTINCT FROM $4 THEN RAISE EXCEPTION 'notice_a_relire'; END IF;
 IF a.validee_a IS NOT NULL AND (a.emetteur IS DISTINCT FROM $2 OR a.sujet IS DISTINCT FROM $3)
   THEN RAISE EXCEPTION 'identite_incompatible'; END IF;
 UPDATE admissions SET emetteur=$2,sujet=$3,validee_a=coalesce(validee_a,now()) WHERE id=$1;
END $$;

CREATE FUNCTION vision_gestion.annuler_admission(demande uuid) RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog,vision_gestion,pg_temp AS $$
BEGIN
 PERFORM 1 FROM configuration WHERE singleton FOR UPDATE;
 UPDATE admissions SET annulee_a=coalesce(annulee_a,now()) WHERE id=$1 AND consommee_a IS NULL;
END $$;

ALTER FUNCTION vision_gestion.activer(text,text,text,text,text) RENAME TO activer_allocation;
CREATE FUNCTION vision_gestion.activer(emetteur text,sujet text,condensat text,notice text,affichage text DEFAULT NULL) RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog,vision_gestion,pg_temp AS $$
DECLARE c comptes; a admissions; resultat jsonb;
BEGIN
 PERFORM 1 FROM configuration WHERE singleton FOR UPDATE;
 SELECT compte.* INTO c FROM identites x JOIN comptes compte USING(utilisateur)
   WHERE x.emetteur=$1 AND x.sujet=$2;
 IF FOUND THEN RETURN compte_public(c); END IF;
 SELECT admission.* INTO a FROM admissions admission JOIN invitations i ON i.id=admission.invitation_id
   WHERE admission.emetteur=$1 AND admission.sujet=$2 AND i.condensat=$3 AND admission.notice_version=$4
   AND admission.validee_a IS NOT NULL AND admission.consommee_a IS NULL AND admission.annulee_a IS NULL
   AND admission.expire_a>now() ORDER BY admission.cree_a LIMIT 1 FOR UPDATE OF admission;
 IF NOT FOUND THEN RAISE EXCEPTION 'admission_requise'; END IF;
 resultat:=activer_allocation($1,$2,$3,$4,$5);
 UPDATE admissions SET consommee_a=now() WHERE id=a.id;
 RETURN resultat;
END $$;

ALTER FUNCTION vision_gestion.administrer(text,text,jsonb) RENAME TO administrer_preavis;
CREATE FUNCTION vision_gestion.administrer(acteur text,op text,p jsonb) RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog,vision_gestion,pg_temp AS $$
DECLARE resultat jsonb; i invitations; places bigint;
BEGIN
 resultat:=administrer_preavis($1,$2,$3);
 IF $2='modifier_invitation' THEN
   SELECT * INTO STRICT i FROM invitations WHERE id=($3->>'id')::uuid;
   SELECT count(*) INTO places FROM admissions WHERE invitation_id=i.id AND expire_a>now()
     AND consommee_a IS NULL AND annulee_a IS NULL;
   IF i.maximum<i.utilise+places THEN RAISE EXCEPTION 'maximum_inferieur_aux_reservations'; END IF;
 END IF;
 RETURN resultat;
END $$;

CREATE OR REPLACE FUNCTION vision_gestion.invitation_publique(i vision_gestion.invitations) RETURNS jsonb
LANGUAGE sql STABLE SET search_path=pg_catalog,vision_gestion,pg_temp AS $$
 SELECT (to_jsonb(i)-'condensat')||jsonb_build_object('en_attente',
   (SELECT count(*) FROM admissions WHERE invitation_id=i.id AND expire_a>now()
     AND consommee_a IS NULL AND annulee_a IS NULL))
$$;
CREATE OR REPLACE FUNCTION vision_gestion.apercu_invitation(condensat text) RETURNS jsonb
LANGUAGE sql STABLE SECURITY DEFINER SET search_path=pg_catalog,vision_gestion,pg_temp AS $$
 SELECT coalesce((SELECT jsonb_build_object('quota_octets',quota_octets,'limites',limites,
   'expire_a',expire_a,'disponible',revoque_a IS NULL AND expire_a>now() AND utilise+
     (SELECT count(*) FROM admissions a WHERE a.invitation_id=i.id AND a.expire_a>now()
       AND a.consommee_a IS NULL AND a.annulee_a IS NULL)<maximum)
   FROM invitations i WHERE i.condensat=$1),jsonb_build_object('disponible',false))
$$;

CREATE FUNCTION vision_gestion.purger_admissions() RETURNS void
LANGUAGE sql SECURITY DEFINER SET search_path=pg_catalog,vision_gestion,pg_temp AS $$
 DELETE FROM admissions a WHERE a.expire_a<now()-interval '30 days' AND
   (a.consommee_a IS NULL OR NOT EXISTS(SELECT FROM identites x WHERE x.emetteur=a.emetteur AND x.sujet=a.sujet))
$$;

REVOKE ALL ON ALL TABLES IN SCHEMA vision_gestion FROM PUBLIC;
REVOKE ALL ON ALL FUNCTIONS IN SCHEMA vision_gestion FROM PUBLIC;
INSERT INTO vision_schema_migrations(version) VALUES(24);
COMMIT;
