-- Exécution postgres, après migrations, avant démarrage des services.
-- Aucun rôle HTTP ne possède les tables, les fonctions privilégiées ou BYPASSRLS.
BEGIN;
DO $$ BEGIN
 IF NOT EXISTS(SELECT FROM pg_roles WHERE rolname='vision_migration') THEN CREATE ROLE vision_migration NOLOGIN; END IF;
 IF NOT EXISTS(SELECT FROM pg_roles WHERE rolname='vision_administration') THEN CREATE ROLE vision_administration LOGIN; END IF;
 IF NOT EXISTS(SELECT FROM pg_roles WHERE rolname='vision_identite') THEN CREATE ROLE vision_identite LOGIN; END IF;
 IF NOT EXISTS(SELECT FROM pg_roles WHERE rolname='vision_cycle') THEN CREATE ROLE vision_cycle LOGIN; END IF;
 IF NOT EXISTS(SELECT FROM pg_roles WHERE rolname='vision_admission') THEN CREATE ROLE vision_admission LOGIN; END IF;
 IF NOT EXISTS(SELECT FROM pg_roles WHERE rolname='vision_fermeture') THEN CREATE ROLE vision_fermeture LOGIN; END IF;
 IF NOT EXISTS(SELECT FROM pg_roles WHERE rolname='vision') THEN CREATE ROLE vision LOGIN; END IF;
END $$;
ALTER ROLE vision_migration NOLOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE NOREPLICATION NOBYPASSRLS;
ALTER ROLE vision NOSUPERUSER NOCREATEDB NOCREATEROLE NOREPLICATION NOBYPASSRLS;
ALTER ROLE vision_administration NOSUPERUSER NOCREATEDB NOCREATEROLE NOREPLICATION NOBYPASSRLS;
ALTER ROLE vision_identite NOSUPERUSER NOCREATEDB NOCREATEROLE NOREPLICATION NOBYPASSRLS;
ALTER ROLE vision_cycle NOSUPERUSER NOCREATEDB NOCREATEROLE NOREPLICATION NOBYPASSRLS;
ALTER ROLE vision_admission NOSUPERUSER NOCREATEDB NOCREATEROLE NOREPLICATION NOBYPASSRLS;
ALTER ROLE vision_fermeture NOSUPERUSER NOCREATEDB NOCREATEROLE NOREPLICATION NOBYPASSRLS;
REVOKE vision_migration FROM vision,vision_administration,vision_identite,vision_cycle,vision_admission,vision_fermeture;
REVOKE ALL ON SCHEMA public FROM PUBLIC,vision,vision_administration,vision_identite,vision_cycle,vision_admission,vision_fermeture;
GRANT USAGE ON SCHEMA public TO vision;
REVOKE ALL ON SCHEMA vision_gestion FROM PUBLIC,vision,vision_administration,vision_identite,vision_cycle,vision_admission,vision_fermeture;
GRANT USAGE ON SCHEMA vision_gestion TO vision,vision_administration,vision_identite,vision_cycle,vision_admission,vision_fermeture;
ALTER SCHEMA vision_gestion OWNER TO vision_migration;
ALTER SCHEMA public OWNER TO vision_migration;
DO $$
DECLARE t record;
BEGIN
 FOR t IN SELECT schemaname,tablename FROM pg_tables WHERE schemaname='vision_gestion'
   OR (schemaname='public' AND tablename LIKE 'vision_%') LOOP
   EXECUTE format('ALTER TABLE %I.%I OWNER TO vision_migration',t.schemaname,t.tablename);
 END LOOP;
 FOR t IN SELECT n.nspname,p.proname,pg_get_function_identity_arguments(p.oid) args
   FROM pg_proc p JOIN pg_namespace n ON n.oid=p.pronamespace
   WHERE n.nspname='vision_gestion' OR (n.nspname='public' AND p.proname LIKE 'vision_%') LOOP
   EXECUTE format('ALTER FUNCTION %I.%I(%s) OWNER TO vision_migration',t.nspname,t.proname,t.args);
 END LOOP;
END $$;
DO $$ BEGIN
 EXECUTE format('ALTER DATABASE %I OWNER TO vision_migration',current_database());
 EXECUTE format('REVOKE ALL ON DATABASE %I FROM PUBLIC',current_database());
 EXECUTE format('REVOKE ALL ON DATABASE %I FROM vision,vision_administration,vision_identite,vision_cycle,vision_admission,vision_fermeture',current_database());
 EXECUTE format('GRANT CONNECT ON DATABASE %I TO vision,vision_administration,vision_identite,vision_cycle,vision_admission,vision_fermeture',current_database());
END $$;
REVOKE ALL ON ALL TABLES IN SCHEMA public FROM vision,vision_administration,vision_identite,vision_cycle,vision_admission,vision_fermeture;
REVOKE ALL ON ALL TABLES IN SCHEMA vision_gestion FROM vision,vision_administration,vision_identite,vision_cycle,vision_admission,vision_fermeture;
REVOKE ALL ON ALL FUNCTIONS IN SCHEMA vision_gestion FROM PUBLIC,vision,vision_administration,vision_identite,vision_cycle,vision_admission,vision_fermeture;
GRANT SELECT ON vision_gestion.comptes TO vision;
GRANT SELECT ON public.vision_schema_migrations TO vision;
GRANT EXECUTE ON FUNCTION vision_gestion.usage(text) TO vision;
GRANT EXECUTE ON FUNCTION vision_gestion.exporter(text,text,integer,bigint),vision_gestion.effacer(text,text) TO vision;
GRANT EXECUTE ON FUNCTION vision_gestion.administrer(text,text,jsonb) TO vision_administration;
GRANT EXECUTE ON FUNCTION vision_gestion.identifier(text,text),vision_gestion.activer(text,text,text,text,text),vision_gestion.notice() TO vision_identite;
GRANT EXECUTE ON FUNCTION vision_gestion.apercu_invitation(text) TO vision_identite;
GRANT EXECUTE ON FUNCTION vision_gestion.reserver_admission(uuid,text,text),
 vision_gestion.certifier_admission(uuid,text,text,text),vision_gestion.annuler_admission(uuid),
 vision_gestion.activer(text,text,text,text,text),vision_gestion.identifier(text,text),vision_gestion.notice() TO vision_admission;
GRANT EXECUTE ON FUNCTION vision_gestion.preavis_a_traiter(),vision_gestion.constater_preavis(uuid,text),
 vision_gestion.engager_effacement(text,uuid),vision_gestion.effacer_cycle(text,text,uuid) TO vision_cycle;
GRANT EXECUTE ON FUNCTION vision_gestion.comptes_identite(text,text),
 vision_gestion.engager_fermeture_identite(text,text,text),
 vision_gestion.effacer_identite_cycle(text,text,text) TO vision_fermeture;
DO $$
DECLARE t record;
BEGIN
 FOR t IN SELECT table_name FROM information_schema.columns WHERE table_schema='public'
   AND column_name='utilisateur' AND table_name LIKE 'vision_%' LOOP
   EXECUTE format('GRANT SELECT,INSERT,UPDATE,DELETE ON public.%I TO vision',t.table_name);
 END LOOP;
END $$;
GRANT USAGE,SELECT ON ALL SEQUENCES IN SCHEMA public TO vision;
-- Le rôle de migration possède les objets, sans pouvoir ouvrir de session.
GRANT USAGE,CREATE ON SCHEMA public TO vision_migration;
GRANT USAGE,SELECT ON ALL SEQUENCES IN SCHEMA public TO vision_migration;
COMMIT;
