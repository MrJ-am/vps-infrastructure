"""Générer les chapitres du tutoriel commun sans recopier les textes dans l’interface."""
import json
from pathlib import Path

RACINE = Path(__file__).resolve().parents[1]


def markdown(section):
    """Composer une section exportable avec les mêmes explications que le web."""
    etapes = [f"{i+1}. **{e['titre']}** — {e['texte']}" for i,e in enumerate(section.get('etapes', []))]
    return '\n\n'.join(['## ' + section['titre'], section['explication'], *etapes,
        section['exemple'], '**À essayer :** ' + section['activite'],
        *([section['complement']] if 'complement' in section else []),
        *([section['calcul']] if 'calcul' in section else [])])


def chaine(texte):
    return json.dumps(texte, ensure_ascii=False)


def generer():
    """Figer les données communes ; l’adresse de connexion est résolue à l’exécution."""
    tutoriel = json.loads((RACINE / 'docs/tutoriel.json').read_text())
    source = '''module Tutoriel exposing (Section, sections)

-- Généré par scripts/contenus.py depuis docs/tutoriel.json.


type alias Section =
    { id : String
    , titre : String
    , explication : String
    , exemple : String
    , activite : String
    , complement : String
    , calcul : String
    , etapes : List { titre : String, texte : String }
    , sources : List { titre : String, url : String }
    }


sections : List Section
sections =
    [ '''
    valeurs=[]
    for s in tutoriel['sections']:
        champs=[f"{k} = {chaine(s.get(k,''))}" for k in ['id','titre','explication','exemple','activite','complement','calcul']]
        champs += ['etapes = [ '+', '.join('{ titre = '+chaine(e['titre'])+', texte = '+chaine(e['texte'])+' }' for e in s.get('etapes',[]))+' ]' if s.get('etapes',[]) else 'etapes = []']
        champs += ['sources = [ '+', '.join('{ titre = '+chaine(e['titre'])+', url = '+chaine(e['url'])+' }' for e in s.get('sources',[]))+' ]' if s.get('sources',[]) else 'sources = []']
        valeurs.append('{ '+', '.join(champs)+' }')
    source += '\n    , '.join(valeurs)+'\n    ]\n'
    (RACINE / 'interface/src/Tutoriel.elm').write_text(source)


if __name__ == '__main__':
    generer()
