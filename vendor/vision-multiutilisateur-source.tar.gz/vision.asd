(asdf:defsystem #:vision
  :description "Authenticated, documented HTTP API for Vision."
  :license "AGPL-3.0-or-later"
  :version "2.7.0"
  :serial t
  :components ((:file "src/package")
               (:file "src/json")
               (:file "src/database")
               (:file "src/embeddings")
               (:file "src/mcp")
               (:file "src/contenus")
               (:file "src/modele")
               (:file "src/browser")
               (:file "src/server")))

