(in-package #:vision)

(setf *mcp-tools* (parse-json (uiop:read-file-string (asdf:system-relative-pathname :vision "docs/outils.json") :external-format :utf-8))
      *instructions-mcp* (concatenate 'string (uiop:read-file-string (asdf:system-relative-pathname :vision "docs/MCP.md") :external-format :utf-8) (string #\Newline) *contrat-pedagogique*))

(defun horodatage-p (texte)
  (and (stringp texte) (<= 20 (length texte) 40)
       (char= (char texte 4) #\-) (char= (char texte 7) #\-)
       (char= (char texte 10) #\T) (char= (char texte 13) #\:)
       (or (char= (char texte (1- (length texte))) #\Z)
           (find-if (lambda (c) (find c "+-")) (subseq texte 19)))
       (every (lambda (c) (or (digit-char-p c) (find c "-+:T.Z"))) texte)))

(defun valider-schema (valeur schema &optional (nom "arguments"))
  ;; Le même schéma borne les trois transports.
  (let* ((type (json-object-get schema "type"))
         (types (if (json-array-p type) (json-array-items type) (list type)))
         (enum (json-object-get schema "enum")))
    (when (and (member "null" types :test #'equal) (eq valeur :null)) (return-from valider-schema valeur))
    (when enum
      (unless (member valeur (json-array-items enum) :test #'equal)
        (invalid-parameters "Valeur non autorisée pour ~A." nom)))
    (cond
      ((member "object" types :test #'equal)
       (ensure-object valeur nom)
       (let* ((proprietes (json-object-get schema "properties"))
              (obligatoires (json-object-get schema "required")))
         (when (eq (json-object-get schema "additionalProperties") :false)
           (validate-object-keys valeur (mapcar #'car (json-object-entries proprietes))))
         (when obligatoires (dolist (cle (json-array-items obligatoires)) (required-value valeur cle)))
         (dolist (entree (json-object-entries valeur))
           (let ((sous-schema (json-object-get proprietes (car entree))))
             (when sous-schema (valider-schema (cdr entree) sous-schema (car entree)))))))
      ((member "array" types :test #'equal)
       (unless (json-array-p valeur) (invalid-parameters "~A doit être un tableau." nom))
       (unless (<= (json-object-get schema "minItems" 0) (length (json-array-items valeur)) (json-object-get schema "maxItems" 50))
         (invalid-parameters "Taille invalide pour ~A." nom))
       (dolist (element (json-array-items valeur)) (valider-schema element (json-object-get schema "items") nom)))
      ((member "integer" types :test #'equal)
       (validated-integer valeur nom (json-object-get schema "minimum" 0) (json-object-get schema "maximum" most-positive-fixnum)))
      ((member "boolean" types :test #'equal)
       (unless (member valeur '(:true :false)) (invalid-parameters "~A doit être un booléen." nom)))
      ((member "string" types :test #'equal)
       (validated-string valeur nom (json-object-get schema "maxLength" 4000))
       (when (< (length valeur) (json-object-get schema "minLength" 0)) (invalid-parameters "~A est trop court." nom))
       (when (equal (json-object-get schema "format") "date-time")
         (unless (horodatage-p valeur) (invalid-parameters "~A exige une date ISO 8601 avec fuseau." nom))))
      (t (invalid-parameters "Type non pris en charge pour ~A." nom))))
  valeur)

(defun operation-vision-base (nom arguments)
  (let ((outil (find nom (json-array-items *mcp-tools*) :test #'string= :key (lambda (o) (json-object-get o "name")))))
    (unless outil (invalid-parameters "Opération inconnue ; recharger tools/list."))
    (valider-schema arguments (json-object-get outil "inputSchema"))
    (unless *utilisateur* (return-from operation-vision-base (jobject "erreur" "identite_requise")))
    (when (string= nom "tutoriel") (return-from operation-vision-base (consulter-tutoriel arguments)))
    (handler-case
        (progn
          (when (string= nom "preparer_creation_item")
            (multiple-value-bind (v modele) (calculer-embedding (json-object-get arguments "contenu"))
              (return-from operation-vision-base
                (database-query-json nom "SELECT vision_preparer_creation_item(:'utilisateur', :'entree'::jsonb, :'embedding'::vector, :'modele')"
                  (list (cons "utilisateur" *utilisateur*) (cons "entree" (json-encode arguments))
                        (cons "embedding" v) (cons "modele" modele))))))
          (when (and (string= nom "enregistrer_item") (json-object-get arguments "id")
                     (json-object-get arguments "contenu"))
            (multiple-value-bind (v modele) (calculer-embedding (json-object-get arguments "contenu"))
              (setf arguments (%make-json-object (append (json-object-entries arguments)
                (list (cons "_embedding" v) (cons "_modele" modele)))))))
        (database-query-json nom
          (cond ((string= nom "rechercher") "SELECT vision_rechercher(:'utilisateur', :'entree'::jsonb)")
                ((string= nom "lire_limites") "SELECT vision_gestion.usage(:'utilisateur')")
                ((string= nom "lire_politique") "SELECT vision_lire_politique(:'utilisateur')")
                ((string= nom "lien_fiche") "SELECT vision_lien_fiche(:'utilisateur', :'entree'::jsonb)")
                ((string= nom "etat_fiche") "SELECT vision_etat_fiche(:'utilisateur', :'entree'::jsonb)")
                ((string= nom "bilan_fiches") "SELECT vision_bilan_fiches(:'utilisateur', :'entree'::jsonb)")
                ((string= nom "lire") "SELECT vision_lire(:'utilisateur', :'entree'::jsonb)")
                ((string= nom "preparer_revision") "SELECT vision_preparer(:'utilisateur', :'entree'::jsonb)")
                ((string= nom "lister_seances") "SELECT vision_lister_seances(:'utilisateur', coalesce((:'entree'::jsonb->>'limite')::integer,20), coalesce((:'entree'::jsonb->>'decalage')::integer,0))")
                ((string= nom "lire_seance") "SELECT vision_lire_seance(:'utilisateur', :'entree'::jsonb)")
                (t "SELECT vision_commande(:'utilisateur', :'operation', :'entree'::jsonb)"))
          (list (cons "utilisateur" *utilisateur*) (cons "operation" nom) (cons "entree" (json-encode arguments)))))
      (embedding-error () (jobject "erreur" "service_embeddings_indisponible"))
      (database-error (condition)
        (jobject "erreur"
          (or (find-if (lambda (code)
                (search (concatenate 'string "ERROR:  " code) (database-error-detail condition)))
              '("quota_depasse" "texte_trop_long" "ligne_trop_longue" "limite_fiches"
                "limite_items_fiche" "invitation_requise" "compte_suspendu"))
            "base_indisponible"))))))

(defun utilisateur-authentifie (headers)
  (let* ((valeurs (header-values "x-mrj-user" headers)) (nom (first valeurs)))
    (and (= (length valeurs) 1) (stringp nom) (<= 1 (length nom) 64)
         (every (lambda (c) (find c "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_.-")) nom)
         nom)))


(defun operation-vision (nom arguments)
  "Valider les transports communs, contrôler l’accès puis composer un lien sans secret."
  (let ((resultat (enrichir-contrat nom (operation-vision-base nom arguments))))
    (when (and (string= nom "lien_fiche") (not (json-object-get resultat "erreur")))
      (let ((base (base-web-configuree)))
        (return-from operation-vision
          (if base
              (jobject "fiche_id" (json-object-get resultat "fiche_id") "prive" :true
                "url" (format nil "~A#fiche/~D" base (json-object-get resultat "fiche_id")))
              (jobject "erreur" "configuration_lien_requise")))))
    resultat))
