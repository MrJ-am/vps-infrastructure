(in-package #:vision)

(defun handle-browser-request (stream path headers body &optional (prefixe "/api/web/"))
  (unless (and *utilisateur*
               (or (string= prefixe "/api/v1/")
                   (equal (header-values "x-vision-browser" headers) '("1"))))
    (write-json stream 401 "Unauthorized" "{\"erreur\":\"identite_requise\"}")
    (return-from handle-browser-request))
  (unless (json-content-type-p headers)
    (write-json stream 415 "Unsupported Media Type" "{\"erreur\":\"json_requis\"}")
    (return-from handle-browser-request))
  (handler-case
      (let* ((nom (subseq path (length prefixe)))
             (arguments (parse-json body))
             (resultat (if (and (string= prefixe "/api/web/")
                               (member nom '("exporter_compte" "effacer_compte") :test #'string=))
                          (droits-personne nom arguments)
                          (operation-vision nom arguments)))
             (erreur (json-object-get resultat "erreur"))
             (statut (cond ((member erreur '("conflit" "conflit_episode" "cle_reutilisee") :test #'equal) 409)
                           ((equal erreur "compte_suspendu") 403)
                           ((member erreur '("introuvable" "seance_introuvable") :test #'equal) 404)
                           ((member erreur '("base_indisponible" "service_embeddings_indisponible" "index_semantique_incomplet") :test #'equal) 503)
                           (erreur 400) (t 200))))
        (write-json stream statut (case statut (200 "OK") (403 "Forbidden") (409 "Conflict") (404 "Not Found") (503 "Service Unavailable") (t "Bad Request"))
                    (json-encode resultat)))
    (json-error () (write-json stream 400 "Bad Request" "{\"erreur\":\"json_invalide\"}"))
    (invalid-parameters (condition)
      (write-json stream 400 "Bad Request" (json-encode (jobject "erreur" "parametres_invalides"
        "message" (invalid-parameters-message condition)))))))

(defun consigner-effacement ()
  ;; L'intention confirmée survit à une restauration de la base. Écriture et
  ;; fsync précèdent le DELETE ; le fichier est privé et hors des dumps SQL.
  ;; En cas de panne après cette étape, la confidentialité prime : la demande
  ;; confirmée est rejouée même si la réponse HTTP n'a pas pu être reçue.
  (let ((chemin (uiop:getenv "VISION_REGISTRE_EFFACEMENTS")))
    (unless (and chemin (plusp (length chemin)))
      (database-fail "Registre d'effacement indisponible." ""))
    (handler-case
        (let* ((fd (sb-posix:open chemin (logior sb-posix:o-wronly sb-posix:o-append sb-posix:o-creat) #o600))
               (flux (sb-sys:make-fd-stream fd :output t :buffering :none :external-format :utf-8 :auto-close t)))
          (unwind-protect
               (progn
                 (write-line (json-encode (jobject "utilisateur" *utilisateur* "confirmee_a" (get-universal-time))) flux)
                 (finish-output flux)
                 (sb-posix:fsync fd)
                 (let ((repertoire (sb-posix:open (directory-namestring chemin) sb-posix:o-rdonly 0)))
                   (unwind-protect (sb-posix:fsync repertoire) (sb-posix:close repertoire))))
            (close flux)))
      (error () (database-fail "Registre d'effacement indisponible." "")))))

(defun droits-personne (nom arguments)
  (ensure-object arguments "arguments")
  (if (string= nom "effacer_compte")
      (progn
        (validate-object-keys arguments '("confirmation"))
        (unless (equal (json-object-get arguments "confirmation") "EFFACER VISION")
          (invalid-parameters "Saisir EFFACER VISION pour confirmer.")))
      (progn
        (validate-object-keys arguments '("table" "debut" "donnees_version"))
        (validated-string (required-value arguments "table") "table" 64)
        (validated-integer (json-object-get arguments "debut" 0) "debut" 0 10000000)
        (when (json-object-get arguments "donnees_version")
          (validated-integer (json-object-get arguments "donnees_version") "donnees_version" 1 most-positive-fixnum))))
  (handler-case
      (progn
       (when (string= nom "effacer_compte") (consigner-effacement))
       (database-query-json nom
        (if (string= nom "effacer_compte")
            "SELECT vision_gestion.effacer(:'utilisateur',:'entree'::jsonb->>'confirmation')"
            "SELECT vision_gestion.exporter(:'utilisateur',:'entree'::jsonb->>'table',coalesce((:'entree'::jsonb->>'debut')::integer,0),(:'entree'::jsonb->>'donnees_version')::bigint)")
        (list (cons "utilisateur" *utilisateur*) (cons "entree" (json-encode arguments)))))
    (database-error () (jobject "erreur" "export_ou_effacement_refuse"))))
