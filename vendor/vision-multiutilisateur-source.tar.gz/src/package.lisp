(require :sb-bsd-sockets)
(require :sb-posix)

(defpackage #:vision
  (:use #:cl)
  (:export #:main
           #:serve))

(in-package #:vision)

(defparameter *version* "2.7.0")
