"""Parcours compte, administration et invitation sur des réponses synthétiques.

Les permissions SQL sont vérifiées séparément dans tests/comptes.py.
"""
from functools import partial
from http.server import SimpleHTTPRequestHandler,ThreadingHTTPServer
import json
import os
from pathlib import Path
import threading
import tempfile
import xml.etree.ElementTree as ET
from playwright.sync_api import sync_playwright,expect

ROOT=Path(__file__).resolve().parents[1]
LIMITES=dict(fiches=1000,items_par_fiche=500,mots_item=500,octets_item=8000,mots_fiche=2000,octets_fiche=32000,mots_note=200,octets_note=2000)
NOTICE=dict(responsable='Responsable synthétique',contact='test@example.test',pays_hebergement='France',version='test',sauvegardes_jours=30,inscriptions_ouvertes=True)
COMPTE=dict(utilisateur='test-compte',affichage='Compte synthétique',administrateur=False,actif=True,quota_octets=10000000,utilise_octets=4000000,fiches=12,items=24,limites=LIMITES,version=1)

class Serveur(SimpleHTTPRequestHandler):
    def log_message(self,*args):pass
    def do_GET(self):
        if self.path.split('?')[0] in ('/invitation','/connexion','/privacy','/admission'):self.path='/app.html'
        super().do_GET()

def verifier(browser,url,largeur):
    ctx=browser.new_context(viewport=dict(width=largeur,height=900),accept_downloads=True)
    page=ctx.new_page();page.set_default_timeout(5000);appels=[];connecte=False
    def api(route):
        nonlocal connecte
        op=route.request.url.rsplit('/',1)[-1];p=route.request.post_data_json if route.request.method=='POST' else {}
        appels.append((op,p))
        if op=='configuration':r=dict(mode='oidc',compte='https://log.mrj.am/realms/mrjam/account/',notice=NOTICE)
        elif op=='session':
            if not connecte:return route.fulfill(status=401,json={'error':'authentication_required'})
            r=dict(username='test-admin',csrf='test-local',administrateur=True,verificationRenforcee=True)
        elif op=='lire_limites':r={**COMPTE,'depassement':False}
        elif op=='lister_comptes':r=dict(comptes=[COMPTE],total=1)
        elif op=='modifier_compte':
            assert p['utilisateur']=='test-compte' and p['quota_octets']==15000000 and p['administrateur'] is True
            r={**COMPTE,**p,'version':2}
        elif op=='demander_suppression':
            assert p=={'utilisateur':'test-compte','version':2}
            r={**COMPTE,'administrateur':True,'quota_octets':15000000,'version':3,
               'suppression':dict(id='preavis-synthetique',etat_courriel='attente',annule_a=None,echeance_a=None)}
        elif op=='annuler_suppression':
            assert p=={'utilisateur':'test-compte','version':3}
            r={**COMPTE,'administrateur':True,'quota_octets':15000000,'version':4,
               'suppression':dict(id='preavis-synthetique',etat_courriel='attente',annule_a='2026-10-08T12:00:00Z',echeance_a=None)}
        elif op=='lister_invitations':r=dict(invitations=[],total=0)
        elif op=='creer_invitation':
            assert p['maximum']==30 and p['quota_octets']==15000000 and p['expire_a']=='2026-12-31T23:59Z'
            r={**p,'id':'11111111-1111-4111-8111-111111111111','utilise':0,'version':1,'lien':url+'/invitation#'+'a'*43}
        elif op=='invitation':
            assert p=={'invitation':'a'*43};r=dict(disponible=True,quota_octets=15000000,limites=LIMITES)
        elif op=='admission':
            assert p==dict(invitation='a'*43,notice='test',courriel='jeune@example.test',pays='France',age='moins15',parent='parent@example.test',pseudonyme='Test')
            r=dict(demande_enregistree=True,information='Vérifiez votre boîte de courrier. La validation parentale reste nécessaire.')
        elif op=='apercu':
            assert p=={'token':'b'*43};r={'type':'parent'}
        elif op=='confirmer':
            assert p=={'token':'b'*43,'acceptation':True};r=dict(confirmee=True,information='Confirmation enregistrée. Vérification manuelle avant admission.')
        elif op=='effacer_compte':
            assert p=={'confirmation':'EFFACER VISION'};r={'efface':True}
        elif op=='exporter_compte':
            tables={'vision_fiches':[dict(id=1,titre='Fiche choisie',contenu='Connaissance choisie',suivi='Suivi exclu'),dict(id=2,titre='Autre fiche',contenu='Contenu non sélectionné')],
                    'vision_items':[dict(id=10,titre='Item lié',contenu='Texte utile\nSeconde ligne',suivi='Suivi exclu',stabilite=-15),dict(id=11,titre='Item seul',contenu='Sans fiche')],
                    'vision_liens':[dict(fiche_id=1,item_id=10,ordre=0)]}
            r=dict(lignes=tables.get(p['table'],[]),suite=False,donnees_version=1)
        else:raise AssertionError('Appel inattendu : '+op)
        route.fulfill(status=200,json=r)
    page.route('**/auth/**',api);page.route('**/api/**',api)
    page.goto(url);page.get_by_role('button',name='Ouvrir le menu',exact=True).click()
    expect(page.get_by_role('link',name='Se connecter',exact=True)).to_be_visible()
    # Les variables OKLCH sont héritées jusque dans les composants et modales.
    accent=page.get_by_role('link',name='Découvrir Vision',exact=True).evaluate('e=>getComputedStyle(e).getPropertyValue("--mrjam-accent")')
    assert '227.507' in accent,accent
    couleurs=page.evaluate('''() => {
      const e=document.querySelector('a[href="/docs#connexion-mcp"]');
      const s=getComputedStyle(e),canvas=document.createElement('canvas');canvas.width=1;canvas.height=1;
      const c=canvas.getContext('2d');let r={};
      for(const nom of ['encre','discret','accent','accentSurvol','danger','surface','papier','doux','controle']){
        c.fillStyle=s.getPropertyValue('--mrjam-'+nom).trim();c.fillRect(0,0,1,1);r[nom]=[...c.getImageData(0,0,1,1).data].slice(0,3);
      }return r;
    }''')
    def luminance(rgb):
        valeurs=[v/255 for v in rgb];lineaires=[v/12.92 if v<=.04045 else ((v+.055)/1.055)**2.4 for v in valeurs]
        return sum(v*p for v,p in zip(lineaires,(.2126,.7152,.0722)))
    def contraste(a,b):
        x,y=sorted((luminance(couleurs[a]),luminance(couleurs[b])));return (y+.05)/(x+.05)
    for encre in ('encre','discret'):
        for fond in ('surface','papier','doux'):assert contraste(encre,fond)>=4.5,(encre,fond,contraste(encre,fond))
    for action in ('accent','accentSurvol','danger'):assert contraste(action,'surface')>=4.5,(action,contraste(action,'surface'))
    assert contraste('controle','surface')>=3
    connecte=True;page.goto(url+'/#compte');page.reload()
    expect(page.get_by_role('heading',name='Mon compte et mes limites',exact=True)).to_be_visible()
    expect(page.get_by_role('link',name='Sécurité et identité de mon compte commun',exact=True)).to_have_attribute('href','https://log.mrj.am/realms/mrjam/account/')
    expect(page.get_by_text('4 Mo utilisés sur 10 Mo autorisés.',exact=False)).to_be_visible()
    expect(page.get_by_text('Un item : 500 mots',exact=False)).to_be_visible()
    with page.expect_download() as telechargement:page.get_by_role('button',name='Exporter mes données',exact=True).click()
    assert telechargement.value.suggested_filename.endswith('.json')
    expect(page.get_by_role('button',name='Exporter mes données',exact=True)).to_be_visible()
    page.get_by_label('Format de l’export',exact=True).select_option('markdown')
    page.get_by_role('checkbox',name='Toutes mes fiches et tous mes items',exact=True).click()
    expect(page.get_by_role('button',name='Sélectionnez au moins une fiche',exact=True)).to_be_disabled()
    page.get_by_role('checkbox',name='Fiche choisie',exact=True).click()
    with page.expect_download() as telechargement:page.get_by_role('button',name='Exporter mes données',exact=True).click()
    with tempfile.TemporaryDirectory() as temporaire:
        chemin=Path(temporaire)/'connaissances.md';telechargement.value.save_as(chemin)
        texte=chemin.read_text()
        assert 'Fiche choisie' in texte and '- **Item lié**' in texte and '  Seconde ligne' in texte
        assert all(s not in texte for s in ('Suivi exclu','stabilite','Autre fiche','Contenu non sélectionné','Item seul'))
    page.get_by_label('Format de l’export',exact=True).select_option('xml')
    with page.expect_download() as telechargement:page.get_by_role('button',name='Exporter mes données',exact=True).click()
    with tempfile.TemporaryDirectory() as temporaire:
        chemin=Path(temporaire)/'donnees.xml';telechargement.value.save_as(chemin)
        racine=ET.parse(chemin).getroot()
        assert racine.tag=='vision' and 'Suivi exclu' in ''.join(racine.itertext())
    page.goto(url+'/#administration')
    expect(page.get_by_role('table',name='Utilisateurs et utilisatrices',exact=True)).to_be_visible()
    page.get_by_role('button',name='Modifier',exact=True).click()
    page.get_by_label('Administrateur / administratrice',exact=True).select_option('oui')
    page.get_by_label('Quota strict en Mo (1 Mo = 1 000 000 octets)',exact=True).fill('15')
    page.get_by_role('button',name='Enregistrer les limites',exact=True).click()
    expect(page.get_by_role('cell',name='Administration',exact=True)).to_be_visible()
    page.get_by_role('button',name='Préparer la suppression de ce compte Vision',exact=True).click()
    expect(page.get_by_text('Engager la suppression de Vision',exact=False)).to_be_visible()
    page.get_by_role('button',name='Confirmer le préavis de trente jours',exact=True).click()
    expect(page.get_by_text('Le courriel de préavis est en attente.',exact=False)).to_be_visible()
    page.get_by_role('button',name='Annuler la suppression prévue',exact=True).click()
    expect(page.get_by_role('button',name='Préparer la suppression de ce compte Vision',exact=True)).to_be_visible()
    page.get_by_role('button',name='Invitations',exact=True).click()
    page.get_by_role('button',name='Créer une invitation',exact=True).click()
    page.get_by_label('Intitulé, par exemple Instagram',exact=True).fill('Instagram')
    page.get_by_label('Nombre maximal d’inscriptions',exact=True).fill('30')
    page.get_by_label('Quota strict en Mo (1 Mo = 1 000 000 octets)',exact=True).fill('15')
    page.get_by_label('Date et heure d’expiration (UTC)',exact=True).fill('2026-12-31T23:59')
    page.get_by_role('button',name='Enregistrer les limites',exact=True).click()
    expect(page.get_by_role('heading',name='Votre lien d’invitation',exact=True)).to_be_visible()
    assert all(op not in ('lire','rechercher') for op,_ in appels),appels
    # Les libellés longs restent dans leur colonne, même avec un tableau défilant.
    assert page.get_by_role('columnheader').evaluate_all('''es => es.every(e => {
      const limites=e.getBoundingClientRect(),textes=document.createTreeWalker(e,NodeFilter.SHOW_TEXT);
      while(textes.nextNode()){
        const plage=document.createRange();plage.selectNodeContents(textes.currentNode);
        for(const r of plage.getClientRects())if(r.width>0 && (r.left<limites.left-1 || r.right>limites.right+1))return false;
      }return true;
    })''')
    page.screenshot(path=str(ROOT/'rapports'/f'administration-{largeur}.png'),full_page=True)
    page.goto(url+'/invitation#'+'a'*43)
    expect(page.get_by_text('Ce lien accorde 15 Mo',exact=False)).to_be_visible()
    assert not any(op=='inscription' for op,_ in appels)
    page.get_by_label('Votre adresse de courrier',exact=True).fill('jeune@example.test')
    page.get_by_label('Pseudonyme (facultatif)',exact=True).fill('Test')
    page.get_by_label('Pays de résidence',exact=True).fill('France')
    page.get_by_label('Votre tranche d’âge',exact=True).select_option('moins15')
    page.get_by_label('Adresse d’un représentant légal (obligatoire avant 15 ans en France)',exact=True).fill('parent@example.test')
    page.get_by_role('checkbox',name='J’ai pris connaissance de la notice de confidentialité.',exact=True).click()
    page.get_by_role('button',name='Demander mon accès',exact=True).click()
    expect(page.get_by_text('Vérifiez votre boîte de courrier.',exact=False)).to_be_visible()
    assert page.evaluate('document.documentElement.scrollWidth<=innerWidth+1')
    page.screenshot(path=str(ROOT/'rapports'/f'invitation-{largeur}.png'),full_page=True)
    page.goto(url+'/admission#'+'b'*43)
    expect(page.get_by_text('Vous confirmez autoriser le jeune concerné',exact=False)).to_be_visible()
    page.get_by_role('button',name='Enregistrer ma confirmation',exact=True).click()
    assert not any(op=='confirmer' for op,_ in appels)
    page.get_by_role('checkbox',name='J’ai lu la notice, je suis le représentant légal et j’autorise cet usage.',exact=True).click()
    page.get_by_role('button',name='Enregistrer ma confirmation',exact=True).click()
    expect(page.get_by_text('Confirmation enregistrée. Vérification manuelle avant admission.',exact=True)).to_be_visible()
    assert page.evaluate('document.documentElement.scrollWidth<=innerWidth+1')
    ctx.close()

if __name__=='__main__':
    (ROOT/'rapports').mkdir(exist_ok=True)
    s=ThreadingHTTPServer(('127.0.0.1',0),partial(Serveur,directory=str(ROOT/'dist')));threading.Thread(target=s.serve_forever,daemon=True).start()
    try:
        with sync_playwright() as pw:
            b=pw.chromium.launch(**({'executable_path':os.environ['CHROMIUM']} if 'CHROMIUM' in os.environ else {}))
            for largeur in (320,1440):verifier(b,f'http://127.0.0.1:{s.server_port}',largeur)
            b.close()
        print('Compte, limites, exports JSON/XML/Markdown sélectif, promotion, invitation et OKLCH : deux largeurs réussies.')
    finally:s.shutdown()
