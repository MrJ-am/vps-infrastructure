"""Capturer le vrai rendu avec une API de lecture et des connaissances fictives.
Les images de présentation ne consultent aucun compte ou contenu de production.
"""
from functools import partial
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
import math
import os
import threading
from PIL import Image
from playwright.sync_api import sync_playwright, expect

RACINE = Path(__file__).resolve().parents[1]

class Silencieux(SimpleHTTPRequestHandler):
    def log_message(self,*_): pass
    def do_GET(self):
        if self.path == '/': self.path='/app.html'
        super().do_GET()

def main():
    items = [dict(id=i+101, contenu=contenu, stabilite=stabilite, version=1, evalue=True,
        reference_a='2026-10-01T10:00:00Z', evalue_a='2026-10-01T10:00:00Z',
        statut=statut, fenetre=dict(etat='calculee', debut=debut, fin=fin), nombre_fiches=1, fiches=[])
        for i,(contenu,stabilite,statut,debut,fin) in enumerate([
            ('Erevan est la capitale de l’Arménie.', -10,'dans_fenetre','2026-10-08T10:00:00Z','2026-10-12T10:00:00Z'),
            ('Tbilissi est la capitale de la Géorgie.', -7,'a_venir','2026-10-15T10:00:00Z','2026-10-24T10:00:00Z'),
            ('Tokyo est la capitale du Japon.', 0,'a_venir','2026-12-12T10:00:00Z','2027-01-22T10:00:00Z')])]
    fiche = dict(id=1,titre='Capitales de l’Asie',contenu='Retrouver les capitales et les pays dans les deux sens.\n\nUne question à la fois. Répondre avec ses mots.',
                 priorite=0,version=1,suivi='',items=items,nombre_items=3,nombre_items_filtres=3)
    def api(route):
        op=route.request.url.rsplit('/',1)[-1]
        if op=='session': resultat=dict(username='demonstration-fictive',csrf='lecture-fictive')
        elif op=='rechercher':
            objets=items if route.request.post_data_json['type']=='item' else [fiche]
            resultat=dict(resultats=objets,total=len(objets),politique={})
        elif op=='lire': resultat=dict(objets=[fiche])
        else: raise AssertionError('Aucune écriture autorisée pour les captures : '+op)
        route.fulfill(status=200,json=resultat)
    serveur=ThreadingHTTPServer(('127.0.0.1',0),partial(Silencieux,directory=str(RACINE/'dist')))
    threading.Thread(target=serveur.serve_forever,daemon=True).start()
    try:
        with sync_playwright() as pw:
            navigateur=pw.chromium.launch(**({'executable_path':os.environ['CHROMIUM']} if 'CHROMIUM' in os.environ else {}))
            page=navigateur.new_page(viewport=dict(width=1200,height=740),device_scale_factor=1)
            page.route('**/auth/session',api);page.route('**/api/web/**',api)
            page.goto(f'http://127.0.0.1:{serveur.server_port}/#fiche/1')
            expect(page.get_by_role('heading',name='Capitales de l’Asie',exact=True)).to_be_visible()
            page.evaluate('document.fonts.ready')
            for nom in ['fiche','items']:
                if nom=='items':
                    page.get_by_role('button',name='Items',exact=True).click()
                    expect(page.get_by_role('table',name='Résultats',exact=True).get_by_role('row')).to_have_count(4)
                image=RACINE/'rapports'/('presentation-'+nom+'.png')
                image.parent.mkdir(exist_ok=True)
                limites=page.get_by_role('main').bounding_box()
                page.set_viewport_size(dict(width=1200,height=math.ceil(limites['y']+limites['height']+24)))
                page.screenshot(path=str(image),full_page=True)
                Image.open(image).save(RACINE/'visuels'/(nom+'.webp'),'WEBP',quality=90,method=6)
            navigateur.close()
    finally:serveur.shutdown()
    print('Deux captures de Vision produites. Données fictives ; aucune écriture.')

if __name__=='__main__': main()
