/* Transport de l'interface : aucune présentation, donnée persistée ou règle pédagogique. */
(() => {
  'use strict';
  if (location.pathname === '/docs/') history.replaceState(null, '', '/docs' + location.hash);
  const application = Elm.Main.init({node: document.getElementById('application'),
    flags: {cle: crypto.randomUUID(), instant: new Date().toISOString(), adresse: location.hash, chemin: location.pathname}});
  window.addEventListener("hashchange", () => application.ports.adresse.send(location.hash));
  const requetes = new Map();
  const chemins = new Set(['/auth/session', '/auth/login', '/auth/logout', '/auth/inscription', '/auth/invitation', '/auth/admission', '/auth/admission/apercu', '/auth/admission/confirmer',
    ...['lister_comptes','lister_invitations','modifier_compte','creer_invitation','modifier_invitation','demander_suppression','annuler_suppression'].map(n => `/api/gestion/${n}`),
    '/api/web/effacer_compte', '/api/web/exporter_compte',
    ...['rechercher', 'lire', 'preparer_creation_item', 'preparer_revision', 'enregistrer_fiche', 'enregistrer_item',
      'lire_limites', 'lire_politique', 'lier_item', 'evaluer_items', 'enregistrer_contexte', 'regler_politique'].map(n => `/api/web/${n}`)]);
  let protege = false;
  fetch('/auth/configuration', {credentials: 'omit', cache: 'no-store', redirect: 'error'})
    .then(r => r.ok ? r.json() : {}).then(auth => application.ports.configuration.send({auth}))
    .catch(() => {});
  if (['/docs', '/docs/'].includes(location.pathname)) {
    // Cette lecture publique ne consulte ni la session ni les données du compte.
    fetch('/mcp-config.json', {credentials: 'omit', cache: 'no-store', redirect: 'error'})
      .then(r => r.ok ? r.json() : {}).then(c => application.ports.configuration.send(c))
      .catch(() => application.ports.configuration.send({}));
  }

  application.ports.requete.subscribe(async demande => {
    const numero = demande.numero;
    const controle = new AbortController();
    requetes.set(numero, controle);
    const minuterie = setTimeout(() => controle.abort(), 30000);
    let statut = 0;
    let corps = {error: 'transport_indisponible'};
    try {
      if (!chemins.has(demande.chemin)
          || demande.methode !== (demande.chemin === '/auth/session' ? 'GET' : 'POST')) {
        throw new Error('contrat_invalide');
      }
      if (demande.chemin.startsWith('/api/web/') && !demande.csrf) throw new Error('csrf_required');
      const entetes = {Accept: 'application/json'};
      if (demande.methode === 'POST') entetes['Content-Type'] = 'application/json';
      if (demande.csrf) entetes['X-CSRF-Token'] = demande.csrf;
      const resultat = await fetch(demande.chemin, {
        method: demande.methode, credentials: 'same-origin', cache: 'no-store',
        redirect: 'error', headers: entetes, signal: controle.signal,
        body: demande.methode === 'POST' ? JSON.stringify(demande.corps) : undefined
      });
      statut = resultat.status;
      try { corps = await resultat.json(); }
      catch { corps = {error: 'reponse_inattendue'}; if (resultat.ok) statut = 502; }
    } catch (erreur) {
      if (['date_invalide', 'csrf_required', 'contrat_invalide'].includes(erreur.message)) {
        statut = 400;
        corps = {error: erreur.message};
      }
    } finally {
      clearTimeout(minuterie);
      // Une expiration/déconnexion retire les requêtes, y compris leurs réponses tardives.
      if (requetes.delete(numero)) application.ports.reponse.send({numero, statut, corps});
    }
  });

  application.ports.effets.subscribe(({nom, valeur}) => {
    if (nom === 'redirection') {
      const cible = new URL(valeur, location.origin);
      if (cible.origin === location.origin && cible.pathname === '/') location.assign(cible.href);
      else if (cible.origin === 'https://compte.mrj.am' && cible.pathname === '/realms/mrjam/protocol/openid-connect/auth') location.assign(cible.href);
    }
    if (nom === 'exporter') exporter(valeur);
    if (nom === 'adresse') history.replaceState(null, '', location.pathname + location.search + valeur);
    if (nom === 'proteger') protege = valeur === true;
    if (nom === 'annulerRequetes') {
      for (const controle of requetes.values()) controle.abort();
      requetes.clear();
    }
    if (nom === 'copier') {
      if (typeof valeur === 'string' && /^https?:\/\//.test(valeur) && navigator.clipboard) {
        navigator.clipboard.writeText(valeur).then(() => application.ports.copie.send(true))
          .catch(() => application.ports.copie.send(false));
      } else application.ports.copie.send(false);
    }
    if (nom === 'focus') {
      requestAnimationFrame(() => requestAnimationFrame(() => {
        const zone = document.getElementById(valeur);
        // Ne pas voler le focus si la personne a déjà commencé sa saisie.
        if (!zone || zone.contains(document.activeElement)) return;
        const cible = ['connexion', 'edition', 'correction'].includes(valeur)
          ? zone.querySelector('input,textarea') || zone
          : zone.querySelector('[role="heading"],h1,h2,h3') || zone;
        cible.focus();
      }));
    }
  });

  async function exporter(options) {
    const controle = new AbortController();
    requetes.set('export', controle);
    const tables = ['vision_profils','vision_fiches','vision_items','vision_liens','vision_episodes',
      'vision_journal','vision_requetes','vision_recherches','vision_contextes','vision_migrations_metier',
      'vision_seances','vision_observations','vision_embeddings','vision_preparations_items',
      'vision_memory_sheets','vision_memory_observations','vision_observation_corrections','vision_sheet_edits','vision_scheduler_settings','comptes','identites'];
    const donnees = {format: 'Vision — export personnel', date: new Date().toISOString(), tables: {}};
    let version;
    try {
      if (!options || !['json','xml','markdown'].includes(options.format) || !options.csrf) throw new Error('export_invalide');
      const aLire = options.format === 'markdown' ? ['vision_fiches','vision_items','vision_liens'] : tables;
      for (const table of aLire) {
        donnees.tables[table] = [];
        for (let debut = 0; ; debut += 100) {
          const response = await fetch('/api/web/exporter_compte', {method: 'POST',credentials: 'same-origin',
            redirect: 'error',cache: 'no-store', signal: controle.signal,
            headers: {'Content-Type':'application/json','X-CSRF-Token':options.csrf},
            body: JSON.stringify({table,debut,...(version ? {donnees_version:version} : {})})});
          if (!response.ok) throw new Error('export_refuse');
          const page = await response.json();
          if (page.erreur || !Array.isArray(page.lignes) || !Number.isSafeInteger(page.donnees_version)) throw new Error('export_refuse');
          version = page.donnees_version;
          donnees.tables[table].push(...page.lignes);
          if (!page.suite) break;
        }
      }
      const type = options.format === 'markdown' ? 'md' : options.format;
      const contenu = type === 'md' ? ExportsVision.markdown(donnees.tables,options.toutes ? null : options.fiches)
        : type === 'xml' ? ExportsVision.xml(donnees) : JSON.stringify(donnees,null,2);
      {
        const url = URL.createObjectURL(new Blob([contenu],{type:(type === 'xml' ? 'application/xml' : type === 'json' ? 'application/json' : 'text/markdown') + ';charset=utf-8'}));
        const lien = document.createElement('a');lien.href=url;lien.download=`vision-${donnees.date.slice(0,10)}.${type}`;
        lien.click();setTimeout(() => URL.revokeObjectURL(url),1000);
      }
      application.ports.exportation.send({reussi:true});
    } catch { if (!controle.signal.aborted) application.ports.exportation.send({reussi:false}); }
    finally { requetes.delete('export'); }
  }
  window.addEventListener('beforeunload', evenement => {
    if (protege) { evenement.preventDefault(); evenement.returnValue = ''; }
  });
})();

