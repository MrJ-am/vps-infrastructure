module Compte exposing (Message(..), Modele, actualiser, initial, recevoir, vue)

import Contrat as C
import Element exposing (Element)
import Json.Encode as E exposing (Value)
import MrJam
import MrJam.Documents as Documents


type alias Modele =
    { format : String, toutes : Bool, selection : List Int, fiches : List Value, debut : Int, suite : Bool }


type Message
    = Format String
    | Toutes Bool
    | Choisir Int Bool
    | Page Int
    | Exporter
    | Effacer


initial : Modele
initial =
    { format = "json", toutes = True, selection = [], fiches = [], debut = 0, suite = False }


actualiser : Message -> Modele -> Modele
actualiser message m =
    case message of
        Format format ->
            { m | format = format }

        Toutes toutes ->
            { m | toutes = toutes }

        Choisir id oui ->
            { m
                | selection =
                    if oui then
                        id :: List.filter ((/=) id) m.selection

                    else
                        List.filter ((/=) id) m.selection
            }

        Page debut ->
            { m | debut = max 0 debut, fiches = [] }

        _ ->
            m


recevoir : Value -> Modele -> Modele
recevoir page m =
    { m | fiches = C.listes "lignes" page, suite = C.vrai "suite" page }


vue : Value -> String -> Bool -> Modele -> List (Element Message)
vue usage identite exportEnCours export =
    let
        limites =
            C.objet "limites" usage

        n cle =
            String.fromInt (C.entier cle limites)

        mo cle =
            String.fromFloat (toFloat (C.entier cle usage) / 1000000)
    in
    [ Documents.document "Mon compte et mes limites"
        [ MrJam.paragraphe (mo "utilise_octets" ++ " Mo utilisés sur " ++ mo "quota_octets" ++ " Mo autorisés. 1 Mo = 1 000 000 octets.")
        , if C.vrai "depassement" usage then
            MrJam.avis MrJam.Avertissement "Votre allocation a diminué. Vos données sont conservées ; les ajouts sont bloqués jusqu’au retour sous le quota. La lecture, l’export et l’effacement restent disponibles."

          else
            Element.none
        , MrJam.paragraphe (String.fromInt (C.entier "fiches" usage) ++ " fiches et " ++ String.fromInt (C.entier "items" usage) ++ " items, archives incluses.")
        , MrJam.paragraphe ("Jusqu’à " ++ n "fiches" ++ " fiches et " ++ n "items_par_fiche" ++ " items par fiche.")
        , MrJam.paragraphe ("Un item : " ++ n "mots_item" ++ " mots et " ++ n "octets_item" ++ " octets au maximum. Une fiche : " ++ n "mots_fiche" ++ " mots et " ++ n "octets_fiche" ++ " octets au maximum.")
        , MrJam.paragraphe ("Une note : " ++ n "mots_note" ++ " mots et " ++ n "octets_note" ++ " octets au maximum. Les assistants sont invités à viser 80 à 120 mots.")
        , MrJam.texteSecondaire "Les deux plafonds de texte s’appliquent ensemble. Les mots sont séparés par des espaces. L’UTF-8 peut utiliser plusieurs octets par caractère."
        , MrJam.paragraphe "L’espace comprend les textes, les notes, les historiques, les copies temporaires et les données dérivées, y compris les vecteurs. Il est compté en UTF-8 non compressé avec un forfait de 256 octets par ligne. L’archivage conserve les données et l’espace utilisé."
        , MrJam.texteSecondaire "Ce quota mesure vos données selon une règle stable. Les fichiers physiques de la base, ses index et ses sauvegardes occupent aussi un espace partagé, surveillé séparément par l’exploitation."
        ]
    , Documents.section "Mes données"
        [ MrJam.paragraphe "Choisissez le format de l’export. JSON et XML contiennent toutes vos données personnelles Vision, y compris les historiques. Le Markdown conserve les connaissances, sans le suivi ni les données de révision. Suspendez les modifications et les assistants pendant l’export."
        , MrJam.selecteur "Format de l’export" [ ( "json", "JSON — toutes mes données" ), ( "xml", "XML — toutes mes données" ), ( "markdown", "Markdown — mes connaissances" ) ] export.format Format
        , if export.format == "markdown" then
            Documents.section "Fiches à exporter"
                ([ MrJam.caseACocher "Toutes mes fiches et tous mes items" export.toutes Toutes ]
                    ++ (if export.toutes then
                            []

                        else
                            List.map (\f -> MrJam.caseACocher (C.chaine "titre" f) (List.member (C.entier "id" f) export.selection) (Choisir (C.entier "id" f))) export.fiches
                                ++ [ MrJam.texteSecondaire (String.fromInt (List.length export.selection) ++ " fiches sélectionnées.")
                                   , if export.debut > 0 then
                                        MrJam.bouton "Fiches précédentes" (Page (export.debut - 100))

                                     else
                                        Element.none
                                   , if export.suite then
                                        MrJam.bouton "Fiches suivantes" (Page (export.debut + 100))

                                     else
                                        Element.none
                                   ]
                       )
                )

          else
            Element.none
        , if exportEnCours then
            MrJam.boutonInactif "Export en cours…"

          else if export.format == "markdown" && not export.toutes && List.isEmpty export.selection then
            MrJam.boutonInactif "Sélectionnez au moins une fiche"

          else
            MrJam.bouton "Exporter mes données" Exporter
        , MrJam.lien "Notice de confidentialité et droits" "/privacy"
        , if identite == "" then
            Element.none

          else
            MrJam.lien "Sécurité et identité de mon compte commun" identite
        , MrJam.paragraphe "Effacer Vision supprime vos contenus et votre accès à cet outil. Votre identité commune et les données des autres outils sont conservées. Pour fermer vous-même votre compte commun, ouvrez Sécurité et identité, puis la suppression du compte : une nouvelle authentification et une confirmation explicite sont nécessaires. Exportez d’abord les données souhaitées."
        , MrJam.boutonDestructif "Effacer mon compte Vision" Effacer
        ]
    , let
        preavis =
            C.objet "suppression" usage
      in
      if preavis /= E.null && C.chaine "annule_a" preavis == "" then
        Documents.section "Préavis de suppression"
            [ MrJam.avis MrJam.Avertissement
                (if C.chaine "echeance_a" preavis == "" then
                    "Une suppression administrative a été demandée. Le courriel de préavis n’est pas encore confirmé ; le délai n’a pas commencé. Vous pouvez exporter vos données."

                 else
                    "Une suppression administrative est prévue à partir du " ++ C.chaine "echeance_a" preavis ++ ". Vous conservez la lecture et l’export pendant le préavis. Pour contester ou demander de l’aide, utilisez le contact de la notice."
                )
            ]

      else
        Element.none
    ]
