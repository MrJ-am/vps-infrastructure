module Gestion exposing (Message(..), Modele, actualiser, initial, recevoir, vue)

import Contrat as C
import Dict exposing (Dict)
import Element exposing (Element)
import Json.Encode as E exposing (Value)
import MrJam
import MrJam.Documents as Documents
import MrJam.Donnees as Donnees
import MrJam.Tableaux as Tableaux


type alias Modele =
    { volet : String, lignes : List Value, total : Int, debut : Int, selection : Maybe Value, champs : Dict String String, lien : String, confirmerSuppression : Bool }


type Message
    = Volet String
    | Page Int
    | Choisir Value
    | Nouveau
    | Saisir String String
    | Sauver
    | Revoquer
    | Preavis
    | ConfirmerPreavis
    | AnnulerPreavis


initial : Modele
initial =
    { volet = "comptes", lignes = [], total = 0, debut = 0, selection = Nothing, champs = Dict.empty, lien = "", confirmerSuppression = False }


limites : List ( String, String, Int )
limites =
    [ ( "fiches", "Fiches, archives incluses", 1000 )
    , ( "items_par_fiche", "Items par fiche", 500 )
    , ( "mots_item", "Mots par item", 500 )
    , ( "octets_item", "Octets par item", 8000 )
    , ( "mots_fiche", "Mots par fiche", 2000 )
    , ( "octets_fiche", "Octets par fiche", 32000 )
    , ( "mots_note", "Mots par note", 200 )
    , ( "octets_note", "Octets par note", 2000 )
    ]


valeur : String -> Modele -> String
valeur cle m =
    Dict.get cle m.champs |> Maybe.withDefault ""


charger : Value -> Dict String String
charger v =
    Dict.fromList
        ([ ( "quota", String.fromFloat (toFloat (C.entier "quota_octets" v) / 1000000) )
         , ( "intitule", C.chaine "intitule" v )
         , ( "maximum", String.fromInt (C.entier "maximum" v) )
         , ( "expire_a", String.left 19 (String.replace "Z" "" (C.chaine "expire_a" v)) )
         , ( "administrateur"
           , if C.vrai "administrateur" v then
                "oui"

             else
                "non"
           )
         , ( "actif"
           , if C.vrai "actif" v then
                "oui"

             else
                "non"
           )
         , ( "retroactif", "oui" )
         ]
            ++ List.map
                (\( k, _, defaut ) ->
                    ( k
                    , String.fromInt
                        (if v == E.null then
                            defaut

                         else
                            C.entier k (C.objet "limites" v)
                        )
                    )
                )
                limites
        )


actualiser : Message -> Modele -> ( Modele, Maybe ( String, Value ) )
actualiser message m =
    case message of
        Volet volet ->
            ( { initial | volet = volet }, Just ( "lister_" ++ volet, E.object [] ) )

        Page debut ->
            ( { m | debut = max 0 debut, selection = Nothing }, Just ( "lister_" ++ m.volet, E.object [ ( "debut", E.int (max 0 debut) ) ] ) )

        Choisir v ->
            ( { m | selection = Just v, champs = charger v, confirmerSuppression = False }, Nothing )

        Preavis ->
            ( { m | confirmerSuppression = True }, Nothing )

        ConfirmerPreavis ->
            procedure "demander_suppression" m

        AnnulerPreavis ->
            procedure "annuler_suppression" m

        Nouveau ->
            ( { m | selection = Just E.null, champs = Dict.union (Dict.fromList [ ( "quota", "10" ), ( "maximum", "1" ) ]) (charger E.null), lien = "" }, Nothing )

        Saisir cle v ->
            ( { m | champs = Dict.insert cle v m.champs }, Nothing )

        Sauver ->
            let
                v =
                    Maybe.withDefault E.null m.selection

                commun =
                    [ ( "quota_octets", E.int (String.toFloat (valeur "quota" m) |> Maybe.map ((*) 1000000 >> round) |> Maybe.withDefault 0) )
                    , ( "limites", E.object (List.map (\( k, _, _ ) -> ( k, E.int (String.toInt (valeur k m) |> Maybe.withDefault 0) )) limites) )
                    ]

                invitation =
                    [ ( "intitule", E.string (valeur "intitule" m) )
                    , ( "maximum", E.int (String.toInt (valeur "maximum" m) |> Maybe.withDefault 0) )
                    , ( "expire_a", E.string (valeur "expire_a" m ++ "Z") )
                    ]

                ( op, p ) =
                    if m.volet == "comptes" then
                        ( "modifier_compte", [ ( "utilisateur", E.string (C.chaine "utilisateur" v) ), ( "version", E.int (C.entier "version" v) ), ( "administrateur", E.bool (valeur "administrateur" m == "oui") ), ( "actif", E.bool (valeur "actif" m == "oui") ) ] )

                    else if v == E.null then
                        ( "creer_invitation", invitation )

                    else
                        ( "modifier_invitation", invitation ++ [ ( "id", E.string (C.chaine "id" v) ), ( "version", E.int (C.entier "version" v) ), ( "retroactif", E.bool (valeur "retroactif" m == "oui") ) ] )
            in
            ( m, Just ( op, E.object (commun ++ p) ) )

        Revoquer ->
            let
                v =
                    Maybe.withDefault E.null m.selection
            in
            ( m, Just ( "modifier_invitation", E.object [ ( "id", E.string (C.chaine "id" v) ), ( "version", E.int (C.entier "version" v) ), ( "revoquer", E.bool True ) ] ) )


recevoir : String -> Value -> Modele -> Modele
recevoir op v m =
    if String.startsWith "lister_" op then
        { m | lignes = C.listes m.volet v, total = C.entier "total" v }

    else
        { m
            | selection = Just v
            , confirmerSuppression = False
            , champs = charger v
            , lien = C.chaine "lien" v
            , lignes =
                if op == "creer_invitation" then
                    v :: m.lignes

                else
                    List.map
                        (\ligne ->
                            if C.chaine "utilisateur" ligne == C.chaine "utilisateur" v && m.volet == "comptes" || C.chaine "id" ligne == C.chaine "id" v && m.volet == "invitations" then
                                v

                            else
                                ligne
                        )
                        m.lignes
            , total =
                m.total
                    + (if op == "creer_invitation" then
                        1

                       else
                        0
                      )
        }


vue : Modele -> List (Element Message)
vue m =
    [ Documents.document "Administration"
        [ MrJam.paragraphe "Vous gérez les droits et les allocations. Seuls le nombre de fiches, le nombre d’items et l’espace utilisé sont accessibles ici."
        , MrJam.actions [ Documents.onglet (m.volet == "comptes") "Comptes" (Volet "comptes"), Documents.onglet (m.volet == "invitations") "Invitations" (Volet "invitations") ]
        , if m.volet == "invitations" then
            MrJam.bouton "Créer une invitation" Nouveau

          else
            Element.none
        , Tableaux.tableau
            (if m.volet == "comptes" then
                "Utilisateurs et utilisatrices"

             else
                "Historique des invitations"
            )
            (if m.volet == "comptes" then
                [ Tableaux.principale "Compte" (C.chaine "affichage" >> Element.text)
                , Tableaux.mesure "Fiches / items" (\v -> Element.text (String.fromInt (C.entier "fiches" v) ++ " / " ++ String.fromInt (C.entier "items" v)))
                , Tableaux.mesure "Utilisé / quota (Mo)" (\v -> Element.text (String.fromFloat (toFloat (C.entier "utilise_octets" v) / 1000000) ++ " / " ++ String.fromFloat (toFloat (C.entier "quota_octets" v) / 1000000)))
                , Tableaux.colonne "Droits"
                    (\v ->
                        Element.text
                            (if C.vrai "administrateur" v then
                                "Administration"

                             else
                                "Utilisateur / utilisatrice"
                            )
                    )
                , Tableaux.commandes (\v -> Documents.action "Modifier" (Choisir v))
                ]

             else
                [ Tableaux.principale "Intitulé" (C.chaine "intitule" >> Element.text)
                , Tableaux.mesure "Inscriptions / maximum" (\v -> Element.text (String.fromInt (C.entier "utilise" v) ++ " / " ++ String.fromInt (C.entier "maximum" v)))
                , Tableaux.mesure "Demandes en attente" (\v -> Element.text (String.fromInt (C.entier "en_attente" v)))
                , Tableaux.mesure "Quota par compte (Mo)" (\v -> Element.text (String.fromFloat (toFloat (C.entier "quota_octets" v) / 1000000)))
                , Tableaux.colonne "Expiration (UTC)" (C.chaine "expire_a" >> String.left 16 >> String.replace "T" " " >> Element.text)
                , Tableaux.commandes (\v -> Documents.action "Modifier" (Choisir v))
                ]
            )
            m.lignes
        , Documents.pagination { debut = m.debut, total = m.total, taille = 100, precedent = Page (m.debut - 100), suivant = Page (m.debut + 100) }
        ]
    , case m.selection of
        Nothing ->
            Element.none

        Just v ->
            Documents.document "Droits et limites"
                ((if m.volet == "comptes" then
                    [ MrJam.selecteur "Administrateur / administratrice" [ ( "non", "Non" ), ( "oui", "Oui" ) ] (valeur "administrateur" m) (Saisir "administrateur")
                    , MrJam.selecteur "Compte actif" [ ( "oui", "Oui" ), ( "non", "Non" ) ] (valeur "actif" m) (Saisir "actif")
                    ]

                  else
                    [ MrJam.champ "Intitulé, par exemple Instagram" (valeur "intitule" m) (Saisir "intitule")
                    , MrJam.champ "Nombre maximal d’inscriptions" (valeur "maximum" m) (Saisir "maximum")
                    , Donnees.dateHeure "Date et heure d’expiration (UTC)" (valeur "expire_a" m) (Saisir "expire_a")
                    , if v == E.null then
                        Element.none

                      else
                        MrJam.selecteur "Appliquer les quotas aux comptes déjà inscrits par ce lien" [ ( "oui", "Oui" ), ( "non", "Seulement aux prochaines inscriptions" ) ] (valeur "retroactif" m) (Saisir "retroactif")
                    ]
                 )
                    ++ [ MrJam.champ "Quota strict en Mo (1 Mo = 1 000 000 octets)" (valeur "quota" m) (Saisir "quota")
                       , MrJam.paragraphe "Un quota inférieur à l’espace déjà utilisé conserve les données et bloque les ajouts. L’archivage conserve l’espace."
                       ]
                    ++ List.map (\( k, titre, _ ) -> MrJam.champ titre (valeur k m) (Saisir k)) limites
                    ++ [ MrJam.actions
                            [ MrJam.bouton "Enregistrer les limites" Sauver
                            , if m.volet == "invitations" && v /= E.null then
                                MrJam.boutonDestructif "Révoquer le lien" Revoquer

                              else
                                Element.none
                            ]
                       ]
                    ++ (if m.volet == "comptes" then
                            [ suppression v m.confirmerSuppression ]

                        else
                            []
                       )
                )
    , if m.lien == "" then
        Element.none

      else
        Documents.section "Votre lien d’invitation"
            [ MrJam.paragraphe m.lien, MrJam.texteSecondaire "Le secret du lien est affiché une seule fois. Copiez-le avant de quitter cette page. Son historique restera disponible ici." ]
    ]


procedure : String -> Modele -> ( Modele, Maybe ( String, Value ) )
procedure operation m =
    case m.selection of
        Just v ->
            ( { m | confirmerSuppression = False }, Just ( operation, E.object [ ( "utilisateur", E.string (C.chaine "utilisateur" v) ), ( "version", E.int (C.entier "version" v) ) ] ) )

        Nothing ->
            ( m, Nothing )


suppression : Value -> Bool -> Element Message
suppression compte confirmer =
    let
        preavis =
            C.objet "suppression" compte

        actif =
            preavis /= E.null && C.chaine "annule_a" preavis == ""
    in
    Documents.section "Suppression avec préavis"
        (if actif then
            [ MrJam.paragraphe
                (if C.chaine "etat_courriel" preavis == "accepte_relais" then
                    "Courriel accepté par le relais le " ++ C.chaine "envoye_a" preavis ++ ". Suppression prévue à partir du " ++ C.chaine "echeance_a" preavis ++ ". Ce statut ne prouve pas la réception en boîte."

                 else if C.chaine "etat_courriel" preavis == "erreur" then
                    "L’envoi du préavis a échoué et sera réessayé. Aucun délai de suppression n’a commencé."

                 else
                    "Le courriel de préavis est en attente. Aucun délai de suppression n’a commencé."
                )
            , MrJam.paragraphe "La personne conserve la lecture et l’export de ses données pendant le préavis."
            , MrJam.bouton "Annuler la suppression prévue" AnnulerPreavis
            ]

         else if confirmer then
            [ MrJam.avis MrJam.Avertissement ("Engager la suppression de Vision pour « " ++ C.chaine "affichage" compte ++ " » ? Un courriel prévient la personne ; elle dispose ensuite d’au moins trente jours pour exporter ses données. Vous pouvez annuler pendant ce délai. Son identité commune est conservée.")
            , MrJam.boutonDestructif "Confirmer le préavis de trente jours" ConfirmerPreavis
            ]

         else
            [ MrJam.paragraphe "Cette procédure prévient la personne par courriel et lui laisse au moins trente jours pour exporter ses données. Elle ne donne accès à aucun contenu. Le compte doit rester actif pour conserver cet accès."
            , MrJam.boutonDestructif "Préparer la suppression de ce compte Vision" Preavis
            ]
        )
