module Admission exposing (Message(..), Modele, actualiser, corps, initial, vue)

import Element exposing (Element)
import Json.Encode as E exposing (Value)
import MrJam
import MrJam.Documents as Documents


type alias Modele =
    { courriel : String, pays : String, age : String, parent : String, pseudonyme : String }


type Message
    = Courriel String
    | Pays String
    | Age String
    | Parent String
    | Pseudonyme String


initial : Modele
initial =
    { courriel = "", pays = "", age = "", parent = "", pseudonyme = "" }


actualiser : Message -> Modele -> Modele
actualiser message m =
    case message of
        Courriel texte ->
            { m | courriel = texte }

        Pays texte ->
            { m | pays = texte }

        Age texte ->
            { m
                | age = texte
                , parent =
                    if texte == "majeur" then
                        ""

                    else
                        m.parent
            }

        Parent texte ->
            { m | parent = texte }

        Pseudonyme texte ->
            { m | pseudonyme = texte }


corps : String -> String -> Modele -> Value
corps invitation notice m =
    E.object
        [ ( "invitation", E.string invitation )
        , ( "notice", E.string notice )
        , ( "courriel", E.string m.courriel )
        , ( "pays", E.string m.pays )
        , ( "age", E.string m.age )
        , ( "parent", E.string m.parent )
        , ( "pseudonyme", E.string m.pseudonyme )
        ]


vue : Modele -> Element Message
vue m =
    Documents.section "Demander mon accès"
        [ MrJam.champ "Votre adresse de courrier" m.courriel Courriel
        , MrJam.champ "Pseudonyme (facultatif)" m.pseudonyme Pseudonyme
        , MrJam.champ "Pays de résidence" m.pays Pays
        , MrJam.selecteur "Votre tranche d’âge"
            [ ( "", "Choisir" ), ( "moins15", "Moins de 15 ans" ), ( "15a17", "15 à 17 ans" ), ( "majeur", "18 ans ou plus" ) ]
            m.age
            Age
        , if m.age /= "majeur" && m.age /= "" then
            MrJam.champ "Adresse d’un représentant légal (obligatoire avant 15 ans en France)" m.parent Parent

          else
            Element.none
        , MrJam.paragraphe "Nous vérifions votre adresse avant toute ouverture de compte. Si vous avez déjà un compte MrJ.am avec cette adresse vérifiée, vous conservez le même compte et le même mot de passe."
        , MrJam.paragraphe "En France, avant 15 ans, un représentant légal doit confirmer son accord par courrier, puis sa qualité doit être vérifiée manuellement. Les demandes de mineurs et celles provenant d’autres pays sont examinées avant admission, selon les règles applicables. Le seuil français ne constitue pas un âge minimum universel."
        , MrJam.texteSecondaire "La date de naissance et une pièce d’identité ne sont pas demandées dans ce formulaire. Ne communiquez pas de document spontanément. Votre pays, votre tranche d’âge et les informations de vérification ne sont pas accessibles à l’administration Vision. Une place est réservée pendant sept jours."
        ]
