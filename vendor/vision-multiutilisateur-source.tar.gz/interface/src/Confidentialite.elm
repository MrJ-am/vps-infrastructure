module Confidentialite exposing (vue)

import Contrat as C
import Element exposing (Element)
import Json.Encode exposing (Value)
import MrJam
import MrJam.Documents as Documents
import MrJam.Vitrine as Vitrine


vue : Value -> List (Element message)
vue notice =
    [ Vitrine.introduction "VOS DONNÉES" "Confidentialité" ("Notice " ++ C.chaine "version" notice)
    , Documents.section "Responsable et contact"
        (if C.chaine "responsable" notice == "" then
            [ MrJam.avis MrJam.Information "Les inscriptions publiques restent fermées tant que l’identité du responsable, son contact et les conditions d’hébergement ne sont pas renseignés et vérifiés." ]

         else
            [ MrJam.paragraphe ("Responsable : " ++ C.chaine "responsable" notice)
            , MrJam.paragraphe ("Contact pour vos droits : " ++ C.chaine "contact" notice)
            , MrJam.paragraphe ("Pays d’hébergement : " ++ C.chaine "pays_hebergement" notice)
            ]
        )
    , Documents.section "Données personnelles sensibles"
        [ MrJam.avis MrJam.Avertissement "N’utilisez pas Vision pour stocker des données personnelles sensibles concernant une personne identifiable, telles que des informations médicales, des convictions religieuses ou des données relatives à la vie sexuelle. Les fiches d’apprentissage générales sur ces sujets restent possibles."
        ]
    , Documents.section "Données et finalités"
        [ MrJam.paragraphe "Le compte commun conserve un identifiant technique, les informations nécessaires à la connexion et à la récupération du compte, ainsi que ses moyens de sécurité. Vision conserve vos fiches, items, liens, notes, évaluations et bilans pour organiser vos révisions. Les invitations conservent leur intitulé, leurs plafonds, leur origine et leurs utilisations."
        , MrJam.paragraphe "La fourniture du service repose sur l’exécution de la relation de service (article 6.1.b du RGPD). Les mesures nécessaires de sécurité et leurs journaux reposent sur l’intérêt légitime à protéger le service (article 6.1.f). Aucun usage publicitaire, aucune vente de données et aucun suivi commercial ne sont prévus."
        , MrJam.paragraphe "Vision aide aux révisions. Ses calculs ne prennent aucune décision juridique ni décision produisant un effet significatif sur votre situation."
        ]
    , Documents.section "Admission et personnes mineures"
        [ MrJam.paragraphe "L’accès exige une invitation, la lecture de cette notice et une adresse de courrier vérifiée. Le formulaire recueille le pays de résidence, une tranche d’âge déclarée et, si nécessaire, le courriel d’un représentant légal. Il ne demande ni date de naissance, ni nom légal, ni pièce d’identité."
        , MrJam.paragraphe "En France, avant quinze ans, un représentant légal doit confirmer son accord, puis sa qualité doit être vérifiée manuellement avant admission. Ce seuil n’est pas un âge minimum universel. Au lancement, les demandes de mineurs et celles provenant d’autres pays sont examinées manuellement selon les règles applicables. Une confirmation de courriel ne suffit pas à prouver l’autorité parentale."
        , MrJam.paragraphe "L’exploitation chargée de l’admission peut consulter ces informations de vérification ; l’administration Vision n’y a pas accès. Une demande inachevée expire après sept jours et son dossier est retiré après trente jours supplémentaires. Les courriels et pseudonymes du dossier d’admission aboutie sont retirés après trente jours ; le pays, la tranche déclarée, la version de notice, les confirmations et la référence minimale du contrôle restent pendant la relation de service. Le compte commun conserve son adresse de connexion."
        , MrJam.paragraphe "Si tu es mineur : Vision garde tes fiches et tes progrès pour t’aider à apprendre. Les administrateurs de Vision ne peuvent pas lire tes fiches. Les personnes qui exploitent techniquement le serveur peuvent cependant avoir accès aux textes. N’écris pas d’informations personnelles sensibles et vérifie avec un adulte ce que ton assistant peut transmettre. Tu peux récupérer et supprimer tes données. Pour poser une question, demander une correction ou retirer un accord parental, utilise le contact indiqué en haut de cette notice."
        ]
    , Documents.section "Qui peut accéder à quoi"
        [ MrJam.paragraphe "Vous accédez aux données de votre compte. Un administrateur ou une administratrice Vision voit les droits, les quotas, les nombres de fiches et d’items et l’espace utilisé. Ce statut ne donne aucun accès aux titres, textes, notes, historiques, exports ou vecteurs d’autres personnes. Il ne permet pas de prendre leur identité ni de réinitialiser leur mot de passe."
        , MrJam.paragraphe "Le serveur traite les contenus en clair pour fournir le service. L’exploitant technique et l’hébergeur peuvent être en mesure d’y accéder avec des droits techniques privilégiés. Cette version ne propose pas de chiffrement de bout en bout. Cet accès technique doit être restreint et encadré par les engagements du responsable et de ses sous-traitants."
        ]
    , Documents.section "Chiffrement et assistants"
        [ MrJam.paragraphe "Les communications avec le site utilisent HTTPS/TLS. Les mots de passe du nouveau fournisseur d’identité sont hachés avec Argon2id ; ils ne sont pas chiffrés de façon réversible. Les secrets servant aux codes de double authentification doivent être récupérables par le fournisseur d’identité et accessibles à son exploitation technique privilégiée. Les contenus de la base de données ne sont pas chiffrés individuellement par Vision. Le chiffrement des sauvegardes et leur stockage doivent être constatés lors de l’activation ; HTTPS ne chiffre pas les fichiers du serveur."
        , MrJam.paragraphe "Les représentations sémantiques sont calculées localement sur le serveur. Vision n’envoie pas de contenu à un fournisseur de LLM de sa propre initiative. Un assistant que vous autorisez par MCP peut lire et modifier vos données. Son fournisseur peut traiter ces données selon ses propres conditions, éventuellement hors de l’Espace économique européen. Vérifiez ces conditions avant de connecter l’assistant."
        , MrJam.lien "Retirer les autorisations d’un assistant" "/auth/mcp"
        ]
    , Documents.section "Conservation et effacement"
        [ MrJam.paragraphe "Vos connaissances et observations sont conservées jusqu’à votre demande d’effacement. L’archivage conserve leur contenu. Les preuves de création, caches de requête et traces de recherche sont bornés ; les caches de requête sont nettoyés après 35 jours, les épisodes temporaires après 90 jours, les journaux métier après 180 jours. Certains bilans et observations restent dans votre historique personnel."
        , MrJam.paragraphe "Une session expire après 12 heures, ou après 2 heures sans activité. Les états de connexion OIDC expirent après 10 minutes. Les événements applicatifs de sécurité et d’administration sont limités à trente jours ; le journal HTTP conserve son plafond distinct de quatorze jours. Ces journaux ne doivent contenir ni contenus pédagogiques ni secrets. Les liens d’invitation expirent à la date indiquée et peuvent être révoqués."
        , MrJam.paragraphe
            ("L’effacement retire les données de la base active. "
                ++ (if C.entier "sauvegardes_jours" notice > 0 then
                        "Les copies locales nouvelles expirent sous " ++ String.fromInt (C.entier "sauvegardes_jours" notice) ++ " jours. La conservation et la purge des anciennes copies, snapshots et copies externes doivent être documentées séparément. "

                    else
                        "Le délai d’expiration des sauvegardes doit être vérifié avant l’ouverture des inscriptions. "
                   )
                ++ "Un registre d’effacement sans contenu est prévu pour empêcher leur réapparition lors d’une restauration. Les procédures de restauration doivent appliquer ce registre avant de rouvrir le service."
            )
        ]
    , Documents.section "Courriels et préavis"
        [ MrJam.paragraphe "Proton fournit les courriels transactionnels nécessaires à la récupération du compte et aux procédures de suppression. TLS protège la soumission SMTP ; ces courriels ne sont pas tous chiffrés de bout en bout. Le registre minimal d’effacement est chiffré avant son envoi à la boîte de l’exploitant et ne contient aucune connaissance."
        , MrJam.paragraphe "Selon sa politique de confidentialité, Proton Mail stocke les messages sur des serveurs en Suisse, Allemagne ou Norvège et peut traiter les métadonnées d’envoi : adresses, dates, objet et nom de pièce jointe. Cette localisation est distincte de celle du serveur de Vision affichée en haut de la notice. Le pays exact d’une boîte n’est pas déduit de cette liste. La Suisse bénéficie d’une décision européenne d’adéquation ; les contrats et éventuels autres transferts doivent également être vérifiés."
        , MrJam.lienExterne "Politique de confidentialité de Proton Mail" "https://proton.me/mail/privacy-policy"
        , MrJam.paragraphe "Une suppression engagée par l’administration laisse au moins trente jours après l’envoi du préavis pour exporter les données. Elle peut être annulée avant le début de l’effacement. Un échec d’envoi ne démarre pas le délai. L’acceptation par le relais SMTP ne prouve ni la réception en boîte ni la lecture du message. Aucune suppression automatique pour inactivité n’est prévue."
        ]
    , Documents.section "Vos droits"
        [ MrJam.paragraphe "Vous pouvez accéder à vos données, les rectifier, les exporter et effacer votre compte Vision depuis Mon compte. Vous pouvez demander la limitation d’un traitement, vous opposer à un traitement fondé sur l’intérêt légitime, et exercer vos droits sur l’identité commune auprès du contact indiqué. Une réponse est apportée dans le délai réglementaire d’un mois, sous réserve des prolongations motivées prévues par le RGPD."
        , MrJam.lien "Mon compte, export et effacement" "/#compte"
        , MrJam.paragraphe "La fermeture autonome du compte MrJ.am se fait dans Sécurité et identité du compte commun, après une nouvelle authentification et une confirmation explicite. Elle supprime l’identité, ses moyens de connexion et les données des outils qui l’ont adoptée (actuellement Vision). Un registre chiffré ne conserve que les identifiants techniques, la date et les outils concernés pour empêcher leur réintroduction lors d’une restauration. Un envoi en attente peut retarder la suppression ; la demande confirmée reprend automatiquement."
        , MrJam.lienExterne "Déposer une réclamation auprès de la CNIL" "https://www.cnil.fr/fr/adresser-une-plainte"
        ]
    , Documents.section "Service et licence"
        [ MrJam.paragraphe "Le code de Vision est proposé sous licence AGPL version 3 ou ultérieure. L’accès à cette instance est un service bénévole, limité par les capacités et quotas annoncés. Conservez vos propres exports : une panne peut entraîner une indisponibilité ou une perte de données, notamment entre deux copies externes mensuelles. Les droits et obligations impératifs applicables à l’hébergement et à vos données personnelles demeurent applicables."
        , MrJam.lien "Télécharger le code source de cette version de Vision" "/code-source/vision.tar.gz"
        , MrJam.lien "Télécharger le code des services d’identité et de gestion MrJ.am" "/code-source/services-mrjam.tar.gz"
        ]
    , Documents.section "Cookies nécessaires"
        [ MrJam.paragraphe "Les cookies servent uniquement à l’authentification, à la sécurité de la connexion et au maintien de la session. Les sessions de chaque outil restent attachées à son hôte. Aucun traceur publicitaire ni mesure d’audience tiers n’est ajouté par Vision. Les brouillons restent en mémoire dans la page et ne sont pas sauvegardés dans localStorage ou sessionStorage."
        ]
    ]
