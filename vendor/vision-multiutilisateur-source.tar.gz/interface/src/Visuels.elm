module Visuels exposing (espacement, partage)

{-| Illustrations du domaine avec légendes et données explicitement fictives.
-}

import Element exposing (Element)
import MrJam.Vitrine as Vitrine


partage : Element message
partage =
    Vitrine.illustration
        { image = "assets/mrjam/vision/partage.svg"
        , description = "Les fiches Capitales de l’Asie et Voyage en Arménie partagent l’item Erevan est la capitale de l’Arménie. Cet item garde une seule stabilité."
        , legende = "Exemple fictif. Une même connaissance peut servir dans plusieurs contextes."
        }


espacement : Element message
espacement =
    Vitrine.illustration
        { image = "assets/mrjam/vision/espacement.svg"
        , description = "Exemple d’intervalles qui doublent : 7 jours puis 14 puis 28."
        , legende = "Exemple fictif. Vos intervalles dépendent de vos réponses et de vos réglages."
        }
