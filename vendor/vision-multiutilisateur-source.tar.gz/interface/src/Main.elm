port module Main exposing (main)

import Admission
import Browser
import Compte
import Contrat as C
import Dict exposing (Dict)
import Element exposing (Element)
import Gestion
import Html exposing (Html)
import Informations
import Json.Decode as D
import Json.Encode as E exposing (Value)
import MrJam exposing (Niveau(..), actions, avis, bouton, boutonDestructif, boutonEnCours, boutonSecondaire, champ, motDePasse, paragraphe, pile, selecteur, texteSecondaire, zoneTexte)
import MrJam.Documents as Documents
import MrJam.Donnees as Donnees
import MrJam.Fenetres as Fenetres
import MrJam.Lecture as Lecture
import MrJam.Pictogrammes as Pictogrammes
import MrJam.Tableaux as Tableaux


port requete : Value -> Cmd message


port reponse : (Value -> message) -> Sub message


port adresse : (String -> message) -> Sub message


port configuration : (Value -> message) -> Sub message


port exportation : (Value -> message) -> Sub message


port copie : (Bool -> message) -> Sub message


port effets : Value -> Cmd message


type alias Flags =
    { cle : String, instant : String, adresse : String, chemin : String }


type alias Session =
    { compte : String, csrf : String, administrateur : Bool, verificationRenforcee : Bool }


type But
    = SessionInitiale
    | Connecter
    | Deconnecter
    | Lister C.Nature
    | Lire C.Nature Int
    | Enregistrer C.Nature
    | EnregistrerLigne Int
    | VerifierCreation
    | RechercherLiens
    | Lier
    | Regler
    | LirePolitique
    | LireLimites
    | ApercuExport
    | Gerer String
    | Inscrire
    | ApercuAdmission
    | ConfirmerAdmission
    | ApercuInvitation
    | EffacerCompte


type alias Ecriture =
    { but : But, chemin : String, corps : Value }


type alias Suspension =
    { compte : String, nature : C.Nature, detail : Maybe Value, brouillon : Dict String String, ecriture : Maybe Ecriture, editionItem : Maybe Int, contenuItem : String }


type Confirmation
    = Changer C.Nature
    | Fermer
    | Quitter
    | EffacerVision
    | Archiver Bool
    | Detacher Int Int Int


type alias Modele =
    { flags : Flags
    , urlMcp : String
    , gestionAcces : String
    , copiee : Bool
    , authMode : String
    , compteUrl : String
    , notice : Value
    , invitation : Value
    , admission : Admission.Modele
    , admissionLien : Value
    , accordAdmission : Bool
    , limites : Value
    , compteOuvert : Bool
    , gestionOuverte : Bool
    , gestion : Gestion.Modele
    , exportEnCours : Bool
    , compteExport : Compte.Modele
    , effacement : String
    , noticeLue : Bool
    , session : Maybe Session
    , identifiant : String
    , secret : String
    , verification : Bool
    , nature : C.Nature
    , recherche : String
    , tags : String
    , etat : String
    , tri : String
    , debut : Int
    , resultats : List Value
    , total : Int
    , detail : Maybe Value
    , debutLiens : Int
    , triLiens : String
    , filtreLiens : String
    , outilsLiens : Maybe String
    , editionItem : Maybe Int
    , contenuItem : String
    , modifieItem : Bool
    , edition : Bool
    , modifie : Bool
    , brouillon : Dict String String
    , candidats : List Value
    , preuve : Maybe String
    , creationVerifiee : Bool
    , liensOuverts : Bool
    , rechercheLiens : String
    , liensTrouves : List Value
    , politique : Value
    , reglagesModifies : List String
    , intervalle : String
    , budget : String
    , dureeSeanceCourte : String
    , questionsTypiques : String
    , filtresOuverts : Bool
    , menuOuvert : Bool
    , reglages : Bool
    , numero : Int
    , dernierListe : Int
    , dernierDetail : Int
    , attentes : Dict Int But
    , ecriture : Maybe Ecriture
    , suspension : Maybe Suspension
    , confirmation : Maybe Confirmation
    , message : Maybe ( Niveau, String )
    }


type Message
    = Configuration Value
    | MonCompte
    | Administration
    | GestionMessage Gestion.Message
    | CompteMessage Compte.Message
    | ExportTermine Value
    | SaisirEffacement String
    | AccepterNotice Bool
    | Inscription
    | AdmissionMessage Admission.Message
    | AccordAdmission Bool
    | ConfirmerLienAdmission
    | CopierAdresse
    | CopieTerminee Bool
    | ChoisirChapitre String
    | Recevoir Value
    | Adresse String
    | Menu
    | Filtres
    | Identifiant String
    | Secret String
    | Connexion
    | Naviguer Confirmation
    | Confirmer
    | Rester
    | Recherche String
    | Tags String
    | Filtrer
    | Etat String
    | Tri String
    | Pagination Int
    | Ouvrir C.Nature Int
    | Nouvelle
    | Editer
    | AnnulerEdition
    | OutilsLiens String
    | TriLiens String
    | FiltreLiens String
    | EditerLigne Int
    | SaisirLigne String
    | SauverLigne
    | AnnulerLigne
    | Saisir String String
    | Sauver
    | CreerDistinct
    | Reutiliser Int
    | Reessayer
    | AfficherLiens
    | RechercheLiens String
    | ChercherLiens
    | Rattacher Value
    | PageLiens Int
    | Reglages
    | Intervalle String
    | Budget String
    | DureeSeanceCourte String
    | QuestionsTypiques String
    | SauverPolitique


changerAdresse : String -> Flags -> Flags
changerAdresse nouvelle flags =
    { flags | adresse = nouvelle }


initial : Flags -> Modele
initial flags =
    { flags = flags
    , urlMcp = ""
    , gestionAcces = ""
    , copiee = False
    , authMode = ""
    , compteUrl = ""
    , notice = E.null
    , invitation = E.null
    , admission = Admission.initial
    , admissionLien = E.null
    , accordAdmission = False
    , limites = E.null
    , compteOuvert = False
    , gestionOuverte = False
    , gestion = Gestion.initial
    , exportEnCours = False
    , compteExport = Compte.initial
    , effacement = ""
    , noticeLue = False
    , session = Nothing
    , identifiant = ""
    , secret = ""
    , verification = True
    , nature = C.Fiche
    , recherche = ""
    , tags = ""
    , etat = "actif"
    , tri = "titre"
    , debut = 0
    , resultats = []
    , total = 0
    , detail = Nothing
    , debutLiens = 0
    , triLiens = "echeance"
    , filtreLiens = "tous"
    , outilsLiens = Nothing
    , editionItem = Nothing
    , contenuItem = ""
    , modifieItem = False
    , edition = False
    , modifie = False
    , brouillon = C.nouveau
    , candidats = []
    , preuve = Nothing
    , creationVerifiee = False
    , liensOuverts = False
    , rechercheLiens = ""
    , liensTrouves = []
    , politique = E.null
    , reglagesModifies = []
    , intervalle = "90"
    , budget = ""
    , dureeSeanceCourte = "60"
    , questionsTypiques = "8"
    , filtresOuverts = False
    , menuOuvert = False
    , reglages = False
    , numero = 0
    , dernierListe = 0
    , dernierDetail = 0
    , attentes = Dict.empty
    , ecriture = Nothing
    , suspension = Nothing
    , confirmation = Nothing
    , message = Nothing
    }


main : Program Flags Modele Message
main =
    Browser.element
        { init =
            \flags ->
                if flags.chemin == "/admission" then
                    envoyer ApercuAdmission "/auth/admission/apercu" (E.object [ ( "token", E.string (String.dropLeft 1 flags.adresse) ) ]) (initial flags)

                else if flags.chemin == "/invitation" then
                    envoyer ApercuInvitation "/auth/invitation" (E.object [ ( "invitation", E.string (String.dropLeft 1 flags.adresse) ) ]) (initial flags)

                else
                    envoyer SessionInitiale "/auth/session" E.null (initial flags)
        , update =
            \msg m ->
                let
                    ( n, cmd ) =
                        actualiser msg m
                in
                ( n, Cmd.batch [ cmd, effet "proteger" (E.bool (n.modifie || n.modifieItem || n.ecriture /= Nothing || n.suspension /= Nothing)) ] )
        , view = vue
        , subscriptions = always (Sub.batch [ reponse Recevoir, adresse Adresse, configuration Configuration, copie CopieTerminee, exportation ExportTermine ])
        }


effet : String -> Value -> Cmd Message
effet nom contenu =
    effets (E.object [ ( "nom", E.string nom ), ( "valeur", contenu ) ])


notifier : Niveau -> String -> Modele -> ( Modele, Cmd Message )
notifier niveau texte m =
    ( { m | message = Just ( niveau, texte ) }, Cmd.none )


envoyer : But -> String -> Value -> Modele -> ( Modele, Cmd Message )
envoyer but chemin corps m =
    let
        numero =
            m.numero + 1

        suite =
            { m | numero = numero, attentes = Dict.insert numero but m.attentes }

        n =
            case but of
                Lister _ ->
                    { suite | dernierListe = numero }

                Lire _ _ ->
                    { suite | dernierDetail = numero }

                _ ->
                    suite
    in
    ( n
    , requete
        (E.object
            [ ( "numero", E.int numero )
            , ( "chemin", E.string chemin )
            , ( "methode"
              , E.string
                    (if chemin == "/auth/session" then
                        "GET"

                     else
                        "POST"
                    )
              )
            , ( "csrf", m.session |> Maybe.map (.csrf >> E.string) |> Maybe.withDefault E.null )
            , ( "corps", corps )
            ]
        )
    )


api : But -> String -> List ( String, Value ) -> Modele -> ( Modele, Cmd Message )
api but operation valeurs =
    envoyer but ("/api/web/" ++ operation) (E.object valeurs)


ecrire : But -> String -> List ( String, Value ) -> Modele -> ( Modele, Cmd Message )
ecrire but operation valeurs m =
    if m.ecriture /= Nothing then
        notifier Information "Une écriture attend son résultat. Réessayez la même opération." m

    else
        let
            e =
                { but = but, chemin = "/api/web/" ++ operation, corps = E.object (( "cle", E.string (m.flags.cle ++ "-" ++ String.fromInt (m.numero + 1)) ) :: ( "emise_a", E.string m.flags.instant ) :: valeurs) }
        in
        envoyer but e.chemin e.corps { m | ecriture = Just e, message = Nothing }


lister : Modele -> ( Modele, Cmd Message )
lister m =
    api (Lister m.nature)
        "rechercher"
        [ ( "type", E.string (C.nom m.nature) )
        , ( "requete", E.string m.recherche )
        , ( "etat", E.string m.etat )
        , ( "tri", E.string m.tri )
        , ( "limite", E.int 20 )
        , ( "decalage", E.int m.debut )
        , ( "tags", E.list E.string (String.split "," m.tags |> List.map String.trim |> List.filter ((/=) "")) )
        ]
        m


lire : C.Nature -> Int -> Modele -> ( Modele, Cmd Message )
lire nature id m =
    api (Lire nature id)
        "lire"
        [ ( "type", E.string (C.nom nature) )
        , ( "ids", E.list E.int [ id ] )
        , ( "decalage", E.int m.debutLiens )
        , ( "limite", E.int 20 )
        , ( "tri_liens", E.string m.triLiens )
        , ( "filtre_liens", E.string m.filtreLiens )
        ]
        m


valeur : String -> Modele -> String
valeur cle m =
    Dict.get cle m.brouillon |> Maybe.withDefault ""


corpsEdition : Modele -> List ( String, Value )
corpsEdition m =
    let
        textes =
            List.map (\cle -> ( cle, E.string (valeur cle m) ))
                (if m.nature == C.Fiche then
                    [ "titre", "contenu", "suivi" ]

                 else
                    [ "contenu" ]
                )

        tableaux =
            List.map (\cle -> ( cle, E.list E.string (C.lignes (valeur cle m)) ))
                (if m.nature == C.Fiche then
                    [ "alias", "tags" ]

                 else
                    [ "alias" ]
                )

        version =
            m.detail |> Maybe.map (\d -> [ ( "id", E.int (C.entier "id" d) ), ( "version", E.int (C.entier "version" d) ) ]) |> Maybe.withDefault []

        specifiques =
            if m.nature == C.Fiche then
                [ ( "priorite", E.int (String.toInt (valeur "priorite" m) |> Maybe.withDefault 0) ) ]

            else if m.detail /= Nothing then
                []

            else
                [ ( "stabilite", E.int (String.toInt (valeur "stabilite" m) |> Maybe.withDefault -15) )
                , ( "preuve_creation", m.preuve |> Maybe.map E.string |> Maybe.withDefault E.null )
                , ( "candidats_examines", E.list E.int (List.map (C.entier "id") m.candidats) )
                , ( "distinction", E.string (valeur "distinction" m) )
                , ( "justification", E.string (valeur "justification" m) )
                ]
                    ++ (if String.isEmpty (valeur "reference_a" m) then
                            []

                        else
                            [ ( "reference_a", E.string (valeur "reference_a" m) ) ]
                       )
    in
    textes ++ tableaux ++ version ++ specifiques


sauver : Modele -> ( Modele, Cmd Message )
sauver m =
    if String.isEmpty (String.trim (valeur "contenu" m)) || (m.nature == C.Fiche && String.isEmpty (String.trim (valeur "titre" m))) then
        notifier Erreur "Le contenu et, pour une fiche, le titre sont requis." m

    else if m.nature == C.Fiche && not (entierValide -20 20 (valeur "priorite" m)) then
        notifier Erreur "La priorité doit être un entier de −20 à +20 dB." m

    else if m.nature == C.Item && m.detail == Nothing && not (entierValide -128 127 (valeur "stabilite" m)) then
        notifier Erreur "La stabilité doit être un entier de −128 à +127 dB." m

    else if m.nature == C.Item && m.detail == Nothing && not m.creationVerifiee then
        api VerifierCreation "preparer_creation_item" [ ( "contenu", E.string (valeur "contenu" m) ) ] m

    else
        ecrire (Enregistrer m.nature) ("enregistrer_" ++ C.nom m.nature) (corpsEdition m) m


entierValide : Int -> Int -> String -> Bool
entierValide minimum maximum texte =
    String.toInt texte |> Maybe.map (\nombre -> nombre >= minimum && nombre <= maximum) |> Maybe.withDefault False


executer : Confirmation -> Modele -> ( Modele, Cmd Message )
executer action m =
    let
        n =
            { m | confirmation = Nothing, message = Nothing }
    in
    case action of
        Changer nature ->
            avecAdresse
                (if nature == C.Item then
                    "#items"

                 else
                    "#fiches"
                )
                (lister
                    { n
                        | nature = nature
                        , compteOuvert = False
                        , gestionOuverte = False
                        , detail = Nothing
                        , edition = False
                        , modifie = False
                        , editionItem = Nothing
                        , modifieItem = False
                        , resultats = []
                        , debut = 0
                        , tri =
                            if nature == C.Item then
                                "alphabetique"

                            else
                                "titre"
                        , candidats = []
                        , liensOuverts = False
                    }
                )

        Fermer ->
            avecAdresse
                (if n.nature == C.Item then
                    "#items"

                 else
                    "#fiches"
                )
                (lister { n | detail = Nothing, edition = False, modifie = False, editionItem = Nothing, modifieItem = False, candidats = [], liensOuverts = False })

        EffacerVision ->
            if m.effacement == "EFFACER VISION" then
                api EffacerCompte "effacer_compte" [ ( "confirmation", E.string m.effacement ) ] n

            else
                notifier Erreur "Saisissez EFFACER VISION pour confirmer." m

        Quitter ->
            envoyer Deconnecter "/auth/logout" (E.object []) n

        Archiver archive ->
            case n.detail of
                Nothing ->
                    ( n, Cmd.none )

                Just d ->
                    ecrire (Enregistrer n.nature) ("enregistrer_" ++ C.nom n.nature) [ ( "id", E.int (C.entier "id" d) ), ( "version", E.int (C.entier "version" d) ), ( "archive", E.bool archive ) ] n

        Detacher fiche item version ->
            ecrire Lier "lier_item" [ ( "fiche_id", E.int fiche ), ( "item_id", E.int item ), ( "version_fiche", E.int version ), ( "action", E.string "detacher" ) ] n


actualiser : Message -> Modele -> ( Modele, Cmd Message )
actualiser msg m =
    case msg of
        Configuration donnees ->
            if C.objet "auth" donnees /= E.null then
                let
                    auth =
                        C.objet "auth" donnees
                in
                ( { m | authMode = C.chaine "mode" auth, compteUrl = C.chaine "compte" auth, notice = C.objet "notice" auth }, Cmd.none )

            else
                ( { m | urlMcp = C.chaine "url_mcp" donnees, gestionAcces = C.chaine "gestion_acces" donnees }, Cmd.none )

        MonCompte ->
            if m.modifie || m.modifieItem then
                notifier Information "Terminez votre saisie avant de changer de page." m

            else
                avecAdresse "#compte" (api LireLimites "lire_limites" [] { m | compteOuvert = True, gestionOuverte = False, menuOuvert = False })

        Administration ->
            if m.modifie || m.modifieItem then
                notifier Information "Terminez votre saisie avant de changer de page." m

            else
                avecAdresse "#administration" (envoyer (Gerer "lister_comptes") "/api/gestion/lister_comptes" (E.object []) { m | gestionOuverte = True, compteOuvert = False, menuOuvert = False })

        GestionMessage action ->
            let
                ( gestion, demande ) =
                    Gestion.actualiser action m.gestion

                n =
                    { m | gestion = gestion }
            in
            demande |> Maybe.map (\( op, p ) -> envoyer (Gerer op) ("/api/gestion/" ++ op) p n) |> Maybe.withDefault ( n, Cmd.none )

        CompteMessage action ->
            let
                export =
                    Compte.actualiser action m.compteExport

                n =
                    { m | compteExport = export }
            in
            case action of
                Compte.Exporter ->
                    ( { n | exportEnCours = True }
                    , effet "exporter" (E.object [ ( "csrf", m.session |> Maybe.map (.csrf >> E.string) |> Maybe.withDefault E.null ), ( "format", E.string export.format ), ( "toutes", E.bool export.toutes ), ( "fiches", E.list E.int export.selection ) ])
                    )

                Compte.Page debut ->
                    envoyer ApercuExport "/api/web/exporter_compte" (E.object [ ( "table", E.string "vision_fiches" ), ( "debut", E.int (max 0 debut) ) ]) n

                Compte.Effacer ->
                    actualiser (Naviguer EffacerVision) n

                _ ->
                    ( n, Cmd.none )

        ExportTermine resultat ->
            notifier
                (if C.vrai "reussi" resultat then
                    Succes

                 else
                    Erreur
                )
                (if C.vrai "reussi" resultat then
                    "Export téléchargé."

                 else
                    "L’export a été interrompu. Réessayez en suspendant les modifications et les assistants."
                )
                { m | exportEnCours = False }

        SaisirEffacement texte ->
            ( { m | effacement = texte }, Cmd.none )

        AccepterNotice valeurNotice ->
            ( { m | noticeLue = valeurNotice }, Cmd.none )

        AdmissionMessage messageAdmission ->
            ( { m | admission = Admission.actualiser messageAdmission m.admission }, Cmd.none )

        AccordAdmission oui ->
            ( { m | accordAdmission = oui }, Cmd.none )

        ConfirmerLienAdmission ->
            if m.accordAdmission then
                envoyer ConfirmerAdmission "/auth/admission/confirmer" (E.object [ ( "token", E.string (String.dropLeft 1 m.flags.adresse) ), ( "acceptation", E.bool True ) ]) m

            else
                notifier Information "Cochez la confirmation avant de continuer." m

        Inscription ->
            if not m.noticeLue || not (C.vrai "inscriptions_ouvertes" m.notice) then
                notifier Information "Lisez la notice. Les inscriptions doivent être ouvertes pour activer le lien." m

            else
                envoyer Inscrire "/auth/admission" (Admission.corps (String.dropLeft 1 m.flags.adresse) (C.chaine "version" m.notice) m.admission) m

        CopierAdresse ->
            ( { m | copiee = False }, effet "copier" (E.string m.urlMcp) )

        CopieTerminee reussite ->
            ( { m | copiee = reussite }, Cmd.none )

        ChoisirChapitre identifiant ->
            ( { m | copiee = False, flags = changerAdresse ("#" ++ identifiant) m.flags }, effet "adresse" (E.string ("#" ++ identifiant)) )

        Filtres ->
            ( { m | filtresOuverts = not m.filtresOuverts }, Cmd.none )

        Menu ->
            ( { m | menuOuvert = not m.menuOuvert }, Cmd.none )

        Adresse valeurAdresse ->
            if m.session == Nothing then
                let
                    flags =
                        m.flags
                in
                ( { m | flags = { flags | adresse = valeurAdresse } }, Cmd.none )

            else if m.modifie || m.modifieItem || m.ecriture /= Nothing then
                ( { m | message = Just ( Information, "Enregistrez ou fermez la saisie avant de consulter un autre objet." ) }
                , effet "adresse" (E.string (m.detail |> Maybe.map (C.entier "id" >> C.destination m.nature) |> Maybe.withDefault ""))
                )

            else if valeurAdresse == "#compte" then
                actualiser MonCompte m

            else if valeurAdresse == "#administration" then
                actualiser Administration m

            else
                case C.depuisAdresse valeurAdresse of
                    Just ( nature, id ) ->
                        actualiser (Ouvrir nature id) m

                    Nothing ->
                        actualiser
                            (Naviguer
                                (Changer
                                    (if valeurAdresse == "#items" then
                                        C.Item

                                     else
                                        C.Fiche
                                    )
                                )
                            )
                            m

        Recevoir r ->
            recevoir r m

        Identifiant s ->
            ( { m | identifiant = s }, Cmd.none )

        Secret s ->
            ( { m | secret = s }, Cmd.none )

        Connexion ->
            envoyer Connecter "/auth/login" (E.object [ ( "username", E.string m.identifiant ), ( "password", E.string m.secret ) ]) { m | secret = "" }

        Naviguer c ->
            if m.ecriture /= Nothing then
                notifier Information "Une écriture attend son résultat." m

            else if
                m.modifie
                    || m.modifieItem
                    || (case c of
                            EffacerVision ->
                                True

                            Archiver _ ->
                                True

                            Detacher _ _ _ ->
                                True

                            _ ->
                                False
                       )
            then
                ( { m | confirmation = Just c }, Cmd.none )

            else
                executer c m

        Confirmer ->
            m.confirmation |> Maybe.map (\c -> executer c { m | modifie = False, modifieItem = False, editionItem = Nothing }) |> Maybe.withDefault ( m, Cmd.none )

        Rester ->
            ( { m | confirmation = Nothing }, Cmd.none )

        Recherche s ->
            ( { m | recherche = s }, Cmd.none )

        Tags s ->
            ( { m | tags = s }, Cmd.none )

        Filtrer ->
            lister { m | debut = 0 }

        Etat s ->
            lister { m | etat = s, debut = 0 }

        Tri s ->
            lister { m | tri = s, debut = 0 }

        Pagination pas ->
            lister { m | debut = max 0 (m.debut + 20 * pas) }

        Ouvrir nature id ->
            if m.modifie || m.modifieItem || m.ecriture /= Nothing then
                notifier Information "Enregistrez ou fermez la saisie avant de consulter un autre objet." m

            else
                lire nature id { m | nature = nature, debutLiens = 0, detail = Nothing, edition = False, liensOuverts = False, candidats = [], triLiens = "echeance", filtreLiens = "tous", outilsLiens = Nothing, editionItem = Nothing }

        Nouvelle ->
            if m.modifie || m.modifieItem || m.ecriture /= Nothing then
                notifier Information "Terminez la saisie en cours." m

            else
                ( { m | detail = Nothing, edition = True, modifie = False, brouillon = C.nouveau, candidats = [], preuve = Nothing, creationVerifiee = False }, effet "focus" (E.string "edition") )

        Editer ->
            m.detail |> Maybe.map (\d -> ( { m | edition = True, brouillon = C.brouillon d }, Cmd.none )) |> Maybe.withDefault ( m, Cmd.none )

        AnnulerEdition ->
            ( { m | edition = False, modifie = False, brouillon = m.detail |> Maybe.map C.brouillon |> Maybe.withDefault C.nouveau }, Cmd.none )

        OutilsLiens commande ->
            ( { m
                | outilsLiens =
                    if m.outilsLiens == Just commande then
                        Nothing

                    else
                        Just commande
              }
            , Cmd.none
            )

        TriLiens tri ->
            if m.modifieItem || m.modifie then
                notifier Information "Enregistrez ou annulez la modification de la ligne." m

            else
                m.detail |> Maybe.map (\d -> lire m.nature (C.entier "id" d) { m | triLiens = tri, debutLiens = 0 }) |> Maybe.withDefault ( m, Cmd.none )

        FiltreLiens filtre ->
            if m.modifieItem || m.modifie then
                notifier Information "Enregistrez ou annulez la modification de la ligne." m

            else
                m.detail |> Maybe.map (\d -> lire m.nature (C.entier "id" d) { m | filtreLiens = filtre, debutLiens = 0 }) |> Maybe.withDefault ( m, Cmd.none )

        EditerLigne id ->
            let
                ligne =
                    m.detail |> Maybe.map (C.listes "items") |> Maybe.withDefault [] |> List.filter (\v -> C.entier "id" v == id) |> List.head
            in
            ( { m | editionItem = Just id, contenuItem = ligne |> Maybe.map (C.chaine "contenu") |> Maybe.withDefault "", modifieItem = False }, Cmd.none )

        SaisirLigne s ->
            ( { m | contenuItem = s, modifieItem = True }, Cmd.none )

        AnnulerLigne ->
            ( { m | editionItem = Nothing, contenuItem = "", modifieItem = False }, Cmd.none )

        SauverLigne ->
            let
                ligne =
                    m.detail |> Maybe.map (C.listes "items") |> Maybe.withDefault [] |> List.filter (\v -> Just (C.entier "id" v) == m.editionItem) |> List.head
            in
            if String.isEmpty (String.trim m.contenuItem) then
                notifier Erreur "La connaissance ne peut pas être vide." m

            else
                ligne |> Maybe.map (\v -> ecrire (EnregistrerLigne (C.entier "id" v)) "enregistrer_item" [ ( "id", E.int (C.entier "id" v) ), ( "version", E.int (C.entier "version" v) ), ( "contenu", E.string m.contenuItem ) ] m) |> Maybe.withDefault ( m, Cmd.none )

        Saisir cle s ->
            if m.ecriture /= Nothing then
                ( m, Cmd.none )

            else
                ( { m
                    | brouillon = Dict.insert cle s m.brouillon
                    , modifie = True
                    , preuve =
                        if cle == "contenu" && m.nature == C.Item then
                            Nothing

                        else
                            m.preuve
                    , candidats =
                        if cle == "contenu" && m.nature == C.Item then
                            []

                        else
                            m.candidats
                    , creationVerifiee =
                        if cle == "titre" || (cle == "contenu" && m.nature == C.Item) then
                            False

                        else
                            m.creationVerifiee
                  }
                , Cmd.none
                )

        Sauver ->
            sauver m

        CreerDistinct ->
            if String.length (valeur "distinction" m) < 10 then
                notifier Erreur "Précisez ce qui distingue cette connaissance des items trouvés." m

            else
                sauver { m | creationVerifiee = True }

        Reutiliser id ->
            lire C.Item id { m | nature = C.Item, modifie = False, edition = False, candidats = [], preuve = Nothing, creationVerifiee = False, debutLiens = 0 }

        Reessayer ->
            m.ecriture |> Maybe.map (\e -> envoyer e.but e.chemin e.corps m) |> Maybe.withDefault ( m, Cmd.none )

        AfficherLiens ->
            ( { m | liensOuverts = not m.liensOuverts, liensTrouves = [] }, Cmd.none )

        RechercheLiens s ->
            ( { m | rechercheLiens = s }, Cmd.none )

        ChercherLiens ->
            api RechercherLiens
                "rechercher"
                [ ( "type"
                  , E.string
                        (if m.nature == C.Fiche then
                            "item"

                         else
                            "fiche"
                        )
                  )
                , ( "requete", E.string m.rechercheLiens )
                , ( "limite", E.int 20 )
                ]
                m

        Rattacher cible ->
            case m.detail of
                Nothing ->
                    ( m, Cmd.none )

                Just d ->
                    let
                        f =
                            if m.nature == C.Fiche then
                                d

                            else
                                cible

                        i =
                            if m.nature == C.Item then
                                d

                            else
                                cible
                    in
                    ecrire Lier "lier_item" [ ( "fiche_id", E.int (C.entier "id" f) ), ( "item_id", E.int (C.entier "id" i) ), ( "version_fiche", E.int (C.entier "version" f) ), ( "action", E.string "rattacher" ) ] m

        PageLiens pas ->
            if m.modifieItem || m.modifie then
                notifier Information "Enregistrez ou annulez la modification de la ligne." m

            else
                m.detail |> Maybe.map (\d -> lire m.nature (C.entier "id" d) { m | debutLiens = max 0 (m.debutLiens + 20 * pas) }) |> Maybe.withDefault ( m, Cmd.none )

        Reglages ->
            envoyer LirePolitique "/api/web/lire_politique" (E.object []) { m | reglages = not m.reglages }

        Intervalle s ->
            ( { m | intervalle = s, reglagesModifies = "intervalle_jours" :: m.reglagesModifies }, Cmd.none )

        Budget s ->
            ( { m | budget = s, reglagesModifies = "budget" :: m.reglagesModifies }, Cmd.none )

        DureeSeanceCourte s ->
            ( { m | dureeSeanceCourte = s, reglagesModifies = "duree_seance_courte_minutes" :: m.reglagesModifies }, Cmd.none )

        QuestionsTypiques s ->
            ( { m | questionsTypiques = s, reglagesModifies = "questions_typiques" :: m.reglagesModifies }, Cmd.none )

        SauverPolitique ->
            if List.isEmpty m.reglagesModifies then
                notifier Information "Aucun réglage n’a été modifié." m

            else if C.entier "version" m.politique < 1 then
                notifier Information "Chargement des réglages en cours." m

            else if not (entierValide 1 3650 m.intervalle) || (m.budget /= "" && not (entierValide 1 1000 m.budget)) || not (entierValide 1 20 m.questionsTypiques) || not (entierValide 1 10080 m.dureeSeanceCourte) then
                notifier Erreur "L’intervalle doit être de 1 à 3650 jours, le budget vide ou de 1 à 1000, le nombre typique de questions de 1 à 20, et le seuil de séance courte de 1 à 10080 minutes." m

            else
                ecrire Regler
                    "regler_politique"
                    (( "version", E.int (C.entier "version" m.politique) )
                        :: List.filter (\( cle, _ ) -> List.member cle m.reglagesModifies)
                            [ ( "intervalle_jours", E.int (String.toInt m.intervalle |> Maybe.withDefault 90) )
                            , ( "budget", String.toInt m.budget |> Maybe.map E.int |> Maybe.withDefault E.null )
                            , ( "duree_seance_courte_minutes", E.int (String.toInt m.dureeSeanceCourte |> Maybe.withDefault 60) )
                            , ( "questions_typiques", E.int (String.toInt m.questionsTypiques |> Maybe.withDefault 8) )
                            ]
                    )
                    m


recevoir : Value -> Modele -> ( Modele, Cmd Message )
recevoir retour m =
    let
        numero =
            C.entier "numero" retour

        statut =
            C.entier "statut" retour

        corps =
            C.objet "corps" retour

        erreur =
            let
                e =
                    C.chaine "erreur" corps
            in
            if e == "" then
                C.chaine "error" corps

            else
                e
    in
    case Dict.get numero m.attentes of
        Nothing ->
            ( m, Cmd.none )

        Just but ->
            let
                n =
                    { m | attentes = Dict.remove numero m.attentes }

                obsolete =
                    case but of
                        Lister _ ->
                            numero /= m.dernierListe

                        Lire _ _ ->
                            numero /= m.dernierDetail

                        _ ->
                            False
            in
            if obsolete then
                ( n, Cmd.none )

            else if (statut == 401 || erreur == "csrf_required") && but /= Connecter then
                let
                    suspension =
                        m.session |> Maybe.map (\s -> { compte = s.compte, nature = m.nature, detail = m.detail, brouillon = m.brouillon, ecriture = m.ecriture, editionItem = m.editionItem, contenuItem = m.contenuItem })

                    vide =
                        initial m.flags
                in
                ( { vide
                    | numero = m.numero
                    , urlMcp = m.urlMcp
                    , gestionAcces = m.gestionAcces
                    , authMode = m.authMode
                    , compteUrl = m.compteUrl
                    , notice = m.notice
                    , verification = False
                    , suspension =
                        if m.modifie || m.modifieItem || m.ecriture /= Nothing then
                            suspension

                        else
                            Nothing
                    , message = Just ( Information, "Connectez-vous pour accéder à vos fiches et items." )
                  }
                , effet "annulerRequetes" E.null
                )

            else if statut == 0 then
                notifier Erreur "La réponse n’a pas été reçue. Une écriture a pu être enregistrée : utilisez Réessayer, qui conserve sa clé." n

            else if statut < 200 || statut >= 300 || erreur /= "" then
                notifier Erreur
                    (if statut == 409 then
                        "L’objet a changé. Votre saisie est conservée ; fermez puis relisez la version actuelle avant de concilier les modifications."

                     else if erreur == "quota_depasse" then
                        "Votre quota est atteint. Consultez Mon compte et mes limites. Vos données sont conservées ; l’archivage ne libère pas d’espace."

                     else if List.member erreur [ "texte_trop_long", "ligne_trop_longue" ] then
                        "Le texte dépasse la longueur autorisée. Raccourcissez-le ; les plafonds sont indiqués dans Mon compte et mes limites."

                     else if List.member erreur [ "limite_fiches", "limite_items_fiche" ] then
                        "La limite de fiches ou d’items par fiche est atteinte. Consultez Mon compte et mes limites."

                     else if erreur == "verification_renforcee_requise" then
                        "L’administration nécessite une nouvelle connexion avec mot de passe et code de sécurité."

                     else
                        "Opération refusée : "
                            ++ (if erreur == "" then
                                    "réponse inattendue"

                                else
                                    erreur
                               )
                    )
                    { n | ecriture = Nothing, verification = False }

            else
                appliquer but corps n


appliquer : But -> Value -> Modele -> ( Modele, Cmd Message )
appliquer but corps m =
    let
        maintenant =
            C.chaine "maintenant" corps

        flags =
            m.flags

        pr =
            C.objet "politique" corps

        -- Une lecture tardive ne remplace pas une saisie ni sa version de base.
        rafraichirPolitique =
            pr /= E.null && (List.isEmpty m.reglagesModifies || but == Regler)

        n =
            { m
                | flags =
                    if maintenant == "" then
                        flags

                    else
                        { flags | instant = maintenant }
                , politique =
                    if pr == E.null || (not rafraichirPolitique && m.politique /= E.null) then
                        m.politique

                    else
                        pr
                , intervalle =
                    if pr == E.null || (but /= Regler && List.member "intervalle_jours" m.reglagesModifies) then
                        m.intervalle

                    else
                        String.fromInt (C.entier "intervalle_jours" pr)
                , budget =
                    if pr == E.null || (but /= Regler && List.member "budget" m.reglagesModifies) then
                        m.budget

                    else
                        C.nombre "budget" pr |> Maybe.map (round >> String.fromInt) |> Maybe.withDefault ""
                , dureeSeanceCourte =
                    if pr == E.null || (but /= Regler && List.member "duree_seance_courte_minutes" m.reglagesModifies) then
                        m.dureeSeanceCourte

                    else
                        String.fromInt (C.entier "duree_seance_courte_minutes" pr)
                , questionsTypiques =
                    if pr == E.null || (but /= Regler && List.member "questions_typiques" m.reglagesModifies) then
                        m.questionsTypiques

                    else
                        String.fromInt (C.entier "questions_typiques" pr)
            }

        connecter =
            case D.decodeValue (D.map4 Session (D.field "username" D.string) (D.field "csrf" D.string) (D.oneOf [ D.field "administrateur" D.bool, D.succeed False ]) (D.oneOf [ D.field "verificationRenforcee" D.bool, D.succeed False ])) corps of
                Err _ ->
                    notifier Erreur "Réponse de session invalide." { n | verification = False }

                Ok s ->
                    if String.isEmpty s.compte || String.isEmpty s.csrf then
                        notifier Erreur "Réponse de session incomplète." { n | verification = False }

                    else
                        let
                            base =
                                { n | session = Just s, verification = False, secret = "", suspension = Nothing, message = Nothing, reglagesModifies = [], politique = E.null, intervalle = "90", budget = "", questionsTypiques = "8", dureeSeanceCourte = "60", reglages = False }

                            restaure =
                                case m.suspension of
                                    Just b ->
                                        if b.compte == s.compte then
                                            { base | nature = b.nature, detail = b.detail, brouillon = b.brouillon, edition = b.editionItem == Nothing, modifie = b.editionItem == Nothing, editionItem = b.editionItem, contenuItem = b.contenuItem, modifieItem = b.editionItem /= Nothing, ecriture = b.ecriture }

                                        else
                                            base

                                    Nothing ->
                                        base
                        in
                        if Informations.publique m.flags.chemin then
                            ( restaure, Cmd.none )

                        else if m.flags.adresse == "#compte" then
                            actualiser MonCompte restaure

                        else if m.flags.adresse == "#administration" then
                            actualiser Administration restaure

                        else if restaure.edition || restaure.editionItem /= Nothing then
                            lister restaure

                        else
                            case C.depuisAdresse m.flags.adresse of
                                Just ( nature, id ) ->
                                    actualiser (Ouvrir nature id) restaure

                                Nothing ->
                                    lister
                                        { restaure
                                            | nature =
                                                if m.flags.adresse == "#items" then
                                                    C.Item

                                                else
                                                    restaure.nature
                                        }
    in
    case but of
        LireLimites ->
            envoyer ApercuExport "/api/web/exporter_compte" (E.object [ ( "table", E.string "vision_fiches" ), ( "debut", E.int n.compteExport.debut ) ]) { n | limites = corps }

        ApercuExport ->
            ( { n | compteExport = Compte.recevoir corps n.compteExport }, Cmd.none )

        Gerer op ->
            ( { n | gestion = Gestion.recevoir op corps n.gestion }, Cmd.none )

        ApercuInvitation ->
            ( { n | invitation = corps }, Cmd.none )

        ApercuAdmission ->
            ( { n | admissionLien = corps }, Cmd.none )

        ConfirmerAdmission ->
            notifier Information (C.chaine "information" corps) { n | accordAdmission = False, admissionLien = E.null }

        Inscrire ->
            notifier Information (C.chaine "information" corps) { n | admission = Admission.initial }

        EffacerCompte ->
            if C.vrai "effacement_en_attente" corps then
                notifier Information "Votre demande d’effacement est enregistrée. La copie chiffrée du registre est encore en attente d’envoi ; la procédure reprendra automatiquement. Vous pouvez encore exporter vos données." n

            else
                ( initial m.flags, Cmd.batch [ effet "annulerRequetes" E.null, effet "redirection" (E.string "/") ] )

        LirePolitique ->
            ( n, Cmd.none )

        SessionInitiale ->
            connecter

        Connecter ->
            connecter

        Deconnecter ->
            ( { n | limites = E.null, gestion = Gestion.initial, compteExport = Compte.initial, compteOuvert = False, gestionOuverte = False, exportEnCours = False, effacement = "", session = Nothing, detail = Nothing, resultats = [], candidats = [], liensTrouves = [], brouillon = C.nouveau, edition = False, modifie = False, ecriture = Nothing, suspension = Nothing, attentes = Dict.empty, reglagesModifies = [], politique = E.null, intervalle = "90", budget = "", questionsTypiques = "8", dureeSeanceCourte = "60", reglages = False }, effet "annulerRequetes" E.null )

        Lister nature ->
            if nature == m.nature then
                ( { n | resultats = C.listes "resultats" corps, total = C.entier "total" corps }, Cmd.none )

            else
                ( n, Cmd.none )

        Lire nature _ ->
            case List.head (C.listes "objets" corps) of
                Nothing ->
                    notifier Erreur "Objet introuvable." n

                Just d ->
                    ( { n | nature = nature, detail = Just d, edition = False, modifie = False, brouillon = C.brouillon d }, Cmd.batch [ effet "focus" (E.string "detail"), effet "adresse" (E.string (C.destination nature (C.entier "id" d))) ] )

        Enregistrer nature ->
            if not (C.vrai "enregistre" corps) then
                notifier Erreur "L’enregistrement n’est pas confirmé." n

            else
                let
                    d =
                        C.objet (C.nom nature) corps
                in
                lire nature (C.entier "id" d) { n | detail = Just d, edition = False, modifie = False, ecriture = Nothing, candidats = [], preuve = Nothing, creationVerifiee = False, message = Just ( Succes, "Enregistré." ) }

        EnregistrerLigne _ ->
            if not (C.vrai "enregistre" corps) then
                notifier Erreur "L’enregistrement n’est pas confirmé." n

            else
                n.detail |> Maybe.map (\d -> lire n.nature (C.entier "id" d) { n | ecriture = Nothing, editionItem = Nothing, contenuItem = "", modifieItem = False, message = Just ( Succes, "Item enregistré." ) }) |> Maybe.withDefault ( { n | ecriture = Nothing }, Cmd.none )

        VerifierCreation ->
            let
                preuve =
                    C.chaine "preuve_creation" corps

                candidats =
                    C.listes "candidats" corps

                suite =
                    { n | preuve = Just preuve, candidats = candidats }
            in
            if preuve == "" then
                notifier Erreur "Préparation indisponible : réessayez après remise en état de la recherche sémantique." n

            else if List.isEmpty candidats then
                sauver { suite | creationVerifiee = True }

            else
                notifier Information "Examinez tous les items proposés. Réutilisez la même connaissance ou expliquez la distinction avant de créer." suite

        RechercherLiens ->
            ( { n | liensTrouves = C.listes "resultats" corps }, Cmd.none )

        Lier ->
            if not (C.vrai "enregistre" corps) then
                notifier Erreur "Le lien n’est pas confirmé." n

            else
                case n.detail of
                    Just d ->
                        lire n.nature (C.entier "id" d) { n | ecriture = Nothing, liensOuverts = False }

                    Nothing ->
                        ( { n | ecriture = Nothing }, Cmd.none )

        Regler ->
            if not (C.vrai "enregistre" corps) then
                notifier Erreur "Le réglage n’est pas confirmé." n

            else
                notifier Succes "Politique enregistrée ; les stabilités sont conservées." { n | ecriture = Nothing, reglagesModifies = [] }


avecAdresse : String -> ( Modele, Cmd Message ) -> ( Modele, Cmd Message )
avecAdresse url ( modele, commande ) =
    ( modele, Cmd.batch [ commande, effet "adresse" (E.string url) ] )


db : Int -> String
db n =
    (if n >= 0 then
        "+"

     else
        ""
    )
        ++ String.fromInt n
        ++ " dB"


fenetre : Value -> Element Message
fenetre f =
    let
        etat =
            C.chaine "etat" f

        texte =
            case etat of
                "reference_inconnue" ->
                    "Référence inconnue — aucune date de révision inventée."

                "reference_future" ->
                    "Date de référence future : à vérifier."

                "hors_horizon" ->
                    "Intervalle hors horizon d’affichage (100 ans)."

                "intervalle_tres_court" ->
                    "Intervalle inférieur à une minute : réglage à vérifier."

                "fenetre_depassee" ->
                    "En retard — fenêtre terminée le " ++ String.left 10 (C.chaine "fin" f)

                "dans_fenetre" ->
                    "Dans la plage — jusqu’au " ++ String.left 10 (C.chaine "fin" f)

                _ ->
                    "Fenêtre : " ++ String.left 10 (C.chaine "debut" f) ++ " → " ++ String.left 10 (C.chaine "fin" f)
    in
    texteSecondaire texte


fenetreLigne : Value -> Element Message
fenetreLigne item =
    let
        f =
            C.objet "fenetre" item
    in
    case C.chaine "statut" item of
        "retard" ->
            texteSecondaire ("En retard depuis le " ++ String.left 10 (C.chaine "fin" f))

        "dans_fenetre" ->
            texteSecondaire ("Dans la plage jusqu’au " ++ String.left 10 (C.chaine "fin" f))

        "nouveau" ->
            texteSecondaire "Non commencé"

        _ ->
            fenetre f


vue : Modele -> Html Message
vue m =
    if Informations.publique m.flags.chemin then
        Informations.vue { chemin = m.flags.chemin, adresse = m.flags.adresse, urlMcp = m.urlMcp, gestionAcces = m.gestionAcces, copiee = m.copiee, menuOuvert = m.menuOuvert, connecte = m.session /= Nothing, notice = m.notice } CopierAdresse ChoisirChapitre Menu

    else if m.session == Nothing && not m.verification && m.flags.chemin == "/" && C.depuisAdresse m.flags.adresse == Nothing then
        Informations.vue { chemin = "/", adresse = "", urlMcp = m.urlMcp, gestionAcces = m.gestionAcces, copiee = m.copiee, menuOuvert = m.menuOuvert, connecte = m.session /= Nothing, notice = m.notice } CopierAdresse ChoisirChapitre Menu

    else if m.flags.chemin == "/admission" then
        Documents.espaceMarque "Vision"
            [ MrJam.lien "Confidentialité" "/privacy" ]
            Nothing
            [ Documents.document "Confirmer la demande"
                [ m.message |> Maybe.map (\( niveau, texte ) -> avis niveau texte) |> Maybe.withDefault Element.none
                , if C.chaine "type" m.admissionLien == "parent" then
                    paragraphe "Vous confirmez autoriser le jeune concerné à utiliser Vision et être son représentant légal. Cette confirmation sera suivie d’une vérification manuelle avant admission. Vous pouvez retirer cet accord auprès de RGPD@MrJ.am."

                  else
                    paragraphe "Confirmez uniquement une demande que vous avez faite avec votre adresse de courrier."
                , MrJam.lien "Lire la notice de confidentialité" "/privacy"
                , if C.chaine "type" m.admissionLien /= "" then
                    pile
                        [ MrJam.caseACocher
                            (if C.chaine "type" m.admissionLien == "parent" then
                                "J’ai lu la notice, je suis le représentant légal et j’autorise cet usage."

                             else
                                "Je confirme mon adresse et ma demande d’accès."
                            )
                            m.accordAdmission
                            AccordAdmission
                        , bouton "Enregistrer ma confirmation" ConfirmerLienAdmission
                        ]

                  else
                    avis Information "Ce lien n’est plus disponible, ou sa vérification est en cours."
                ]
            ]

    else if m.flags.chemin == "/invitation" then
        Documents.espaceMarque "Vision"
            [ MrJam.lien "Confidentialité" "/privacy", MrJam.lien "Se connecter" "/connexion" ]
            Nothing
            [ Documents.document "Invitation à Vision"
                [ m.message |> Maybe.map (\( niveau, texte ) -> avis niveau texte) |> Maybe.withDefault Element.none
                , paragraphe "Votre compte MrJ.am sera commun aux outils auxquels vous aurez accès. Chaque outil garde ses propres données et droits."
                , if C.vrai "disponible" m.invitation then
                    paragraphe ("Ce lien accorde " ++ String.fromFloat (toFloat (C.entier "quota_octets" m.invitation) / 1000000) ++ " Mo par compte, au maximum " ++ String.fromInt (C.entier "fiches" (C.objet "limites" m.invitation)) ++ " fiches et " ++ String.fromInt (C.entier "items_par_fiche" (C.objet "limites" m.invitation)) ++ " items par fiche. Un item est limité à " ++ String.fromInt (C.entier "mots_item" (C.objet "limites" m.invitation)) ++ " mots et " ++ String.fromInt (C.entier "octets_item" (C.objet "limites" m.invitation)) ++ " octets. Ces quotas peuvent être modifiés ; une baisse conserve vos données et bloque les ajouts au-delà du plafond.")

                  else
                    avis Information "Ce lien n’est pas disponible, ou sa vérification est en cours."
                , MrJam.lien "Lire la notice de confidentialité" "/privacy"
                , MrJam.mapper AdmissionMessage (Admission.vue m.admission)
                , MrJam.caseACocher "J’ai pris connaissance de la notice de confidentialité." m.noticeLue AccepterNotice
                , if C.vrai "inscriptions_ouvertes" m.notice && C.vrai "disponible" m.invitation then
                    bouton "Demander mon accès" Inscription

                  else
                    avis Information "Les inscriptions sont actuellement fermées."
                ]
            ]

    else
        Documents.espaceMarque "Vision"
            (if m.session == Nothing then
                []

             else
                [ Documents.onglet (m.nature == C.Fiche) "Fiches" (Naviguer (Changer C.Fiche))
                , Documents.onglet (m.nature == C.Item) "Items" (Naviguer (Changer C.Item))
                , Pictogrammes.action Pictogrammes.Reglages "Réglages" Reglages
                , Documents.menu m.menuOuvert
                    Menu
                    [ Documents.action "Mon compte et mes limites" MonCompte
                    , if m.session |> Maybe.map .administrateur |> Maybe.withDefault False then
                        Documents.action "Administration" Administration

                      else
                        Element.none
                    , MrJam.lien "Tutoriel" "/docs"
                    , MrJam.lien "Tokens d’accès" "/auth/mcp"
                    , Pictogrammes.action Pictogrammes.Sortir "Se déconnecter" (Naviguer Quitter)
                    ]
                ]
            )
            (vueConfirmation m)
            ((m.message |> Maybe.map (\( niveau, texte ) -> [ avis niveau texte ]) |> Maybe.withDefault [])
                ++ (if m.verification then
                        [ texteSecondaire "Vérification de la session…" ]

                    else
                        case m.session of
                            Nothing ->
                                [ Documents.document "Connexion"
                                    (if m.authMode == "oidc" then
                                        [ paragraphe "Connectez-vous avec votre compte commun MrJ.am.", MrJam.lien "Se connecter" "/auth/connexion" ]

                                     else
                                        [ champ "Identifiant" m.identifiant Identifiant, motDePasse "Mot de passe" m.secret Secret, bouton "Se connecter" Connexion ]
                                    )
                                ]

                            Just s ->
                                if m.compteOuvert then
                                    List.map (MrJam.mapper CompteMessage) (Compte.vue m.limites m.compteUrl m.exportEnCours m.compteExport)

                                else if m.gestionOuverte then
                                    if not s.verificationRenforcee then
                                        [ Documents.document "Vérification de sécurité"
                                            [ paragraphe "L’administration nécessite votre mot de passe et un second facteur vérifiés il y a moins de cinq minutes. Activez la double authentification depuis votre compte commun, puis reconnectez-vous."
                                            , MrJam.lien "Sécurité de mon compte" m.compteUrl
                                            , MrJam.lien "Vérifier mon identité" "/auth/connexion?verification=renforcee&retour=%2F%23administration"
                                            ]
                                        ]

                                    else
                                        List.map (\e -> MrJam.mapper GestionMessage e) (Gestion.vue m.gestion)

                                else
                                    espace m
                   )
            )


vueConfirmation : Modele -> Maybe (Html Message)
vueConfirmation m =
    case m.confirmation of
        Nothing ->
            Nothing

        Just c ->
            Just <|
                Fenetres.modale "confirmation"
                    "Confirmer"
                    Rester
                    [ paragraphe
                        (case c of
                            EffacerVision ->
                                "Cet effacement supprime définitivement vos données Vision. Exportez-les auparavant. Votre identité commune et vos autres outils sont conservés."

                            Archiver _ ->
                                "L’archivage est réversible et conserve les connaissances et leurs liens."

                            Detacher _ _ _ ->
                                "Détacher conserve cet item et ses autres rattachements."

                            _ ->
                                "Quitter abandonnera la saisie non enregistrée."
                        )
                    , if c == EffacerVision then
                        champ "Saisissez EFFACER VISION" m.effacement SaisirEffacement

                      else
                        Element.none
                    , actions [ boutonDestructif "Confirmer" Confirmer, boutonSecondaire "Continuer" Rester ]
                    ]


espace : Modele -> List (Element Message)
espace m =
    []
        ++ (if m.ecriture /= Nothing && Dict.isEmpty m.attentes then
                [ bouton "Réessayer la même écriture" Reessayer ]

            else
                []
           )
        ++ (if m.reglages then
                [ Documents.section "Politique de révision"
                    [ Donnees.nombre "Intervalle de référence (jours)" m.intervalle Intervalle
                    , actions (List.map (\j -> boutonSecondaire (String.fromInt j ++ " jours") (Intervalle (String.fromInt j))) [ 7, 14, 30, 90 ])
                    , Donnees.nombre "Budget d’items par jour (facultatif)" m.budget Budget
                    , Donnees.nombre "Nombre typique de questions (1 à 20)" m.questionsTypiques QuestionsTypiques
                    , Donnees.nombre "Seuil de séance courte (minutes)" m.dureeSeanceCourte DureeSeanceCourte
                    , paragraphe "Sous ce seuil strict, les dates manquantes peuvent être approximées à la clôture. À la borne ou au-delà, une clarification, une trace non datée ou votre accord explicite est nécessaire."
                    , paragraphe "Si davantage d’items évalués sont dans la fenêtre, Vision demandera combien en réviser ; les items non évalués peuvent compléter un petit lot."
                    , paragraphe ("Décalage de charge : " ++ db (C.entier "decalage" m.politique) ++ ". Adaptation d’au plus 1 dB par semaine à partir des items distincts.")
                    , bouton "Enregistrer la politique" SauverPolitique
                    ]
                ]

            else
                []
           )
        ++ (if m.edition && m.detail == Nothing then
                [ vueEdition m ]

            else
                case m.detail of
                    Just d ->
                        [ vueDetail m d ]

                    Nothing ->
                        [ vueListe m ]
           )


vueListe : Modele -> Element Message
vueListe m =
    pile
        [ Documents.entete (C.pluriel m.nature)
            [ bouton
                (if m.nature == C.Fiche then
                    "Nouvelle fiche"

                 else
                    "Nouvel item"
                )
                Nouvelle
            ]
        , Documents.filtres
            [ MrJam.champIdentifieSoumis
                { identifiant = "recherche"
                , libelle = "Recherche"
                , aide = Nothing
                , exemple =
                    Just
                        (if m.nature == C.Item then
                            "Rechercher une connaissance…"

                         else
                            "Rechercher un titre…"
                        )
                , limite = Nothing
                }
                m.recherche
                Recherche
                Filtrer
            , Documents.actions [ Documents.action "Rechercher" Filtrer, MrJam.boutonDevoiler "filtres" "Filtres et tri" m.filtresOuverts Filtres ]
            ]
        , if m.filtresOuverts then
            Documents.repere "filtres" <|
                Documents.filtres
                    ([ selecteur "État" [ ( "actif", "Actifs" ), ( "archive", "Archivés" ), ( "tous", "Tous" ) ] m.etat Etat
                     , selecteur "Tri"
                        [ ( if m.nature == C.Fiche then
                                "titre"

                            else
                                "alphabetique"
                          , if m.nature == C.Fiche then
                                "Titre"

                            else
                                "Connaissance"
                          )
                        , ( "modification", "Modification récente" )
                        , ( C.grandeur m.nature
                          , if m.nature == C.Fiche then
                                "Priorité"

                            else
                                "Stabilité"
                          )
                        ]
                        m.tri
                        Tri
                     ]
                        ++ (if m.nature == C.Fiche then
                                [ champ "Tags (séparés par des virgules)" m.tags Tags ]

                            else
                                []
                           )
                    )

          else
            Element.none
        , Tableaux.tableauAvecOutils "Résultats"
            [ Pictogrammes.action Pictogrammes.Trier "Trier le tableau" Filtres, Pictogrammes.action Pictogrammes.Filtrer "Filtrer le tableau" Filtres ]
            [ Tableaux.principale
                (if m.nature == C.Fiche then
                    "Titre"

                 else
                    "Connaissance"
                )
                (lienObjet m.nature)
            , Tableaux.mesure
                (if m.nature == C.Fiche then
                    "Priorité"

                 else
                    "Stabilité"
                )
                (C.entier (C.grandeur m.nature) >> db >> Element.text)
            , Tableaux.mesure
                (if m.nature == C.Fiche then
                    "Items"

                 else
                    "Évaluation"
                )
                (\v ->
                    Element.text
                        (if m.nature == C.Fiche then
                            String.fromInt (C.entier "nombre_items" v)

                         else if C.vrai "evalue" v then
                            "Évalué"

                         else
                            "Non évalué"
                        )
                )
            ]
            m.resultats
        , Documents.pagination { debut = m.debut, total = m.total, taille = 20, precedent = Pagination -1, suivant = Pagination 1 }
        ]


libelle : C.Nature -> Value -> String
libelle nature objet =
    if nature == C.Item then
        C.chaine "contenu" objet

    else
        C.chaine "titre" objet


lienObjet : C.Nature -> Value -> Element Message
lienObjet nature objet =
    Documents.lien (libelle nature objet) (C.destination nature (C.entier "id" objet))


vueDetail : Modele -> Value -> Element Message
vueDetail m d =
    let
        estFiche =
            m.nature == C.Fiche

        archive =
            C.objet "archive_a" d /= E.null

        autre =
            C.autre m.nature

        lies =
            C.listes (C.nom autre ++ "s") d

        detacher v =
            Naviguer
                (if estFiche then
                    Detacher (C.entier "id" d) (C.entier "id" v) (C.entier "version" d)

                 else
                    Detacher (C.entier "id" v) (C.entier "id" d) (C.entier "version" v)
                )
    in
    Documents.repere "detail" <|
        Documents.document (libelle m.nature d)
            [ Documents.actions
                [ Pictogrammes.action Pictogrammes.Retour "Retour à la liste" (Naviguer Fermer)
                , if m.edition then
                    Pictogrammes.action Pictogrammes.Enregistrer "Enregistrer" Sauver

                  else
                    Pictogrammes.action Pictogrammes.Modifier "Modifier" Editer
                , if m.edition then
                    Pictogrammes.action Pictogrammes.Fermer "Annuler" AnnulerEdition

                  else
                    Element.none
                , Documents.action
                    (if archive then
                        "Restaurer"

                     else
                        "Archiver"
                    )
                    (Naviguer (Archiver (not archive)))
                ]
            , if m.edition && estFiche then
                champ "Titre" (valeur "titre" m) (Saisir "titre")

              else
                Element.none
            , texteSecondaire
                ((if estFiche then
                    "Priorité "

                  else
                    "Stabilité "
                 )
                    ++ db (C.entier (C.grandeur m.nature) d)
                )
            , if estFiche then
                texteSecondaire "Priorité positive : révisions avancées."

              else
                fenetre (C.objet "fenetre" d)
            , if m.edition then
                zoneTexte "Contenu de référence" (valeur "contenu" m) (Saisir "contenu")

              else
                Lecture.markdown (C.chaine "contenu" d)
            , if m.edition then
                zoneTexte "Alias (un par ligne)" (valeur "alias" m) (Saisir "alias")

              else
                Element.none
            , if not estFiche || (not m.edition && C.chaine "suivi" d == "") then
                Element.none

              else
                Documents.section "Suivi actuel"
                    [ if m.edition then
                        zoneTexte "Suivi actuel" (valeur "suivi" m) (Saisir "suivi")

                      else
                        Donnees.lecture (C.chaine "suivi" d)
                    ]
            , if m.edition && estFiche then
                Documents.section "Classement" [ zoneTexte "Tags (un par ligne)" (valeur "tags" m) (Saisir "tags"), Donnees.nombre "Priorité P (dB, −20 à +20)" (valeur "priorite" m) (Saisir "priorite") ]

              else
                Element.none
            , if estFiche then
                Element.none

              else
                texteSecondaire
                    (if not (C.vrai "evalue" d) then
                        "Cet item n’a pas été évalué."

                     else
                        "Dernière évaluation : " ++ C.chaine "evalue_a" d
                    )
            , Documents.section
                (if autre == C.Fiche then
                    "Fiches associées"

                 else
                    "Items associés"
                )
                [ Documents.action "Ajouter un rattachement" AfficherLiens
                , Tableaux.tableauAvecOutils "Rattachements"
                    [ Pictogrammes.action Pictogrammes.Trier "Trier les items" (OutilsLiens "tri"), Pictogrammes.action Pictogrammes.Filtrer "Filtrer les items" (OutilsLiens "filtre") ]
                    [ Tableaux.principale
                        (if estFiche then
                            "Connaissance"

                         else
                            "Titre"
                        )
                        (\v ->
                            if estFiche && m.editionItem == Just (C.entier "id" v) then
                                Tableaux.celluleEditable "Connaissance de l’item" m.contenuItem SaisirLigne

                            else
                                lienObjet autre v
                        )
                    , Tableaux.colonne
                        (if estFiche then
                            "Révision"

                         else
                            "Contexte"
                        )
                        (\v ->
                            if estFiche then
                                fenetreLigne v

                            else
                                texteSecondaire (C.chaine "contexte" v)
                        )
                    , Tableaux.commandes
                        (\v ->
                            if estFiche && m.editionItem == Just (C.entier "id" v) then
                                actions [ Pictogrammes.action Pictogrammes.Enregistrer "Enregistrer l’item" SauverLigne, Pictogrammes.action Pictogrammes.Fermer "Annuler la modification de l’item" AnnulerLigne ]

                            else
                                actions
                                    [ if estFiche then
                                        Pictogrammes.action Pictogrammes.Modifier ("Modifier l’item : " ++ libelle autre v) (EditerLigne (C.entier "id" v))

                                      else
                                        Element.none
                                    , Documents.actionSur "Détacher" (libelle autre v) (detacher v)
                                    ]
                        )
                    ]
                    lies
                , if m.outilsLiens /= Nothing && estFiche then
                    Documents.filtres
                        (case m.outilsLiens of
                            Just "tri" ->
                                [ selecteur "Trier les items" [ ( "echeance", "Date due" ), ( "alphabetique", "Ordre alphabétique" ), ( "ordre", "Ordre de rattachement" ) ] m.triLiens TriLiens ]

                            Just "filtre" ->
                                [ selecteur "Filtrer les items par échéance" [ ( "tous", "Tous" ), ( "retard", "En retard" ), ( "dans_fenetre", "Dans la plage" ), ( "nouveau", "Non commencés" ), ( "a_venir", "À venir" ) ] m.filtreLiens FiltreLiens ]

                            _ ->
                                []
                        )

                  else
                    Element.none
                , Documents.pagination
                    { debut = m.debutLiens
                    , total =
                        if estFiche then
                            C.entier "nombre_items_filtres" d

                        else
                            C.entier ("nombre_" ++ C.nom autre ++ "s") d
                    , taille = 20
                    , precedent = PageLiens -1
                    , suivant = PageLiens 1
                    }
                ]
            , if m.liensOuverts then
                Documents.section "Rattacher un objet existant"
                    [ champ "Rechercher un objet à rattacher" m.rechercheLiens RechercheLiens
                    , Documents.action "Chercher" ChercherLiens
                    , Tableaux.tableau "Objets disponibles"
                        [ Tableaux.principale "Contenu" (libelle autre >> paragraphe)
                        , Tableaux.commandes (\v -> Documents.actionSur "Rattacher" (libelle autre v) (Rattacher v))
                        ]
                        m.liensTrouves
                    ]

              else
                Element.none
            ]


vueEdition : Modele -> Element Message
vueEdition m =
    Documents.repere "edition" <|
        Documents.document
            (if m.detail == Nothing then
                "Créer"

             else
                "Modifier"
            )
            ([ zoneTexte "Contenu de référence" (valeur "contenu" m) (Saisir "contenu")
             , zoneTexte "Alias (un par ligne)" (valeur "alias" m) (Saisir "alias")
             ]
                ++ (if m.nature == C.Fiche then
                        [ champ "Titre" (valeur "titre" m) (Saisir "titre"), zoneTexte "Suivi qualitatif (facultatif)" (valeur "suivi" m) (Saisir "suivi"), zoneTexte "Tags (un par ligne)" (valeur "tags" m) (Saisir "tags"), Donnees.nombre "Priorité P (dB, −20 à +20)" (valeur "priorite" m) (Saisir "priorite"), texteSecondaire "Priorité positive : révisions avancées." ]

                    else if m.detail == Nothing then
                        [ Donnees.nombre "Stabilité initiale S (dB)" (valeur "stabilite" m) (Saisir "stabilite"), champ "Date de départ connue (ISO 8601, facultatif)" (valeur "reference_a" m) (Saisir "reference_a"), champ "Justification de l’estimation (si S ≠ −15)" (valeur "justification" m) (Saisir "justification") ]

                    else
                        [ texteSecondaire "La stabilité est actualisée par les évaluations ; cette édition conserve les dates de rappel." ]
                   )
                ++ [ actions
                        [ if m.ecriture /= Nothing then
                            boutonEnCours "Enregistrement…"

                          else
                            bouton "Enregistrer" Sauver
                        , boutonSecondaire "Fermer la saisie" (Naviguer Fermer)
                        ]
                   ]
                ++ (if List.isEmpty m.candidats then
                        []

                    else
                        [ Documents.section "Items proches déjà présents"
                            (List.map (\v -> pile [ paragraphe (C.chaine "contenu" v), Donnees.lecture (C.chaine "contenu" v), boutonSecondaire "Réutiliser cet item" (Reutiliser (C.entier "id" v)) ]) m.candidats
                                ++ [ champ "Pourquoi s’agit-il d’une connaissance distincte ?" (valeur "distinction" m) (Saisir "distinction"), bouton "Créer cet item distinct" CreerDistinct ]
                            )
                        ]
                   )
            )
