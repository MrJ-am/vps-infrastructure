/* Formats de portabilité : aucune révision dans le Markdown des connaissances. */
const ExportsVision = (() => {
  'use strict';
  function markdown(tables, selection = null) {
    const ids = selection === null ? null : new Set(selection);
    const fiches = (tables.vision_fiches || []).filter(f => ids === null || ids.has(f.id));
    if (ids && fiches.length !== ids.size) throw new Error('selection_introuvable');
    const items = new Map((tables.vision_items || []).map(i => [i.id, i]));
    const lies = new Set();
    const titre = t => String(t || 'Sans titre').replace(/[\r\n]+/g, ' ');
    const puce = i => '- **' + titre(i.titre) + '**\n' + String(i.contenu || '').split('\n').map(l => '  ' + l).join('\n');
    const lignes = ['# Mes connaissances Vision'];
    for (const fiche of fiches) {
      lignes.push('', '## ' + titre(fiche.titre), '', fiche.contenu || '');
      const liens = (tables.vision_liens || []).filter(l => l.fiche_id === fiche.id)
        .sort((a,b) => a.ordre - b.ordre || a.item_id - b.item_id);
      for (const lien of liens) {
        const item = items.get(lien.item_id);
        if (!item) throw new Error('item_manquant');
        lies.add(item.id);
        lignes.push('', puce(item));
      }
    }
    if (ids === null) {
      const seuls = [...items.values()].filter(i => !lies.has(i.id));
      if (seuls.length) lignes.push('', '## Items sans fiche', ...seuls.flatMap(i => ['', puce(i)]));
    }
    return lignes.join('\n') + '\n';
  }
  function xml(donnees) {
    const echapper = s => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
    function valeur(v) {
      if (v === null) return '<valeur type="null"/>';
      if (Array.isArray(v)) return '<valeur type="tableau">' + v.map(x => '<element>' + valeur(x) + '</element>').join('') + '</valeur>';
      if (typeof v === 'object') return '<valeur type="objet">' + Object.entries(v).map(([k,x]) => '<champ nom="' + echapper(k) + '">' + valeur(x) + '</champ>').join('') + '</valeur>';
      // XML 1.0 interdit certains contrôles : le codage base64 préserve ces textes.
      if (typeof v === 'string' && /[\x00-\x08\x0B\x0C\x0E-\x1F]/.test(v)) {
        const octets = new TextEncoder().encode(v);
        return '<valeur type="string" encodage="base64-utf8">' + btoa(Array.from(octets, c => String.fromCharCode(c)).join('')) + '</valeur>';
      }
      return '<valeur type="' + typeof v + '">' + echapper(v) + '</valeur>';
    }
    return '<?xml version="1.0" encoding="UTF-8"?>\n<vision version="1">' + valeur(donnees) + '</vision>\n';
  }
  return {markdown, xml};
})();
