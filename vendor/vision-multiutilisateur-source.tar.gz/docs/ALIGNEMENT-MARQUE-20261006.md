# Alignement de Vision.MrJ.am

Le centrage vertical de deux blocs ElmUI indépendants décalait Vision. par
rapport à MrJ.am. Parisienne et la fonte composée Signature ont des métriques
différentes. `MrJam.Identite.marque` compose désormais une même ligne
typographique, avec une marge pour les descendantes. Les fontes, leurs
contours et le texte sélectionnable restent conservés.

Style : `3c87b98aa48a5f6a533d7f88de9faf57cff1706d`.
Application : `ba19503113f94e2bd73cec27a09b2cf11a143cbe`.

Le test navigateur compare les pixels des deux parties de la marque et vérifie
que la signature n'est pas rognée. Il détecte effectivement le défaut de la
version précédente servie en HTTPS. La version corrigée passe aux largeurs
320, 375, 768 et 1440 px, ainsi qu'agrandie quatre fois. Les parcours de vitrine,
tutoriel, confidentialité et interface privée passent. Aucune migration SQL.

Publication effective sur https://vision.mrj.am/ : préparation
[37488460816](https://github.com/MrJ-am/vps-infrastructure/actions/runs/37488460816),
activation [37488989857](https://github.com/MrJ-am/vps-infrastructure/actions/runs/37488989857)
et constat indépendant [37489386224](https://github.com/MrJ-am/vps-infrastructure/actions/runs/37489386224)
réussis. Opérateur : `412bbcb9ea9983a7f2b29c6bac277402f90d49b9`.
Le même contrôle des pixels passe directement en HTTPS aux quatre largeurs et
à un grossissement de quatre fois. Les fontes restent intactes et sélectionnables.

CI réussies : style 37487274118, interface 37487447204, serveur 37487447391,
création sémantique 37487447187 et infrastructure 37487971501 (140 tests,
évaluations Nix et restauration PostgreSQL isolée). Les cinq tests locaux
des archives réussissent après intégration des archives exactes assemblées
par 37487771914. Le contrôle avait d'abord refusé les métadonnées nouvelles
associées aux archives précédentes, avant leur remplacement.

La première préparation est restée bloquée dans GitHub avant toute exécution.
La relance identique a réussi à la tentative 2. Aucune protection n'a été changée.

La version fonctionnelle reste 2.6.1. Cette correction de présentation ne modifie
aucun outil MCP, aucune route ni aucun réglage. Les vingt tables sont préservées.
Aucune migration SQL, aucune restauration de production ni modification NixOS.
Les sauvegardes et anciennes releases restent disponibles ; le retour autonome
est désarmé après vérification. Matheval et Logique gardent leurs releases.
Le rapport détaillé est conservé dans le dépôt privé VPS sous
`operations/vision-alignement-publication.json`.
