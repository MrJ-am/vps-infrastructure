# Qualification du candidat multi-utilisateur

Contrôles réalisés le 8 octobre 2026 sur données synthétiques uniquement.
Référence de départ : `43bc38b7ce139dfadba78e2a059805411fd976ad`.
Style figé : `96fa28ac564b9492768837d4087608e83acc721b`.

- Pipeline métier complet : contrats REST/MCP, compilation Common Lisp,
  régressions SQL, documents, migrations historiques et cohérence ; mesure
  sur 5 000 fiches dans une base jetable avec plafonds de test explicites.
- PostgreSQL 17.6/pgvector 0.8.0 : migrations 019–022 et vrais rôles HTTP
  non propriétaires. Les sept tests `tests/comptes.py` vérifient isolation
  croisée, administration sans accès aux contenus, quotas UTF-8/historiques,
  rollback, écritures concurrentes, invitations et rétroactivité, export et
  effacement. `tests/droits_http.py` vérifie aussi les refus HTTP, l'identité
  transmise dans le corps et le registre d'effacement durable.
- Navigateur réel Chromium et backend Common Lisp/PostgreSQL : recherche,
  pagination, édition, partage, doublons, archivage, session, CSRF, conflits et
  rejeu sur 320, 375, 768 et 1 280 pixels. La connexion se trouve dans le menu
  en haut à droite de la vitrine.
- Parcours nouveaux, dans `interface/tests/multiutilisateur.py` : vitrine,
  compte, export, administration, promotion et création/aperçu d'invitation
  sur 320 et 1 440 pixels. Contrastes mesurés sur les couleurs réellement
  rendues : texte au moins 4,5:1, contrôles au moins 3:1. Les tests graphiques,
  vitrine, types Elm, routage et architecture ont réussi.
- Infrastructure associée : 153 tests Python, évaluations NixOS existantes
  et configuration multi-utilisateur activée dans une fixture uniquement.
  Keycloak 26.7.3 : realm versionné, mot de passe et OTP, PKCE, nonce, signature
  RSA, AMR et auth_time vérifiés sur le véritable fournisseur en conteneur.
- Sauvegarde/restauration isolée : dump PostgreSQL 17 chiffré age, restauration
  puis rejeu du registre externe ; le compte et les contenus effacés ne
  réapparaissent pas. Test reproductible dans le dépôt Infrastructure.

Ces contrôles ne constituent pas une preuve de l'état de production. Le test
Keycloak utilise H2 et HTTP loopback ; JDBC Unix, DNS/TLS, SMTP, charge, copies
hors machine, anciennes sauvegardes et retour des ACL restent à qualifier sur
le staging VPS. La rétention et la réplication du registre d'effacement doivent
être prouvées avec les copies réellement conservées.

Le dossier [RGPD.md](RGPD.md) distingue mesures préparées et faits à obtenir.
Le responsable du traitement, le contact, la localisation contractuelle, les
accords des sous-traitants et les transferts LLM ne sont pas inventés. Les
inscriptions et les modules nouveaux restent fermés/désactivés par défaut.
L'accès privilégié potentiel de l'exploitation technique aux contenus en clair
est déclaré ; aucun chiffrement de bout en bout n'est promis.

Les CI publiées sur les propositions de changement sont les preuves attachées
aux révisions finales. Aucun déploiement de production n'est réalisé par cette
qualification. Suivre le dossier opérateur du dépôt Infrastructure pour une
activation distincte et son retour préparé.

## Admission contrôlée — prolongement de la qualification

La migration 024 ajoute la réservation pendant sept jours et le certificat
privé d'admission. L'activation OIDC directe sans ce certificat est refusée.
Neuf tests PostgreSQL réels passent, incluant la consommation concurrente,
les droits SQL privés, l'accord préalable et le contrôle du rattachement.
Le formulaire et la confirmation parentale explicite ont été vérifiés sur
Chromium à 320 et 1440 pixels, avec réponses de test et messages visibles.
Le backend natif Keycloak 26.7.3 qualifie le client privé de provisionnement,
la création désactivée et le profil minimal sans nom ni prénom.
Les dix tests du service d'admission qualifient les contrôles et reprises.
La copie sur disque a été testée avec un véritable chiffrement age : une
mauvaise clé échoue sans publier de génération et aucun clair n'est copié.
Les tests SMTP STARTTLS locaux qualifient aussi le refus d'un certificat
non reconnu et l'absence d'authentification avant TLS.

Les inscriptions restent fermées. Les validations des demandes parentales,
les contrats effectifs des sous-traitants et la qualification Proton réelle
ne sont pas déduits de ces tests. Aucune activation n'est attestée.

## Lien magique et fermeture commune

La qualification réelle de Keycloak 26.7.3 couvre le jeton signé natif, le
navigateur d'origine, le clic explicite, PKCE, état, nonce, AMR courriel sans
mot de passe, OTP conservé et refus du rejeu. L'OTP déjà employé pendant une
fenêtre TOTP est refusé ; la qualification attend le code suivant.

La fermeture est une action native personnelle, avec réauthentification et
OTP. Une confirmation erronée n'appelle pas le service privé ; un état 202
conserve l'identité, un état 200 permet la suppression native. L'activation
du droit personnel est idempotente et conserve toutes les autres actions
natives. Elle n'accorde aucune administration d'identité à Vision.

La migration 025 sépare le rôle vision_fermeture : métadonnées d'association
et effacement aveugle seulement. Les dix tests SQL réels vérifient aussi le
refus de lecture, l'émetteur exact et la reprise sans double effacement.
L'engagement partage le verrou d'admission et conserve un marqueur minimal :
aucune certification ni activation du sujet fermé n'est possible. Le service
d'admission annule aussi une demande personnelle encore sans sujet avant
le retrait natif. Les 180 tests Python de l'infrastructure passent.
Le courrier du registre commun est chiffré réellement avec age, puis
déchiffré pour vérifier son schéma minimal ; aucun contenu ni courriel usager.
La restauration PostgreSQL 17 rejoue les pièces anciennes et communes :
les contenus Vision et l'identité dans un realm Keycloak isolé sont retirés,
et le second passage réussit. Le test IdP emploie un import natif synthétique
sur H2 ; une restauration de son dump PostgreSQL réel reste à qualifier.
