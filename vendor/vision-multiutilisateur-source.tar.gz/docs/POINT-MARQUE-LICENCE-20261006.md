# Point de marque et licence de Vision

Le séparateur entre Vision et MrJ.am utilise le dessin original de la fonte
EchoPoint. Sa taille et sa position reprennent le point de la composition
Signature : agrandissement ×2, décalage de −.01 em. Le caractère reste un point
U+002E sélectionnable. La marque garde sa baseline commune et une hauteur de
41 px. Le CSS partagé empêche le texte ElmUI agrandi de doubler l’interligne.
Aucune fonte ni aucun contour de Signature n’a été modifié.

Le code, la documentation et les visuels originaux de Vision sont désormais
sous AGPL-3.0-or-later. LICENSE contient le texte intégral ; LICENCE.md accorde
explicitement le choix de toute version ultérieure et précise les exclusions.
README, ASDF et les métadonnées npm portent la même licence. Logo et signature
restent réservés ; les fontes gardent leur OFL et les dépendances leurs avis.
Les licences des dépôts externes ne sont pas modifiées.

Application servie : `ba6c9d8b1f4ef6ad6d0c78ef570d89bbe223eccf`.
Style : `4e8214970c22160059fe1024f854e8ecb0cbc59e`.
Opérateur : `f27ea81080d570bc2f905c7fcad4099ac245bc05`.

Les tests des pixels comparent aussi le motif blanc des deux points, leur
position et l’absence de rognage. Ils passent sur l’artefact compilé et en
HTTPS réel, aux quatre largeurs 320, 375, 768 et 1440 px, avec un grossissement
×4 pour comparer les motifs. Les parcours publics et privés passent, ainsi
que les quatre tests Elm. CI style 37491731775, interface 37492348030, serveur
37492347991, création sémantique 37492347952 et infrastructure 37492890918
(140 tests) réussies. Les cinq contrôles locaux des archives exactes passent ;
la licence complète et la concession « ou ultérieure » y ont été vérifiées.

Préparation [37493315938](https://github.com/MrJ-am/vps-infrastructure/actions/runs/37493315938),
activation [37493485203](https://github.com/MrJ-am/vps-infrastructure/actions/runs/37493485203)
et constat indépendant [37493885562](https://github.com/MrJ-am/vps-infrastructure/actions/runs/37493885562)
réussis. Basic, Bearer, OAuth PKCE, sessions, CSRF, révocation, tutoriel et
35 contrôles HTTP/TLS vérifiés. Version fonctionnelle 2.6.1, vingt tables
préservées, aucune migration SQL ni restauration de production. NixOS et
les releases voisines restent identiques ; anciennes releases et sauvegardes
conservées, retour autonome désarmé.

Un contrôle final du premier push du style a reçu un 401 transitoire. La
relecture de main a confirmé son commit exact. La révision finale et ses CI
ont ensuite été publiées et vérifiées. Aucun accès ni protection n’a changé.
Le rapport détaillé reste dans le dépôt privé VPS sous
`operations/vision-point-licence-publication.json`.
