# Vision multi-utilisateur

Cette branche prépare une migration de sécurité. Aucun déploiement de cette
version ni aucune ouverture des inscriptions n'est attesté par ce document.

Le 9 octobre 2026, le propriétaire retient `https://log.mrj.am` pour la
connexion commune. L'émetteur OIDC sera `https://log.mrj.am/realms/mrjam` ;
Vision garde son domaine propre. Ce choix précède l'activation de l'identité
commune et ne modifie aucun compte ni registre déjà présent en production.

## Plan après les choix du propriétaire

Le cadrage ci-dessous intègre les réponses du 8 octobre 2026. Les décisions
d'exploitation ne sont pas toutes réalisées par le candidat actuel. La notice
doit décrire les mesures effectivement constatées lors de l'ouverture.

| Étape | Résultat attendu | État de la préparation |
| --- | --- | --- |
| 1. Identité commune | Un compte MrJ.am, connexion depuis la vitrine, admission et droits par outil | OIDC, récupération, lien magique avec OTP et fermeture commune testés sur Keycloak réel ; admission contrôlée et contrôle parental préparés |
| 2. Confidentialité et capacité | Isolation SQL, administration limitée aux métadonnées, quota transactionnel de 10 Mo et plafonds lisibles | Préparés et testés ; vérifier les données historiques dans un staging réel |
| 3. Invitations | Liens nommés, maximum d'inscriptions, quota individuel, historique et changements rétroactifs | Préparés et testés ; réservations, preuve d'admission et inscription native fermée préparées |
| 4. Droits des personnes | Export sélectif et Markdown épuré, export structuré complet, suppression autonome | JSON/XML complets et Markdown sélectif testés ; fermeture personnelle commune et rejeu après restauration testés |
| 5. Administration du cycle de vie | Préavis de 30 jours, suivi du courriel, échéance et annulation, maintien de l'export | Migration 023, interface et service aveugle préparés ; délai, annulation et ACL testés dans PostgreSQL |
| 6. Courriels et mineurs | Proton SMTP, parcours de récupération, dossier parental et validation manuelle | File privée avec reprise ; récupération et lien magique avec OTP testés ; admission parentale préparée ; Proton réel à qualifier |
| 7. Conservation et restauration | Journaux applicatifs de sécurité à 30 jours, sauvegardes chiffrées et respect des effacements | Purges à 30 jours et copie chiffrée par effacement préparées ; SMTP Proton réel, copie externe mensuelle et récupération hors machine à qualifier |
| 8. Identité graphique | Palette commune OKLab/OKLCH, variantes de teinte et Visio recentré et agrandi | Préparés et testés dans style-mrjam ; adoption à révision exacte par chaque outil |
| 9. Ouverture | Région et contrats vérifiés, conformité documentée, migration et retour qualifiés, parcours réels contrôlés | Étape distincte après les preuves ; aucune activation déduite du présent plan |

Le responsable est Jean-Christophe Jameux, agissant en France à titre personnel.
Le contact public pour les droits est `RGPD@MrJ.am`. Le code reste sous
AGPL-3.0-or-later ; cette licence ne remplace pas les obligations liées au
service hébergé. L'adresse du compte initial et les secrets de messagerie sont
des paramètres privés d'exploitation, absents de cette documentation publique.

L'accès est mondial, exclusivement par les invitations diffusées par le
propriétaire. Le 8 octobre 2026, l'exploitant confirme que hPanel Hostinger
affiche l'Allemagne comme emplacement de son VPS. Cette information est fournie
par l'exploitant ; la localisation des copies et les engagements des fournisseurs
restent à documenter séparément. Les pays de la base, des fichiers et des copies
doivent être réexaminés en cas de changement de VPS.

Pour les mineurs, le lancement prévoit un accord parental lorsque nécessaire,
avec confirmation par courriel et vérification finale manuelle avant admission.
Le choix d'admission en France exige cet accord avant quinze ans et n'exclut
donc pas ces enfants. Sur le plan juridique, le seuil de quinze ans
concerne le consentement numérique applicable, et non un âge minimum général
d'utilisation. Définir les règles selon le pays et la base juridique ; une
confirmation par courriel seule ne prouve pas l'autorité parentale. Conserver
une preuve proportionnée et une notice compréhensible par l'enfant, sans
collecter systématiquement de pièces d'identité. Voir [RGPD.md](RGPD.md).

Le fournisseur de courriel retenu est le service Proton déjà utilisé par le
propriétaire : expéditeur `Automath@MrJ.am`, SMTP Submission sur
`smtp.protonmail.ch:587`, STARTTLS obligatoire et certificat vérifié. Le jeton
dédié reste hors Git, des logs et du store Nix. Le mot de passe oublié utilise
un parcours natif Keycloak testé avec un relais synthétique, conserve l'OTP et
exige une nouvelle connexion après changement. Le lien magique utilise un jeton
natif signé valable dix minutes, lié au navigateur et au client d'origine,
avec confirmation expresse puis OTP éventuel. Il ne produit pas l'AMR mot de
passe requis pour administrer. L'extension est figée sur Keycloak 26.7.3.
Ni une connexion SMTP ni un envoi réel ne sont attestés à cette étape.

Aucune suppression automatique pour inactivité n'est retenue. L'administration
pourra engager une suppression avec un préavis de trente jours, afficher
l'état d'envoi et l'échéance, puis annuler la procédure. L'échec du courriel ne
doit pas déclencher silencieusement la suppression. La personne conserve
l'export pendant le préavis. Séparer explicitement l'effacement de Vision de
la fermeture du compte MrJ.am et de ses effets sur les autres outils.

Les suppléments de sauvegarde Hostinger sont exclus du budget. Prévoir une
copie complète chiffrée mensuelle sur le disque externe déjà disponible du PC
Linux, avec vérification de restauration et conservation sûre de la clé.
Une perte totale du VPS peut alors entraîner jusqu'à un mois de données perdues
si la copie mensuelle est à jour. Les sauvegardes locales ne couvrent pas ce
risque de destruction complète de la machine.

À chaque effacement, le propriétaire autorise l'envoi automatique à sa boîte
Proton d'une copie chiffrée du registre minimal : identifiants techniques et
dates, sans contenus pédagogiques. Qualifier la confirmation de dépôt hors
machine, les erreurs, les reprises et l'ordre des opérations avant de garantir
qu'une suppression confirmée survive à la perte du VPS. L'acceptation SMTP ne
doit pas être confondue avec une preuve de réception durable. Une restauration
applique le registre le plus récent avant toute réouverture. La copie mensuelle
des connaissances et cette protection des effacements ont des rythmes distincts.

La durée retenue pour les événements applicatifs de sécurité et
d'administration est trente jours. Adapter et vérifier la purge ; distinguer
ces événements des historiques d'apprentissage et du journal HTTP VPS, dont
le contrat existant plafonne la rétention à quatorze jours.

Le [style commun préparé](https://github.com/MrJ-am/style-mrjam/blob/96fa28ac564b9492768837d4087608e83acc721b/docs/OKLAB.md)
utilise OKLab et sa représentation cylindrique OKLCH. Une teinte porte
l'identité de l'outil ; luminosité et chroma définissent fonds discrets,
surfaces et boutons plus soutenus. Les couleurs d'état gardent leur sens,
avec contrastes et états de focus contrôlés. La variante Visio conserve les
contours de la source Signature, avec agrandissement et recentrage. Chaque
consommateur reconstruit et vérifie son propre artefact à la révision exacte.

## Identité et droits

Keycloak porte l'identité commune MrJ.am. Chaque outil possède son client OIDC,
ses sessions sur son propre hôte, son admission et ses droits. La paire immuable
`iss`/`sub` rattache l'identité à Vision ; une adresse de courriel ou un nom
d'utilisateur ne suffit jamais à reprendre un compte historique. Un compte
commun peut accéder aux futurs outils sans recréer son identité ; chacun doit
cependant définir explicitement son admission. Administrer Vision ne donne aucun
droit d'administration sur Keycloak ni sur un autre outil.

La connexion navigateur utilise le code OIDC, PKCE S256, un état à usage unique
lié au navigateur, un nonce et la validation cryptographique du jeton. Aucun
jeton du fournisseur n'est conservé côté navigateur. La session utilise un
cookie `__Host-`, Secure, HttpOnly et SameSite=Lax, sans Domain, expirant après
12 heures ou 2 heures d'inactivité. Les mutations vérifient origine et CSRF.
L'administration exige une authentification récente, dans les cinq dernières
minutes, ayant réellement exécuté mot de passe **et** OTP. Un rôle modifié ou
une suspension s'applique aussi aux sessions et accès MCP existants.

Le serveur de gestion utilise `vision_administration`, sans accès aux tables de
contenu, à l'identité ou aux exports. Sa seule fonction SQL autorisée fournit
droits, allocations, nombres et consommation. Les administrateurs applicatifs
ne peuvent pas changer l'identité, réinitialiser un mot de passe ou usurper une
session. Les comptes SQL HTTP ne sont ni propriétaires, ni superusers, ni
BYPASSRLS et ne peuvent devenir le propriétaire NOLOGIN `vision_migration`.
RLS est forcé sur les tables personnelles ; l'identité de transaction vient
du frontal authentifié, dont les en-têtes écrasent ceux du client.

Cette protection exclut les administrateurs **applicatifs** des contenus tiers.
L'exploitation technique privilégiée peut accéder aux contenus traités en clair
par le serveur. Ce point est explicite dans la notice : le MCP et la recherche
actuels ne sont pas compatibles avec une promesse de chiffrement de bout en bout.

## Un quota strict et explicable

Le plafond initial est **10 Mo, soit 10 000 000 octets**. Il est contrôlé dans
la transaction SQL, avec un verrou du compte qui sérialise les écritures
concurrentes. Une transaction refusée n'ajoute aucune donnée et ne modifie pas
le compteur. Le quota porte sur toutes les tables personnelles modernes et
les copies historiques attribuées explicitement à leur propriétaire : contenus,
notes, archives, caches, traces, données de recherche et vecteurs.

La règle versionnée comptabilise la représentation JSON UTF-8 non compressée,
les colonnes dérivées, 256 octets par ligne, et le vecteur en float32 avec son
en-tête. Ce compteur logique pondéré est déterministe. Il ne prétend pas mesurer
exactement les pages physiques PostgreSQL d'une personne : index partagés,
pages, espace libre, WAL et sauvegardes exigent une surveillance globale et une
marge séparée. Le budget initial des allocations logiques est de 1 Go ; le
budget physique doit être fixé à partir des mesures et alertes de l'exploitation.

| Limite initiale | Plafond |
| --- | --- |
| Fiches, archives incluses | 1 000 |
| Items attachés à une fiche | 500 |
| Texte d'un item | 500 mots **et** 8 000 octets |
| Texte d'une fiche | 2 000 mots **et** 32 000 octets |
| Note ou suivi | 200 mots **et** 2 000 octets |

Ces plafonds sont visibles dans « Mon compte et mes limites » et par l'outil
MCP `lire_limites`. Le total de 10 Mo peut être atteint avant les plafonds de
nombre. Les autres champs restent bornés par leurs contraintes métier et
la taille maximale de ligne. Le MCP demande des notes de 80 à 120 mots ; la
base impose les limites réelles, indépendamment du comportement du LLM.
Les anciens textes déjà présents sont conservés ; une modification doit
respecter les nouveaux plafonds. L'archivage conserve l'espace utilisé.

## Invitations

Un lien porte un intitulé, un maximum d'inscriptions, une expiration, les
plafonds de texte et le quota de chaque compte. Son secret aléatoire n'est
affiché qu'une fois et seul son SHA-256 est conservé. Le secret est dans le
fragment du lien, jamais dans les paramètres journalisés. L'aperçu transmet
le secret dans un POST sans consommer une place et n'expose aucun bénéficiaire.
Seule l'activation d'une identité nouvelle consomme une place, sous verrou.

L'administration conserve l'historique, peut augmenter le maximum, révoquer
un lien et appliquer de nouveaux quotas aux comptes déjà inscrits par ce lien.
Le maximum ne peut être inférieur aux inscriptions acquises et aux demandes encore réservées. Une réservation dure sept jours et apparaît comme demande en attente. Le budget réserve
les allocations des comptes et celles des places restantes des liens actifs.
Une baisse sous l'utilisation actuelle préserve toutes les données et interdit
la croissance ; lecture, export et effacement restent disponibles. Les
modifications utilisent une version pour éviter l'écrasement d'un changement
concurrent. Aucun quota ne doit être abaissé sans information intelligible.

## Droits des personnes et exploitation

L'export navigateur propose les tables personnelles et métadonnées propres en
JSON ou XML, et les connaissances en Markdown sans suivi ni révisions. Le
Markdown permet de sélectionner les fiches par leur titre, et comprend leurs
items en puces ; l'export complet inclut aussi les items sans fiche. Les exports sont
paginés et vérifient une version des données : un changement en cours interrompt
l'export. Ils ne sont pas des outils MCP donnés à l'assistant. Les demandes
portant sur l'identité commune et les autres applications passent par le contact
du responsable du traitement ; ne pas présenter l'export Vision comme un export
complet de Keycloak ou de tous les outils.

L'effacement exige la saisie `EFFACER VISION`. Une intention confirmée est
consignée et synchronisée sur disque **avant** la suppression SQL dans un fichier
privé hors du dump. Après une panne, cette intention reste applicable même si
la réponse n'a pas été reçue. Le SQL supprime aussi observations immuables,
copies historiques et rattachement OIDC, anonymise l'audit correspondant et
préserve les autres comptes. Si le dernier administrateur s'efface, les
inscriptions ferment ; son droit d'effacement n'est pas bloqué.

L'identité commune et les données des autres outils sont conservées. Les sessions
et autorisations MCP du compte effacé sont purgées par mrj-auth et deviennent
immédiatement inutilisables lors des vérifications d'accès. Une restauration
doit appliquer le registre externe **le plus récent** avant toute réouverture.
Le registre et les sauvegardes chiffrées doivent aussi être protégés hors machine.
La preuve de restauration et le traitement des anciennes sauvegardes en clair
restent des préconditions de l'activation.

Les migrations 019–025 s'exécutent par l'exploitation dans un staging isolé,
puis `scripts/roles.sql` retire la propriété aux rôles HTTP. Le service HTTP
n'exécute plus de DDL au démarrage. Conserver le dump, la génération système,
la release et les ACL de départ ; un retour du seul code ne restaure ni les
propriétaires ni les politiques RLS. Après admission de comptes multiples, ne
jamais revenir à un code ancien qui les ignorerait. Voir le dossier opérateur
`docs/VISION-MULTIUTILISATEUR.md` dans VPS Infrastructure et `docs/RGPD.md` ici.
