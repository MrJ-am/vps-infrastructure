# Découverte de Vision 2.6.1

L’accueil public est une page de présentation avec illustration originale,
schémas et deux captures réelles de l’interface. Les captures sont produites
par `interface/tests/captures.py` avec une API de lecture fictive. Elles ne
consultent pas la production. Les cinq visuels pèsent ensemble moins de
105 ko et ne nécessitent aucune animation ou ressource externe.

La marque sélectionnable est « Vision.MrJ.am ». Vision emploie la Parisienne
originale de Signature à la même révision que les deux fontes de signature.
La conversion WOFF2 conserve les glyphes originaux. La licence et les
empreintes sont dans `interface/identite/`. La signature de footer est retirée
par la variante `Documents.espaceMarque` du style commun. Les composants de
vitrine et les pictogrammes appartiennent à style-mrjam ; Vision fournit les
textes, destinations et états métier.

`docs/tutoriel.json` reste la source unique des onze chapitres. Le site affiche
un chapitre à la fois. Les cinq identifiants pédagogiques historiques restent
valides. Les nouveaux chapitres décrivent ChatGPT, Claude, Gemini CLI, Codex CLI
et les autres clients. Chaque procédure de fournisseur cite son guide officiel
consulté le 6 octobre 2026. Les offres et menus des fournisseurs peuvent évoluer.
La procédure Gemini concerne le CLI ; aucune connexion arbitraire dans le site
web Gemini n’est annoncée. Claude et Anthropic désignent le même parcours.

`GET /mcp-config.json` expose seulement l’adresse MCP et la page de gestion des
accès. Cette lecture est publique. Elle ignore Host et les en-têtes de proxy.
Les adresses viennent de la configuration de routage utilisée par `lien_fiche`.
Elle retourne 503 si l’adresse MCP n’est pas configurée. Le site affiche alors
l’indisponibilité et masque les commandes incomplètes. L’outil `tutoriel`
renvoie la même configuration et résout le repère d’adresse dans les exemples.
Le tutoriel ne crée ni compte, ni fiche, ni réglage.

La confidentialité constitue une page indépendante. Elle décrit les données,
les accès des assistants, les cookies, la durée des informations de visite et
les demandes de suppression. Aucun schéma pédagogique ou détail d’hébergement
n’est affiché sur cette page.

Le serveur reste compatible avec SQL 7 / création 1. Aucun fichier de migration
n’est modifié. La publication doit basculer ensemble le serveur et le candidat
statique exact, puisque le tutoriel est intégré au binaire Lisp. Les sources et
contrôles sont conservés avec un retour applicatif préparé.

Les visuels du produit sont servis sous `assets/mrjam/vision/`. Ce sous-répertoire
utilise la route statique existante sans changement de Nginx ou de NixOS.
Le manifeste contrôle aussi chacun de ces fichiers.
