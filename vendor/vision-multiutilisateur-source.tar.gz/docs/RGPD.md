# Vérification RGPD avant ouverture

Le dépôt GitHub Vision est actuellement privé. La notice comporte donc une
offre de téléchargement du code correspondant à la version servie, accessible
sans compte GitHub par `/code-source/vision.tar.gz`, ainsi que le code des services
MrJ.am par `/code-source/services-mrjam.tar.gz`. Ces archives sont figées avec la
publication ; aucune donnée d’usager, configuration privée ou coordination n’y
figure. Vérifier les deux téléchargements avant ouverture (AGPL, article 13).

État du 8 octobre 2026 : mesures techniques préparées et testées en environnement
isolé ; **conformité globale non attestée et inscriptions publiques fermées**.
Le droit européen exige également des faits et engagements d'exploitation que
le code ne peut pas établir. Aucun nom, pays, contrat ou engagement de chiffrement
inconnu n'est inventé dans la notice.

## Choix confirmés et éléments à vérifier

Le propriétaire confirme les éléments suivants pour préparer le lancement :

- responsable : Jean-Christophe Jameux, à titre personnel, activité en France ;
- contact public pour les droits : `RGPD@MrJ.am` ;
- inscriptions mondiales, exclusivement sur invitation, diffusion très limitée ;
- accueil des mineurs, y compris avant quinze ans en France avec accord parental ;
  confirmation par courriel et vérification finale manuelle ;
- mise en garde sur les données personnelles sensibles concernant une personne
  identifiable ; accès technique privilégié potentiel déclaré ;
- LLM choisi et raccordé au MCP par chaque personne, local ou distant ;
- absence de suppression automatique pour inactivité ; préavis administrateur
  de trente jours, export et effacement autonomes à proposer ;
- journaux applicatifs de sécurité et d'administration : trente jours ;
- copie complète chiffrée mensuelle sur un disque externe, PC Linux, sans
  supplément Hostinger ; registre chiffré des effacements envoyé à la boîte
  Proton de l'exploitant à chaque suppression.

Le 8 octobre 2026, le propriétaire confirme que hPanel Hostinger affiche
l'Allemagne comme emplacement de son VPS. La source est cette confirmation
de l'exploitant. La localisation des copies, les accès, contrats et
sous-traitants de Hostinger et de Proton restent à vérifier séparément.
Le pays doit être configurable et revu lors d'une migration.

Ces réponses fixent un cahier des charges. Elles ne prouvent pas que les
parcours parentaux, les courriels, les copies externes, la purge des nouveaux
journaux ou la fermeture du compte commun sont déjà mis en œuvre. Le
[plan](MULTIUTILISATEUR.md) distingue le socle testé des travaux restants.

Le candidat dispose désormais des confirmations d'admission, du contrôle
manuel, des exports et de l'effacement Vision, du lien magique signé conservant
le second facteur, et de la fermeture autonome de l'identité commune. Ces
parcours ont été qualifiés sur PostgreSQL 17 et Keycloak 26.7.3 isolés. Cela
ne prouve ni leur activation, ni un envoi Proton réel, ni la conformité des
contrats de l'instance. La restauration testée rejoue aussi les fermetures
communes avant réouverture : identité et données Vision sont retirées.

## Références officielles

Le contrôle suit le [texte RGPD publié par la CNIL](https://www.cnil.fr/fr/reglement-europeen-protection-donnees),
notamment les articles 5–6, 12–22, 24–25, 28, 30, 32–35 et 44–49, le
[guide de sécurité CNIL](https://www.cnil.fr/fr/guide-de-la-securite-des-donnees-personnelles),
les [règles d'information](https://www.cnil.fr/fr/conformite-rgpd-information-des-personnes-et-transparence)
et les [transferts hors UE](https://www.cnil.fr/fr/transferts-de-donnees-hors-ue-le-cadre-general-prevu-par-le-rgpd).
Les cookies strictement nécessaires à l'authentification sont analysés selon
les [règles CNIL sur les traceurs](https://www.cnil.fr/fr/cookies-et-autres-traceurs/regles/cookies).
Leur exemption de consentement ne dispense pas d'information ni des autres
obligations. Une validation doit porter sur les traitements effectivement ouverts.

Pour les mineurs, consulter l'[article 8 du RGPD](https://eur-lex.europa.eu/eli/reg/2016/679/oj/fra),
l'[article 45 de la loi française](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000037823135),
les recommandations CNIL sur le [consentement du parent](https://www.cnil.fr/fr/recommandation-4-rechercher-le-consentement-dun-parent-pour-les-mineurs-de-moins-de-15-ans)
et la [vérification de l'âge et de l'accord parental](https://www.cnil.fr/fr/recommandation-7-verifier-lage-de-lenfant-et-laccord-des-parents-dans-le-respect-de-sa-vie-privee).
En France, quinze ans est le seuil du consentement autonome visé par ces règles,
pas un âge minimum légal universel pour créer tout compte. L'article 8 concerne
les traitements fondés sur le consentement pour l'offre directe d'un service
de la société de l'information. Il ne transforme pas toute opération nécessaire
au service en traitement fondé sur le consentement. La capacité contractuelle,
l'information adaptée et les règles du pays concerné demandent leur propre examen.

La procédure retenue au lancement maintient les admissions concernées en attente
jusqu'à la vérification manuelle. Le choix d'admission du propriétaire exige
l'accord parental avant quinze ans en France ; distinguer cette règle d'accès
de la détermination des bases juridiques. Définir qui vérifie l'autorité parentale,
avec quelle preuve proportionnée, pendant combien de temps, et comment traiter
le retrait ou l'évolution de la situation. Le seul clic dans un courriel ne
constitue pas automatiquement une preuve suffisante. Pour un pays dont les
règles n'ont pas été vérifiées, ne pas présenter un seuil français comme une
validation juridique locale. L'invitation ne dispense pas de ces contrôles.

## Traitements et minimisation

| Traitement | Données | Finalité et base envisagée | Accès |
| --- | --- | --- | --- |
| Identité commune | identifiant, nom de connexion, courriel vérifié, hash du mot de passe, moyens MFA, événements de sécurité | fournir et sécuriser la relation de service ; 6.1.b et intérêt légitime de sécurité 6.1.f à documenter | personne, exploitation autorisée, fournisseur d'hébergement |
| Vision personnel | fiches, items, notes, évaluations, contextes, bilans, représentations locales | révisions demandées ; 6.1.b si objectivement nécessaire à la prestation | personne, assistant explicitement autorisé, exploitation privilégiée potentielle |
| Administration | statut, identifiant d'affichage, quotas, nombres, poids logique | gérer admission, droits et capacité | administrateurs Vision ; aucun contenu pédagogique |
| Invitations | intitulé, digest du secret, maximum, usages, quota, expiration, rattachement | admission et allocation | administrateurs ; aperçu de limites pour le détenteur du lien |
| Sessions et autorisations | condensats, CSRF, hôte, identité technique, portée MCP, expiration et révocation | authentification et autorisation | services techniques ; chaque personne voit ses autorisations |
| Journaux | métadonnées de sécurité, opérations de droits et allocations | sécurité 6.1.f, justification et balance à conserver | exploitation ; gestion pour son périmètre |
| Effacement et sauvegardes | identifiant minimal, intention confirmée, date ; copies chiffrées bornées | exécuter les droits et empêcher une réapparition | exploitation restreinte |

La prise de connaissance d'une notice est enregistrée avec sa version et sa
date. Elle n'est **pas** présentée comme un consentement général ni comme la
base juridique du fonctionnement nécessaire du service. Séparer tout futur
usage optionnel de cette relation de service. Ne pas collecter date de naissance,
adresse postale ou donnée de facturation sans nécessité démontrée.

Les contenus libres peuvent contenir des données sensibles ou concerner des
tiers. Le propriétaire demande une mise en garde explicite le 8 octobre 2026 :

> N'utilisez pas Vision pour stocker des données personnelles sensibles
> concernant une personne identifiable, telles que des informations médicales,
> des convictions religieuses ou des données relatives à la vie sexuelle.
> Les fiches d'apprentissage générales sur ces sujets restent possibles.

Cette information figure dans la notice du candidat. Elle distingue les données
concernant une personne identifiable des connaissances générales sur un sujet.
L'analyse juridique et les mesures de sécurité doivent tenir compte de la
présence possible de telles données dans les textes libres et les notes d'un
LLM. La mise en garde ne dispense pas du respect de l'article 9. Évaluer l'AIPD
selon risques, échelle, usages et public ; aucune dispense générale n'est déduite
du petit quota. Vision ne prend pas de décision juridique ou d'effet significatif
au sens de l'article 22. Référence : [définition CNIL des données sensibles](https://www.cnil.fr/fr/definition/donnee-sensible).

## Chiffrement et confidentialité annoncés

HTTPS protège le transport. Le futur IdP utilise Argon2id, avec sel et paramètres
explicites. Les mots de passe ne sont pas récupérables en clair. En revanche,
les textes et vecteurs sont traités en clair sur le serveur. Les secrets OTP
doivent être utilisables par l'IdP : ne pas les présenter comme des hashes de
mots de passe ni promettre leur chiffrement individuel sans preuve.

Le nouveau module prépare des sauvegardes age chiffrées. Cela ne prouve pas
que les anciennes sauvegardes, snapshots VPS, volumes ou archives hors site
le sont. Il faut vérifier rétention, possession et protection de la clé privée,
restauration, destinataires et accès fournisseur. L'administration applicative
est séparée de l'exploitation root/PostgreSQL, dont l'accès potentiel est déclaré.
Le propriétaire confirme le 8 octobre 2026 que l'interdiction d'accès concerne
les administrateurs applicatifs et demande une notice annonçant l'accès
technique potentiel de l'exploitant et de l'hébergeur. La version retenue
traite les contenus en clair sur le serveur. Un futur chiffrement empêchant
cet accès demanderait une autre architecture pour la recherche, le traitement
serveur et le MCP, ainsi qu'une mise à jour de la notice.

Le calcul des représentations est local. Un LLM connecté par la personne peut
lire ses données au titre de l'autorisation MCP. Identifier les rôles respectifs
des fournisseurs, les destinataires et pays, les garanties, modalités et risques
de transferts. Le choix d'un assistant par l'utilisateur n'exonère pas le
responsable de ses obligations pour ses propres transferts et sous-traitants.

Le service d'envoi retenu est [Proton SMTP Submission](https://proton.me/support/smtp-submission)
avec une adresse active du domaine du propriétaire. STARTTLS protège la
soumission au serveur, mais ne rend pas tout courriel de récupération ou de
préavis chiffré de bout en bout. Pour le registre d'effacement, chiffrer la
pièce jointe elle-même avant l'envoi, avec une clé de restauration conservée
en sécurité ; le message ne contient ni fiche, ni item, ni secret de connexion.
Prévoir les métadonnées de messagerie et ce destinataire dans le registre des
traitements. Aucun envoi réel ni dépôt externe durable n'est encore constaté.

## Rétention et droits

Connaissances et observations : jusqu'à l'effacement demandé ou à l'issue d'une
procédure de fermeture annoncée. Le propriétaire exclut une suppression
automatique pour inactivité ; documenter la nécessité de la conservation et
réexaminer les finalités et les données conservées. Archives : mêmes règles. Purge technique
quotidienne proposée pour caches/recherches, préparation et requêtes (35 jours),
épisodes/contextes (90 jours), journaux métier (180 jours). La purge de l'audit
de gestion du candidat est fixée à **30 jours**, comme les événements de
sécurité Keycloak et leur namespace journald. Constater les purges effectives
sur le VPS avant ouverture.
Les traces de recherche expirent en 30 minutes, avec purge au plus tard à la
prochaine exécution quotidienne. Les historiques factuels utiles restent
conservés selon leur finalité, sans assimiler une archive à une suppression.

Sessions : 12 h absolues, 2 h d'inactivité. États OIDC : 10 min. Autorisations MCP
nommées : un an maximum, révocables ; vingt actives par compte et historique
borné. OAuth : accès 1 h, renouvellement rotatif jusqu'à 30 jours. Journaux
HTTP : plafond de 14 jours ; le module et l'état réel doivent être vérifiés.
Sauvegardes nouvelles : objectif 30 jours, configurable dans une borne 1–90
jours et synchronisé avec la notice ; expiration de toutes les anciennes copies
et snapshots à prouver. Registre d'effacement externe : jusqu'à expiration
de la dernière copie susceptible de réintroduire les données, puis purge sûre.

La copie externe complète aura une fréquence mensuelle. La fréquence d'une
copie n'est pas sa durée de conservation : préciser les dates d'expiration et
la purge effective sur le disque externe, y compris si ce disque est débranché.
Ne pas promettre un délai d'effacement de toutes les copies sur la seule base
du timer VPS. Vérifier réception et récupération du registre chiffré transmis
à chaque effacement ; une restauration est fermée au public tant que le
registre à jour n'est pas appliqué. Une erreur d'envoi ne doit pas être assimilée
à une protection externe réussie.

Une suppression administrative doit être précédée du préavis accepté de
trente jours, avec courriel, échéance, export disponible et possibilité
d'annulation depuis l'administration. Ce délai est un choix de fonctionnement,
pas une durée légale universelle déduite du RGPD. Distinguer ce préavis du délai
de réponse aux droits. Documenter également la suppression autonome des données
et la fermeture de l'identité commune, en explicitant les effets sur chaque outil.

Accès et portabilité : export JSON/XML complet et Markdown sélectif personnel ; métadonnées de compte
Vision incluses, identité globale et autorisations à fournir également sur demande.
Rectification : édition ou observation corrective pour les faits historiques.
Effacement : suppression du compte Vision et de ses contenus, plus traitement
des sauvegardes au terme annoncé. Limitation/opposition : procédure du responsable,
sans confondre suspension disciplinaire et exercice de droits. Réponse sous un
mois, avec prolongation motivée dans les conditions de l'article 12. Prévoir
une vérification proportionnée de l'identité et l'orientation vers l'autorité
compétente ; la CNIL est citée pour la France, sans exclure les autres autorités.

## Conditions encore à établir

Avant de renseigner les quatre champs techniques d'ouverture, constituer une
validation d'exploitation et juridique comprenant :

- renseigner les coordonnées confirmées du responsable et le contact public ;
  vérifier les mentions légales et l'éventuelle nécessité d'un DPO ;
- pays réel des bases, fichiers, sauvegardes et snapshots ; contrats de
  sous-traitance article 28, sous-traitants ultérieurs et transferts éventuels ;
- appliquer au public mineur retenu les règles locales, le contexte
  familial/scolaire, l'information adaptée et le fondement applicable ; qualifier
  la vérification parentale manuelle et sa preuve proportionnée ;
- registre article 30, balance de l'intérêt légitime, analyse AIPD et règles
  concernant les données sensibles et les tiers ;
- justification de la conservation sans effacement automatique pour inactivité,
  durées de l'identité globale, des invitations expirées et du registre
  d'effacement ; purges effectives, export et fermeture globale ;
- SMTP sécurisé, récupération de compte, double authentification des admins,
  restriction des accès techniques et procédure de violation (article 33 :
  notification sous 72 h lorsque les conditions sont réunies ; article 34) ;
- contrôle des traceurs et ressources tiers, tests de restauration avec registre
  externe, sauvegarde hors machine, preuves d'accès et migration sans perte.

La fermeture par défaut des inscriptions évite de présenter un formulaire
d'admission opérationnel avec une notice incomplète. Renseigner des champs ne
constitue pas, à lui seul, la preuve de conformité requise.

## Contrats fournisseurs consultés le 8 octobre 2026

Le [DPA Hostinger](https://www.hostinger.com/legal/dpa), révisé le
29 septembre 2026, inclut les services VPS et décrit les responsabilités,
sous-traitants et mécanismes de transfert. Sa liste couvre plusieurs services :
elle ne prouve pas que chaque sous-traitant intervient sur le VPS allemand.
Conserver l'entité contractante et la version acceptée pour ce compte, puis
préciser les accès et copies effectivement utilisés. Les engagements généraux
de sécurité ne prouvent pas un chiffrement des fichiers de notre VPS.

Le [DPA Proton](https://proton.me/legal/dpa) encadre les prestations en qualité
de sous-traitant, les sous-traitants ultérieurs et les transferts. Son champ
d'application vise les organisations utilisatrices, indépendamment de leur
forme juridique. Vérifier son application à l'activité personnelle hébergée
avec l'abonnement existant ; aucune augmentation d'abonnement n'est retenue.
La lecture publique du contrat ne constitue pas une preuve de son acceptation
par le compte du responsable.

La [politique Proton Mail](https://proton.me/mail/privacy-policy), modifiée
le 14 septembre 2026 et consultée le 8 octobre, situe son stockage en Suisse,
Allemagne ou Norvège et décrit les métadonnées SMTP accessibles. Elle ne
localise pas individuellement notre boîte. La Suisse figure parmi les
[pays adéquats reconnus par la Commission](https://commission.europa.eu/law/law-topic/data-protection/international-dimension-data-protection/adequacy-decisions_en).
Cela traite le mécanisme de transfert vers ce pays ; documenter aussi les
destinataires effectifs et les engagements article 28. Le pays du VPS ne
justifie aucune affirmation générale d'un traitement exclusivement dans l'UE.

L'[analyse d'impact du candidat](AIPD-VISION.md) examine aussi les mineurs,
les évaluations de révision et le texte libre. Ses mesures vérifiées et ses
conditions d'exploitation non établies sont distinguées ; aucune ouverture
ne découle de la seule rédaction de ce document.
