# Analyse d'impact du candidat Vision

Version de travail du 8 octobre 2026. Responsable : Jean-Christophe Jameux,
activité en France ; contact RGPD@MrJ.am. Périmètre : cette instance sur VPS
allemand confirmé par l'exploitant, identité commune et outils qui l'adoptent,
actuellement Vision. Les personnes qui installent le code AGPL opèrent leurs
propres instances et déterminent leurs traitements.

## Nécessité de cette analyse

Vision traite des textes personnels, des réponses et des indicateurs de
révision. La présence de mineurs est prévue, avec des personnes vulnérables
et une évaluation personnelle de leurs apprentissages. Ce rapprochement de
critères conduit à préparer une AIPD plutôt qu'à déduire une dispense du
faible nombre d'invitations. Références : [article 35 RGPD](https://eur-lex.europa.eu/eli/reg/2016/679/oj/fra),
[AIPD selon la CNIL](https://www.cnil.fr/fr/RGPD-analyse-impact-protection-des-donnees-aipd).
Cette analyse devra être arrêtée par le responsable sur les faits de
l'exploitation ; un risque élevé non maîtrisé peut imposer l'article 36.

## Finalités, moyens et nécessité

Le service conserve les fiches, items, notes, liens, réponses et observations
pour les révisions personnelles demandées. Les indicateurs calculés organisent
ces révisions ; ils n'attribuent aucun droit juridique, note scolaire officielle
ou accès administratif. Les contenus sont privés, sans publication ni profil
public, sans publicité ou analyse commerciale.

Un identifiant global et un courriel vérifié permettent connexion et reprise.
Le fournisseur d'identité conserve un hash Argon2id et les moyens MFA. Chaque
outil associe iss/sub à son identifiant propre ; aucun rapprochement automatique
par adresse entre données historiques. La création exige une invitation et un
contrôle d'admission. Le pays et une tranche déclarée évitent la date de
naissance ; une confirmation et un contrôle manuel minimal remplacent la
collecte systématique de justificatifs d'identité. Les dossiers étrangers
restent en attente jusqu'à vérification des conditions applicables.

La base envisagée pour le service demandé est l'article 6.1.b, sous réserve
de la capacité à s'engager ; les contrôles parentaux sont distincts de la
lecture de notice. La sécurité relève de 6.1.f. Son intérêt est de protéger
les données, les accès et la capacité partagée ; les métadonnées sont bornées,
les contenus exclus des journaux HTTP, les accès techniques restreints et
les durées justifiées. L'absence de traceurs optionnels évite un traitement
supplémentaire. Les droits d'opposition et limitation sont traités par le
responsable. Une mesure de sécurité ne justifie pas l'analyse des contenus.

Un assistant choisi par la personne peut lire et écrire via une autorisation
MCP limitée à son compte. Les représentations de recherche sont calculées
localement. La personne doit examiner son propre fournisseur LLM, ses pays
et conditions ; l'opérateur reste responsable de ses transferts et fournisseurs.
L'autorisation est révocable et les notes sont plafonnées ; elle ne donne
aucun accès aux autres comptes.

Le texte libre peut contenir des données article 9 ou de tiers. L'information
demande d'éviter les données personnelles sensibles identifiantes, en expliquant
l'accès technique potentiel. Aucun scan de contenu n'est ajouté. La présence
éventuelle de ces données demeure un risque à examiner ; la notice seule
n'établit ni exception article 9 ni absence de responsabilité.

## Risques pour les personnes et mesures du candidat

| Risque | Conséquence | Réponse préparée et preuve | Limite résiduelle |
| --- | --- | --- | --- |
| Lecture entre comptes | Atteinte à la vie privée | RLS et transaction par utilisateur, rôles non propriétaires, refus SQL/HTTP réels | Audit des ACL réelles et retour SQL requis |
| Administrateur pédagogique lisant un contenu | Surveillance et divulgation | Interface de métadonnées, rôle séparé sans SELECT sur contenus/identités, aucun export tiers | Root, PostgreSQL et hébergeur gardent un accès technique potentiel annoncé |
| Compte volé ou usurpé | Lecture et destruction | OIDC signé, PKCE, nonce/état, cookies limités, CSRF, OTP administrateur récent ; récupération et lien magique testés | Boîte de courrier compromise ; OTP personnel recommandé, sans promesse de protection absolue |
| Lien consommé par tiers ou scanner | Admission ou connexion indues | Secret aléatoire/digest, expiration, POST explicite ; lien magique lié au navigateur ; rejeu testé | Vérifier les limites d'envoi et le fournisseur réel |
| Faux accord parental | Admission inadéquate et risques pour mineur | Adresse distincte sous quinze ans en France, confirmations et validation manuelle, référence minimale ; information adaptée | Compétence de contrôle et règles locales à constater ; l'email seul est insuffisant |
| Assistant divulguant une connaissance | Transmission imprévue | MCP personnel révocable, notice sur assistant local/distant, aucune visibilité publique, synthèse plafonnée | Choix et instructions du fournisseur usager ; recommandation d'éviter les informations sensibles |
| Saturation ou dépassement | Indisponibilité et perte d'écriture | Quotas logiques stricts, textes/nombres plafonnés, verrou concurrent, budget global et limite des invitations | Espace disque et ressources système à auditer ; quota logique distinct du poids physique des index |
| Suppression injustifiée | Perte de données personnelles | Préavis administratif trente jours, envoi/échéance/annulation, export maintenu ; suppression personnelle explicite | SMTP accepté ne prouve pas la lecture ; litige traité par le responsable |
| Restauration réintroduisant des données | Effacement rendu inefficace | Registre minimal chiffré externe et rejeu testé, identité et contenus retirés avant réouverture | Réception du registre et toutes les copies réellement détenues à qualifier |
| Panne VPS ou perte de clé | Perte des connaissances ou impossibilité de reprise | Dumps age, test PostgreSQL 17 et native IdP isolé, procédure mensuelle sur disque Linux | Copie physique, clé et restauration réelle IdP à prouver ; jusqu'à un mois de données peut manquer |
| Journaux et dossiers trop longtemps conservés | Exposition prolongée | Événements sécurité/gestion trente jours, HTTP quatorze, dossier d'admission purgé, export/fermeture autonome | Constater les timers et rétention de chaque copie, boîte et snapshot |
| Fournisseur ou transfert inadéquat | Accès technique et droits incomplets | Pays VPS configurable, distinction Proton, sources/DPA examinés | Contrats applicables, accès support, copies et destinataires réels non attestés |

Les mesures d'isolation et de récupération ont des preuves synthétiques,
référencées dans [la qualification](VALIDATION-MULTIUTILISATEUR-20261008.md).
Les conséquences d'une lecture technique de textes sensibles ou concernant un
enfant peuvent rester graves. Les preuves fournisseur, accès et sauvegardes
manquantes empêchent d'arrêter un niveau résiduel acceptable pour l'ouverture.
Les inscriptions restent fermées. Aucune certification de conformité générale
ou de sécurité absolue n'est déduite de ces tests.

## Exercice des droits et exploitation

La personne exporte JSON/XML ou Markdown sélectif, corrige, efface Vision et
ferme son identité commune. L'administration ne participe pas à l'export
personnel. Les autres demandes, retrait d'accord parental et identité globale
passent par le contact public, avec vérification proportionnée et réponse
dans le délai réglementaire. Conserver uniquement la trace nécessaire du
traitement de la demande, avec accès restreint.

Les copies restaurées restent hors public jusqu'au rejeu du registre récent.
Les registres d'effacement sont limités aux identifiants et dates, conservés
tant qu'une copie peut réintroduire les données, puis purgés après vérification
de cette extinction. La copie externe mensuelle et sa rétention effective
doivent être enregistrées même lorsque le disque est débranché. Aucune durée
de conservation du disque n'est présentée comme déjà acceptée ou appliquée.

En cas de violation : préserver les preuves utiles sans diffuser les contenus,
contenir l'accès, évaluer les personnes et catégories touchées, documenter
mesures et risque, appliquer notification sous 72 heures quand l'article 33
l'exige, et information des personnes selon l'article 34. La décision et
son motif restent dans un registre privé d'incident. Revoir cette analyse
à un changement de pays, hébergeur, LLM exploité par le service, chiffrement,
public, taille d'utilisation ou outils adoptants. Elle n'autorise aucune
extension silencieuse des finalités ni accès applicatif tiers.
