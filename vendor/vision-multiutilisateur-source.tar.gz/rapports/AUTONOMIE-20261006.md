# Vision 2.6 — contrat, temps, consultation et accueil

Publication vérifiée le 6 octobre 2026 à 08:24 UTC sur https://vision.mrj.am.
Source applicative exacte : `c747ad881849ffbc9bd7caa6c24e9934e75ce9a2`.
Source opérateur VPS : `88b72ae8e5deb9eb1db6152f0eda910d555d58c1`.
Les commits de livraison ultérieurs ne changent pas ces fichiers servis.
Le module Nix proposé exige désormais un domaine explicite ; la production
utilise déjà le routage explicite de projects.json par son wrapper de release.

## Fonctionnalités livrées

Le contrat unique [CONTRAT-SEANCE.md](../docs/CONTRAT-SEANCE.md) est incorporé
aux descriptions des outils et aux réponses de préparation, ouverture, reprise,
clôture et évaluation. Il prescrit une évaluation sémantique selon les critères
annoncés, un signal explicite pour une réponse fausse ou incomplète, une
clarification de l’ambiguïté, des aides progressives et préférentiellement
sémantiques, et le respect du choix de passer ou arrêter. Une réussite aidée
ne devient pas un rappel autonome. Production initiale, manque, aides, réponse
finale et vérification peuvent être conservés dans le déroulement ; les
évaluations ponctuelles et rectifications conservent également leurs traces.
Le serveur contrôle les gains déclarés incompatibles avec les aides ou l’état
initial ; il ne peut pas certifier la fidélité des déclarations du LLM.

La datation distingue ouverture, rappel, clôture et enregistrement. Une séance
est courte seulement si sa durée serveur est strictement inférieure au seuil
personnel, 60 minutes par défaut. Ses dates manquantes peuvent prendre la
clôture avec provenance d’approximation explicite. À la borne et au-delà,
les dates manquantes produisent une réponse structurée, avec résolution par
groupes possible. Les dates civiles déclarées avec décalage de fuseau sont
représentées à midi comme approximation documentée. L’approximation à la
clôture d’une séance longue exige un accord explicite ; une trace inconnue
peut rester non datée sans déplacer la référence mémorielle. Les dates hors
bornes et incohérences directement détectables refusent tout le lot concerné.
Un rejeu ne crédite rien à nouveau ; une rectification conserve les dates
historiques et ne peut effacer une aide déjà enregistrée pour obtenir un gain.

Les vingt opérations existantes et nouvelles sont décrites dans
[outils.json](../docs/outils.json) et [OpenAPI](../docs/openapi.json).
Les cinq nouvelles lectures sont `lire_politique`, `lien_fiche`,
`etat_fiche`, `bilan_fiches` et `tutoriel`. Elles utilisent MCP et les
routes POST `/api/v1/<opération>` et `/api/web/<opération>`.
`regler_politique` accepte des changements partiels, versionnés et
idempotents, dont `duree_seance_courte_minutes`. Une lecture, le tutoriel
ou un enregistrement sans champ modifié ne change pas la politique.

Les liens sont construits à partir du routage public configuré, avec
préfixes et origines séparées possibles ; aucun Host ou Forwarded arbitraire
ne décide de l’adresse. Le lien utilise `/#fiche/<id>`, vérifie l’accès
et ne change aucun partage. Les rapports donnent contenu intégral, items,
stabilités propres aux items, derniers rappels, dates techniques, fenêtres
et contexte. Pagination, totaux, continuation et exports Markdown partiels
sont explicites ; les observations ont leurs propres pages.

Le [tutoriel commun](../docs/tutoriel.json) alimente le site et le MCP à la
demande : fiches/items partagés, capitales, langues, modèle logarithmique
effectivement implémenté, priorité, période cible, déplacement et largeur des
fenêtres, budget et actions. Les exemples fictifs ne créent aucune donnée.
L’accueil public `/`, `/docs` et l’accès direct `/connexion` expliquent
le service. Deux schémas originaux, textuels et accompagnés d’explications,
illustrent le partage d’un item et l’espacement des rappels. Les contrôles,
menus, styles et fontes restent ceux des bibliothèques communes.

## Migrations et préservation

Les migrations additives 017 et 018 ajoutent le seuil et les métadonnées de
datation, puis les lectures et rapports. Les réglages précédents, versions,
historiques, observations, contenus et états mémoriels ont été comparés :
19 tables préservées. Aucune provenance ancienne incertaine n’est reconstruite.
Le barème et le modèle logarithmique sont conservés. Le démarrage vérifie
le contrat SQL 7 et le contrat de création 1.

Une sauvegarde récente a été réellement restaurée sur le VPS dans une base
jetable. Le retour des fonctions SQL anciennes a été essayé puis les
migrations réinstallées. L’activation a conservé un second dump privé ;
aucune base de production n’est restaurée par le retour applicatif.
Anciennes releases et génération NixOS active conservées ; aucune
reconstruction système, rotation de secret ou évolution du style partagé.

## Vérifications exécutées et preuves

- [Backend 37433500057](https://github.com/MrJ-am/vision/actions/runs/37433500057) :
  compilation SBCL, 42 scénarios HTTP/SQL, six tests unitaires de catalogue
  et contenu, contrats OpenAPI, liens, migrations et invariants SQL : réussis.
- [Interface 37433499844](https://github.com/MrJ-am/vision/actions/runs/37433499844) :
  formatage, compilation Elm et interactions Playwright avec le vrai serveur
  Lisp/PostgreSQL isolé, formats 320/375/768/1280 : réussis. Politique partielle,
  absence d’écriture sans changement et changement de compte couverts.
- [Création sémantique 37433499839](https://github.com/MrJ-am/vision/actions/runs/37433499839) :
  qualification existante préservée, réussie.
- [Infrastructure 37434782274](https://github.com/MrJ-am/vps-infrastructure/actions/runs/37434782274)
  et [retour SQL 37434782279](https://github.com/MrJ-am/vps-infrastructure/actions/runs/37434782279) :
  réussis sur la révision opérateur exacte.
- [Préparation 37435153077](https://github.com/MrJ-am/vps-infrastructure/actions/runs/37435153077) :
  compilation réelle, sauvegarde restaurée, migrations, retour SQL, données
  préservées, timer indépendant essayé et 35 sondes HTTP/TLS réussis.
- [Activation 37435297652](https://github.com/MrJ-am/vps-infrastructure/actions/runs/37435297652)
  et [constat indépendant 37435615890](https://github.com/MrJ-am/vps-infrastructure/actions/runs/37435615890) :
  réussis. Interface exacte, pages publiques, liens privés, politique, rapports,
  tutoriel, Basic/Bearer/OAuth PKCE, sessions, CSRF, révocation et services vérifiés.
  Publication enregistrée, timer de retour désarmé, nouvelle connexion et
  contrats SQL 7/1 confirmés. Aucun essai métier en production.

Les deux préparations antérieures ont échoué avant activation : accès au TOC
de restauration après changement d’utilisateur, puis Python absent du PATH
système. Les fichiers privés sont désormais accessibles au seul compte
PostgreSQL pendant la restauration et Python provient du Nixpkgs installé.

Preuves et empreintes détaillées :
[operations/vision-autonomie-publication.json](https://github.com/MrJ-am/vps-infrastructure/blob/main/operations/vision-autonomie-publication.json).

## Limites vérifiées

Les tests du contrat prouvent sa présence et sa cohérence, pas que tous les
LLM suivront ses prescriptions. Les bornes temporelles vérifient la
plausibilité d’un instant, pas l’authenticité de sa provenance. La stabilité
n’est pas une probabilité de rappel scientifiquement garantie.
Les sauvegardes restent privées et locales au VPS.

