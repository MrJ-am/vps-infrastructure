(in-package #:vision)

(defparameter +mcp-default-protocol-version+ "2025-06-18")
(defvar *utilisateur* nil)
(defvar *mcp-tools* (jarray))
(defvar *instructions-mcp* "")
(defvar *mcp-trace-counter* 0)
(defvar *mcp-trace-lock* (sb-thread:make-mutex :name "vision-mcp-trace"))
(defun mcp-next-trace ()
  (sb-thread:with-mutex (*mcp-trace-lock*) (incf *mcp-trace-counter*)))
(defun mcp-trace (numero requete reponse)
  ;; Les valeurs, identités, épisodes et contenus ne passent jamais au journal.
  (let* ((methode (json-object-get requete "method"))
         (nom (json-object-get (json-object-get requete "params") "name")))
    (format *error-output* "mcp_trace=~D method=~A tool=~A result=~A~%" numero
      (if (member methode '("initialize" "ping" "tools/list" "tools/call") :test #'equal) methode "autre")
      (if (find nom (json-array-items *mcp-tools*) :test #'equal :key (lambda (outil) (json-object-get outil "name"))) nom "autre")
      (or (json-object-get (json-object-get reponse "error") "code")
          (if (eq (json-object-get (json-object-get reponse "result") "isError") :true) "tool_error" "ok")))))

(define-condition invalid-parameters (error)
  ((message :initarg :message :reader invalid-parameters-message)))

(defun invalid-parameters (message &rest arguments)
  (error 'invalid-parameters :message (apply #'format nil message arguments)))

(defun object-schema (properties &rest required)
  (jobject "type" "object"
           "properties" properties
           "required" (%make-json-array required)
           "additionalProperties" :false))

(defun array-schema (items &key (maximum 50))
  (jobject "type" "array" "items" items "maxItems" maximum))

(defun string-schema (&key description maximum-length enum nullable)
  (apply #'jobject
         (append
          (list "type" (if nullable (jarray "string" "null") "string"))
          (when description (list "description" description))
          (when maximum-length (list "maxLength" maximum-length))
          (when enum (list "enum" (%make-json-array enum))))))

(defun integer-schema (&key description minimum maximum default)
  (apply #'jobject
         (append (list "type" "integer")
                 (when description (list "description" description))
                 (when minimum (list "minimum" minimum))
                 (when maximum (list "maximum" maximum))
                 (when default (list "default" default)))))

(defun tool-annotations (read-only idempotent)
  (jobject "readOnlyHint" (if read-only :true :false)
           "destructiveHint" :false
           "idempotentHint" (if idempotent :true :false)
           "openWorldHint" :false))

(defun ensure-object (value description)
  (unless (json-object-p value)
    (invalid-parameters "~A must be an object." description))
  value)

(defun validate-object-keys (object allowed)
  (dolist (entry (json-object-entries object))
    (unless (member (car entry) allowed :test #'string=)
      (invalid-parameters "Unexpected argument ~S." (car entry)))))

(defun required-value (object key)
  (multiple-value-bind (value present) (json-object-get object key)
    (unless present
      (invalid-parameters "Missing required argument ~S." key))
    value))

(defun validated-string (value name maximum &key (allow-empty t))
  (unless (stringp value)
    (invalid-parameters "~A must be a string." name))
  (when (> (length value) maximum)
    (invalid-parameters "~A is too long." name))
  (when (and (not allow-empty) (string= (string-trim '(#\Space #\Tab #\Return #\Linefeed) value) ""))
    (invalid-parameters "~A must not be empty." name))
  (when (find (code-char 0) value)
    (invalid-parameters "~A contains a null character." name))
  value)

(defun optional-string (object key default maximum)
  (multiple-value-bind (value present) (json-object-get object key)
    (if present
        (validated-string value key maximum)
        default)))

(defun validated-integer (value name minimum maximum)
  (unless (and (integerp value) (<= minimum value maximum))
    (invalid-parameters "~A must be an integer between ~D and ~D."
                        name minimum maximum))
  value)

(defun optional-integer (object key default minimum maximum)
  (multiple-value-bind (value present) (json-object-get object key)
    (if present
        (validated-integer value key minimum maximum)
        default)))

(defun normalized-string-array (object key maximum-count maximum-length &key downcase)
  (multiple-value-bind (value present) (json-object-get object key)
    (unless present
      (return-from normalized-string-array (jarray)))
    (unless (json-array-p value)
      (invalid-parameters "~A must be an array of strings." key))
    (when (> (length (json-array-items value)) maximum-count)
      (invalid-parameters "~A contains too many values." key))
    (let ((items '()))
      (dolist (item (json-array-items value))
        (let* ((text (validated-string item key maximum-length :allow-empty nil))
               (trimmed (string-trim '(#\Space #\Tab #\Return #\Linefeed) text))
               (normalized (if downcase (string-downcase trimmed) trimmed)))
          (unless (member normalized items :test #'string-equal)
            (push normalized items))))
      (%make-json-array (nreverse items)))))

(defun boolean-json (value)
  (if value "true" "false"))

(defun timestamp-arguments (object key prefix)
  (multiple-value-bind (value present) (json-object-get object key)
    (cond
      ((not present)
       (list (cons (format nil "~A_present" prefix) "false")
             (cons (format nil "~A_is_null" prefix) "false")
             (cons (format nil "~A" prefix) "1970-01-01T00:00:00Z")))
      ((eq value :null)
       (list (cons (format nil "~A_present" prefix) "true")
             (cons (format nil "~A_is_null" prefix) "true")
             (cons (format nil "~A" prefix) "1970-01-01T00:00:00Z")))
      (t
       (list (cons (format nil "~A_present" prefix) "true")
             (cons (format nil "~A_is_null" prefix) "false")
             (cons (format nil "~A" prefix)
                   (validated-string value key 64 :allow-empty nil)))))))

(defun plain-timestamp-arguments (object key prefix)
  (multiple-value-bind (value present) (json-object-get object key)
    (list (cons (format nil "~A_present" prefix) (boolean-json present))
          (cons prefix
                (if present
                    (validated-string value key 64 :allow-empty nil)
                    "1970-01-01T00:00:00Z")))))

(defun database-result-success-p (result key)
  (multiple-value-bind (value present) (json-object-get result key)
    (and present (eq value :true))))

(defun database-object-value (object key)
  (multiple-value-bind (value present) (json-object-get object key)
    (unless present
      (database-fail "Malformed PostgreSQL result."
                     (format nil "Missing field ~S." key)))
    value))

(defun database-result-error (result)
  (multiple-value-bind (value present) (json-object-get result "error")
    (and present value)))

(defun invoke-mcp-tool (nom arguments)
  (when (member nom '("search_memory_sheets" "list_due_memory_sheets" "get_memory_sheet" "save_memory_sheet" "record_review") :test #'string=)
    (return-from invoke-mcp-tool (jobject "content" (jarray (jobject "type" "text" "text" "Contrat Vision 1 retiré. Mettre à jour la configuration du connecteur client pour exposer les neuf outils Vision 2, puis reconnecter ce client. Recharger tools/list sur le serveur seul ne modifie pas un catalogue statique. Aucune note FSRS de fiche n'est convertie en item.")) "isError" :true
      "structuredContent" (jobject "erreur" "contrat_retire" "version" 2 "catalogue" "https://vision.mrj.am/mcp"))))
  (let* ((resultat (operation-vision nom arguments))
         (erreur (json-object-get resultat "erreur")))
    (jobject "content" (jarray (jobject "type" "text" "text"
      (cond (erreur (format nil "Opération refusée : ~A. Relire l’état avant de réessayer." erreur))
            ((string= nom "preparer_revision") "Contexte de révision chargé. Poser une question sans divulgation.")
            (t (json-encode resultat)))))
      "structuredContent" resultat "isError" (if erreur :true :false))))

(defun mcp-success-response (id result)
  (jobject "jsonrpc" "2.0" "id" id "result" result))

(defun mcp-error-response (id code message &optional data)
  (jobject "jsonrpc" "2.0"
           "id" id
           "error" (apply #'jobject
                          (append (list "code" code "message" message)
                                  (when data (list "data" data))))))

(defun protocol-version-p (value)
  (and (stringp value)
       (= (length value) 10)
       (char= (char value 4) #\-)
       (char= (char value 7) #\-)
       (loop for index from 0 below 10
             always (or (member index '(4 7))
                        (digit-char-p (char value index))))))

(defun initialize-result (params)
  (let ((requested
          (multiple-value-bind (value present)
              (json-object-get params "protocolVersion")
            (if (and present (protocol-version-p value))
                value
                +mcp-default-protocol-version+))))
    (jobject
     "protocolVersion" requested
     "capabilities" (jobject "tools" (jobject "listChanged" :false))
     "serverInfo" (jobject "name" "vision" "title" "Vision" "version" *version*)
     "instructions" *instructions-mcp*)))

(defun dispatch-mcp-request (request)
  (ensure-object request "JSON-RPC request")
  (multiple-value-bind (jsonrpc jsonrpc-present) (json-object-get request "jsonrpc")
    (unless (and jsonrpc-present (stringp jsonrpc) (string= jsonrpc "2.0"))
      (return-from dispatch-mcp-request
        (values 200 (mcp-error-response :null -32600 "Invalid Request")))))
  (multiple-value-bind (id id-present) (json-object-get request "id")
    (multiple-value-bind (method method-present) (json-object-get request "method")
      (unless (and method-present (stringp method))
        (return-from dispatch-mcp-request
          (values 200 (mcp-error-response (if id-present id :null)
                                          -32600 "Invalid Request"))))
      (multiple-value-bind (raw-params params-present) (json-object-get request "params")
        (let ((params (if params-present
                          (ensure-object raw-params "params")
                          (jobject))))
          (unless id-present
            ;; Les notifications ne peuvent pas déclencher silencieusement un outil d'écriture.
            (return-from dispatch-mcp-request (values 202 nil)))
          (handler-case
              (cond
                ((string= method "initialize")
                 (values 200 (mcp-success-response id (initialize-result params))))
                ((string= method "ping")
                 (values 200 (mcp-success-response id (jobject))))
                ((string= method "tools/list")
                 (validate-object-keys params '("cursor" "_meta"))
                 (values 200
                         (mcp-success-response id (jobject "tools" *mcp-tools*))))
                ((string= method "tools/call")
                 (validate-object-keys params '("name" "arguments" "_meta"))
                 (let ((name (validated-string (required-value params "name")
                                               "name" 128 :allow-empty nil))
                       (arguments
                         (multiple-value-bind (value present)
                             (json-object-get params "arguments")
                           (if present
                               (ensure-object value "arguments")
                               (jobject)))))
                   (values 200
                           (mcp-success-response
                            id (invoke-mcp-tool name arguments)))))
                (t
                 (values 200 (mcp-error-response id -32601 "Method not found"))))
            (invalid-parameters (condition)
              (values 200
                      (mcp-error-response
                       id -32602 "Invalid params"
                       (jobject "message" (invalid-parameters-message condition)))))))))))

(defun handle-mcp-message (body)
  (let ((trace (mcp-next-trace)))
    (handler-case
      (let ((request (parse-json body)))
        (multiple-value-bind (status response)
            (dispatch-mcp-request request)
          (mcp-trace trace request response)
          (values status
                  (if (= status 202) "Accepted" "OK")
                  (and response (json-encode response)))))
    (json-error (condition)
      (format *error-output* "mcp_trace=~D result=parse_error~%" trace)
      (finish-output *error-output*)
      (values 200 "OK"
              (json-encode
               (mcp-error-response
                :null -32700 "Parse error"
                (jobject "message" (json-error-message condition))))))
    (invalid-parameters (condition)
      (format *error-output* "mcp_trace=~D result=invalid_request~%" trace)
      (finish-output *error-output*)
      (values 200 "OK"
              (json-encode
               (mcp-error-response
                :null -32600 "Invalid Request"
                (jobject "message" (invalid-parameters-message condition)))))))))
