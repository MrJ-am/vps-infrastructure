(require :sb-bsd-sockets)

(defpackage #:vision
  (:use #:cl)
  (:export #:main
           #:serve))

(in-package #:vision)

(defparameter *version* "2.0.0")
