(in-package #:vision)

(defun handle-browser-request (stream path headers body &optional (prefixe "/api/web/"))
  (unless (and *utilisateur*
               (or (string= prefixe "/api/v1/")
                   (equal (header-values "x-vision-browser" headers) '("1"))))
    (write-json stream 401 "Unauthorized" "{\"erreur\":\"identite_requise\"}")
    (return-from handle-browser-request))
  (unless (json-content-type-p headers)
    (write-json stream 415 "Unsupported Media Type" "{\"erreur\":\"json_requis\"}")
    (return-from handle-browser-request))
  (handler-case
      (let* ((resultat (operation-vision (subseq path (length prefixe)) (parse-json body)))
             (erreur (json-object-get resultat "erreur"))
             (statut (cond ((member erreur '("conflit" "conflit_episode" "cle_reutilisee") :test #'equal) 409)
                           ((equal erreur "introuvable") 404)
                           ((equal erreur "base_indisponible") 503)
                           (erreur 400) (t 200))))
        (write-json stream statut (case statut (200 "OK") (409 "Conflict") (404 "Not Found") (503 "Service Unavailable") (t "Bad Request"))
                    (json-encode resultat)))
    (json-error () (write-json stream 400 "Bad Request" "{\"erreur\":\"json_invalide\"}"))
    (invalid-parameters (condition)
      (write-json stream 400 "Bad Request" (json-encode (jobject "erreur" "parametres_invalides"
        "message" (invalid-parameters-message condition)))))))
