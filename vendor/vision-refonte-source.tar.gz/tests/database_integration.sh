#!/bin/sh
set -eu

cd -- "$(dirname -- "$0")/.."

port="${VISION_DATABASE_TEST_PORT:-39002}"
temporary="$(mktemp -d)"
build_temporary="$(mktemp -d)"
server_pid=""
cleanup() {
  if [ -n "$server_pid" ]; then
    kill "$server_pid" 2>/dev/null || true
    wait "$server_pid" 2>/dev/null || true
  fi
  rm -rf -- "$temporary"
  rm -rf -- "$build_temporary"
  rm -f -- vision
}
trap cleanup EXIT INT TERM

sh scripts/migrate.sh
sh scripts/migrate.sh
env TMPDIR="$build_temporary" XDG_CACHE_HOME="$build_temporary/cache" sh build.sh
# Régression : l'exécutable doit rester capable d'appeler psql après la
# disparition du répertoire temporaire dans lequel SBCL l'a construit.
rm -rf -- "$build_temporary"

IP=127.0.0.1 PORT="$port" VISION_VERSION=1.2.0 \
  VISION_PSQL="$(command -v psql)" \
  VISION_DOCUMENT_ROOT="$PWD/docs" ./vision >"$temporary/server.log" 2>&1 &
server_pid=$!

for _attempt in $(seq 1 50); do
  if curl --fail --silent --max-time 1 \
      "http://127.0.0.1:$port/healthz" >/dev/null; then
    break
  fi
  sleep 0.1
done

VISION_DATABASE_TEST_PORT="$port" python3 tests/check_mcp_database.py

VISION_DATABASE_TEST_PORT="$port" python3 tests/check_browser_database.py
