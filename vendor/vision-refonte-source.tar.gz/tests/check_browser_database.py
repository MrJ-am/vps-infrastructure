"""Exercise browser writes, pagination, corrections and races on an isolated DB."""
import json, os, urllib.request, urllib.error, subprocess
PORT=os.environ.get('VISION_DATABASE_TEST_PORT','39002')
def call(action, data, code=200, authenticated=True, browser=True):
    headers={'Content-Type':'application/json'}
    if authenticated: headers['X-Vision-Authenticated']='1'
    if browser: headers['X-Vision-Browser']='1'
    headers['X-Mrj-User']='test-browser'
    req=urllib.request.Request(f'http://127.0.0.1:{PORT}/api/web/{action}',json.dumps(data).encode(),headers)
    try:r=urllib.request.urlopen(req)
    except urllib.error.HTTPError as e:r=e
    with r:
        body=r.read();assert r.status==code,(r.status,body);return json.loads(body)
def sql(text):
    return subprocess.check_output(['psql','-XAt','-v','ON_ERROR_STOP=1','-c',text],text=True).strip()
base={'query':'browser-fixture','tags':[],'tagMode':'all','state':'active','sort':'title','direction':'asc','limit':1,'offset':0}
call('list',base,401,False);call('list',base,401,browser=False)
call('list',{**base,'sort':'id; DROP TABLE vision_memory_sheets'},400)
new={'title':'A browser-fixture','body':'Une idée <script>test</script>','summary':'résumé accentué','tags':['analyse','maths'],'aliases':['alias recherche'],'importance':4,'dueAt':'2025-01-01T00:00:00Z','fsrsStability':None,'fsrsDifficulty':None,'fsrsLastReviewedAt':None,'archived':False}
id=call('save',new)['sheetId'];second=call('save',{**new,'title':'B browser-fixture','tags':['logique']})['sheetId']
page=call('list',base);assert page['total']==2 and page['sheets'][0]['id']==id
assert call('list',{**base,'offset':1})['sheets'][0]['id']==second
assert call('list',{**base,'direction':'desc'})['sheets'][0]['id']==second
assert call('list',{**base,'tags':['analyse','logique']})['total']==0
assert call('list',{**base,'tags':['analyse','logique'],'tagMode':'any'})['total']==2
assert call('list',{**base,'query':'alias recherche'})['total']>=2
assert call('list',{**base,'query':"' OR 1=1 --"})['total']==0
record=call('get',{'sheetId':id});assert record['sheet']['body']==new['body']
updated={**new,'sheetId':id,'expectedUpdatedAt':record['sheet']['updatedAt'],'title':'C browser-fixture','fsrsStability':5.75,'fsrsDifficulty':4.2,'fsrsLastReviewedAt':'2026-01-01T00:00:00Z'}
assert call('save',updated)['saved'];call('save',updated,409)
call('save',{**updated,'expectedUpdatedAt':call('get',{'sheetId':id})['sheet']['updatedAt'],'fsrsStability':0},400)
assert call('list',{**base,'minStability':5,'maxDifficulty':5})['total']==1
assert call('list',{**base,'minStability':6})['total']==0
assert call('list',{**base,'maxRetrievability':.99})['total']==1
assert call('list',{**base,'dueAfter':'2026-01-01T00:00:00Z'})['total']==0
assert call('list',{**base,'state':'due'})['total']==2
assert call('list',{**base,'dueBefore':'bad-date'},400)['error']=='invalid_data'
# Corrected qualitative data reaches the LLM, while the original remains intact.
observation=int(sql(f"INSERT INTO vision_memory_observations(sheet_id,outcome,note,context) VALUES({id},'partial','Original','{{\"confidence\":0.4}}') RETURNING id").splitlines()[0])
correction={'observationId':observation,'expectedCorrectionId':0,'note':'Correction humaine','context':{'confidence':.9,'comment':'à vérifier'}}
assert call('correct',correction)['saved'];call('correct',correction,409)
obs=call('get',{'sheetId':id})['observations'][0];assert obs['note']=='Correction humaine' and obs['original']['note']=='Original'
assert sql(f'SELECT note FROM vision_memory_observations WHERE id={observation}')=='Original'
req=urllib.request.Request(f'http://127.0.0.1:{PORT}/mcp',json.dumps({'jsonrpc':'2.0','id':1,'method':'tools/call','params':{'name':'get_memory_sheet','arguments':{'sheetId':id}}}).encode(),{'Content-Type':'application/json','X-Vision-Authenticated':'1'})
with urllib.request.urlopen(req) as r:
    data=json.load(r)['result'];assert not data['isError'];assert 'Correction humaine' in json.dumps(data,ensure_ascii=False)
record=call('get',{'sheetId':id})['sheet']
call('save',{**updated,'expectedUpdatedAt':record['updatedAt'],'archived':True})
assert call('list',base)['total']==1
assert call('list',{**base,'state':'archived'})['total']==1
assert call('list',{**base,'state':'all'})['total']==2
assert call('get',{'sheetId':id})['sheet']['archivedAt']
record=call('get',{'sheetId':id})['sheet'];call('save',{**updated,'expectedUpdatedAt':record['updatedAt'],'archived':False})
assert call('list',base)['total']==2
# All observations remain accessible beyond the former 20/100-item MCP window.
sql(f"INSERT INTO vision_memory_observations(sheet_id,outcome,note) SELECT {id},'not_assessed','pagination '||n FROM generate_series(1,110) n")
assert len(call('get',{'sheetId':id})['observations'])==50
assert len(call('get',{'sheetId':id,'observationOffset':100})['observations'])==11
call('get',{'sheetId':999999999},404)
assert int(sql(f'SELECT count(*) FROM vision_sheet_edits WHERE sheet_id={id}'))==4
print('Browser database: auth gates, search, pagination, tags, sorts, numbers, optimistic locking, archive/restore and immutable corrections OK')
