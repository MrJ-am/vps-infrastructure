BEGIN;
DO $$
DECLARE a jsonb;b jsonb;centre timestamptz; entree timestamptz; sortie timestamptz;s integer;p integer;
BEGIN
 a:=vision_fenetre(0,0,90,0,'2026-01-01','2026-04-01');
 ASSERT abs((a->>'intervalle_jours')::numeric-90)<1e-9;
 ASSERT abs((a->>'debut_jours')::numeric/90-power(10::numeric,-0.1))<1e-12;
 ASSERT abs((a->>'fin_jours')::numeric/90-power(10::numeric,0.1))<1e-12;
 ASSERT abs((vision_fenetre(-15,0,90,0,NULL)->>'intervalle_jours')::numeric-2.84604989415154)<1e-10;
 ASSERT vision_fenetre(127,-20,3650,30,'2026-01-01','2026-04-01')->>'etat'='hors_horizon';
 ASSERT vision_fenetre(-128,20,1,0,'2026-01-01','2026-04-01')->>'etat'='intervalle_tres_court';
 ASSERT vision_fenetre(0,0,90,0,NULL)->>'etat'='reference_inconnue';
 ASSERT vision_fenetre(0,0,90,0,'2026-04-01','2026-01-01')->>'etat'='reference_future';
 ASSERT vision_fenetre(0,0,90,0,'2026-01-01','2026-01-01')->>'urgence' IS NULL;
 FOR s IN -127..127 LOOP
  a:=vision_fenetre(s,0,90,0,NULL);b:=vision_fenetre(s-1,0,90,0,NULL);
  ASSERT (a->>'intervalle_jours')::numeric>(b->>'intervalle_jours')::numeric;
 END LOOP;
 FOR p IN -19..20 LOOP
  a:=vision_fenetre(0,p,90,0,NULL);b:=vision_fenetre(0,p-1,90,0,NULL);
  ASSERT (a->>'intervalle_jours')::numeric<(b->>'intervalle_jours')::numeric;
 END LOOP;
 a:=vision_fenetre(0,0,90,0,'2026-01-01','2026-01-01');
 entree:=(a->>'debut')::timestamptz;sortie:=(a->>'fin')::timestamptz;
 ASSERT abs((vision_fenetre(0,0,90,0,'2026-01-01',entree)->>'urgence')::numeric+1)<1e-9;
 ASSERT abs((vision_fenetre(0,0,90,0,'2026-01-01',sortie)->>'urgence')::numeric-1)<1e-9;
END $$;
ROLLBACK;
