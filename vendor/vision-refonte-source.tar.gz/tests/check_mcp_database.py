#!/usr/bin/env python3
import json
import os
import urllib.request


ORIGIN = f"http://127.0.0.1:{os.environ.get('VISION_DATABASE_TEST_PORT', '39002')}"
HEADERS = {
    "Content-Type": "application/json",
    "Accept": "application/json, text/event-stream",
    "X-Vision-Authenticated": "1",
}


def call(name, arguments, request_id):
    payload = json.dumps(
        {
            "jsonrpc": "2.0",
            "id": request_id,
            "method": "tools/call",
            "params": {"name": name, "arguments": arguments},
        },
        ensure_ascii=False,
        separators=(",", ":"),
    ).encode()
    request = urllib.request.Request(ORIGIN + "/mcp", data=payload, headers=HEADERS)
    with urllib.request.urlopen(request, timeout=10) as response:
        assert response.status == 200
        document = json.load(response)
    assert "error" not in document, document
    assert document["result"]["isError"] is False, document
    return document["result"]["structuredContent"]


created = call(
    "save_memory_sheet",
    {
        "title": "Guy Brousseau",
        "body": "Didacticien français, associé à la théorie des situations didactiques.\n"
        "Retenir le prénom Guy et distinguer ses travaux de ceux de ses contemporains.",
        "summary": "Guy Brousseau et la théorie des situations didactiques.",
        "tags": ["Didactique", "Personnes"],
        "aliases": ["Brousseau"],
        "importance": 4,
        "dueAt": "2026-01-01T00:00:00Z",
    },
    "create",
)
assert created["saved"] is True and created["created"] is True
sheet_id = created["sheet"]["id"]
assert created["sheet"]["tags"] == ["didactique", "personnes"]

searched = call(
    "search_memory_sheets",
    {"query": "Brousseau", "tags": ["DIDACTIQUE"]},
    "search",
)
assert searched["count"] == 1
assert searched["sheets"][0]["id"] == sheet_id

loaded = call(
    "get_memory_sheet",
    {"sheetId": sheet_id, "observationLimit": 20},
    "get-before-review",
)
assert loaded["found"] is True
assert loaded["sheet"]["title"] == "Guy Brousseau"
assert loaded["observations"] == []

recorded = call(
    "record_review",
    {
        "sheetId": sheet_id,
        "outcome": "partial",
        "note": "Le prénom a nécessité un indice ; le lien avec les situations didactiques était spontané.",
        "context": {"fatigue": "unknown", "support": "conversation"},
        "reviewedAt": "2026-09-20T12:00:00Z",
        "rating": 3,
    },
    "review",
)
assert recorded["recorded"] is True
assert recorded["sheet"]["reviewCount"] == 1
assert recorded["sheet"]["fsrsReviewCount"] == 1
assert recorded["sheet"]["lastOutcome"] == "partial"
assert abs(recorded["sheet"]["fsrsStability"] - 2.3065) < 1e-5
assert abs(recorded["sheet"]["fsrsDifficulty"] - 2.118104) < 1e-5
assert recorded["sheet"]["dueAt"] == "2026-09-22T12:00:00+00:00"
assert recorded["scheduling"]["applied"] is True
assert recorded["scheduling"]["modelVersion"] == "fsrs-6"
assert recorded["scheduling"]["scheduledDays"] == 2

qualitative = call(
    "record_review",
    {
        "sheetId": sheet_id,
        "outcome": "not_assessed",
        "note": "Fatigue trop importante pour interpréter la réponse.",
        "context": {"fatigue": "high", "support": "conversation"},
        "reviewedAt": "2026-09-20T13:00:00Z",
    },
    "qualitative-review",
)
assert qualitative["recorded"] is True
assert qualitative["sheet"]["reviewCount"] == 2
assert qualitative["sheet"]["fsrsReviewCount"] == 1
assert qualitative["sheet"]["dueAt"] == "2026-09-22T12:00:00+00:00"
assert qualitative["scheduling"] == {"applied": False, "reason": "rating_absent"}

not_due = call(
    "list_due_memory_sheets",
    {"before": "2026-09-22T11:59:59Z"},
    "not-due",
)
assert not_due == {"sheets": [], "count": 0}

due = call(
    "list_due_memory_sheets",
    {"before": "2026-09-22T12:00:01Z", "tags": ["didactique"]},
    "due",
)
assert due["count"] == 1 and due["sheets"][0]["id"] == sheet_id

loaded = call(
    "get_memory_sheet",
    {"sheetId": sheet_id},
    "get-after-review",
)
assert len(loaded["observations"]) == 2
assert loaded["observations"][0]["outcome"] == "not_assessed"
assert loaded["observations"][0]["rating"] is None
assert loaded["observations"][0]["schedulingApplied"] is False
assert loaded["observations"][1]["outcome"] == "partial"
assert loaded["observations"][1]["rating"] == 3
assert loaded["observations"][1]["schedulingApplied"] is True
assert loaded["observations"][1]["context"]["support"] == "conversation"

updated = call(
    "save_memory_sheet",
    {
        "sheetId": sheet_id,
        "title": "Guy Brousseau",
        "body": loaded["sheet"]["body"] + "\nLa fiche reste volontairement synthétique.",
        "summary": loaded["sheet"]["summary"],
        "tags": loaded["sheet"]["tags"],
        "aliases": loaded["sheet"]["aliases"],
        "importance": loaded["sheet"]["importance"],
        "dueAt": None,
    },
    "update",
)
assert updated["saved"] is True and updated["created"] is False
assert updated["sheet"]["dueAt"] is None

print("MCP PostgreSQL integration tests OK")
