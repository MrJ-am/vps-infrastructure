#!/bin/sh
set -eu

operation=""
for argument in "$@"; do
  case "$argument" in
    operation=*) operation="${argument#operation=}" ;;
  esac
done

# Le vrai psql lit la requête sur l'entrée standard afin d'appliquer la
# substitution et la citation de ses variables. Le faux client la consomme
# aussi pour reproduire ce cycle de vie sans fermer le tube prématurément.
while IFS= read -r _line; do :; done

case "$operation" in
  search_memory_sheets|list_due_memory_sheets)
    printf '%s\n' '{"sheets":[],"count":0}'
    ;;
  get_memory_sheet)
    printf '%s\n' '{"found":false,"sheet":null,"observations":[]}'
    ;;
  save_memory_sheet_create)
    printf '%s\n' '{"saved":true,"created":true,"sheet":{"id":1,"title":"Guy Brousseau"}}'
    ;;
  save_memory_sheet_update)
    printf '%s\n' '{"saved":true,"created":false,"sheet":{"id":1,"title":"Guy Brousseau"}}'
    ;;
  record_review)
    printf '%s\n' '{"recorded":true,"sheet":{"id":1,"reviewCount":1,"fsrsReviewCount":0},"observation":{"id":1,"sheetId":1,"outcome":"partial","rating":null,"schedulingApplied":false},"scheduling":{"applied":false,"reason":"rating_absent"}}'
    ;;
  *)
    printf 'Unexpected fake psql operation: %s\n' "$operation" >&2
    exit 2
    ;;
esac

