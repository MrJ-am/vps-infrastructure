(require :asdf)
(asdf:load-asd (truename "vision.asd"))
(asdf:load-system :vision)

(in-package #:vision)

(defun approximately= (actual expected &optional (epsilon 1.0d-5))
  (< (abs (- (coerce actual 'double-float)
             (coerce expected 'double-float)))
     epsilon))

(defun assert-approximately= (actual expected &optional (epsilon 1.0d-5))
  (assert (approximately= actual expected epsilon)
          (actual expected)
          "Expected ~A to be within ~A of ~A." actual epsilon expected))

(assert (= (length +fsrs-default-parameters+) 21))
(assert (string= +fsrs-model-version+ "fsrs-6"))
(assert (string= +fsrs-implementation-version+ "fsrs-rs-6.6.2"))

;; Oracle values copied from the upstream fsrs-rs v6.6.2 tests.
(loop for elapsed in '(0.0d0 1.0d0 2.0d0 3.0d0 4.0d0 5.0d0)
      for stability in '(1.0d0 2.0d0 3.0d0 4.0d0 4.0d0 2.0d0)
      for expected in '(1.0d0 0.9403443d0 0.9253786d0
                        0.9185229d0 0.9d0 0.8261359d0)
      do (assert-approximately=
          (fsrs-retrievability stability elapsed +fsrs-default-parameters+)
          expected))

(loop for rating from 1 to 4
      for expected-stability in '(0.212d0 1.2931d0 2.3065d0 8.2956d0)
      for expected-difficulty in '(6.4133d0 5.1121707d0 2.118104d0 1.0d0)
      do (multiple-value-bind (state interval scheduled-days)
             (fsrs-schedule nil rating 0 0.9d0 +fsrs-default-parameters+)
           (assert-approximately=
            (fsrs-memory-state-stability state) expected-stability)
           (assert-approximately=
            (fsrs-memory-state-difficulty state) expected-difficulty)
           (assert-approximately= interval expected-stability)
           (assert (= scheduled-days
                      (max 1 (floor (+ expected-stability 0.5d0)))))))

(let ((state nil))
  (loop for rating in '(1 3 3 3 3 3)
        for elapsed in '(0 0 1 3 8 21)
        do (setf state
                 (fsrs-next-state state rating elapsed
                                  +fsrs-default-parameters+)))
  (assert-approximately= (fsrs-memory-state-stability state) 53.62691d0 1.0d-4)
  (assert-approximately= (fsrs-memory-state-difficulty state) 6.3574867d0 1.0d-4))

(format t "FSRS-6 Common Lisp oracle tests OK~%")
