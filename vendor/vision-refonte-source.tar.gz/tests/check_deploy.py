from pathlib import Path


module = Path("deploy/vision.nix").read_text(encoding="utf-8")

expected = '${pkgs.dash}/bin/dash /srv/vision/current/scripts/migrate.sh'
assert expected in module
assert '${pkgs.dash}/bin/sh' not in module
assert 'chmod -R u=rwX,g=rX,o= "$staging"' in module
assert 'chmod 0550 "$staging/vision"' in module
assert "runtimeInputs = [ pkgs.openssl pkgs.coreutils ];" in module
assert "openssl passwd -6 -stdin" in module
assert "htpasswd -i -n -B" not in module
assert '"d /var/lib/vision 0710 root vision-auth -"' in module
assert module.count('path = [ config.services.postgresql.package ];') == 2
assert 'PGOPTIONS = "-c statement_timeout=5000";' in module
assert 'VISION_PSQL = "${config.services.postgresql.package}/bin/psql";' in module
assert 'default = "1.3.0";' in module
assert "THIRD_PARTY_NOTICES.md" in module

print("Module de déploiement valide")

