#!/usr/bin/env python3
import json
from pathlib import Path


document = json.loads(Path("docs/openapi.json").read_text(encoding="utf-8"))
assert document["openapi"].startswith("3.1.")
assert document["servers"][0]["url"] == "https://vision.mrj.am"
assert document["security"] == [{"basicAuth": []}]
assert document["components"]["securitySchemes"]["basicAuth"] == {
    "type": "http",
    "scheme": "basic",
}

outils = json.loads(Path("docs/outils.json").read_text(encoding="utf-8"))
assert list(document["paths"]) == ["/api/v1/" + outil["name"] for outil in outils]
for outil in outils:
    operation = document["paths"]["/api/v1/" + outil["name"]]["post"]
    assert operation["operationId"] == outil["name"]
    assert operation["requestBody"]["content"]["application/json"]["schema"] == outil["inputSchema"]
    assert {"200", "400", "401", "409", "503"} <= set(operation["responses"])
print("OpenAPI contract OK")

test_document = json.loads(
    Path("docs/mobile-live-test-openapi.json").read_text(encoding="utf-8")
)
assert test_document["openapi"].startswith("3.1.")
assert test_document["servers"][0]["url"] == document["servers"][0]["url"]
assert test_document["security"] == [{"mobileLiveTestBasicAuth": []}]
assert list(test_document["paths"]) == ["/api/v1/mobile-live-test"]
test_operation = test_document["paths"]["/api/v1/mobile-live-test"]["get"]
assert test_operation["operationId"] == "testMobileLiveAuthentication"
assert test_operation["x-openai-isConsequential"] is False
assert set(test_operation["responses"]) == {"200", "401", "429"}
assert test_document["components"]["securitySchemes"]["mobileLiveTestBasicAuth"] == {
    "type": "http",
    "scheme": "basic",
    "description": "Disposable credentials restricted to this harmless test endpoint.",
}
print("Mobile Live test contract OK")
