#!/usr/bin/env python3
import json
from pathlib import Path


document = json.loads(Path("docs/openapi.json").read_text(encoding="utf-8"))
assert document["openapi"].startswith("3.1.")
assert document["servers"] == [{
    "url": "https://vision.mrj.am",
    "description": "Production",
}]
assert document["security"] == [{"basicAuth": []}]
assert document["components"]["securitySchemes"]["basicAuth"] == {
    "type": "http",
    "scheme": "basic",
    "description": "Dedicated Vision identifier and password, sent only over HTTPS.",
}

operations = []
for path, path_item in document["paths"].items():
    assert path.startswith("/api/v1/")
    for method, operation in path_item.items():
        assert method in {"get", "post"}
        operation_id = operation["operationId"]
        assert operation_id not in operations
        operations.append(operation_id)
        assert "200" in operation["responses"]
        assert "401" in operation["responses"]

assert operations == [
    "getVisionHealth",
    "getVisionCapabilities",
    "sayHello",
]
print("OpenAPI contract OK")

test_document = json.loads(
    Path("docs/mobile-live-test-openapi.json").read_text(encoding="utf-8")
)
assert test_document["openapi"].startswith("3.1.")
assert test_document["servers"] == document["servers"]
assert test_document["security"] == [{"mobileLiveTestBasicAuth": []}]
assert list(test_document["paths"]) == ["/api/v1/mobile-live-test"]
test_operation = test_document["paths"]["/api/v1/mobile-live-test"]["get"]
assert test_operation["operationId"] == "testMobileLiveAuthentication"
assert test_operation["x-openai-isConsequential"] is False
assert set(test_operation["responses"]) == {"200", "401", "429"}
assert test_document["components"]["securitySchemes"]["mobileLiveTestBasicAuth"] == {
    "type": "http",
    "scheme": "basic",
    "description": "Disposable credentials restricted to this harmless test endpoint.",
}
print("Mobile Live test contract OK")
