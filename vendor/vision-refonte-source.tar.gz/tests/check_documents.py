"""Routes publiques du véritable serveur Lisp, avec la cohérence PostgreSQL vérifiée au démarrage."""
import os
from pathlib import Path
import socket
import subprocess
import tempfile
import time
from urllib.error import HTTPError
from urllib.request import urlopen

RACINE = Path(__file__).resolve().parents[1]


def verifier():
    with socket.socket() as adresse:
        adresse.bind(('127.0.0.1', 0))
        port = adresse.getsockname()[1]
    with tempfile.TemporaryFile() as journal:
        serveur = subprocess.Popen([str(RACINE / 'vision')], cwd=RACINE,
            env={**os.environ, 'IP': '127.0.0.1', 'PORT': str(port),
                 'VISION_DOCUMENT_ROOT': str(RACINE / 'docs')}, stdout=journal, stderr=journal)
        try:
            base = f'http://127.0.0.1:{port}'
            for _ in range(50):
                try:
                    with urlopen(base + '/healthz', timeout=1): break
                except OSError:
                    if serveur.poll() is not None: raise RuntimeError('Serveur arrêté')
                    time.sleep(.1)
            for chemin in ['/', '/docs', '/docs/', '/privacy']:
                with urlopen(base + chemin, timeout=2) as reponse:
                    contenu = reponse.read()
                    assert reponse.status == 200 and b'id="application"' in contenu, chemin
                    assert contenu == (RACINE / 'interface/app.html').read_bytes(), chemin
                    assert "base-uri 'none'" in reponse.headers['Content-Security-Policy']
                    assert b'<base ' not in contenu
            for chemin in ['/api/fiches', '/mcp']:
                try:
                    urlopen(base + chemin, timeout=2)
                    raise AssertionError('Refus anonyme absent : ' + chemin)
                except HTTPError as erreur:
                    assert erreur.code == 401
        finally:
            serveur.terminate()
            serveur.wait(timeout=5)
    print('Serveur Lisp : quatre routes ElmUI publiques, CSP et refus anonyme vérifiés.')


if __name__ == '__main__':
    verifier()
