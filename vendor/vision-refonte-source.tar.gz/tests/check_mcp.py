#!/usr/bin/env python3
import json
import os
import urllib.error
import urllib.request


ORIGIN = f"http://127.0.0.1:{os.environ.get('VISION_TEST_PORT', '39001')}"
AUTH = {"X-Vision-Authenticated": "1"}


def request(path, *, payload=None, authenticated=True, content_type="application/json"):
    data = None
    headers = dict(AUTH if authenticated else {})
    if payload is not None:
        if isinstance(payload, bytes):
            data = payload
        else:
            data = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode()
        headers["Content-Type"] = content_type
        headers["Accept"] = "application/json, text/event-stream"
        headers["MCP-Protocol-Version"] = "2025-06-18"
    req = urllib.request.Request(ORIGIN + path, data=data, headers=headers)
    try:
        response = urllib.request.urlopen(req, timeout=5)
    except urllib.error.HTTPError as exc:
        response = exc
    with response:
        return response.status, response.headers, response.read()


def rpc(method, params=None, request_id=1):
    payload = {"jsonrpc": "2.0", "id": request_id, "method": method}
    if params is not None:
        payload["params"] = params
    status, headers, body = request("/mcp", payload=payload)
    assert status == 200, (status, body)
    assert headers.get_content_type() == "application/json"
    parsed = json.loads(body)
    assert parsed["jsonrpc"] == "2.0"
    assert parsed["id"] == request_id
    return parsed


status, headers, body = request("/mcp", authenticated=False)
assert status == 401
assert headers["WWW-Authenticate"].startswith("Basic ")
assert json.loads(body)["error"] == "authentication_required"

status, headers, body = request("/mcp")
assert status == 405
assert headers["Allow"] == "POST"

initialized = rpc(
    "initialize",
    {
        "protocolVersion": "2025-06-18",
        "capabilities": {},
        "clientInfo": {"name": "vision-test", "version": "1"},
    },
)
assert initialized["result"]["protocolVersion"] == "2025-06-18"
assert initialized["result"]["serverInfo"]["name"] == "vision"
assert initialized["result"]["capabilities"] == {"tools": {"listChanged": False}}

status, _, body = request(
    "/mcp",
    payload={"jsonrpc": "2.0", "method": "notifications/initialized"},
)
assert status == 202
assert body == b""

listed = rpc("tools/list", {})
tools = listed["result"]["tools"]
assert [tool["name"] for tool in tools] == [
    "search_memory_sheets",
    "list_due_memory_sheets",
    "get_memory_sheet",
    "save_memory_sheet",
    "record_review",
]
assert all(tool["inputSchema"]["additionalProperties"] is False for tool in tools)
assert tools[0]["annotations"]["readOnlyHint"] is True
assert tools[-1]["annotations"]["readOnlyHint"] is False

searched = rpc(
    "tools/call",
    {"name": "search_memory_sheets", "arguments": {"query": "variété"}},
    request_id="search",
)
assert searched["result"]["isError"] is False
assert searched["result"]["structuredContent"] == {"sheets": [], "count": 0}

listed_with_metadata = rpc("tools/list", {"_meta": {"progressToken": "client"}})
assert len(listed_with_metadata["result"]["tools"]) == 5
searched_with_metadata = rpc(
    "tools/call",
    {"name": "search_memory_sheets", "arguments": {"query": ""},
     "_meta": {"progressToken": "client"}},
    request_id="search-meta",
)
assert searched_with_metadata["result"]["structuredContent"] == {"sheets": [], "count": 0}

saved = rpc(
    "tools/call",
    {
        "name": "save_memory_sheet",
        "arguments": {
            "title": "Guy Brousseau",
            "body": "Informations à retenir.",
            "tags": ["didactique", "personnes"],
        },
    },
    request_id="save",
)
assert saved["result"]["structuredContent"]["saved"] is True

reviewed = rpc(
    "tools/call",
    {
        "name": "record_review",
        "arguments": {
            "sheetId": 1,
            "outcome": "partial",
            "note": "Le prénom a nécessité un indice.",
            "context": {"fatigue": "unknown"},
        },
    },
    request_id="review",
)
assert reviewed["result"]["structuredContent"]["recorded"] is True

invalid_schedule = rpc(
    "tools/call",
    {
        "name": "record_review",
        "arguments": {
            "sheetId": 1,
            "outcome": "recalled",
            "note": "Conflit volontaire pour tester le contrat.",
            "rating": 3,
            "nextReviewAt": "2030-01-01T00:00:00Z",
        },
    },
    request_id="invalid-schedule",
)
assert invalid_schedule["error"]["code"] == -32602

invalid = rpc(
    "tools/call",
    {"name": "search_memory_sheets", "arguments": {"query": "x", "limit": 0}},
    request_id="invalid",
)
assert invalid["error"]["code"] == -32602

status, _, body = request("/mcp", payload=b"{")
assert status == 200
assert json.loads(body)["error"]["code"] == -32700

status, _, body = request(
    "/mcp",
    payload=b'{}',
    content_type="text/plain",
)
assert status == 415
assert json.loads(body)["error"] == "unsupported_media_type"

print("MCP integration tests OK")
