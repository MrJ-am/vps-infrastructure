#!/usr/bin/env python3
"""Scénarios métier de Vision 2 sur HTTP avec une base isolée, jamais la production."""
import concurrent.futures,datetime as dt,json,os,unittest,urllib.request,urllib.error,uuid
ORIGINE='http://127.0.0.1:'+os.environ.get('VISION_DATABASE_TEST_PORT','39003')

def maintenant(jours=0):return (dt.datetime.now(dt.timezone.utc)+dt.timedelta(days=jours)).isoformat()
def identifiant():return uuid.uuid4().hex

def requete(chemin,p,utilisateur='alice',navigateur=False):
 entetes={'Content-Type':'application/json','X-Vision-Authenticated':'1'}
 if utilisateur is not None:entetes['X-Mrj-User']=utilisateur
 if navigateur:entetes['X-Vision-Browser']='1'
 r=urllib.request.Request(ORIGINE+chemin,data=json.dumps(p).encode(),headers=entetes)
 try:
  with urllib.request.urlopen(r,timeout=30) as s:return s.status,json.load(s)
 except urllib.error.HTTPError as e:return e.code,json.load(e)

def appel(nom,p,utilisateur='alice',ecriture=False):
 if ecriture:p={'cle':identifiant(),'emise_a':maintenant(),**p}
 code,r=requete('/api/v1/'+nom,p,utilisateur)
 if code!=200:raise AssertionError((code,r))
 return r

def fiche(titre='Fiche',priorite=0):return appel('enregistrer_fiche',dict(titre=titre,contenu='Contenu de référence.',priorite=priorite),ecriture=True)['fiche']
def item(titre='Item',**champs):
 titre=titre+' '+identifiant()[:8]
 r=appel('rechercher',dict(type='item',requete=titre,preparer_creation=True))
 candidats=[c['id'] for c in r['resultats']]
 for k in range(0,len(candidats),20):appel('lire',dict(type='item',ids=candidats[k:k+20],preuve_recherche=r['preuve_recherche']))
 return appel('enregistrer_item',dict(titre=titre,contenu='Réponse de référence.',objectifs=['Reconnaître et expliquer'],sens=['direct','inverse'],preuve_recherche=r['preuve_recherche'],distinction='Connaissance distincte pour ce scénario isolé.',**champs),ecriture=True)['item']
def lire(i):return appel('lire',dict(type='item',ids=[i['id']]))['objets'][0]
def evaluer(i,q,episode=None,version_episode=0,**champs):
 e=dict(item_id=i['id'],version=i['version'],episode=episode or identifiant(),version_episode=version_episode,q=q,sens='direct',aide='aucune',**champs)
 return appel('evaluer_items',dict(evaluations=[e]),ecriture=True)['evaluations'][0]

class Refonte(unittest.TestCase):
 def test_liste_items_sans_terme_et_mots_vides(self):
  item('Liste')
  for q in ('','et','le'):
   r=appel('rechercher',dict(type='item',requete=q))
   self.assertIn('resultats',r);self.assertEqual(r['politique']['intervalle_jours'],90)
 def test_independance_et_episodes(self):
  a=item('Erevan',reference_a=maintenant(-8));b=item('Bruxelles',reference_a=maintenant(-8))
  a2=evaluer(a,-3);b2=evaluer(b,2)
  self.assertEqual(lire(a)['stabilite'],-18);self.assertEqual(lire(b)['stabilite'],-13)
  precision=evaluer(b2['item'],3,episode=b2['episode'],version_episode=b2['version_episode'])
  self.assertEqual(precision['delta_applique'],1);self.assertEqual(precision['item']['stabilite'],-12)
  self.assertEqual(lire(a)['stabilite'],-18)
 def test_rejeu_conflit_et_atomique(self):
  i=item('Transaction',reference_a=maintenant(-8));j=item('Autre')
  e=dict(item_id=i['id'],version=i['version'],episode=identifiant(),version_episode=0,q=2,sens='direct',aide='aucune')
  p=dict(cle=identifiant(),emise_a=maintenant(),evaluations=[e])
  a=appel('evaluer_items',p);b=appel('evaluer_items',p)
  self.assertTrue(b['rejeu']);self.assertEqual(lire(i)['stabilite'],-13)
  p['evaluations'][0]['q']=3
  self.assertEqual(requete('/api/v1/evaluer_items',p)[0],409)
  e2={**e,'episode':identifiant(),'version':lire(i)['version'],'q':0}
  mauvais={**e,'item_id':j['id'],'version':999,'episode':identifiant()}
  p2=dict(cle=identifiant(),emise_a=maintenant(),evaluations=[e2,mauvais])
  self.assertEqual(requete('/api/v1/evaluer_items',p2)[0],409)
  self.assertEqual(lire(i)['version'],a['evaluations'][0]['item']['version'])
 def test_isolation_identites_et_transports(self):
  i=item('Privé')
  self.assertEqual(appel('lire',dict(type='item',ids=[i['id']]),'bob')['objets'],[])
  self.assertEqual(requete('/api/v1/lire',dict(type='item',ids=[i['id']]),None)[0],401)
  self.assertEqual(requete('/api/web/lire',dict(type='item',ids=[i['id']]))[0],401)
  code,r=requete('/api/web/lire',dict(type='item',ids=[i['id']]),navigateur=True)
  self.assertEqual(code,200);self.assertEqual(r['objets'][0]['id'],i['id'])
  p=dict(cle=identifiant(),emise_a=maintenant(),id=i['id'],version=i['version'],suivi='Intrusion')
  self.assertEqual(requete('/api/v1/enregistrer_item',p,'bob')[0],404)
 def test_edition_et_suivi_ne_reportent_pas_reference(self):
  i=item('Édition',reference_a=maintenant(-8));date=i['reference_a']
  j=appel('enregistrer_item',dict(id=i['id'],version=i['version'],suivi='Inverse encore à tester.'),ecriture=True)['item']
  self.assertEqual(j['reference_a'],date);self.assertEqual(j['evalue_a'],None)
  k=evaluer(j,0,type_evenement='suivi')['item'];self.assertEqual(k['reference_a'],date)
  self.assertEqual(k['suivi'],'Inverse encore à tester.')
 def test_dates_inconnues_aide_et_rapprochement(self):
  i=item('Date inconnue');r=evaluer(i,0,date_inconnue=True)
  self.assertIsNone(r['item']['evalue_a']);self.assertIsNone(r['item']['reference_a'])
  i=item('Rapproché');r=evaluer(i,1)
  p=dict(cle=identifiant(),emise_a=maintenant(),evaluations=[dict(item_id=i['id'],version=r['item']['version'],episode=identifiant(),version_episode=0,q=1,sens='direct',aide='aucune')])
  self.assertEqual(requete('/api/v1/evaluer_items',p)[1]['erreur'],'gain_rapproche_deja_applique')
  p['cle']=identifiant();p['evaluations'][0].update(q=2,aide='correction')
  self.assertEqual(requete('/api/v1/evaluer_items',p)[1]['erreur'],'gain_aide_excessif')
 def test_partage_priorite_et_detachement(self):
  i=item('Partagé',reference_a=maintenant(-8));f=fiche('Neutre');g=fiche('Prioritaire',3)
  for x in (f,g):
   r=appel('lier_item',dict(fiche_id=x['id'],version_fiche=x['version'],item_id=i['id'],action='rattacher'),ecriture=True);x.update(r['fiche'])
  a=appel('lire',dict(type='fiche',ids=[f['id']]))['objets'][0]['items'][0]['fenetre']
  b=appel('lire',dict(type='fiche',ids=[g['id']]))['objets'][0]['items'][0]['fenetre']
  self.assertAlmostEqual(float(a['intervalle_jours'])/float(b['intervalle_jours']),10**.3,places=9)
  self.assertEqual(len(lire(i)['fiches']),2)
  appel('lier_item',dict(fiche_id=f['id'],version_fiche=f['version'],item_id=i['id'],action='detacher'),ecriture=True)
  self.assertEqual(len(lire(i)['fiches']),1);self.assertEqual(lire(i)['stabilite'],-15)
 def test_recherche_prealable_courses_et_homonymes(self):
  nom='Institutionnalisation '+identifiant()[:8]
  r=appel('rechercher',dict(type='item',requete=nom,preparer_creation=True))
  p=dict(cle=identifiant(),emise_a=maintenant(),titre=nom,contenu='Contenu.',objectifs=['Expliquer'],sens=['direct'],preuve_recherche=r['preuve_recherche'],distinction='Sens distinct pour ce test isolé.')
  # Les candidats éventuels doivent être réellement lus.
  if r['resultats']:appel('lire',dict(type='item',ids=[c['id'] for c in r['resultats']],preuve_recherche=r['preuve_recherche']))
  q={**p,'cle':identifiant()}
  with concurrent.futures.ThreadPoolExecutor(2) as ex:rs=list(ex.map(lambda x:requete('/api/v1/enregistrer_item',x),[p,q]))
  self.assertEqual(sorted(x[0] for x in rs),[200,400])
  r2=appel('rechercher',dict(type='item',requete=nom,preparer_creation=True))
  q.update(cle=identifiant(),preuve_recherche=r2['preuve_recherche'])
  self.assertEqual(requete('/api/v1/enregistrer_item',q)[1]['erreur'],'lire_candidats')
  appel('lire',dict(type='item',ids=[c['id'] for c in r2['resultats']],preuve_recherche=r2['preuve_recherche']))
  self.assertTrue(appel('enregistrer_item',q)['enregistre'])
 def test_contrat_mcp_et_ancien_client(self):
  def rpc(m,p):return requete('/mcp',dict(jsonrpc='2.0',id=1,method=m,params=p))[1]
  init=rpc('initialize',{})['result'];self.assertIn('Calibrage db-1',init['instructions']);self.assertIn('attendre',init['instructions'])
  outils=rpc('tools/list',{'_meta':{}})['result']['tools'];self.assertEqual(len(outils),9)
  r=rpc('tools/call',dict(name='record_review',arguments=dict(sheetId=1,rating=3)))
  self.assertEqual(r['result']['structuredContent']['erreur'],'contrat_retire')
  f=fiche();r=rpc('tools/call',dict(name='preparer_revision',arguments=dict(fiche_id=f['id'])))
  self.assertNotIn('usage_assistant',r['result']['content'][0]['text'])
 def test_recherche_creation_ignore_filtre_local(self):
  i=item('Global');f=fiche('Fiche vide')
  r=appel('rechercher',dict(type='item',requete=i['titre'],fiche_id=f['id'],preparer_creation=True))
  self.assertIn(i['id'],[c['id'] for c in r['resultats']])
 def test_contexte_versionne(self):
  f=fiche();i=item('Contexte');conv=identifiant()
  p=dict(conversation=conv,version=0,fiche_id=f['id'],items=[i['id']],reprise='Demander le sens inverse sans indice.',questions=[])
  c=appel('enregistrer_contexte',p,ecriture=True)['contexte']
  r=appel('preparer_revision',dict(conversation=conv))
  self.assertEqual(r['contexte']['version'],c['version'])
  self.assertIsNone(appel('preparer_revision',dict(conversation=conv),'bob')['contexte'])

if __name__=='__main__':unittest.main(verbosity=2)
