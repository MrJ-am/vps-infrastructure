#!/usr/bin/env python3
"""Scénarios métier de Vision 2 sur HTTP avec une base isolée, jamais la production."""
import concurrent.futures,datetime as dt,json,os,unittest,urllib.request,urllib.error,uuid
ORIGINE='http://127.0.0.1:'+os.environ.get('VISION_DATABASE_TEST_PORT','39003')

def maintenant(jours=0):return (dt.datetime.now(dt.timezone.utc)+dt.timedelta(days=jours)).isoformat()
def identifiant():return uuid.uuid4().hex

def requete(chemin,p,utilisateur='alice',navigateur=False):
 entetes={'Content-Type':'application/json','X-Vision-Authenticated':'1'}
 if utilisateur is not None:entetes['X-Mrj-User']=utilisateur
 if navigateur:entetes['X-Vision-Browser']='1'
 r=urllib.request.Request(ORIGINE+chemin,data=json.dumps(p).encode(),headers=entetes)
 try:
  with urllib.request.urlopen(r,timeout=30) as s:return s.status,json.load(s)
 except urllib.error.HTTPError as e:return e.code,json.load(e)

def appel(nom,p,utilisateur='alice',ecriture=False):
 if ecriture:p={'cle':identifiant(),'emise_a':maintenant(),**p}
 code,r=requete('/api/v1/'+nom,p,utilisateur)
 if code!=200:raise AssertionError((code,r))
 return r

def fiche(titre='Fiche',priorite=0):return appel('enregistrer_fiche',dict(titre=titre,contenu='Contenu de référence.',priorite=priorite),ecriture=True)['fiche']
def item(titre='Item',**champs):
 contenu=titre+' '+identifiant()[:8]+' est une connaissance de référence autonome.'
 r=appel('rechercher',dict(type='item',requete=contenu,preparer_creation=True))
 candidats=[c['id'] for c in r['resultats']]
 for k in range(0,len(candidats),20):appel('lire',dict(type='item',ids=candidats[k:k+20],preuve_recherche=r['preuve_recherche']))
 return appel('enregistrer_item',dict(contenu=contenu,preuve_recherche=r['preuve_recherche'],distinction='Connaissance distincte pour ce scénario isolé.',**champs),ecriture=True)['item']
def lire(i):return appel('lire',dict(type='item',ids=[i['id']]))['objets'][0]
def evaluer(i,q,episode=None,version_episode=0,**champs):
 e=dict(item_id=i['id'],version=i['version'],episode=episode or identifiant(),version_episode=version_episode,q=q,sens='direct',aide='aucune',**champs)
 return appel('evaluer_items',dict(evaluations=[e]),ecriture=True)['evaluations'][0]

class Refonte(unittest.TestCase):
 def test_liste_items_sans_terme_et_mots_vides(self):
  item('Liste')
  for q in ('','et','le'):
   r=appel('rechercher',dict(type='item',requete=q))
   self.assertIn('resultats',r);self.assertEqual(r['politique']['intervalle_jours'],90)
 def test_independance_et_episodes(self):
  a=item('Erevan',reference_a=maintenant(-8));b=item('Bruxelles',reference_a=maintenant(-8))
  a2=evaluer(a,-3);b2=evaluer(b,2)
  self.assertEqual(lire(a)['stabilite'],-18);self.assertEqual(lire(b)['stabilite'],-13)
  precision=evaluer(b2['item'],3,episode=b2['episode'],version_episode=b2['version_episode'])
  self.assertEqual(precision['delta_applique'],1);self.assertEqual(precision['item']['stabilite'],-12)
  self.assertEqual(lire(a)['stabilite'],-18)
 def test_rejeu_conflit_et_atomique(self):
  i=item('Transaction',reference_a=maintenant(-8));j=item('Autre')
  e=dict(item_id=i['id'],version=i['version'],episode=identifiant(),version_episode=0,q=2,sens='direct',aide='aucune')
  p=dict(cle=identifiant(),emise_a=maintenant(),evaluations=[e])
  a=appel('evaluer_items',p);b=appel('evaluer_items',p)
  self.assertTrue(b['rejeu']);self.assertEqual(lire(i)['stabilite'],-13)
  p['evaluations'][0]['q']=3
  self.assertEqual(requete('/api/v1/evaluer_items',p)[0],409)
  e2={**e,'episode':identifiant(),'version':lire(i)['version'],'q':0}
  mauvais={**e,'item_id':j['id'],'version':999,'episode':identifiant()}
  p2=dict(cle=identifiant(),emise_a=maintenant(),evaluations=[e2,mauvais])
  self.assertEqual(requete('/api/v1/evaluer_items',p2)[0],409)
  self.assertEqual(lire(i)['version'],a['evaluations'][0]['item']['version'])
 def test_isolation_identites_et_transports(self):
  i=item('Privé')
  self.assertEqual(appel('lire',dict(type='item',ids=[i['id']]),'bob')['objets'],[])
  self.assertEqual(requete('/api/v1/lire',dict(type='item',ids=[i['id']]),None)[0],401)
  self.assertEqual(requete('/api/web/lire',dict(type='item',ids=[i['id']]))[0],401)
  code,r=requete('/api/web/lire',dict(type='item',ids=[i['id']]),navigateur=True)
  self.assertEqual(code,200);self.assertEqual(r['objets'][0]['id'],i['id'])
  p=dict(cle=identifiant(),emise_a=maintenant(),id=i['id'],version=i['version'],contenu='Intrusion')
  self.assertEqual(requete('/api/v1/enregistrer_item',p,'bob')[0],404)
 def test_edition_et_observation_ne_reportent_pas_reference(self):
  i=item('Édition',reference_a=maintenant(-8));date=i['reference_a']
  j=appel('enregistrer_item',dict(id=i['id'],version=i['version'],contenu='Édition : connaissance reformulée.'),ecriture=True)['item']
  self.assertEqual(j['reference_a'],date);self.assertEqual(j['evalue_a'],None)
  appel('ajouter_observation',dict(objet='item',objet_id=i['id'],texte='Inverse encore à tester.'),ecriture=True)
  self.assertEqual(lire(j)['reference_a'],date)
  self.assertEqual(lire(j)['observations'][-1]['texte'],'Inverse encore à tester.')
 def test_dates_inconnues_aide_et_rapprochement(self):
  i=item('Date inconnue');r=evaluer(i,0,date_inconnue=True)
  self.assertIsNone(r['item']['evalue_a']);self.assertIsNone(r['item']['reference_a'])
  i=item('Rapproché');r=evaluer(i,1)
  p=dict(cle=identifiant(),emise_a=maintenant(),evaluations=[dict(item_id=i['id'],version=r['item']['version'],episode=identifiant(),version_episode=0,q=1,sens='direct',aide='aucune')])
  self.assertEqual(requete('/api/v1/evaluer_items',p)[1]['erreur'],'gain_rapproche_deja_applique')
  p['cle']=identifiant();p['evaluations'][0].update(q=2,aide='correction')
  self.assertEqual(requete('/api/v1/evaluer_items',p)[1]['erreur'],'gain_aide_excessif')
 def test_partage_priorite_et_detachement(self):
  i=item('Partagé',reference_a=maintenant(-8));f=fiche('Neutre');g=fiche('Prioritaire',3)
  for x in (f,g):
   r=appel('lier_item',dict(fiche_id=x['id'],version_fiche=x['version'],item_id=i['id'],action='rattacher'),ecriture=True);x.update(r['fiche'])
  a=appel('lire',dict(type='fiche',ids=[f['id']]))['objets'][0]['items'][0]['fenetre']
  b=appel('lire',dict(type='fiche',ids=[g['id']]))['objets'][0]['items'][0]['fenetre']
  self.assertAlmostEqual(float(a['intervalle_jours'])/float(b['intervalle_jours']),10**.3,places=9)
  self.assertEqual(len(lire(i)['fiches']),2)
  appel('lier_item',dict(fiche_id=f['id'],version_fiche=f['version'],item_id=i['id'],action='detacher'),ecriture=True)
  self.assertEqual(len(lire(i)['fiches']),1);self.assertEqual(lire(i)['stabilite'],-15)
 def test_recherche_prealable_courses_et_homonymes(self):
  nom='Institutionnalisation '+identifiant()[:8]
  r=appel('rechercher',dict(type='item',requete=nom,preparer_creation=True))
  p=dict(cle=identifiant(),emise_a=maintenant(),contenu=nom,preuve_recherche=r['preuve_recherche'],distinction='Sens distinct pour ce test isolé.')
  # Les candidats éventuels doivent être réellement lus.
  if r['resultats']:appel('lire',dict(type='item',ids=[c['id'] for c in r['resultats']],preuve_recherche=r['preuve_recherche']))
  q={**p,'cle':identifiant()}
  with concurrent.futures.ThreadPoolExecutor(2) as ex:rs=list(ex.map(lambda x:requete('/api/v1/enregistrer_item',x),[p,q]))
  self.assertEqual(sorted(x[0] for x in rs),[200,400])
  r2=appel('rechercher',dict(type='item',requete=nom,preparer_creation=True))
  q.update(cle=identifiant(),preuve_recherche=r2['preuve_recherche'])
  self.assertEqual(requete('/api/v1/enregistrer_item',q)[1]['erreur'],'lire_candidats')
  appel('lire',dict(type='item',ids=[c['id'] for c in r2['resultats']],preuve_recherche=r2['preuve_recherche']))
  self.assertTrue(appel('enregistrer_item',q)['enregistre'])
 def test_item_autonome_sans_metadonnees_de_fiche(self):
  i=item('Lisbonne est la capitale du Portugal')
  for champ in ('titre','objectifs','sens','suivi'):
   self.assertNotIn(champ,lire(i))
   self.assertEqual(requete('/api/v1/enregistrer_item',dict(cle=identifiant(),emise_a=maintenant(),id=i['id'],version=i['version'],**{champ:'bruit' if champ in ('titre','suivi') else ['bruit']}))[0],400)
  f=fiche('Capitales européennes')
  f=appel('lier_item',dict(fiche_id=f['id'],version_fiche=f['version'],item_id=i['id'],action='rattacher'),ecriture=True)['fiche']
  s=appel('ouvrir_seance',dict(fiche_id=f['id']),ecriture=True)
  self.assertEqual(s['usage_assistant']['items'][0]['contenu'],i['contenu'])
  self.assertTrue(all(champ not in s['usage_assistant']['items'][0] for champ in ('titre','objectifs','sens','suivi')))
  appel('clore_seance',dict(seance_id=s['seance_id'],evaluations=[],deroulement=[],
    retour=dict(difficulte='non_indiquee',reformulations=[],ajouts=[])),ecriture=True)
 def test_fermeture_fenetre_prioritaire_et_nouveaux_en_complement(self):
  f=fiche('Ordre des échéances')
  tard=item('Fenêtre tardive',reference_a=maintenant(-5))
  tot=item('Fenêtre proche',reference_a=maintenant(-8))
  neuf=item('Connaissance nouvelle')
  for i in (tard,tot,neuf):
   f=appel('lier_item',dict(fiche_id=f['id'],version_fiche=f['version'],item_id=i['id'],action='rattacher'),ecriture=True)['fiche']
  s=appel('ouvrir_seance',dict(fiche_id=f['id'],nombre_questions=1),ecriture=True)
  self.assertEqual([i['id'] for i in s['usage_assistant']['items']],[tot['id']])
  self.assertEqual(s['usage_assistant']['fiche']['titre'],f['titre'])
  self.assertIn('observations',s['usage_assistant']['fiche'])
  appel('clore_seance',dict(seance_id=s['seance_id'],evaluations=[],deroulement=[],
    retour=dict(difficulte='non_indiquee',reformulations=[],ajouts=[])),ecriture=True)
 def test_liens_filtrables_et_retard_de_revision(self):
  f=fiche('Fenêtres filtrables '+identifiant()[:6])
  retard=item('Connaissance échue',reference_a=maintenant(-12))
  dans=item('Connaissance dans la fenêtre',reference_a=maintenant(-3))
  nouveau=item('Connaissance sans départ')
  for i in (nouveau,dans,retard):
   f=appel('lier_item',dict(fiche_id=f['id'],version_fiche=f['version'],item_id=i['id'],action='rattacher'),ecriture=True)['fiche']
  def liens(filtre,tri='echeance',decalage=0):
   return appel('lire',dict(type='fiche',ids=[f['id']],filtre_liens=filtre,tri_liens=tri,limite=1,decalage=decalage))['objets'][0]
  premiere=liens('tous')
  self.assertEqual(premiere['items'][0]['id'],retard['id'])
  self.assertNotIn('titre',premiere['items'][0])
  self.assertEqual(liens('retard')['nombre_items_filtres'],1)
  self.assertEqual(liens('retard')['items'][0]['id'],retard['id'])
  self.assertEqual(liens('dans_fenetre')['items'][0]['id'],dans['id'])
  self.assertEqual(liens('nouveau')['items'][0]['id'],nouveau['id'])
  self.assertEqual(liens('tous','alphabetique')['items'][0]['id'],dans['id'])
  self.assertEqual(liens('tous','alphabetique',1)['items'][0]['id'],retard['id'])
  suggestions=appel('preparer_revision',dict(limite=20))
  entree=next(x for x in suggestions['suggestions'] if x['fiche_id']==f['id'])
  self.assertGreaterEqual(entree['nombre_en_retard'],1)
  self.assertGreaterEqual(suggestions['total_en_retard'],1)
  self.assertIn('en retard',suggestions['message_retard'])

 def test_contrat_mcp_et_ancien_client(self):
  def rpc(m,p):return requete('/mcp',dict(jsonrpc='2.0',id=1,method=m,params=p))[1]
  attendus=['rechercher','lire','preparer_revision','lister_seances','lire_seance','ouvrir_seance','clore_seance','enregistrer_fiche','enregistrer_item',
           'lier_item','evaluer_items','ajouter_observation','enregistrer_contexte','regler_politique']
  anciens=['search_memory_sheets','list_due_memory_sheets','get_memory_sheet',
          'save_memory_sheet','record_review']
  init=rpc('initialize',{})['result']
  self.assertEqual(init['serverInfo']['version'],'2.4.1')
  self.assertIn('Calibrage db-1',init['instructions'])
  self.assertIn('clore_seance',init['instructions'])
  outils=rpc('tools/list',{'_meta':{}})['result']['tools']
  self.assertEqual([o['name'] for o in outils],attendus)
  self.assertEqual(outils,json.load(open('docs/outils.json',encoding='utf-8')))
  self.assertTrue(all(o['inputSchema']['additionalProperties'] is False for o in outils))
  for ancien in anciens:
   self.assertNotIn(ancien,attendus)
   r=rpc('tools/call',dict(name=ancien,arguments=dict(sheetId=1,rating=3)))
   self.assertEqual(r['result']['structuredContent']['erreur'],'contrat_retire')
   self.assertTrue(r['result']['isError'])
   self.assertIn('configuration du connecteur',r['result']['content'][0]['text'])
  f=fiche('Révision compatible')
  trouve=rpc('tools/call',dict(name='rechercher',arguments=dict(type='fiche',requete='Révision compatible')))
  self.assertIn(f['id'],[x['id'] for x in trouve['result']['structuredContent']['resultats']])
  f=fiche();r=rpc('tools/call',dict(name='preparer_revision',arguments=dict(fiche_id=f['id'])))
  self.assertNotIn('usage_assistant',r['result']['content'][0]['text'])
 def test_recherche_creation_ignore_filtre_local(self):
  i=item('Global');f=fiche('Fiche vide')
  r=appel('rechercher',dict(type='item',requete=i['contenu'],fiche_id=f['id'],preparer_creation=True))
  self.assertIn(i['id'],[c['id'] for c in r['resultats']])
 def test_seance_lot_retour_et_transaction(self):
  f=fiche('Capitales en séance');a=item('Erevan');b=item('Bratislava')
  for i in (a,b):
   f=appel('lier_item',dict(fiche_id=f['id'],version_fiche=f['version'],item_id=i['id'],action='rattacher'),ecriture=True)['fiche']
  self.assertEqual(requete('/api/v1/preparer_revision',dict(fiche_id=f['id']))[1]['erreur'],'utiliser_ouvrir_seance')
  premiere=appel('ouvrir_seance',dict(fiche_id=f['id'],limite=8,conversation=identifiant()),ecriture=True)
  self.assertEqual(premiere['nombre_questions'],2)
  self.assertEqual(len(premiere['usage_assistant']['items']),2)
  self.assertEqual(lire(a)['version'],a['version'])
  attente=appel('preparer_revision',{})
  self.assertIn(premiere['seance_id'],[x['id'] for x in attente['seances_en_attente']])
  avertissement=appel('ouvrir_seance',dict(fiche_id=f['id']),ecriture=True)
  self.assertTrue(avertissement['confirmation_requise'])
  seconde=appel('ouvrir_seance',dict(fiche_id=f['id'],nouvelle_seance=True),ecriture=True)
  self.assertNotEqual(seconde['seance_id'],premiere['seance_id'])
  evaluations=[dict(item_id=i['id'],version=i['version'],episode=identifiant(),version_episode=0,
                    q=0,sens='direct',aide='aucune') for i in (a,b)]
  retour=dict(difficulte='adaptee',commentaire='Un peu long.',reformulations=[dict(item_id=a['id'],suggestion='Clarifier la question.')],ajouts=['Une autre capitale'])
  deroulement=[dict(item_id=i['id'],question='Quelle est la capitale ?',etat='tente',reponse='Réponse donnée.',correction='Correction donnée.',aide='aucune') for i in (a,b)]
  p=dict(cle=identifiant(),emise_a=maintenant(),seance_id=premiere['seance_id'],evaluations=evaluations,deroulement=deroulement,retour=retour,synthese='Deux réponses tentées.')
  mauvais={**p,'cle':identifiant(),'evaluations':[{**evaluations[0],'version':999},evaluations[1]]}
  self.assertEqual(requete('/api/v1/clore_seance',mauvais)[0],409)
  self.assertEqual(lire(b)['version'],b['version'])
  rapport=appel('clore_seance',p)['rapport']
  self.assertEqual(rapport['tentatives_enregistrees'],2)
  self.assertEqual(rapport['retour'],retour)
  self.assertEqual(rapport['deroulement'],deroulement)
  self.assertEqual(len(rapport['propositions_en_attente']['ajouts']),1)
  self.assertTrue(appel('clore_seance',p)['rejeu'])
  self.assertNotIn(premiere['seance_id'],[x['id'] for x in appel('preparer_revision',{})['seances_en_attente']])
  self.assertEqual(lire(a)['version'],a['version']+1)
  self.assertEqual(lire(b)['version'],b['version']+1)
  hors={**p,'cle':identifiant(),'seance_id':seconde['seance_id'],'evaluations':[{**evaluations[0],'item_id':item('Hors séance')['id']}]}
  self.assertEqual(requete('/api/v1/clore_seance',hors)[1]['erreur'],'item_hors_seance')
 def test_observations_transversales_et_choix_du_nombre(self):
  f=fiche('Capitales et questions variées');autre=fiche('Repères partagés')
  items=[]
  for n in range(4):
   i=item('Capitale vérifiable '+str(n),reference_a=maintenant(-8))
   i=evaluer(i,0,evenement_a=maintenant(-7))['item']
   f=appel('lier_item',dict(fiche_id=f['id'],version_fiche=f['version'],
      item_id=i['id'],action='rattacher'),ecriture=True)['fiche']
   items.append(i)
  autre=appel('lier_item',dict(fiche_id=autre['id'],version_fiche=autre['version'],
    item_id=items[0]['id'],action='rattacher'),ecriture=True)['fiche']
  original=items[0]['stabilite'];reference=items[0]['reference_a']
  obs=appel('ajouter_observation',dict(objet='item',objet_id=items[0]['id'],
    texte='Confusion répétée avec une autre capitale.'),ecriture=True)['observation']
  rectification=appel('ajouter_observation',dict(objet='item',objet_id=items[0]['id'],
    texte='Confusion observée une seule fois, à vérifier.',rectifie_id=obs['id']),ecriture=True)['observation']
  appel('ajouter_observation',dict(objet='fiche',objet_id=f['id'],
    texte='Vérifier les liens entre régions voisines.'),ecriture=True)
  lu=lire(items[0]);self.assertEqual(lu['stabilite'],original)
  self.assertEqual(lu['reference_a'],reference)
  self.assertEqual([o['id'] for o in lu['observations'][-2:]],[obs['id'],rectification['id']])
  self.assertEqual(rectification['rectifie_id'],obs['id'])
  self.assertEqual([o['id'] for o in appel('lire',dict(type='item',ids=[items[0]['id']]))['objets'][0]['observations'][-2:]],
    [obs['id'],rectification['id']])
  choix=appel('ouvrir_seance',dict(fiche_id=f['id'],limite=2,nouvelle_seance=True),ecriture=True)
  self.assertTrue(choix['choix_nombre_requis']);self.assertFalse(choix['enregistre'])
  self.assertEqual(choix['nombre_items_a_reviser'],4)
  r=appel('ouvrir_seance',dict(fiche_id=f['id'],limite=2,nombre_questions=3,nouvelle_seance=True),ecriture=True)
  self.assertEqual(r['nombre_questions'],3)
  self.assertEqual(len(r['usage_assistant']['items']),3)
  self.assertEqual(len(r['usage_assistant']['fiche']['observations']),1)
  question=r['usage_assistant']['items'][0]
  self.assertIn('observations',question)
  p=dict(seance_id=r['seance_id'],evaluations=[],deroulement=[
    dict(item_id=question['id'],question='Question formulée dans un sens nouveau ?',
      etat='saute',observation='Le sens inverse reste à travailler.')],
    retour=dict(difficulte='non_indiquee',reformulations=[],ajouts=[]),
    observation_fiche='Relier les pays voisins dans une prochaine séance.')
  fermeture=appel('clore_seance',p,ecriture=True)
  self.assertTrue(fermeture['enregistre'])
  self.assertEqual(lire(question)['observations'][-1]['details']['question'],p['deroulement'][0]['question'])
  self.assertIsNone(lire(question)['observations'][-1]['evenement_a'])
  self.assertEqual(len(appel('lire',dict(type='fiche',ids=[f['id']]))['objets'][0]['observations']),2)
 def test_contexte_versionne(self):
  f=fiche();i=item('Contexte');conv=identifiant()
  p=dict(conversation=conv,version=0,fiche_id=f['id'],items=[i['id']],reprise='Demander le sens inverse sans indice.',questions=[])
  c=appel('enregistrer_contexte',p,ecriture=True)['contexte']
  r=appel('preparer_revision',dict(conversation=conv))
  self.assertEqual(r['contexte']['version'],c['version'])
  self.assertIsNone(appel('preparer_revision',dict(conversation=conv),'bob')['contexte'])

 def test_zz_seances_multiples_reprise_et_gain_borne(self):
  f=fiche('Séances récupérables');i=item('Gain rapproché')
  f=appel('lier_item',dict(fiche_id=f['id'],version_fiche=f['version'],item_id=i['id'],action='rattacher'),ecriture=True)['fiche']
  initial=appel('lister_seances',dict(limite=1))['total']
  premiere=appel('ouvrir_seance',dict(fiche_id=f['id'],nouvelle_seance=initial>0),ecriture=True)
  self.assertTrue(appel('ouvrir_seance',dict(fiche_id=f['id']),ecriture=True)['confirmation_requise'])
  autre=appel('ouvrir_seance',dict(fiche_id=f['id'],nouvelle_seance=True),ecriture=True)
  for _ in range(29):
   appel('ouvrir_seance',dict(fiche_id=f['id'],nouvelle_seance=True),ecriture=True)
  page=appel('lister_seances',dict(limite=20,decalage=0))
  suite=appel('lister_seances',dict(limite=20,decalage=20))
  self.assertEqual(page['total'],initial+31)
  self.assertTrue(page['suite'])
  self.assertEqual(len(page['seances'])+len(suite['seances']),min(40,initial+31))
  self.assertEqual(len({s['id'] for s in page['seances']+suite['seances']}),len(page['seances'])+len(suite['seances']))
  self.assertTrue(any(s['theme']=='Séances récupérables' and s['cree_a'] for s in page['seances']))
  self.assertEqual(appel('lister_seances',{},'bob')['total'],0)
  self.assertEqual(requete('/api/v1/lire_seance',dict(seance_id=premiere['seance_id']),'bob'),(404,{'erreur':'seance_introuvable'}))
  reprise=appel('lire_seance',dict(seance_id=premiere['seance_id']))
  self.assertEqual(reprise['seance']['theme'],'Séances récupérables')
  self.assertIsNone(reprise['rapport'])
  self.assertEqual(reprise['usage_assistant']['items'][0]['id'],i['id'])
  retour=dict(difficulte='non_indiquee',reformulations=[],ajouts=[])
  def clore(seance,q):
   e=dict(item_id=i['id'],version=i['version'],episode=identifiant(),version_episode=0,q=q,sens='direct',aide='aucune')
   d=dict(item_id=i['id'],question='Quelle réponse ?',etat='tente',reponse='Réponse donnée.')
   return appel('clore_seance',dict(seance_id=seance['seance_id'],evaluations=[e],deroulement=[d],retour=retour),ecriture=True)['rapport']
  premier=clore(premiere,3)
  self.assertEqual(premier['evaluations_demandees'][0]['q'],3)
  self.assertEqual(premier['evaluations'][0]['q_cumulatif'],1)
  self.assertEqual(premier['ajustements'][0]['motif'],'gain_rapproche_limite')
  second=clore(autre,4)
  self.assertEqual(second['evaluations'][0]['q_cumulatif'],0)
  self.assertEqual(second['ajustements'][0]['version_appliquee'],lire(i)['version']-1)
  self.assertEqual(lire(i)['stabilite'],-14)
  encore=appel('lister_seances',{})
  self.assertEqual(encore['total'],initial+29)
  abandon=encore['seances'][0]
  resultat=appel('clore_seance',dict(seance_id=abandon['id'],evaluations=[],deroulement=[],retour=retour),ecriture=True)
  self.assertEqual(resultat['rapport']['tentatives_enregistrees'],0)
  self.assertEqual(appel('lister_seances',{})['total'],initial+28)

if __name__=='__main__':unittest.main(verbosity=2)