#!/usr/bin/env python3
"""Vérifie le catalogue réellement exposé à un client Vision.

L'entrée est un export JSON des outils visibles dans le client, et non la réponse
du serveur à tools/list : ces deux catalogues peuvent diverger durablement.
"""
import json
import sys
from pathlib import Path

RACINE = Path(__file__).resolve().parents[1]
ATTENDUS = json.loads((RACINE / 'docs/outils.json').read_text(encoding='utf-8'))


def verifier(document):
    outils = document['tools'] if isinstance(document, dict) else document
    noms_attendus = [outil['name'] for outil in ATTENDUS]
    noms = [outil['name'] for outil in outils]
    if noms != noms_attendus:
        absents = sorted(set(noms_attendus) - set(noms))
        anciens = sorted(set(noms) - set(noms_attendus))
        raise AssertionError(
            f'Catalogue client périmé : absents={absents}, inattendus={anciens}. '
            'Mettre à jour la définition du connecteur, puis vérifier son catalogue réel.'
        )
    for reel, attendu in zip(outils, ATTENDUS):
        for champ in ('description', 'inputSchema'):
            if reel.get(champ) != attendu[champ]:
                raise AssertionError(f'{reel["name"]} : {champ} diffère du contrat servi')


if __name__ == '__main__':
    if len(sys.argv) != 2:
        raise SystemExit('Usage : check_client_catalog.py catalogue-client.json')
    verifier(json.loads(Path(sys.argv[1]).read_text(encoding='utf-8')))
    print('Catalogue du client conforme au serveur Vision 2')
