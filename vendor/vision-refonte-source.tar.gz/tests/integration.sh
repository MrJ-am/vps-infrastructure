#!/bin/sh
set -eu

cd -- "$(dirname -- "$0")/.."

port="${VISION_TEST_PORT:-39001}"
temporary="$(mktemp -d)"
server_pid=""
cleanup() {
  if [ -n "$server_pid" ]; then
    kill "$server_pid" 2>/dev/null || true
    wait "$server_pid" 2>/dev/null || true
  fi
  rm -rf -- "$temporary"
  rm -f -- vision
}
trap cleanup EXIT INT TERM

mkdir -p "$temporary/bin"
cp tests/fake-psql.sh "$temporary/bin/psql"
chmod 0755 "$temporary/bin/psql"

sh build.sh
PATH="$temporary/bin:$PATH" IP=127.0.0.1 PORT="$port" VISION_VERSION=1.2.0 \
  VISION_DOCUMENT_ROOT="$PWD/docs" ./vision >"$temporary/server.log" 2>&1 &
server_pid=$!

for _attempt in $(seq 1 50); do
  if curl --fail --silent --max-time 1 \
      "http://127.0.0.1:$port/healthz" >"$temporary/health.json"; then
    break
  fi
  sleep 0.1
done

grep -qx '{"status":"ok","version":"1.2.0"}' "$temporary/health.json"

status="$(curl --silent --output "$temporary/unauthorized.json" --write-out '%{http_code}' \
  "http://127.0.0.1:$port/api/v1/health")"
test "$status" = 401
grep -q 'authentication_required' "$temporary/unauthorized.json"

curl --fail --silent --header 'X-Vision-Authenticated: 1' \
  "http://127.0.0.1:$port/api/v1/capabilities" \
  >"$temporary/capabilities.json"
grep -q 'getVisionCapabilities' "$temporary/capabilities.json"

curl --fail --silent --request POST --header 'X-Vision-Authenticated: 1' \
  "http://127.0.0.1:$port/api/v1/hello" >"$temporary/hello.json"
grep -qx '{"message":"World"}' "$temporary/hello.json"

curl --fail --silent --header 'X-Vision-Authenticated: 1' \
  "http://127.0.0.1:$port/api/v1/mobile-live-test" \
  >"$temporary/mobile-live-test.json"
grep -q 'VISION-MOBILE-LIVE-AUTH-OK' "$temporary/mobile-live-test.json"
grep -q '"scope":"test-only"' "$temporary/mobile-live-test.json"

curl --fail --silent "http://127.0.0.1:$port/openapi.json" \
  >"$temporary/openapi.json"
cmp docs/openapi.json "$temporary/openapi.json"

curl --fail --silent \
  "http://127.0.0.1:$port/mobile-live-test-openapi.json" \
  >"$temporary/mobile-live-test-openapi.json"
cmp docs/mobile-live-test-openapi.json \
  "$temporary/mobile-live-test-openapi.json"

status="$(curl --silent --output "$temporary/not-found.json" --write-out '%{http_code}' \
  --header 'X-Vision-Authenticated: 1' \
  "http://127.0.0.1:$port/api/v1/does-not-exist")"
test "$status" = 404

VISION_TEST_PORT="$port" python3 tests/check_mcp.py

echo 'HTTP integration tests OK'
