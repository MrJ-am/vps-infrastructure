#!/usr/bin/env python3
"""Contrats MCP et OpenAPI générés depuis une seule définition française."""
import json
from pathlib import Path
RACINE=Path(__file__).resolve().parent.parent

def texte(maximum=4000, **kw):return dict(type='string',maxLength=maximum,**kw)
def entier(minimum=0,maximum=2147483647,**kw):return dict(type='integer',minimum=minimum,maximum=maximum,**kw)
def tableau(elements,maximum=50,minimum=0):return dict(type='array',items=elements,minItems=minimum,maxItems=maximum)
def objet(proprietes=None,obligatoires=(),libre=False):return dict(type='object',properties=proprietes or {},required=list(obligatoires),additionalProperties=libre)
def choix(*valeurs):return texte(40,enum=list(valeurs))
def date():return texte(40,format='date-time')
def nullable(schema):return {**schema,'type':[schema['type'],'null']}
BOOLEEN={'type':'boolean'}
ID=entier(1)
COMMUN={'cle':texte(100,minLength=8,description='Clé stable pour tous les rejeux du même enregistrement ; ne pas la changer après un délai réseau.'),'emise_a':date()}
SORTIE_COMMUNE={'erreur':texte(100),'enregistre':BOOLEEN,'rejeu':BOOLEEN,'maintenant':date(),'politique':objet(libre=True)}
OUTILS=[]
def outil(nom,titre,description,proprietes,obligatoires,sortie,ecriture=False):
 if ecriture:proprietes={**COMMUN,**proprietes};obligatoires=['cle','emise_a',*obligatoires]
 OUTILS.append(dict(name=nom,title=titre,description=description,inputSchema=objet(proprietes,obligatoires),outputSchema=objet({**SORTIE_COMMUNE,**sortie}),annotations=dict(readOnlyHint=not ecriture,destructiveHint=False,idempotentHint=True,openWorldHint=False)))

outil('rechercher','Rechercher des fiches et des items',
 'Recherche paginée. Avant CHAQUE création d’item : type=item, requete=intitulé envisagé, preparer_creation=true. Cette recherche globale inclut les archives et renvoie au plus 50 candidats et une preuve, valable 30 minutes. Lire TOUS ces candidats avec lire et la preuve. Si aucun jeton n’est retourné ou s’il reste une page, préciser la recherche ; ne pas conclure à une absence. Même connaissance : réutiliser et lier. Les homonymes distincts exigent une distinction explicite. La préparation écrit uniquement une preuve technique temporaire.',
 {'type':choix('fiche','item'),'requete':texte(200),'tags':tableau(texte(64)),'etat':choix('actif','archive','tous'),'tri':choix('titre','priorite','stabilite','modification'),'limite':entier(1,50),'decalage':entier(0,1000000),'fiche_id':ID,'preparer_creation':BOOLEEN},['type','requete'],
 {'resultats':tableau(objet(libre=True)),'total':entier(),'limite':entier(),'decalage':entier(),'suite':BOOLEEN,'preuve_recherche':nullable(texte(40))})
outil('lire','Lire les objets utiles',
 'Lire jusqu’à 20 fiches ou items ciblés avec contenu, suivi, versions et relations. Les relations d’une fiche sont paginées ; nombre_items indique le total. Pour examiner des doublons, fournir la preuve de rechercher. En révision, garder ces données comme contexte : ne pas afficher les réponses ou les titres révélateurs avant la question.',
 {'type':choix('fiche','item'),'ids':tableau(ID,20,1),'limite':entier(1,50),'decalage':entier(0,1000000),'preuve_recherche':texte(40)},['type','ids'],{'objets':tableau(objet(libre=True),20)})
outil('preparer_revision','Préparer une révision ou des suggestions',
 'Avec fiche_id, renvoyer exactement UN item dans usage_assistant.items, même si limite>1 : poser UNE question puis attendre. Après CHAQUE tentative, appeler evaluer_items avant toute autre question ; rappeler preparer_revision pour obtenir le seul item suivant. Ne jamais demander ni conserver une liste d’items pour poursuivre seul. Sans fiche_id, suggérer des fiches depuis les items distincts. conversation retrouve un contexte minimal de reprise, jamais l’historique privé du client. exclus évite des répétitions ; repeter ne sert qu’à une répétition explicitement pertinente. Une fenêtre dépassée ne prouve pas l’oubli.',
 {'fiche_id':ID,'conversation':texte(100,minLength=1),'limite':entier(1,20),'exclus':tableau(ID,20),'repeter':BOOLEEN},[],
 {'usage_assistant':objet(libre=True),'suggestions':tableau(objet(libre=True),20),'contexte':nullable(objet(libre=True)),'consigne':texte(),'message':texte()})
outil('enregistrer_fiche','Créer ou modifier une fiche',
 'Création seulement sur demande explicite : titre et contenu requis. Pour modifier, fournir id et version lus et uniquement les champs à changer. suivi est une synthèse actuelle, sans chronologie redondante. P entière entre −20 et +20 dB ; positive avance la révision. Ne changer une priorité personnelle qu’à la demande. archive est réversible. Aucun état mémoriel de fiche.',
 {'id':ID,'version':entier(1),'titre':texte(200,minLength=1),'contenu':texte(50000,minLength=1),'suivi':texte(),'alias':tableau(texte(120)),'tags':tableau(texte(64)),'priorite':entier(-20,20),'archive':BOOLEEN},[],{'fiche':objet(libre=True)},True)
outil('enregistrer_item','Créer ou modifier un item',
 'Avant création, rechercher globalement avec le même titre puis lire les candidats ; preuve_recherche requise. Réutiliser une même connaissance au lieu de la recréer. S’il s’agit d’un homonyme distinct, expliquer distinction (au moins 10 caractères). Création : titre, contenu, objectifs et sens requis ; S=-15 dB par défaut. Toute autre initialisation exige justification. reference_a est un départ déclaré, pas une évaluation inventée ; omettre si inconnue. Modification avec id et version : pas de changement de S ou de date mémoire, utiliser evaluer_items. Ne pas fusionner automatiquement. Un seul S pour tous les sens ; conserver les asymétries dans suivi.',
 {'id':ID,'version':entier(1),'titre':texte(200,minLength=1),'contenu':texte(12000,minLength=1),'suivi':texte(),'alias':tableau(texte(120)),'objectifs':tableau(texte(500),12,1),'sens':tableau(texte(300),12,1),'stabilite':entier(-128,127),'reference_a':nullable(date()),'justification':texte(1000),'preuve_recherche':texte(40),'distinction':texte(1000),'archive':BOOLEEN},[],{'item':objet(libre=True)},True)
outil('lier_item','Rattacher ou détacher un item',
 'Réutiliser un item existant dans une autre fiche. Fournir la version courante de la fiche. Le lien porte seulement ordre et contexte propre à la fiche. Détacher ne supprime ni l’item ni ses autres liens et ne change jamais S ou sa date. Répéter un rattachement identique ne crée aucun doublon.',
 {'fiche_id':ID,'item_id':ID,'version_fiche':entier(1),'action':choix('rattacher','detacher'),'ordre':entier(0,1000000),'contexte':texte(1000)},['fiche_id','item_id','version_fiche','action'],{'fiche':objet(libre=True),'item_id':ID,'modifie':BOOLEEN},True)
evaluation=objet({'item_id':ID,'version':entier(1),'episode':texte(100,minLength=1),'version_episode':entier(),'q':entier(-20,20),'sens':texte(300,minLength=1),'aide':choix('aucune','indice','correction'),'type_evenement':choix('rappel','apprentissage','suivi'),'evenement_a':date(),'date_inconnue':BOOLEEN,'suivi':texte(),'justification':texte(1000)},['item_id','version','episode','version_episode','q','sens','aide'])
outil('evaluer_items','Actualiser les items après une tentative',
 'Après CHAQUE réponse à une question de révision, enregistrer immédiatement la tentative avant une nouvelle préparation, y compris oubli, erreur ou réussite ; Q=0 si incertain. Ne pas inventer de rappel à partir d’une interruption. Chaque item distinct a son propre Q entier et épisode. Q est CUMULATIF : +2 corrigé en +3 ajoute seulement +1 ; renvoyer les versions courantes. Rejeu : même cle, même emise_a, mêmes paramètres. Correction tardive : relire les versions, ne pas écraser. Une nouvelle tentative plusieurs jours après est un nouvel épisode, même conversation. Dates réelles si disponibles ; sinon convention prudente de l’échange courant (date serveur), date_inconnue=true pour un ancien échange non daté. Q=0 possible, suivi facultatif. apprentissage/suivi exigent Q=0 ; suivi ne change pas la référence. Aide correction : pas de gain ; indice : au plus +1. Délai <24h ou inconnu : au plus +1 ; gains rapprochés cumulés au plus +1/24h. Abs(Q)>5 exige une justification. Hors bornes S : refus explicite, pas de saturation. Voir grille db-1 dans initialize.',
 {'conversation':texte(100,minLength=1),'evaluations':tableau(evaluation,20,1)},['evaluations'],{'evaluations':tableau(objet(libre=True),20)},True)
question=objet({'item_id':ID,'question':texte(500),'sens':texte(300),'aide':choix('aucune','indice','correction')},['item_id','question'])
outil('enregistrer_contexte','Conserver un contexte minimal de reprise',
 'Conserver uniquement fiche, items actifs, jusqu’à 12 questions/aides et une synthèse de reprise ≤2000 caractères ; aucune conversation complète. Version=0 à la création, puis version lue dans preparer_revision. Une conversation n’est pas une séance. Fin de séance : consolider sans rejouer les gains ni créer de nouveaux items. Contexte conservé 90 jours, au plus 50 conversations actives par compte.',
 {'conversation':texte(100,minLength=1),'version':entier(),'fiche_id':nullable(ID),'items':tableau(ID,20),'reprise':texte(2000),'questions':tableau(question,12)},['conversation','version'],{'contexte':objet(libre=True)},True)
outil('regler_politique','Régler l’intervalle et le budget de révision',
 'Uniquement sur demande de l’utilisateur. T est une politique, 90 jours par défaut (1–3650), pas une probabilité de rappel. budget est un nombre d’items distincts par jour, null désactive l’adaptation. G augmente les intervalles lorsque la charge estimée dépasse ce budget ; déplacement d’au plus 1 dB par semaine, entre 0 et 30. Aucun changement de S. Fournir la version du profil renvoyée par une lecture.',
 {'version':entier(),'intervalle_jours':entier(1,3650),'budget':nullable(entier(1,1000))},['version','intervalle_jours','budget'],{},True)

def generer():
 (RACINE/'docs/outils.json').write_text(json.dumps(OUTILS,ensure_ascii=False,indent=2)+'\n')
 chemins={}
 for outil in OUTILS:
  chemins['/api/v1/'+outil['name']]={'post':{'operationId':outil['name'],'summary':outil['title'],'description':outil['description'],'requestBody':{'required':True,'content':{'application/json':{'schema':outil['inputSchema']}}},'responses':{'200':{'description':'Résultat de l’opération ; vérifier erreur et enregistre.','content':{'application/json':{'schema':outil['outputSchema']}}},'400':{'description':'Paramètres ou règle métier invalides.'},'401':{'description':'Authentification Basic et identité interne requises.'},'409':{'description':'Version périmée ou clé réutilisée ; relire sans écraser.'},'503':{'description':'Base indisponible.'}}}}
 doc={'openapi':'3.1.0','info':{'title':'Vision — fiches et items','version':'2.0.0'},'servers':[{'url':'https://vision.mrj.am'}],'security':[{'basicAuth':[]}],'paths':chemins,'components':{'securitySchemes':{'basicAuth':{'type':'http','scheme':'basic'}}}}
 (RACINE/'docs/openapi.json').write_text(json.dumps(doc,ensure_ascii=False,indent=2)+'\n')
if __name__=='__main__':generer()
