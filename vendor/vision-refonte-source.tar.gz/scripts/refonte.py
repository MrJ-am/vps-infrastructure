#!/usr/bin/env python3
"""Préparer ou appliquer une migration sémantique depuis les données fraîches.

Le plan contient des données privées : fichier 0600 hors Git, jamais dans les
journaux Actions. L'application est atomique, vérifie l'empreinte sous verrou,
archive les sources et refuse de remigrer une collection v2 non vide.
"""
import argparse,collections,json,os,re,subprocess,unicodedata
from pathlib import Path

def normaliser(s):return ''.join(c for c in unicodedata.normalize('NFKD',s.casefold()) if not unicodedata.combining(c)).strip()
def preposition_capitale(pays):
 if pays in ('Albanie','Allemagne','Arménie','Autriche','Azerbaïdjan','Espagne',
             'Estonie','Irlande','Islande','Italie','Ukraine'):return "de l'"
 if pays=='Andorre':return "d'"
 if pays in ('Malte','Chypre','Monaco','Saint-Marin'):return 'de '
 if pays=='Pays-Bas':return 'des '
 if pays in ('France','Géorgie','Grèce','Hongrie','Lettonie','Lituanie','Moldavie',
             'Norvège','Pologne','Roumanie','Russie','Serbie','Slovaquie','Slovénie',
             'Suède','Suisse','Finlande','Croatie','Biélorussie','Bulgarie',
             'Macédoine du Nord','République tchèque'):return 'de la '
 return 'du '
def sql(texte,variables=None):
 commande=[os.environ.get('VISION_PSQL','psql'),'-X','-q','-t','-A','-v','ON_ERROR_STOP=1','--file=-']
 for k,v in (variables or {}).items():commande+=['--set',k+'='+v]
 r=subprocess.run(commande,input=texte,text=True,capture_output=True)
 if r.returncode:raise RuntimeError('Opération SQL de migration refusée ; aucun contenu privé publié.')
 return json.loads(r.stdout)

def construire(source,empreinte):
 corrections={}
 for c in source['corrections']:
  corrections[c['observation_id']]=c
 observations=[]
 for o in source['observations']:
  observations.append({**o,**{k:v for k,v in corrections.get(o['id'],{}).items() if k in ('note','context')}})
 fiches=[];orphelines=[];notes=[]
 for f in source['fiches']:
  titre=normaliser(f['title']);items=[]
  liees=sorted((o for o in observations if o['sheet_id']==f['id']),key=lambda o:(o['reviewed_at'],o['id']))
  fiche=dict(id=f['id'],titre=f['title'],contenu=f['body'],alias=f['aliases'],tags=f['tags'],
    priorite=f['importance']-3,cree_a=f['created_at'],modifie_a=f['updated_at'],archive_a=f['archived_at'])
  if 'capitales europeennes' in titre:
   associations={}
   for pays,capitale in re.findall(r'^-\s+([^\n→]+)\s*→\s*([^\n:]+)',f['body'],re.M):
    pays=pays.strip();capitale=capitale.strip()
    if pays in associations and associations[pays]!=capitale:raise ValueError('Association ambiguë : préparation manuelle nécessaire.')
    associations[pays]=capitale
   if not associations:raise ValueError('Aucune association extraite : migration arrêtée.')
   attribuees=set()
   for pays,capitale in associations.items():
    traces=[o for o in liees if re.match(r'^'+re.escape(normaliser(pays))+r'\s*→',normaliser(o['note']))]
    attribuees.update(o['id'] for o in traces)
    evaluees=[o for o in traces if o['outcome']!='not_assessed']
    dernier=evaluees[-1] if evaluees else None
    oubli=any(o['outcome']=='forgotten' for o in evaluees)
    stabilite=-15;suivi='';estimation='Initialisation prudente −15 dB ; exposition initiale et évaluation inconnues.'
    if dernier:
     if dernier['outcome']=='forgotten':
      stabilite=-20;suivi='Association pays → capitale non rappelée lors de la dernière tentative ; à reprendre. Sens inverse non évalué.'
     elif oubli:
      stabilite=-17;suivi='Dernier rappel pays → capitale correct après un oubli historique ; durabilité à confirmer à distance. Sens inverse non évalué.'
     elif dernier['outcome']=='partial':
      stabilite=-16;suivi='Rappel partiel à préciser lors de la prochaine tentative. Sens inverse non évalué.'
     else:
      stabilite=-12;suivi='Rappel pays → capitale correct enregistré ; sens inverse non évalué.'
     estimation=f'Estimation initiale {stabilite:+d} dB depuis les seules traces attribuables ; aucun transfert FSRS et aucun gain historique rejoué.'
    items.append(dict(cle='capitale:'+normaliser(pays),titre=f'Capitale ({pays}) : {capitale}',
      contenu=f'{capitale} est la capitale {preposition_capitale(pays)}{pays}.',alias=[pays,capitale],objectifs=['Associer le pays à sa capitale et la capitale à son pays.'],
      sens=['pays → capitale','capitale → pays'],suivi=suivi,stabilite=stabilite,
      reference_a=dernier['reviewed_at'] if dernier else None,evalue_a=dernier['reviewed_at'] if dernier else None,
      observations=[o['id'] for o in traces],estimation=estimation,ordre=len(items),contexte='Association dans le périmètre européen déjà demandé.'))
   orphelines += [o['id'] for o in liees if o['id'] not in attribuees]
   fiche['contenu']='# Capitales européennes\n\nAssocier les pays et leurs capitales dans les deux sens. Le périmètre est celui des associations déjà présentes dans cette fiche ; il inclut les pays transcontinentaux et les territoires explicitement retenus.\n\nLes associations et leur suivi figurent dans les items liés. Les fenêtres sont dérivées de leur stabilité et de la priorité de cette fiche ; elles restent indicatives. Une révision peut être demandée à tout moment.'
  elif 'theorie des situations didactiques' in titre or titre=='tsd':
   definitions={}
   for nom,definition in re.findall(r'^(?:- |\d+\. )\*\*([^*]+)\*\*\s*:\s*(.+)$',f['body'],re.M):
    definitions.setdefault(normaliser(nom),(nom,definition))
   attendus=['situation didactique','situation adidactique','milieu','devolution','institutionnalisation','contrat didactique','action','formulation','validation']
   if not all(n in definitions for n in attendus):raise ValueError('Structure TSD modifiée : relire la fiche avant de préparer sa migration.')
   for cle in attendus:
    nom,contenu=definitions[cle]
    items.append(dict(cle='tsd:'+cle,titre='TSD — '+nom,
      contenu=f'Dans la théorie des situations didactiques de Guy Brousseau, le terme « {nom} » désigne : {contenu}',
      alias=[],objectifs=['Définir, reconnaître dans une situation et distinguer les concepts voisins.'],
      sens=['terme → définition et exemple','situation → concept'],suivi='',stabilite=-15,reference_a=None,evalue_a=None,observations=[],
      estimation='Connaissance présente dans le contenu ; aucune évaluation attribuable. Initialisation −15 dB.',ordre=len(items),contexte='Théorie des situations didactiques.'))
   if liees:raise ValueError('De nouvelles évaluations TSD exigent une attribution avant migration.')
  else:
   raise ValueError('Une nouvelle fiche exige un plan sémantique avant migration ; contenu conservé, aucune écriture réalisée.')
  fiche['items']=items;fiches.append(fiche)
 if orphelines:raise ValueError('Des observations restent sans item : attribution nécessaire avant migration.')
 repartition=collections.Counter(str(i['stabilite']) for f in fiches for i in f['items'])
 rapport=dict(modele='db-1',fiches_avant=len(source['fiches']),observations_archivees=len(source['observations']),
  corrections_archivees=len(source['corrections']),items_prevus=sum(len(f['items']) for f in fiches),
  sans_evaluation=sum(i['evalue_a'] is None for f in fiches for i in f['items']),stabilites=dict(repartition),
  priorites=[dict(id=f['id'],priorite=f['priorite']) for f in fiches],correspondance_priorite='P = ancienne importance − 3 ; TSD +2, capitales 0 si valeurs inchangées.',
  estimations='−20 dernier oubli ; −17 réussite après oubli ; −16 partiel ; −12 rappel correct seul ; −15 sans évaluation. Heuristique prudente, sans conversion FSRS.')
 return dict(empreinte_source=empreinte,fiches=fiches,rapport=rapport)

def preparer():
 r=sql("WITH s AS (SELECT vision_source_historique() AS contenu) SELECT jsonb_build_object('source',contenu,'empreinte',encode(sha256(convert_to(contenu::text,'UTF8')),'hex')) FROM s;")
 return construire(r['source'],r['empreinte'])

def appliquer(utilisateur,plan,simulation=False):
 return sql("BEGIN; SELECT vision_importer(:'utilisateur',:'plan'::jsonb); "+('ROLLBACK;' if simulation else 'COMMIT;'),
   dict(utilisateur=utilisateur,plan=json.dumps(plan,ensure_ascii=False)))

if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('operation',choices=['preparer','simuler','appliquer']);a.add_argument('--plan',type=Path,required=True);a.add_argument('--utilisateur')
 args=a.parse_args();os.umask(0o077)
 if args.operation=='preparer':
  plan=preparer();args.plan.write_text(json.dumps(plan,ensure_ascii=False,indent=2)+'\n');print(json.dumps(plan['rapport'],ensure_ascii=False))
 else:
  if not args.utilisateur:raise SystemExit('--utilisateur requis')
  print(json.dumps(appliquer(args.utilisateur,json.loads(args.plan.read_text()),args.operation=='simuler'),ensure_ascii=False))
