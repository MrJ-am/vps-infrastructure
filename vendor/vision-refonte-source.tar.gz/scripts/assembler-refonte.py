#!/usr/bin/env python3
"""Figer les sources et l'interface exacte validée par deux exécutions CI."""
import base64,gzip,hashlib,io,json,os,re,subprocess,tarfile,urllib.request,zipfile
from pathlib import Path
d=json.loads(Path('operations/assembler-refonte.json').read_text())
assert set(d)=={'application','ci_backend','ci_interface','artefact_interface','sha256_interface'}
rev=d['application'];assert re.fullmatch('[0-9a-f]{40}',rev)
base='https://api.github.com/repos/'+os.environ['GITHUB_REPOSITORY']
def api(path,data=None):
    req=urllib.request.Request(base+path,data=None if data is None else json.dumps(data).encode(),headers={'Authorization':'Bearer '+os.environ['GH_TOKEN'],'Accept':'application/vnd.github+json','Content-Type':'application/json'})
    with urllib.request.urlopen(req,timeout=120) as r:return json.load(r)
for cle,chemin in [('ci_backend','.github/workflows/check.yml'),('ci_interface','.github/workflows/interface.yml')]:
    r=api('/actions/runs/'+str(d[cle]))
    assert r['head_sha']==rev and r['path']==chemin and r['conclusion']=='success' and r['event']=='push'
a=api('/actions/artifacts/'+str(d['artefact_interface']))
assert not a['expired'] and a['name']=='interface-vision-verifiee' and a['workflow_run']['head_sha']==rev and a['workflow_run']['id']==d['ci_interface']
req=urllib.request.Request(base+'/actions/artifacts/'+str(a['id'])+'/zip',headers={'Authorization':'Bearer '+os.environ['GH_TOKEN']})
class RedirectionSansSecret(urllib.request.HTTPRedirectHandler):
    def redirect_request(self,req,fp,code,msg,headers,newurl):
        nouveau=super().redirect_request(req,fp,code,msg,headers,newurl)
        nouveau.remove_header('Authorization')
        return nouveau
with urllib.request.build_opener(RedirectionSansSecret()).open(req,timeout=120) as r:interface=r.read()
assert hashlib.sha256(interface).hexdigest()==d['sha256_interface'] and a['digest']=='sha256:'+d['sha256_interface']
with zipfile.ZipFile(io.BytesIO(interface)) as z:
    m=json.loads(z.read('manifest.json'))
    assert m['revisionApplication']==rev
    assert {n for n in z.namelist() if not n.endswith('/')}==set(m['fichiers'])|{'manifest.json'}
    for n,h in m['fichiers'].items():
        assert not n.startswith('/') and '..' not in Path(n).parts
        assert hashlib.sha256(z.read(n)).hexdigest()==h
racine=Path('application')
assert subprocess.check_output(['git','-C',str(racine),'rev-parse','HEAD'],text=True).strip()==rev
noms=subprocess.check_output(['git','-C',str(racine),'ls-files','-z']).decode().strip('\0').split('\0')
tampon=io.BytesIO()
with gzip.GzipFile(fileobj=tampon,mode='wb',mtime=0) as gz:
    with tarfile.open(fileobj=gz,mode='w') as t:
        for nom in sorted(noms+['revision-application.txt']):
            p=racine/nom
            assert not p.is_symlink()
            contenu=(rev+'\n').encode() if nom=='revision-application.txt' else p.read_bytes()
            info=tarfile.TarInfo(nom);info.size=len(contenu);info.mode=0o644;info.mtime=0
            t.addfile(info,io.BytesIO(contenu))
source=tampon.getvalue()
candidat={k:v for k,v in d.items() if k!='sha256_interface'}
candidat['fichiers']={'vendor/vision-refonte-source.tar.gz':hashlib.sha256(source).hexdigest(),'vendor/vision-refonte-interface.zip':hashlib.sha256(interface).hexdigest()}
fichiers={'source.tar.gz':source,'interface.zip':interface,'candidat.json':(json.dumps(candidat,ensure_ascii=False,indent=2)+'\n').encode()}
entrees=[]
for nom,contenu in fichiers.items():
    b=api('/git/blobs',{'content':base64.b64encode(contenu).decode(),'encoding':'base64'})
    entrees.append({'path':nom,'type':'blob','mode':'100644','sha':b['sha']})
arbre=api('/git/trees',{'tree':entrees})
commit=api('/git/commits',{'message':'Figer le candidat Vision '+rev,'tree':arbre['sha'],'parents':[]})
branche='artefacts/vision-refonte-'+rev
api('/git/refs',{'ref':'refs/heads/'+branche,'sha':commit['sha']})
print(json.dumps({'branche':branche,'commit':commit['sha'],'candidat':candidat},ensure_ascii=False,indent=2))
