# Securite

## Perimetre

Le service Common Lisp ecoute uniquement sur `127.0.0.1:3001`. Nginx est le
seul point d’entrée public : il termine TLS, vérifie l’authentification, limite le débit
et la taille des requetes, supprime tout en-tete d'authentification fourni par
le client avant de transmettre une preuve interne au service.

La route MCP `/mcp` accepte Basic ou le token Bearer décrit dans
[MISTRAL.md](docs/MISTRAL.md), activé le 22 septembre 2026. Les tokens
MCP ne sont pas acceptés comme identifiants REST ou comme sessions web.
L'application refuse aussi ces routes si la preuve interne de Nginx manque.
Elle n'accepte pas de SQL fourni par le client : chaque outil utilise une
requete fixe et les valeurs sont transmises comme variables correctement citees
par `psql`.

PostgreSQL utilise exclusivement le socket Unix `/run/postgresql`. Le role
`vision` n'accede qu'a la base `vision` et ne possede aucun privilege global.

## Secrets

Le fichier `/var/lib/vision/auth/htpasswd` appartient a `root:vision-auth`,
avec le mode `0640`. Le depot ne contient ni mot de passe, ni cle privee, ni
fichier d'environnement. Les identifiants sont geres par les secrets de
l'environnement GitHub `vps-production`, puis installes sans etre affiches.

Le test Mobile Live utilise un fichier d'authentification distinct et une
route Nginx exacte. Son mot de passe jetable n'est pas conserve dans Git ; seul
un condensat est deploye. Cette route renvoie une constante, n'accepte aucun
corps et ne donne acces a aucune operation ni donnee Vision.

## Signalement

Ne pas ouvrir de ticket public contenant un secret, un en-tete Authorization,
une cle SSH, un dump PostgreSQL ou des donnees personnelles. Revoquer d'abord
le secret concerne, puis transmettre un rapport prive au proprietaire du depot.

## Limites

Aucun logiciel ne peut etre qualifie de parfaitement sur. Les protections sont
donc verifiees en couches : TLS, authentification, limitation de debit, ecoute
locale, privileges Unix/PostgreSQL minimaux, durcissement systemd, tests et
retour arriere de l'infrastructure.


## Interface navigateur

Audit du 22 septembre 2026 : l'authentification actuellement intégrée utilise
`sha512_crypt` (format `$6$`, 5 000 tours lors du provisionnement OpenSSL), et
non Argon2id ou scrypt. Ce format est compatible avec Nginx Basic mais protège
moins bien contre une attaque hors ligne qu'un hachage à coût mémoire. Une
migration doit traiter ensemble l'API Basic et le navigateur ; ajouter un
deuxième condensat fort au seul navigateur laisserait le mot de passe exposé
par le condensat faible. Le rapport comparé et les suites coordonnées sont
conservés dans `vps-infrastructure/docs/AUDIT-AUTHENTIFICATION-20260922.md`.

Les sessions ont une durée absolue de douze heures, expirent après deux heures
d'inactivité et sont révoquées au logout ou après modification des identifiants.
Le cookie est partagé uniquement entre les hôtes autorisés de `mrj.am`.
Un administrateur système peut lire les condensats et modifier le serveur ;
cela ne lui révèle pas directement les mots de passe déjà hachés, mais lui
permettrait de capturer de futures saisies s'il compromettait le service.

Les sessions du navigateur sont vérifiées par VPS Infrastructure, avec cookie
Secure/HttpOnly et jeton CSRF. Les routes `/api/web/` exigent également une
preuve interne distincte, écrasée par le proxy. Les données ne sont conservées
ni en localStorage ni dans une URL. Le HTML des fiches reste du texte ; la
politique CSP interdit le code en ligne et les connexions à des tiers. Les
corrections et éditions sont historisées, sans suppression des observations.

## Tokens MCP

Le token est produit par un générateur cryptographique (256 bits aléatoires).
Seul son SHA-256 est stocké dans la base privée du service d’authentification ;
ce hachage rapide convient à un secret aléatoire de forte entropie, pas à un
mot de passe humain. Expiration à un an, révocation et remplacement immédiats.
La modification du fichier de comptes invalide également les tokens.

Création et révocation exigent une session valide, l’origine exacte et CSRF.
Le token est affiché une seule fois, sans stockage navigateur ni journalisation.
Il autorise les cinq outils MCP, donc les lectures et écritures ; le logout
navigateur ne le révoque pas. Aucun token n’est transmis au serveur Lisp.
