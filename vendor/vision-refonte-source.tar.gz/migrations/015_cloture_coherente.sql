BEGIN;
-- Correction additive : aucune réécriture de résultats, dates, séances ou observations.
-- Redéfinir les fonctions explicitement : pas de capture d'une ancienne version par renommage.

CREATE OR REPLACE FUNCTION vision_evaluer(u text,p jsonb) RETURNS jsonb LANGUAGE plpgsql AS $$
DECLARE e jsonb; i vision_items; ancien vision_items; episode vision_episodes;
  q integer; delta integer; instant timestamptz; rapproche boolean; precedent integer; resultat jsonb:='[]';
  type_evenement text; sens text; aide text; total integer; distincts integer;
BEGIN
  SELECT count(*),count(DISTINCT x->>'item_id') INTO total,distincts FROM jsonb_array_elements(p->'evaluations') x;
  IF total<>distincts OR total NOT BETWEEN 1 AND 20 THEN PERFORM vision_refuser('items_distincts_requis'); END IF;
  FOR e IN SELECT value FROM jsonb_array_elements(p->'evaluations') LOOP
    SELECT * INTO i FROM vision_items WHERE utilisateur=u AND id=(e->>'item_id')::bigint FOR UPDATE;
    IF NOT FOUND THEN PERFORM vision_refuser('introuvable'); END IF;
    IF i.archive_a IS NOT NULL THEN PERFORM vision_refuser('objet_archive'); END IF;
    IF i.version IS DISTINCT FROM (e->>'version')::bigint THEN PERFORM vision_refuser('conflit'); END IF;
    ancien:=i;
    SELECT * INTO episode FROM vision_episodes WHERE utilisateur=u AND item_id=i.id AND cle=e->>'episode';
    IF coalesce(episode.version,0) IS DISTINCT FROM (e->>'version_episode')::bigint THEN PERFORM vision_refuser('conflit_episode'); END IF;
    IF episode.cle IS NOT NULL AND episode.enregistre_a<now()-interval '30 days' THEN PERFORM vision_refuser('episode_expire'); END IF;
    q:=(e->>'q')::integer;
    IF q IS NULL OR q NOT BETWEEN -20 AND 20 THEN PERFORM vision_refuser('ajustement_invalide'); END IF;
    IF abs(q)>5 AND char_length(coalesce(e->>'justification',''))<10 THEN PERFORM vision_refuser('ajustement_a_justifier'); END IF;
    type_evenement:=coalesce(e->>'type_evenement','rappel');
    instant:=CASE WHEN coalesce((e->>'date_inconnue')::boolean,false) THEN NULL
      WHEN e ? 'evenement_a' THEN (e->>'evenement_a')::timestamptz ELSE now() END;
    IF instant>now()+interval '5 minutes' OR instant<'1900-01-01'::timestamptz THEN PERFORM vision_refuser('date_invalide'); END IF;
    IF episode.cle IS NOT NULL THEN
      -- Une précision conserve la date de la tentative originale.
      IF e ? 'evenement_a' AND instant IS DISTINCT FROM episode.evenement_a THEN PERFORM vision_refuser('date_episode_immuable'); END IF;
      instant:=episode.evenement_a;
    END IF;
    sens:=coalesce(e->>'sens',''); aide:=coalesce(e->>'aide','aucune');
    -- Le sens décrit la question, jamais une liste historique masquée de l'item.
    IF char_length(sens)>300 THEN PERFORM vision_refuser('sens_invalide'); END IF;
    IF aide NOT IN ('aucune','indice','correction') THEN PERFORM vision_refuser('aide_invalide'); END IF;
    IF type_evenement NOT IN ('rappel','apprentissage','suivi') THEN PERFORM vision_refuser('evenement_invalide'); END IF;
    IF type_evenement IN ('apprentissage','suivi') AND q<>0 THEN PERFORM vision_refuser('rappel_requis'); END IF;
    IF aide='correction' AND q>0 OR aide='indice' AND q>1 THEN PERFORM vision_refuser('gain_aide_excessif'); END IF;
    rapproche:=CASE WHEN episode.cle IS NOT NULL THEN episode.rapproche
      ELSE instant IS NULL OR i.reference_a IS NULL OR instant-i.reference_a<interval '1 day' END;
    delta:=q-coalesce(episode.q,0);
    IF rapproche AND q>1 THEN PERFORM vision_refuser('gain_rapproche_excessif'); END IF;
    IF rapproche AND delta>0 THEN
      SELECT coalesce(sum(greatest(a.q,0)),0) INTO precedent FROM vision_episodes a WHERE a.utilisateur=u
        AND a.item_id=i.id AND a.rapproche AND a.enregistre_a>now()-interval '1 day' AND a.cle<>e->>'episode';
      IF precedent+greatest(q,0)>1 THEN PERFORM vision_refuser('gain_rapproche_deja_applique'); END IF;
    END IF;
    IF i.stabilite+delta NOT BETWEEN -128 AND 127 THEN PERFORM vision_refuser('borne_stabilite'); END IF;
    -- Un ancien événement est daté honnêtement ; il ne remplace pas la référence récente.
    UPDATE vision_items SET stabilite=stabilite+delta,suivi=coalesce(e->>'suivi',suivi),
      reference_a=CASE WHEN type_evenement<>'suivi' AND instant IS NOT NULL THEN greatest(reference_a,instant) ELSE reference_a END,
      origine_reference=CASE WHEN type_evenement<>'suivi' AND instant IS NOT NULL AND (reference_a IS NULL OR instant>=reference_a)
        THEN type_evenement ELSE origine_reference END,
      evalue=evalue OR type_evenement='rappel',
      evalue_a=CASE WHEN type_evenement='rappel' AND instant IS NOT NULL THEN greatest(evalue_a,instant) ELSE evalue_a END,
      version=version+1,modifie_a=now() WHERE utilisateur=u AND id=i.id RETURNING * INTO i;
    INSERT INTO vision_episodes(utilisateur,item_id,cle,conversation,q,stabilite_avant,evenement_a,sens,aide,rapproche)
      VALUES(u,i.id,e->>'episode',p->>'conversation',q,ancien.stabilite,instant,sens,aide,rapproche)
      ON CONFLICT(utilisateur,item_id,cle) DO UPDATE SET q=excluded.q,version=vision_episodes.version+1,
        sens=excluded.sens,aide=excluded.aide RETURNING * INTO episode;
    INSERT INTO vision_journal(utilisateur,objet,objet_id,operation,episode,delta,avant,apres,evenement_a,justification)
      VALUES(u,'item',i.id,'evaluer',episode.cle,delta,
        jsonb_build_object('stabilite',ancien.stabilite,'suivi',ancien.suivi,'reference_a',ancien.reference_a),
        jsonb_build_object('stabilite',i.stabilite,'suivi',i.suivi,'reference_a',i.reference_a),instant,coalesce(e->>'justification',''));
    IF e ? 'suivi' AND coalesce(e->>'suivi','')<>'' AND ancien.suivi IS DISTINCT FROM e->>'suivi' THEN
      INSERT INTO vision_observations(utilisateur,item_id,texte,source,evenement_a)
        VALUES(u,i.id,e->>'suivi','evaluation_historique',instant);
    END IF;
    resultat:=resultat||jsonb_build_array(jsonb_build_object('item',vision_item_public(i),'episode',episode.cle,
      'version_episode',episode.version,'q_cumulatif',q,'delta_applique',delta,
      'horodatage',CASE WHEN instant IS NULL THEN 'inconnu' WHEN e ? 'evenement_a' THEN 'fourni' ELSE 'echange_courant_serveur' END));
  END LOOP;
  RETURN jsonb_build_object('enregistre',true,'evaluations',resultat);
END $$;

CREATE OR REPLACE FUNCTION vision_clore_seance_v2(u text,p jsonb) RETURNS jsonb LANGUAGE plpgsql AS $$
DECLARE s vision_seances; e jsonb; retour jsonb:=p->'retour'; evaluations jsonb:=p->'evaluations';
  bilan jsonb; bilan_final jsonb; normalisees jsonb:='[]'::jsonb; ajustements jsonb:='[]'::jsonb;
  item_courant vision_items; version_preparee bigint; q_demande integer; q_applique integer;
  maximum integer; precedent integer; instant timestamptz; rapproche boolean; motif text;
BEGIN
  SELECT * INTO s FROM vision_seances WHERE utilisateur=u AND id=(p->>'seance_id')::uuid FOR UPDATE;
  IF NOT FOUND THEN PERFORM vision_refuser('seance_introuvable'); END IF;
  IF s.etat<>'ouverte' THEN
    IF s.rapport->>'empreinte_cloture'=p->>'empreinte_cloture' THEN
      RETURN jsonb_build_object('enregistre',true,'rejeu',true,'rapport',s.rapport);
    END IF;
    PERFORM vision_refuser('cloture_differente');
  END IF;
  IF jsonb_typeof(evaluations)<>'array' OR jsonb_array_length(evaluations)>20 THEN
    PERFORM vision_refuser('evaluations_invalides');
  END IF;
  FOR e IN SELECT value FROM jsonb_array_elements(evaluations) LOOP
    IF NOT EXISTS(SELECT 1 FROM jsonb_array_elements(s.items) i WHERE (i->>'id')::bigint=(e->>'item_id')::bigint) THEN
      PERFORM vision_refuser('item_hors_seance');
    END IF;
  END LOOP;
  FOR e IN SELECT value FROM jsonb_array_elements(retour->'reformulations') LOOP
    IF NOT EXISTS(SELECT 1 FROM jsonb_array_elements(s.items) i WHERE (i->>'id')::bigint=(e->>'item_id')::bigint) THEN
      PERFORM vision_refuser('item_hors_seance');
    END IF;
  END LOOP;
  FOR e IN SELECT value FROM jsonb_array_elements(p->'deroulement') LOOP
    IF NOT EXISTS(SELECT 1 FROM jsonb_array_elements(s.items) i WHERE (i->>'id')::bigint=(e->>'item_id')::bigint) THEN
      PERFORM vision_refuser('item_hors_seance');
    END IF;
  END LOOP;
  -- Le lot peut avoir vieilli pendant que d'autres séances sur les mêmes items ont été closes.
  -- Les évaluations indépendantes sont recalculées sur l'état courant, sans modifier la trace demandée.
  FOR e IN SELECT value FROM jsonb_array_elements(evaluations) LOOP
    SELECT * INTO item_courant FROM vision_items WHERE utilisateur=u AND id=(e->>'item_id')::bigint FOR UPDATE;
    SELECT (x->>'version')::bigint INTO version_preparee
      FROM jsonb_array_elements(s.items) x WHERE x->>'id'=e->>'item_id' LIMIT 1;
    IF item_courant.id IS NULL OR ((e->>'version')::bigint<>version_preparee AND
                        (e->>'version')::bigint<>item_courant.version) THEN
      PERFORM vision_refuser('conflit');
    END IF;
    q_demande:=(e->>'q')::integer;
    q_applique:=q_demande;
    motif:='';
    IF coalesce(e->>'type_evenement','rappel')='rappel' AND q_demande>0 THEN
      instant:=CASE WHEN coalesce((e->>'date_inconnue')::boolean,false) THEN NULL
        WHEN e ? 'evenement_a' THEN (e->>'evenement_a')::timestamptz ELSE now() END;
      rapproche:=instant IS NULL OR item_courant.reference_a IS NULL OR instant-item_courant.reference_a<interval '1 day';
      maximum:=CASE WHEN e->>'aide'='correction' THEN 0
        WHEN rapproche OR e->>'aide'='indice' THEN 1 ELSE 20 END;
      IF rapproche THEN
        SELECT coalesce(sum(greatest(a.q,0)),0) INTO precedent FROM vision_episodes a
          WHERE a.utilisateur=u AND a.item_id=item_courant.id AND a.rapproche
            AND a.enregistre_a>now()-interval '1 day' AND a.cle<>e->>'episode';
        maximum:=least(maximum,greatest(0,1-precedent));
      END IF;
      q_applique:=least(q_demande,maximum);
      IF q_applique<q_demande THEN
        motif:=CASE WHEN e->>'aide'='correction' THEN 'correction_devoilee'
          WHEN rapproche THEN 'gain_rapproche_limite' ELSE 'indice' END;
      END IF;
    END IF;
    IF q_applique<>q_demande OR item_courant.version<>(e->>'version')::bigint THEN
      ajustements:=ajustements||jsonb_build_array(jsonb_build_object('item_id',item_courant.id,
        'q_demande',q_demande,'q_applique',q_applique,'motif',motif,
        'version_demandee',(e->>'version')::bigint,'version_appliquee',item_courant.version));
    END IF;
    normalisees:=normalisees||jsonb_build_array(e||jsonb_build_object('q',q_applique,'version',item_courant.version));
  END LOOP;
  IF jsonb_array_length(normalisees)>0 THEN
    bilan:=vision_evaluer(u,(p||jsonb_build_object('evaluations',normalisees,'conversation',s.conversation)));
  ELSE bilan:=jsonb_build_object('enregistre',true,'evaluations','[]'::jsonb);
  END IF;
  bilan_final:=jsonb_build_object('seance_id',s.id,'fiche_id',s.fiche_id,
    'empreinte_cloture',p->>'empreinte_cloture',
    'items_sans_deroulement',(SELECT coalesce(jsonb_agg(x.valeur->'item_id'),'[]'::jsonb)
      FROM jsonb_array_elements(evaluations) AS x(valeur) WHERE NOT EXISTS (
        SELECT 1 FROM jsonb_array_elements(p->'deroulement') d
        WHERE d->>'item_id'=x.valeur->>'item_id' AND d->>'etat'='tente')),
    'questions_preparees',jsonb_array_length(s.items),
    'tentatives_enregistrees',jsonb_array_length(evaluations),
    'evaluations',bilan->'evaluations','evaluations_demandees',evaluations,
    'ajustements',ajustements,'deroulement',p->'deroulement',
    'retour',retour,'synthese',coalesce(p->>'synthese',''),
    'propositions_en_attente',jsonb_build_object('reformulations',retour->'reformulations','ajouts',retour->'ajouts'));
  UPDATE vision_seances SET etat='terminee',retour=p->'retour',rapport=bilan_final,terminee_a=now()
    WHERE id=s.id;
  RETURN jsonb_build_object('enregistre',true,'rapport',bilan_final);
END $$;

CREATE OR REPLACE FUNCTION vision_clore_seance(u text,p jsonb) RETURNS jsonb LANGUAGE plpgsql AS $$
DECLARE resultat jsonb; ligne jsonb; identifiant bigint; s vision_seances;
  normalise jsonb; evaluations jsonb:='[]'::jsonb; e jsonb; version_item bigint;
  empreinte text; contenu jsonb;
BEGIN
  SELECT * INTO s FROM vision_seances WHERE utilisateur=u AND id=(p->>'seance_id')::uuid FOR UPDATE;
  IF NOT FOUND THEN PERFORM vision_refuser('seance_introuvable'); END IF;
  normalise:=p||jsonb_build_object('deroulement',coalesce(p->'deroulement','[]'::jsonb),
    'retour',jsonb_build_object('difficulte','non_indiquee','reformulations','[]'::jsonb,'ajouts','[]'::jsonb)
      ||coalesce(p->'retour','{}'::jsonb));
  -- Empreinte métier stable : un nouvel identifiant de requête après interruption
  -- n'autorise ni un double crédit ni le remplacement d'un rapport existant.
  SELECT coalesce(jsonb_agg(x.valeur-'version'-'episode'-'version_episode' ORDER BY (x.valeur->>'item_id')::bigint),'[]'::jsonb)
    INTO contenu FROM jsonb_array_elements(p->'evaluations') AS x(valeur);
  empreinte:=encode(sha256(convert_to((jsonb_build_object('evaluations',contenu,
    'deroulement',normalise->'deroulement','retour',normalise->'retour',
    'synthese',coalesce(p->>'synthese',''),'observation_fiche',coalesce(p->>'observation_fiche','')))::text,'UTF8')),'hex');
  IF s.etat<>'ouverte' THEN
    IF s.rapport->>'empreinte_cloture'=empreinte THEN
      RETURN jsonb_build_object('enregistre',true,'rejeu',true,'rapport',s.rapport);
    END IF;
    PERFORM vision_refuser('cloture_differente');
  END IF;
  FOR e IN SELECT value FROM jsonb_array_elements(p->'evaluations') LOOP
    SELECT (x->>'version')::bigint INTO version_item FROM jsonb_array_elements(s.items) x
      WHERE x->>'id'=e->>'item_id';
    IF NOT FOUND THEN PERFORM vision_refuser('item_hors_seance'); END IF;
    evaluations:=evaluations||jsonb_build_array(
      jsonb_build_object('version',version_item,'sens','')||e||
      jsonb_build_object('episode','seance:'||s.id::text||':'||(e->>'item_id'),'version_episode',0));
  END LOOP;
  normalise:=normalise||jsonb_build_object('evaluations',evaluations,'empreinte_cloture',empreinte);
  resultat:=vision_clore_seance_v2(u,normalise);
  IF NOT coalesce((resultat->>'enregistre')::boolean,false) OR coalesce((resultat->>'rejeu')::boolean,false) THEN RETURN resultat; END IF;
  FOR ligne IN SELECT value FROM jsonb_array_elements(normalise->'deroulement') LOOP
    identifiant:=(ligne->>'item_id')::bigint;
    INSERT INTO vision_observations(utilisateur,item_id,texte,source,details,evenement_a)
      VALUES(u,identifiant,coalesce(ligne->>'observation',''),'seance',
        (ligne-'observation')||jsonb_build_object('seance_id',p->>'seance_id',
          'evaluation',(SELECT e.value FROM jsonb_array_elements(p->'evaluations') e
            WHERE e.value->>'item_id'=ligne->>'item_id' LIMIT 1)),
        (ligne->>'posee_a')::timestamptz);
  END LOOP;
  IF coalesce(btrim(p->>'observation_fiche'),'')<>'' THEN
    INSERT INTO vision_observations(utilisateur,fiche_id,texte,source,details)
      VALUES(u,(resultat#>>'{rapport,fiche_id}')::bigint,p->>'observation_fiche',
        'seance',jsonb_build_object('seance_id',p->>'seance_id'));
  END IF;
  RETURN resultat;
END $$;

CREATE OR REPLACE FUNCTION vision_revision_contrat() RETURNS integer LANGUAGE sql IMMUTABLE AS $$ SELECT 6 $$;
INSERT INTO vision_schema_migrations(version) VALUES(15) ON CONFLICT DO NOTHING;
COMMIT;
