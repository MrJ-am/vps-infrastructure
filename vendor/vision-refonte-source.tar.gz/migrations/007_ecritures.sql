BEGIN;

CREATE OR REPLACE FUNCTION vision_refuser(code text) RETURNS void LANGUAGE plpgsql AS $$
BEGIN RAISE EXCEPTION USING ERRCODE='P0001',MESSAGE=code; END $$;

CREATE OR REPLACE FUNCTION vision_ajuster_charge(u text) RETURNS void LANGUAGE plpgsql AS $$
DECLARE pr vision_profils; demande numeric; cible integer;
BEGIN
  SELECT * INTO pr FROM vision_profils WHERE utilisateur=u;
  IF pr.budget IS NULL THEN
    UPDATE vision_profils SET decalage=0 WHERE utilisateur=u AND decalage<>0;
    RETURN;
  END IF;
  IF pr.charge_actualisee_a IS NOT NULL AND pr.charge_actualisee_a>now()-interval '7 days' THEN RETURN; END IF;
  SELECT coalesce(sum(1/greatest(1,pr.intervalle_jours*power(10::numeric,(i.stabilite-c.priorite)::numeric/10))),0)
    INTO demande FROM vision_candidats(u) c JOIN vision_items i ON i.id=c.item_id AND i.utilisateur=u;
  cible := CASE WHEN demande<=pr.budget THEN 0 ELSE least(30,ceil(10*log(demande/pr.budget))::integer) END;
  UPDATE vision_profils SET decalage=decalage+sign(cible-decalage)::integer,
    charge_actualisee_a=now(),version=version+1 WHERE utilisateur=u;
END $$;

CREATE OR REPLACE FUNCTION vision_ecrire_fiche(u text,p jsonb) RETURNS jsonb LANGUAGE plpgsql AS $$
DECLARE ancienne vision_fiches; nouvelle vision_fiches;
BEGIN
  IF p ? 'id' THEN
    SELECT * INTO ancienne FROM vision_fiches WHERE utilisateur=u AND id=(p->>'id')::bigint FOR UPDATE;
    IF NOT FOUND THEN PERFORM vision_refuser('introuvable'); END IF;
    IF ancienne.version IS DISTINCT FROM (p->>'version')::bigint THEN PERFORM vision_refuser('conflit'); END IF;
    UPDATE vision_fiches SET titre=coalesce(p->>'titre',titre),contenu=coalesce(p->>'contenu',contenu),
      suivi=coalesce(p->>'suivi',suivi),priorite=coalesce((p->>'priorite')::integer,priorite),
      alias=CASE WHEN p ? 'alias' THEN ARRAY(SELECT jsonb_array_elements_text(p->'alias')) ELSE alias END,
      tags=CASE WHEN p ? 'tags' THEN ARRAY(SELECT jsonb_array_elements_text(p->'tags')) ELSE tags END,
      archive_a=CASE WHEN p ? 'archive' THEN CASE WHEN (p->>'archive')::boolean THEN coalesce(archive_a,now()) END ELSE archive_a END,
      version=version+1,modifie_a=now() WHERE utilisateur=u AND id=ancienne.id RETURNING * INTO nouvelle;
  ELSE
    INSERT INTO vision_fiches(utilisateur,titre,contenu,suivi,alias,tags,priorite)
      VALUES(u,p->>'titre',p->>'contenu',coalesce(p->>'suivi',''),
        ARRAY(SELECT jsonb_array_elements_text(coalesce(p->'alias','[]'))),
        ARRAY(SELECT jsonb_array_elements_text(coalesce(p->'tags','[]'))),coalesce((p->>'priorite')::integer,0)) RETURNING * INTO nouvelle;
  END IF;
  INSERT INTO vision_journal(utilisateur,objet,objet_id,operation,avant,apres)
    VALUES(u,'fiche',nouvelle.id,'enregistrer',coalesce(vision_fiche_publique(ancienne),'{}'),vision_fiche_publique(nouvelle));
  RETURN jsonb_build_object('enregistre',true,'fiche',vision_fiche_publique(nouvelle));
END $$;

CREATE OR REPLACE FUNCTION vision_ecrire_item(u text,p jsonb) RETURNS jsonb LANGUAGE plpgsql AS $$
DECLARE ancien vision_items; nouveau vision_items; recherche vision_recherches; generation bigint;
BEGIN
  IF p ? 'id' THEN
    IF p ?| ARRAY['stabilite','reference_a'] THEN PERFORM vision_refuser('utiliser_evaluation'); END IF;
    SELECT * INTO ancien FROM vision_items WHERE utilisateur=u AND id=(p->>'id')::bigint FOR UPDATE;
    IF NOT FOUND THEN PERFORM vision_refuser('introuvable'); END IF;
    IF ancien.version IS DISTINCT FROM (p->>'version')::bigint THEN PERFORM vision_refuser('conflit'); END IF;
    UPDATE vision_items SET titre=coalesce(p->>'titre',titre),contenu=coalesce(p->>'contenu',contenu),
      suivi=coalesce(p->>'suivi',suivi),
      alias=CASE WHEN p ? 'alias' THEN ARRAY(SELECT jsonb_array_elements_text(p->'alias')) ELSE alias END,
      objectifs=CASE WHEN p ? 'objectifs' THEN ARRAY(SELECT jsonb_array_elements_text(p->'objectifs')) ELSE objectifs END,
      sens=CASE WHEN p ? 'sens' THEN ARRAY(SELECT jsonb_array_elements_text(p->'sens')) ELSE sens END,
      archive_a=CASE WHEN p ? 'archive' THEN CASE WHEN (p->>'archive')::boolean THEN coalesce(archive_a,now()) END ELSE archive_a END,
      version=version+1,modifie_a=now() WHERE utilisateur=u AND id=ancien.id RETURNING * INTO nouveau;
  ELSE
    SELECT * INTO recherche FROM vision_recherches WHERE utilisateur=u AND cle=(p->>'preuve_recherche')::uuid;
    SELECT catalogue INTO generation FROM vision_profils WHERE utilisateur=u;
    IF recherche.cle IS NULL OR recherche.cree_a<now()-interval '30 minutes'
      OR recherche.catalogue<>generation OR recherche.titre<>vision_normaliser(p->>'titre') THEN
      PERFORM vision_refuser('recherche_prealable_requise');
    END IF;
    IF NOT recherche.lus @> recherche.candidats THEN PERFORM vision_refuser('lire_candidats'); END IF;
    IF cardinality(recherche.candidats)>0 AND char_length(coalesce(p->>'distinction',''))<10 THEN
      PERFORM vision_refuser('distinguer_candidats');
    END IF;
    IF (p->>'reference_a')::timestamptz>now() THEN PERFORM vision_refuser('date_future'); END IF;
    IF coalesce((p->>'stabilite')::integer,-15)<>-15 AND char_length(coalesce(p->>'justification',''))<10 THEN
      PERFORM vision_refuser('initialisation_a_justifier');
    END IF;
    INSERT INTO vision_items(utilisateur,titre,contenu,alias,objectifs,sens,suivi,stabilite,reference_a,origine_reference)
    VALUES(u,p->>'titre',p->>'contenu',ARRAY(SELECT jsonb_array_elements_text(coalesce(p->'alias','[]'))),
      ARRAY(SELECT jsonb_array_elements_text(p->'objectifs')),ARRAY(SELECT jsonb_array_elements_text(p->'sens')),
      coalesce(p->>'suivi',''),coalesce((p->>'stabilite')::integer,-15),(p->>'reference_a')::timestamptz,
      CASE WHEN p->>'reference_a' IS NULL THEN 'inconnue' ELSE 'declaree' END) RETURNING * INTO nouveau;
    DELETE FROM vision_recherches WHERE cle=recherche.cle;
  END IF;
  UPDATE vision_profils SET catalogue=catalogue+1 WHERE utilisateur=u;
  INSERT INTO vision_journal(utilisateur,objet,objet_id,operation,avant,apres,justification)
    VALUES(u,'item',nouveau.id,'enregistrer',coalesce(vision_item_public(ancien),'{}'),vision_item_public(nouveau),coalesce(p->>'justification',''));
  RETURN jsonb_build_object('enregistre',true,'item',vision_item_public(nouveau));
END $$;

CREATE OR REPLACE FUNCTION vision_lier(u text,p jsonb) RETURNS jsonb LANGUAGE plpgsql AS $$
DECLARE fiche vision_fiches; item vision_items; changement integer;
BEGIN
  SELECT * INTO fiche FROM vision_fiches WHERE utilisateur=u AND id=(p->>'fiche_id')::bigint FOR UPDATE;
  SELECT * INTO item FROM vision_items WHERE utilisateur=u AND id=(p->>'item_id')::bigint;
  IF fiche.id IS NULL OR item.id IS NULL THEN PERFORM vision_refuser('introuvable'); END IF;
  IF fiche.version IS DISTINCT FROM (p->>'version_fiche')::bigint THEN PERFORM vision_refuser('conflit'); END IF;
  IF p->>'action'='detacher' THEN
    DELETE FROM vision_liens WHERE utilisateur=u AND fiche_id=fiche.id AND item_id=item.id;
  ELSE
    IF fiche.archive_a IS NOT NULL OR item.archive_a IS NOT NULL THEN PERFORM vision_refuser('objet_archive'); END IF;
    INSERT INTO vision_liens(utilisateur,fiche_id,item_id,contexte,ordre)
    VALUES(u,fiche.id,item.id,coalesce(p->>'contexte',''),coalesce((p->>'ordre')::integer,0))
    ON CONFLICT(utilisateur,fiche_id,item_id) DO UPDATE SET contexte=excluded.contexte,ordre=excluded.ordre
      WHERE (vision_liens.contexte,vision_liens.ordre) IS DISTINCT FROM (excluded.contexte,excluded.ordre);
  END IF;
  GET DIAGNOSTICS changement=ROW_COUNT;
  IF changement>0 THEN
    UPDATE vision_fiches SET version=version+1,modifie_a=now() WHERE utilisateur=u AND id=fiche.id RETURNING * INTO fiche;
    INSERT INTO vision_journal(utilisateur,objet,objet_id,operation,apres)
      VALUES(u,'lien',item.id,p->>'action',jsonb_build_object('fiche_id',fiche.id));
  END IF;
  RETURN jsonb_build_object('enregistre',true,'fiche',vision_fiche_publique(fiche),'item_id',item.id,'modifie',changement>0);
END $$;

CREATE OR REPLACE FUNCTION vision_evaluer(u text,p jsonb) RETURNS jsonb LANGUAGE plpgsql AS $$
DECLARE e jsonb; i vision_items; ancien vision_items; episode vision_episodes;
  q integer; delta integer; instant timestamptz; rapproche boolean; precedent integer; resultat jsonb:='[]';
  type_evenement text; sens text; aide text; total integer; distincts integer;
BEGIN
  SELECT count(*),count(DISTINCT x->>'item_id') INTO total,distincts FROM jsonb_array_elements(p->'evaluations') x;
  IF total<>distincts OR total NOT BETWEEN 1 AND 20 THEN PERFORM vision_refuser('items_distincts_requis'); END IF;
  FOR e IN SELECT value FROM jsonb_array_elements(p->'evaluations') LOOP
    SELECT * INTO i FROM vision_items WHERE utilisateur=u AND id=(e->>'item_id')::bigint FOR UPDATE;
    IF NOT FOUND THEN PERFORM vision_refuser('introuvable'); END IF;
    IF i.archive_a IS NOT NULL THEN PERFORM vision_refuser('objet_archive'); END IF;
    IF i.version IS DISTINCT FROM (e->>'version')::bigint THEN PERFORM vision_refuser('conflit'); END IF;
    ancien:=i;
    SELECT * INTO episode FROM vision_episodes WHERE utilisateur=u AND item_id=i.id AND cle=e->>'episode';
    IF coalesce(episode.version,0) IS DISTINCT FROM (e->>'version_episode')::bigint THEN PERFORM vision_refuser('conflit_episode'); END IF;
    IF episode.cle IS NOT NULL AND episode.enregistre_a<now()-interval '30 days' THEN PERFORM vision_refuser('episode_expire'); END IF;
    q:=(e->>'q')::integer;
    IF q IS NULL OR q NOT BETWEEN -20 AND 20 THEN PERFORM vision_refuser('ajustement_invalide'); END IF;
    IF abs(q)>5 AND char_length(coalesce(e->>'justification',''))<10 THEN PERFORM vision_refuser('ajustement_a_justifier'); END IF;
    type_evenement:=coalesce(e->>'type_evenement','rappel');
    instant:=CASE WHEN coalesce((e->>'date_inconnue')::boolean,false) THEN NULL
      WHEN e ? 'evenement_a' THEN (e->>'evenement_a')::timestamptz ELSE now() END;
    IF instant>now()+interval '5 minutes' OR instant<'1900-01-01'::timestamptz THEN PERFORM vision_refuser('date_invalide'); END IF;
    IF episode.cle IS NOT NULL THEN
      -- Une précision conserve la date de la tentative originale.
      IF e ? 'evenement_a' AND instant IS DISTINCT FROM episode.evenement_a THEN PERFORM vision_refuser('date_episode_immuable'); END IF;
      instant:=episode.evenement_a;
    END IF;
    sens:=coalesce(e->>'sens',''); aide:=coalesce(e->>'aide','aucune');
    IF NOT sens=ANY(i.sens) THEN PERFORM vision_refuser('sens_invalide'); END IF;
    IF aide NOT IN ('aucune','indice','correction') THEN PERFORM vision_refuser('aide_invalide'); END IF;
    IF type_evenement NOT IN ('rappel','apprentissage','suivi') THEN PERFORM vision_refuser('evenement_invalide'); END IF;
    IF type_evenement IN ('apprentissage','suivi') AND q<>0 THEN PERFORM vision_refuser('rappel_requis'); END IF;
    IF aide='correction' AND q>0 OR aide='indice' AND q>1 THEN PERFORM vision_refuser('gain_aide_excessif'); END IF;
    rapproche:=CASE WHEN episode.cle IS NOT NULL THEN episode.rapproche
      ELSE instant IS NULL OR i.reference_a IS NULL OR instant-i.reference_a<interval '1 day' END;
    delta:=q-coalesce(episode.q,0);
    IF rapproche AND q>1 THEN PERFORM vision_refuser('gain_rapproche_excessif'); END IF;
    IF rapproche AND delta>0 THEN
      SELECT coalesce(sum(greatest(a.q,0)),0) INTO precedent FROM vision_episodes a WHERE a.utilisateur=u
        AND a.item_id=i.id AND a.rapproche AND a.enregistre_a>now()-interval '1 day' AND a.cle<>e->>'episode';
      IF precedent+greatest(q,0)>1 THEN PERFORM vision_refuser('gain_rapproche_deja_applique'); END IF;
    END IF;
    IF i.stabilite+delta NOT BETWEEN -128 AND 127 THEN PERFORM vision_refuser('borne_stabilite'); END IF;
    -- Un ancien événement est daté honnêtement ; il ne remplace pas la référence récente.
    UPDATE vision_items SET stabilite=stabilite+delta,suivi=coalesce(e->>'suivi',suivi),
      reference_a=CASE WHEN type_evenement<>'suivi' AND instant IS NOT NULL THEN greatest(reference_a,instant) ELSE reference_a END,
      origine_reference=CASE WHEN type_evenement<>'suivi' AND instant IS NOT NULL AND (reference_a IS NULL OR instant>=reference_a)
        THEN type_evenement ELSE origine_reference END,
      evalue=evalue OR type_evenement='rappel',
      evalue_a=CASE WHEN type_evenement='rappel' AND instant IS NOT NULL THEN greatest(evalue_a,instant) ELSE evalue_a END,
      version=version+1,modifie_a=now() WHERE utilisateur=u AND id=i.id RETURNING * INTO i;
    INSERT INTO vision_episodes(utilisateur,item_id,cle,conversation,q,stabilite_avant,evenement_a,sens,aide,rapproche)
      VALUES(u,i.id,e->>'episode',p->>'conversation',q,ancien.stabilite,instant,sens,aide,rapproche)
      ON CONFLICT(utilisateur,item_id,cle) DO UPDATE SET q=excluded.q,version=vision_episodes.version+1,
        sens=excluded.sens,aide=excluded.aide RETURNING * INTO episode;
    INSERT INTO vision_journal(utilisateur,objet,objet_id,operation,episode,delta,avant,apres,evenement_a,justification)
      VALUES(u,'item',i.id,'evaluer',episode.cle,delta,
        jsonb_build_object('stabilite',ancien.stabilite,'suivi',ancien.suivi,'reference_a',ancien.reference_a),
        jsonb_build_object('stabilite',i.stabilite,'suivi',i.suivi,'reference_a',i.reference_a),instant,coalesce(e->>'justification',''));
    resultat:=resultat||jsonb_build_array(jsonb_build_object('item',vision_item_public(i),'episode',episode.cle,
      'version_episode',episode.version,'q_cumulatif',q,'delta_applique',delta,
      'horodatage',CASE WHEN instant IS NULL THEN 'inconnu' WHEN e ? 'evenement_a' THEN 'fourni' ELSE 'echange_courant_serveur' END));
  END LOOP;
  RETURN jsonb_build_object('enregistre',true,'evaluations',resultat);
END $$;

CREATE OR REPLACE FUNCTION vision_ecrire_contexte(u text,p jsonb) RETURNS jsonb LANGUAGE plpgsql AS $$
DECLARE c vision_contextes; ids bigint[]:=ARRAY(SELECT jsonb_array_elements_text(coalesce(p->'items','[]'))::bigint);
BEGIN
  SELECT * INTO c FROM vision_contextes WHERE utilisateur=u AND conversation=p->>'conversation' FOR UPDATE;
  IF coalesce(c.version,0) IS DISTINCT FROM (p->>'version')::bigint THEN PERFORM vision_refuser('conflit'); END IF;
  IF EXISTS(SELECT unnest(ids) EXCEPT SELECT id FROM vision_items WHERE utilisateur=u) THEN PERFORM vision_refuser('introuvable'); END IF;
  INSERT INTO vision_contextes(utilisateur,conversation,fiche_id,items,reprise,questions)
    VALUES(u,p->>'conversation',(p->>'fiche_id')::bigint,ids,coalesce(p->>'reprise',''),coalesce(p->'questions','[]'))
    ON CONFLICT(utilisateur,conversation) DO UPDATE SET fiche_id=excluded.fiche_id,items=excluded.items,
      reprise=excluded.reprise,questions=excluded.questions,version=vision_contextes.version+1,modifie_a=now() RETURNING * INTO c;
  RETURN jsonb_build_object('enregistre',true,'contexte',to_jsonb(c)-'utilisateur');
END $$;

CREATE OR REPLACE FUNCTION vision_commande(u text,op text,p jsonb) RETURNS jsonb LANGUAGE plpgsql AS $$
DECLARE empreinte text:=encode(sha256(convert_to(op||p::text,'UTF8')),'hex'); deja vision_requetes; resultat jsonb; pr vision_profils;
BEGIN
  IF u IS NULL OR u='' THEN RETURN jsonb_build_object('erreur','identite_requise'); END IF;
  IF p->>'emise_a' IS NULL OR (p->>'emise_a')::timestamptz<now()-interval '30 days'
    OR (p->>'emise_a')::timestamptz>now()+interval '5 minutes' THEN RETURN jsonb_build_object('erreur','requete_expiree'); END IF;
  IF char_length(coalesce(p->>'cle','')) NOT BETWEEN 8 AND 100 THEN RETURN jsonb_build_object('erreur','cle_requise'); END IF;
  PERFORM pg_advisory_xact_lock(hashtextextended(u,718));
  INSERT INTO vision_profils(utilisateur) VALUES(u) ON CONFLICT DO NOTHING;
  SELECT * INTO deja FROM vision_requetes WHERE utilisateur=u AND cle=p->>'cle';
  IF FOUND THEN
    IF deja.empreinte<>empreinte THEN RETURN jsonb_build_object('erreur','cle_reutilisee'); END IF;
    RETURN deja.resultat||jsonb_build_object('rejeu',true);
  END IF;
  BEGIN
    CASE op
      WHEN 'enregistrer_fiche' THEN resultat:=vision_ecrire_fiche(u,p);
      WHEN 'enregistrer_item' THEN resultat:=vision_ecrire_item(u,p);
      WHEN 'lier_item' THEN resultat:=vision_lier(u,p);
      WHEN 'evaluer_items' THEN resultat:=vision_evaluer(u,p);
      WHEN 'enregistrer_contexte' THEN resultat:=vision_ecrire_contexte(u,p);
      WHEN 'regler_politique' THEN
        SELECT * INTO pr FROM vision_profils WHERE utilisateur=u;
        IF pr.version IS DISTINCT FROM (p->>'version')::bigint THEN PERFORM vision_refuser('conflit'); END IF;
        UPDATE vision_profils SET intervalle_jours=(p->>'intervalle_jours')::integer,budget=(p->>'budget')::integer,
          version=version+1 WHERE utilisateur=u;
        resultat:=jsonb_build_object('enregistre',true);
      ELSE PERFORM vision_refuser('operation_inconnue');
    END CASE;
    PERFORM vision_ajuster_charge(u);
    resultat:=resultat||jsonb_build_object('politique',vision_politique(u),'maintenant',now());
    INSERT INTO vision_requetes(utilisateur,cle,empreinte,resultat) VALUES(u,p->>'cle',empreinte,resultat);
    -- Rétention explicite ; les requêtes expirées restent refusées après purge.
    DELETE FROM vision_requetes WHERE utilisateur=u AND enregistre_a<now()-interval '35 days';
    DELETE FROM vision_episodes WHERE utilisateur=u AND enregistre_a<now()-interval '90 days';
    DELETE FROM vision_journal WHERE utilisateur=u AND (enregistre_a<now()-interval '180 days' OR id IN
      (SELECT id FROM vision_journal WHERE utilisateur=u ORDER BY id DESC OFFSET 5000));
    DELETE FROM vision_contextes WHERE utilisateur=u AND (modifie_a<now()-interval '90 days' OR conversation IN
      (SELECT conversation FROM vision_contextes WHERE utilisateur=u ORDER BY modifie_a DESC OFFSET 50));
    RETURN resultat;
  EXCEPTION WHEN raise_exception THEN RETURN jsonb_build_object('erreur',SQLERRM);
    WHEN integrity_constraint_violation OR data_exception THEN RETURN jsonb_build_object('erreur','donnees_invalides');
  END;
END $$;

INSERT INTO vision_schema_migrations(version) VALUES(7) ON CONFLICT DO NOTHING;
COMMIT;
