BEGIN;

-- Les séances historiques restent ouvertes et consultables.
CREATE OR REPLACE FUNCTION vision_lister_seances(u text,limite integer,decalage integer)
RETURNS jsonb LANGUAGE plpgsql STABLE AS $$
DECLARE total integer; page jsonb;
BEGIN
  SELECT count(*) INTO total FROM vision_seances WHERE utilisateur=u AND etat='ouverte';
  SELECT coalesce(jsonb_agg(to_jsonb(s) ORDER BY s.cree_a DESC,s.id DESC),'[]'::jsonb)
    INTO page FROM (
      SELECT s.id,s.fiche_id,f.titre AS theme,s.cree_a,s.conversation,
        jsonb_array_length(s.items) AS nombre_questions
      FROM vision_seances s JOIN vision_fiches f ON f.id=s.fiche_id AND f.utilisateur=u
      WHERE s.utilisateur=u AND s.etat='ouverte'
      ORDER BY s.cree_a DESC,s.id DESC LIMIT limite OFFSET decalage
    ) s;
  RETURN jsonb_build_object('seances',page,'total',total,'decalage',decalage,
    'suite',decalage+jsonb_array_length(page)<total);
END $$;

CREATE OR REPLACE FUNCTION vision_seances_en_attente(u text) RETURNS jsonb LANGUAGE sql STABLE AS $$
  SELECT vision_lister_seances(u,20,0)->'seances'
$$;

CREATE OR REPLACE FUNCTION vision_lire_seance(u text,p jsonb) RETURNS jsonb LANGUAGE plpgsql STABLE AS $$
DECLARE s vision_seances; f vision_fiches;
BEGIN
  SELECT * INTO s FROM vision_seances WHERE utilisateur=u AND id=(p->>'seance_id')::uuid;
  IF NOT FOUND THEN RETURN jsonb_build_object('erreur','seance_introuvable'); END IF;
  SELECT * INTO f FROM vision_fiches WHERE utilisateur=u AND id=s.fiche_id;
  RETURN jsonb_build_object('seance',jsonb_build_object('id',s.id,'etat',s.etat,
    'fiche_id',s.fiche_id,'theme',f.titre,'cree_a',s.cree_a,'terminee_a',s.terminee_a,
    'conversation',s.conversation,'nombre_questions',jsonb_array_length(s.items)),
    'usage_assistant',jsonb_build_object('fiche',vision_fiche_publique(f),'items',s.items),
    'rapport',s.rapport,
    'message',CASE WHEN s.etat='ouverte' THEN
      'Vision conserve le lot préparé, mais aucune réponse de la conversation. Reprendre si les réponses sont connues ; une clôture sans évaluation est possible sur demande.'
      ELSE 'Cette séance est terminée.' END);
END $$;

CREATE OR REPLACE FUNCTION vision_ouvrir_seance(u text,p jsonb) RETURNS jsonb LANGUAGE plpgsql AS $$
DECLARE lot jsonb; total integer; attente jsonb; s vision_seances; f vision_fiches;
  limite integer:=coalesce((p->>'limite')::integer,8);
BEGIN
  SELECT * INTO f FROM vision_fiches WHERE utilisateur=u AND id=(p->>'fiche_id')::bigint AND archive_a IS NULL;
  IF NOT FOUND THEN PERFORM vision_refuser('introuvable'); END IF;
  attente:=vision_lister_seances(u,20,0);
  IF (attente->>'total')::integer>0 AND NOT coalesce((p->>'nouvelle_seance')::boolean,false) THEN
    RETURN jsonb_build_object('enregistre',false,'confirmation_requise',true,
      'seances_en_attente',attente->'seances','total_seances_ouvertes',attente->'total',
      'suite_seances_ouvertes',attente->'suite',
      'message','Des séances sont ouvertes. Demander : voulez-vous ouvrir une nouvelle séance ou obtenir des informations sur les séances ouvertes ? Pour la première réponse, rappeler ouvrir_seance avec nouvelle_seance=true ; pour la seconde, appeler lister_seances.');
  END IF;
  SELECT count(*) INTO total FROM vision_candidats(u,f.id) c
    WHERE c.urgence>=-1 OR c.fenetre->>'etat'='reference_inconnue';
  WITH candidats AS (
    SELECT c.item_id,c.fenetre,i.suivi,i.evalue
      FROM vision_candidats(u,f.id) c JOIN vision_items i ON i.id=c.item_id AND i.utilisateur=u
      WHERE c.urgence>=-1 OR c.fenetre->>'etat'='reference_inconnue'
      ORDER BY (i.suivi<>'') DESC,(NOT i.evalue) DESC,c.urgence DESC NULLS LAST,c.item_id
      LIMIT limite
  ) SELECT coalesce(jsonb_agg(vision_item_public(i)||jsonb_build_object('fenetre',c.fenetre)
      ORDER BY (c.suivi<>'') DESC,(NOT c.evalue) DESC,c.item_id),'[]'::jsonb)
    INTO lot FROM candidats c JOIN vision_items i ON i.id=c.item_id AND i.utilisateur=u;
  IF jsonb_array_length(lot)=0 THEN
    RETURN jsonb_build_object('enregistre',false,'nombre_items_disponibles',0,'seances_en_attente',attente->'seances');
  END IF;
  INSERT INTO vision_seances(utilisateur,conversation,fiche_id,items)
    VALUES(u,p->>'conversation',f.id,lot) RETURNING * INTO s;
  RETURN jsonb_build_object('enregistre',true,'seance_id',s.id,'etat',s.etat,
    'conversation',s.conversation,'fiche_id',s.fiche_id,'cree_a',s.cree_a,
    'nombre_questions',jsonb_array_length(lot),'nombre_items_disponibles',total,
    'usage_assistant',jsonb_build_object('fiche',vision_fiche_publique(f),'items',lot),
    'seances_en_attente',attente->'seances','total_seances_ouvertes',attente->'total',
    'consigne','Annoncer une séance d’environ nombre_questions questions, demander si la personne est prête. Poser les questions une par une sans dévoiler les réponses des suivantes. Recueillir le retour final, puis appeler clore_seance une seule fois avec les évaluations et ce retour.');
END $$;

CREATE OR REPLACE FUNCTION vision_clore_seance(u text,p jsonb) RETURNS jsonb LANGUAGE plpgsql AS $$
DECLARE s vision_seances; e jsonb; retour jsonb:=p->'retour'; evaluations jsonb:=p->'evaluations';
  bilan jsonb; bilan_final jsonb; normalisees jsonb:='[]'::jsonb; ajustements jsonb:='[]'::jsonb;
  item_courant vision_items; version_preparee bigint; q_demande integer; q_applique integer;
  maximum integer; precedent integer; instant timestamptz; rapproche boolean; motif text;
BEGIN
  SELECT * INTO s FROM vision_seances WHERE utilisateur=u AND id=(p->>'seance_id')::uuid FOR UPDATE;
  IF NOT FOUND THEN PERFORM vision_refuser('seance_introuvable'); END IF;
  IF s.etat<>'ouverte' THEN PERFORM vision_refuser('seance_terminee'); END IF;
  IF jsonb_typeof(evaluations)<>'array' OR jsonb_array_length(evaluations)>20 THEN
    PERFORM vision_refuser('evaluations_invalides');
  END IF;
  FOR e IN SELECT value FROM jsonb_array_elements(evaluations) LOOP
    IF NOT EXISTS(SELECT 1 FROM jsonb_array_elements(s.items) i WHERE (i->>'id')::bigint=(e->>'item_id')::bigint) THEN
      PERFORM vision_refuser('item_hors_seance');
    END IF;
    IF NOT EXISTS(SELECT 1 FROM jsonb_array_elements(p->'deroulement') d
        WHERE d->>'item_id'=e->>'item_id' AND d->>'etat'='tente') THEN
      PERFORM vision_refuser('tentative_sans_deroulement');
    END IF;
  END LOOP;
  FOR e IN SELECT value FROM jsonb_array_elements(retour->'reformulations') LOOP
    IF NOT EXISTS(SELECT 1 FROM jsonb_array_elements(s.items) i WHERE (i->>'id')::bigint=(e->>'item_id')::bigint) THEN
      PERFORM vision_refuser('item_hors_seance');
    END IF;
  END LOOP;
  FOR e IN SELECT value FROM jsonb_array_elements(p->'deroulement') LOOP
    IF NOT EXISTS(SELECT 1 FROM jsonb_array_elements(s.items) i WHERE (i->>'id')::bigint=(e->>'item_id')::bigint) THEN
      PERFORM vision_refuser('item_hors_seance');
    END IF;
  END LOOP;
  -- Le lot peut avoir vieilli pendant que d'autres séances sur les mêmes items ont été closes.
  -- Les évaluations indépendantes sont recalculées sur l'état courant, sans modifier la trace demandée.
  FOR e IN SELECT value FROM jsonb_array_elements(evaluations) LOOP
    SELECT * INTO item_courant FROM vision_items WHERE utilisateur=u AND id=(e->>'item_id')::bigint FOR UPDATE;
    SELECT (x->>'version')::bigint INTO version_preparee
      FROM jsonb_array_elements(s.items) x WHERE x->>'id'=e->>'item_id' LIMIT 1;
    IF item_courant.id IS NULL OR ((e->>'version')::bigint<>version_preparee AND
                        (e->>'version')::bigint<>item_courant.version) THEN
      PERFORM vision_refuser('conflit');
    END IF;
    q_demande:=(e->>'q')::integer;
    q_applique:=q_demande;
    motif:='';
    IF coalesce(e->>'type_evenement','rappel')='rappel' AND q_demande>0 THEN
      instant:=CASE WHEN coalesce((e->>'date_inconnue')::boolean,false) THEN NULL
        WHEN e ? 'evenement_a' THEN (e->>'evenement_a')::timestamptz ELSE now() END;
      rapproche:=instant IS NULL OR item_courant.reference_a IS NULL OR instant-item_courant.reference_a<interval '1 day';
      maximum:=CASE WHEN e->>'aide'='correction' THEN 0
        WHEN rapproche OR e->>'aide'='indice' THEN 1 ELSE 20 END;
      IF rapproche THEN
        SELECT coalesce(sum(greatest(a.q,0)),0) INTO precedent FROM vision_episodes a
          WHERE a.utilisateur=u AND a.item_id=item_courant.id AND a.rapproche
            AND a.enregistre_a>now()-interval '1 day' AND a.cle<>e->>'episode';
        maximum:=least(maximum,greatest(0,1-precedent));
      END IF;
      q_applique:=least(q_demande,maximum);
      IF q_applique<q_demande THEN
        motif:=CASE WHEN e->>'aide'='correction' THEN 'correction_devoilee'
          WHEN rapproche THEN 'gain_rapproche_limite' ELSE 'indice' END;
      END IF;
    END IF;
    IF q_applique<>q_demande OR item_courant.version<>(e->>'version')::bigint THEN
      ajustements:=ajustements||jsonb_build_array(jsonb_build_object('item_id',item_courant.id,
        'q_demande',q_demande,'q_applique',q_applique,'motif',motif,
        'version_demandee',(e->>'version')::bigint,'version_appliquee',item_courant.version));
    END IF;
    normalisees:=normalisees||jsonb_build_array(e||jsonb_build_object('q',q_applique,'version',item_courant.version));
  END LOOP;
  IF jsonb_array_length(normalisees)>0 THEN
    bilan:=vision_evaluer(u,(p||jsonb_build_object('evaluations',normalisees,'conversation',s.conversation)));
  ELSE bilan:=jsonb_build_object('enregistre',true,'evaluations','[]'::jsonb);
  END IF;
  bilan_final:=jsonb_build_object('seance_id',s.id,'fiche_id',s.fiche_id,
    'questions_preparees',jsonb_array_length(s.items),
    'tentatives_enregistrees',jsonb_array_length(evaluations),
    'evaluations',bilan->'evaluations','evaluations_demandees',evaluations,
    'ajustements',ajustements,'deroulement',p->'deroulement',
    'retour',retour,'synthese',coalesce(p->>'synthese',''),
    'propositions_en_attente',jsonb_build_object('reformulations',retour->'reformulations','ajouts',retour->'ajouts'));
  UPDATE vision_seances SET etat='terminee',retour=p->'retour',rapport=bilan_final,terminee_a=now()
    WHERE id=s.id;
  RETURN jsonb_build_object('enregistre',true,'rapport',bilan_final);
END $$;

-- preparer_revision reste la lecture des suggestions ; une séance ciblée doit être ouverte explicitement.
CREATE OR REPLACE FUNCTION vision_preparer(u text,p jsonb) RETURNS jsonb LANGUAGE plpgsql AS $$
DECLARE resultat jsonb; contexte jsonb; limite integer:=coalesce((p->>'limite')::integer,8);
BEGIN
  SELECT to_jsonb(c)-'utilisateur' INTO contexte FROM vision_contextes c
    WHERE utilisateur=u AND conversation=p->>'conversation' AND modifie_a>now()-interval '90 days';
  IF p ? 'fiche_id' THEN RETURN jsonb_build_object('erreur','utiliser_ouvrir_seance',
    'seances_en_attente',vision_seances_en_attente(u)); END IF;
  WITH candidats AS (
    SELECT c.*,row_number() OVER(PARTITION BY c.fiche_id ORDER BY c.urgence DESC NULLS LAST,c.item_id) AS rang
    FROM vision_candidats(u) c WHERE c.urgence>=-1 OR c.fenetre->>'etat'='reference_inconnue'
  ), groupes AS (
    SELECT fiche_id,count(*) AS nombre,avg(least(coalesce(urgence,-1),20)) FILTER(WHERE rang<=3)
        + least(count(*),5)*0.1 AS score FROM candidats GROUP BY fiche_id
  ) SELECT coalesce(jsonb_agg(to_jsonb(a)),'[]'::jsonb) INTO resultat FROM (
    SELECT f.id,f.titre,g.nombre AS nombre_items,g.score FROM groupes g JOIN vision_fiches f ON f.id=g.fiche_id AND f.utilisateur=u
    ORDER BY g.score DESC,f.id LIMIT limite) a;
  RETURN jsonb_build_object('suggestions',resultat,'contexte',contexte,'maintenant',now(),
    'politique',vision_politique(u),'seances_en_attente',vision_seances_en_attente(u),
    'total_seances_ouvertes',vision_lister_seances(u,1,0)->'total',
    'message','Si des séances sont ouvertes, demander : voulez-vous ouvrir une nouvelle séance ou obtenir des informations sur les séances ouvertes ? Fenêtres indicatives, aucune preuve d’oubli.');
END $$;

CREATE OR REPLACE FUNCTION vision_commande(u text,op text,p jsonb) RETURNS jsonb LANGUAGE plpgsql AS $$
DECLARE empreinte text:=encode(sha256(convert_to(op||p::text,'UTF8')),'hex'); deja vision_requetes; resultat jsonb; pr vision_profils;
BEGIN
  IF u IS NULL OR u='' THEN RETURN jsonb_build_object('erreur','identite_requise'); END IF;
  IF p->>'emise_a' IS NULL OR (p->>'emise_a')::timestamptz<now()-interval '30 days'
    OR (p->>'emise_a')::timestamptz>now()+interval '5 minutes' THEN RETURN jsonb_build_object('erreur','requete_expiree'); END IF;
  IF char_length(coalesce(p->>'cle','')) NOT BETWEEN 8 AND 100 THEN RETURN jsonb_build_object('erreur','cle_requise'); END IF;
  PERFORM pg_advisory_xact_lock(hashtextextended(u,718));
  INSERT INTO vision_profils(utilisateur) VALUES(u) ON CONFLICT DO NOTHING;
  SELECT * INTO deja FROM vision_requetes WHERE utilisateur=u AND cle=p->>'cle';
  IF FOUND THEN
    IF deja.empreinte<>empreinte THEN RETURN jsonb_build_object('erreur','cle_reutilisee'); END IF;
    RETURN deja.resultat||jsonb_build_object('rejeu',true);
  END IF;
  BEGIN
    CASE op
      WHEN 'enregistrer_fiche' THEN resultat:=vision_ecrire_fiche(u,p);
      WHEN 'enregistrer_item' THEN resultat:=vision_ecrire_item(u,p);
      WHEN 'lier_item' THEN resultat:=vision_lier(u,p);
      WHEN 'evaluer_items' THEN resultat:=vision_evaluer(u,p);
      WHEN 'enregistrer_contexte' THEN resultat:=vision_ecrire_contexte(u,p);
      WHEN 'regler_politique' THEN
        SELECT * INTO pr FROM vision_profils WHERE utilisateur=u;
        IF pr.version IS DISTINCT FROM (p->>'version')::bigint THEN PERFORM vision_refuser('conflit'); END IF;
        UPDATE vision_profils SET intervalle_jours=(p->>'intervalle_jours')::integer,budget=(p->>'budget')::integer,
          version=version+1 WHERE utilisateur=u;
        resultat:=jsonb_build_object('enregistre',true);
      WHEN 'ouvrir_seance' THEN resultat:=vision_ouvrir_seance(u,p);
      WHEN 'clore_seance' THEN resultat:=vision_clore_seance(u,p);
      ELSE PERFORM vision_refuser('operation_inconnue');
    END CASE;
    PERFORM vision_ajuster_charge(u);
    resultat:=resultat||jsonb_build_object('politique',vision_politique(u),'maintenant',now());
    INSERT INTO vision_requetes(utilisateur,cle,empreinte,resultat) VALUES(u,p->>'cle',empreinte,resultat);
    DELETE FROM vision_requetes WHERE utilisateur=u AND enregistre_a<now()-interval '35 days';
    DELETE FROM vision_episodes WHERE utilisateur=u AND enregistre_a<now()-interval '90 days';
    DELETE FROM vision_journal WHERE utilisateur=u AND (enregistre_a<now()-interval '180 days' OR id IN
      (SELECT id FROM vision_journal WHERE utilisateur=u ORDER BY id DESC OFFSET 5000));
    DELETE FROM vision_contextes WHERE utilisateur=u AND (modifie_a<now()-interval '90 days' OR conversation IN
      (SELECT conversation FROM vision_contextes WHERE utilisateur=u ORDER BY modifie_a DESC OFFSET 50));
    RETURN resultat;
  EXCEPTION WHEN raise_exception THEN RETURN jsonb_build_object('erreur',SQLERRM);
    WHEN integrity_constraint_violation OR data_exception THEN RETURN jsonb_build_object('erreur','donnees_invalides');
  END;
END $$;

INSERT INTO vision_schema_migrations(version) VALUES(12) ON CONFLICT DO NOTHING;
COMMIT;
