BEGIN;

CREATE OR REPLACE FUNCTION vision_source_historique() RETURNS jsonb LANGUAGE sql STABLE AS $$
  SELECT jsonb_build_object('fiches',coalesce((SELECT jsonb_agg(to_jsonb(f) ORDER BY id) FROM vision_memory_sheets f),'[]'),
    'observations',coalesce((SELECT jsonb_agg(to_jsonb(o) ORDER BY id) FROM vision_memory_observations o),'[]'),
    'corrections',coalesce((SELECT jsonb_agg(to_jsonb(c) ORDER BY id) FROM vision_observation_corrections c),'[]'))
$$;

CREATE OR REPLACE FUNCTION vision_legacy_fige() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF EXISTS(SELECT 1 FROM vision_migrations_metier WHERE cle='fiches-items-v2') THEN
    RAISE EXCEPTION 'Modele historique archive : utiliser Vision 2. Aucune ecriture perdue.';
  END IF;
  RETURN coalesce(NEW,OLD);
END $$;

CREATE OR REPLACE FUNCTION vision_importer(u text,p jsonb) RETURNS jsonb LANGUAGE plpgsql AS $$
DECLARE source jsonb; fiche jsonb; item jsonb; f bigint; i bigint; plan_item jsonb; resultat jsonb;
BEGIN
  PERFORM pg_advisory_xact_lock(hashtextextended(u,718));
  SELECT rapport INTO resultat FROM vision_migrations_metier WHERE cle='fiches-items-v2' AND utilisateur=u;
  IF FOUND THEN RETURN resultat||jsonb_build_object('rejeu',true); END IF;
  IF EXISTS(SELECT 1 FROM vision_migrations_metier WHERE cle='fiches-items-v2') THEN PERFORM vision_refuser('autre_proprietaire'); END IF;
  LOCK TABLE vision_memory_sheets,vision_memory_observations,vision_observation_corrections IN SHARE ROW EXCLUSIVE MODE;
  source:=vision_source_historique();
  IF encode(sha256(convert_to(source::text,'UTF8')),'hex') IS DISTINCT FROM p->>'empreinte_source' THEN
    PERFORM vision_refuser('source_modifiee_repreparer');
  END IF;
  IF EXISTS(SELECT 1 FROM vision_fiches WHERE utilisateur=u) OR EXISTS(SELECT 1 FROM vision_items WHERE utilisateur=u) THEN
    PERFORM vision_refuser('collection_v2_non_vide');
  END IF;
  INSERT INTO vision_profils(utilisateur) VALUES(u) ON CONFLICT DO NOTHING;
  FOR fiche IN SELECT value FROM jsonb_array_elements(p->'fiches') LOOP
    f:=(fiche->>'id')::bigint;
    INSERT INTO vision_fiches(id,utilisateur,titre,contenu,alias,tags,priorite,cree_a,modifie_a,archive_a)
      VALUES(f,u,fiche->>'titre',fiche->>'contenu',ARRAY(SELECT jsonb_array_elements_text(fiche->'alias')),
        ARRAY(SELECT jsonb_array_elements_text(fiche->'tags')),(fiche->>'priorite')::integer,
        (fiche->>'cree_a')::timestamptz,(fiche->>'modifie_a')::timestamptz,(fiche->>'archive_a')::timestamptz);
    FOR item IN SELECT value FROM jsonb_array_elements(fiche->'items') LOOP
      -- Le plan sémantique validé est préparé sur une collection v2 vide.
      -- Une clé sémantique commune relie les doublons explicitement identifiés.
      SELECT (valeur->>'id')::bigint INTO i FROM jsonb_each(coalesce(p->'items_deja_importes','{}')) AS x(cle,valeur)
        WHERE cle=item->>'cle';
      IF i IS NULL THEN
        INSERT INTO vision_items(utilisateur,titre,contenu,alias,objectifs,sens,suivi,stabilite,reference_a,origine_reference,evalue_a,evalue)
        VALUES(u,item->>'titre',item->>'contenu',ARRAY(SELECT jsonb_array_elements_text(item->'alias')),
          ARRAY(SELECT jsonb_array_elements_text(item->'objectifs')),ARRAY(SELECT jsonb_array_elements_text(item->'sens')),
          item->>'suivi',(item->>'stabilite')::integer,(item->>'reference_a')::timestamptz,
          CASE WHEN item->>'reference_a' IS NULL THEN 'inconnue' ELSE 'migration' END,(item->>'evalue_a')::timestamptz,item->>'evalue_a' IS NOT NULL)
          RETURNING id INTO i;
        p:=jsonb_set(p,'{items_deja_importes}',coalesce(p->'items_deja_importes','{}')||jsonb_build_object(item->>'cle',jsonb_build_object('id',i)));
        INSERT INTO vision_journal(utilisateur,objet,objet_id,operation,apres,justification,evenement_a)
          VALUES(u,'item',i,'migration',jsonb_build_object('stabilite',item->'stabilite','observations_source',item->'observations'),
            item->>'estimation',(item->>'evalue_a')::timestamptz);
      END IF;
      INSERT INTO vision_liens(utilisateur,fiche_id,item_id,ordre,contexte) VALUES(u,f,i,(item->>'ordre')::integer,coalesce(item->>'contexte',''))
        ON CONFLICT DO NOTHING;
    END LOOP;
  END LOOP;
  PERFORM setval(pg_get_serial_sequence('vision_fiches','id'),greatest(1,(SELECT max(id) FROM vision_fiches)),true);
  resultat:=p->'rapport'||jsonb_build_object('enregistre',true,'fiches_apres',(SELECT count(*) FROM vision_fiches WHERE utilisateur=u),
    'items_apres',(SELECT count(*) FROM vision_items WHERE utilisateur=u),'liens_apres',(SELECT count(*) FROM vision_liens WHERE utilisateur=u));
  INSERT INTO vision_migrations_metier(cle,utilisateur,source,rapport) VALUES('fiches-items-v2',u,source,resultat);
  UPDATE vision_profils SET catalogue=catalogue+1 WHERE utilisateur=u;
  RETURN resultat;
END $$;

DROP TRIGGER IF EXISTS vision_legacy_fige ON vision_memory_sheets;
CREATE TRIGGER vision_legacy_fige BEFORE INSERT OR UPDATE OR DELETE ON vision_memory_sheets FOR EACH ROW EXECUTE FUNCTION vision_legacy_fige();
DROP TRIGGER IF EXISTS vision_legacy_fige ON vision_memory_observations;
CREATE TRIGGER vision_legacy_fige BEFORE INSERT OR UPDATE OR DELETE ON vision_memory_observations FOR EACH ROW EXECUTE FUNCTION vision_legacy_fige();
DROP TRIGGER IF EXISTS vision_legacy_fige ON vision_observation_corrections;
CREATE TRIGGER vision_legacy_fige BEFORE INSERT OR UPDATE OR DELETE ON vision_observation_corrections FOR EACH ROW EXECUTE FUNCTION vision_legacy_fige();

INSERT INTO vision_schema_migrations(version) VALUES(8) ON CONFLICT DO NOTHING;
COMMIT;
