BEGIN;

CREATE OR REPLACE FUNCTION vision_item_public(i vision_items) RETURNS jsonb
LANGUAGE sql STABLE AS $$ SELECT to_jsonb(i)-'utilisateur'-'recherche'-'texte_recherche' $$;
CREATE OR REPLACE FUNCTION vision_fiche_publique(f vision_fiches) RETURNS jsonb
LANGUAGE sql STABLE AS $$ SELECT to_jsonb(f)-'utilisateur' $$;

CREATE OR REPLACE FUNCTION vision_politique(u text) RETURNS jsonb LANGUAGE sql STABLE AS $$
  SELECT coalesce((SELECT to_jsonb(p)-'utilisateur'-'catalogue' FROM vision_profils p WHERE utilisateur=u),
    jsonb_build_object('intervalle_jours',90,'budget',null,'decalage',0,'version',1))
$$;

CREATE OR REPLACE FUNCTION vision_rechercher(u text,p jsonb) RETURNS jsonb
LANGUAGE plpgsql AS $$
DECLARE q text := vision_normaliser(coalesce(p->>'requete','')); resultat jsonb; ids bigint[];
  total integer; preuve uuid; preparation boolean := coalesce((p->>'preparer_creation')::boolean,false);
  limite integer := coalesce((p->>'limite')::integer,20); decalage_page integer := coalesce((p->>'decalage')::integer,0);
BEGIN
  IF p->>'type'='fiche' THEN
    WITH candidats AS (
      SELECT f.*,count(*) OVER() AS total FROM vision_fiches f
      WHERE utilisateur=u
        AND (coalesce(p->>'etat','actif')='tous' OR (archive_a IS NOT NULL)=coalesce(p->>'etat'='archive',false))
        AND (q='' OR vision_normaliser(titre||' '||contenu||' '||array_to_string(alias,' ')) LIKE '%'||q||'%')
        AND tags @> ARRAY(SELECT jsonb_array_elements_text(coalesce(p->'tags','[]')))
    ), page AS (
      SELECT * FROM candidats ORDER BY
        CASE WHEN p->>'tri'='priorite' THEN priorite END DESC,
        CASE WHEN p->>'tri'='modification' THEN modifie_a END DESC,
        vision_normaliser(titre),id LIMIT limite OFFSET decalage_page
    )
    SELECT jsonb_build_object('resultats',coalesce(jsonb_agg(jsonb_build_object(
      'id',a.id,'titre',a.titre,'tags',a.tags,'alias',a.alias,'priorite',a.priorite,
      'version',a.version,'archive_a',a.archive_a,'modifie_a',a.modifie_a,
      'nombre_items',(SELECT count(*) FROM vision_liens l JOIN vision_items i ON i.id=l.item_id
         AND i.utilisateur=l.utilisateur WHERE l.utilisateur=u AND l.fiche_id=a.id AND i.archive_a IS NULL))), '[]'),
      'total',(SELECT count(*) FROM candidats),'limite',limite,'decalage',decalage_page,'politique',vision_politique(u),'maintenant',now()) INTO resultat FROM page a;
    RETURN resultat;
  END IF;
  IF preparation THEN
    IF btrim(q)='' OR decalage_page<>0 THEN RETURN jsonb_build_object('erreur','recherche_creation_invalide'); END IF;
    limite:=50;
    INSERT INTO vision_profils(utilisateur) VALUES(u) ON CONFLICT DO NOTHING;
    PERFORM pg_advisory_xact_lock(hashtextextended(u,718));
  END IF;
  WITH candidats AS (
    SELECT i.*,CASE WHEN q='' THEN 0::real ELSE ts_rank(i.texte_recherche,websearch_to_tsquery('french',q)) END AS rang
    FROM vision_items i WHERE utilisateur=u
      AND (preparation OR coalesce(p->>'etat','actif')='tous' OR (archive_a IS NOT NULL)=coalesce(p->>'etat'='archive',false))
      AND (q='' OR texte_recherche @@ websearch_to_tsquery('french',q)
        OR recherche LIKE '%'||q||'%' OR q <% recherche)
      AND (preparation OR NOT p ? 'fiche_id' OR EXISTS (SELECT 1 FROM vision_liens l WHERE l.utilisateur=u AND l.item_id=i.id AND l.fiche_id=(p->>'fiche_id')::bigint))
  ), page AS (
    SELECT * FROM candidats ORDER BY
      CASE WHEN p->>'tri'='stabilite' THEN stabilite END ASC,
      CASE WHEN p->>'tri'='modification' THEN modifie_a END DESC,
      rang DESC,vision_normaliser(titre),id LIMIT limite OFFSET decalage_page
  )
  SELECT coalesce(jsonb_agg(jsonb_build_object('id',a.id,'titre',a.titre,'alias',a.alias,
    'stabilite',a.stabilite,'evalue_a',a.evalue_a,'evalue',a.evalue,'version',a.version,'archive_a',a.archive_a)), '[]'),
    coalesce(array_agg(id),'{}'),(SELECT count(*) FROM candidats) INTO resultat,ids,total FROM page a;
  IF preparation AND total<=50 THEN
    DELETE FROM vision_recherches WHERE utilisateur=u AND cree_a < now()-interval '30 minutes';
    -- Un jeton couvre un instantané complet, y compris les items archivés.
    INSERT INTO vision_recherches(utilisateur,titre,catalogue,candidats)
      SELECT u,q,catalogue,ids FROM vision_profils WHERE utilisateur=u RETURNING cle INTO preuve;
  END IF;
  RETURN jsonb_build_object('resultats',resultat,'total',total,'limite',limite,'decalage',decalage_page,
    'preuve_recherche',preuve,'politique',vision_politique(u),'maintenant',now(),'suite',decalage_page+limite<total);
END $$;

CREATE OR REPLACE FUNCTION vision_lire(u text,p jsonb) RETURNS jsonb LANGUAGE plpgsql AS $$
DECLARE resultat jsonb; ids bigint[] := ARRAY(SELECT jsonb_array_elements_text(coalesce(p->'ids','[]'))::bigint);
  limite integer := coalesce((p->>'limite')::integer,50); decalage_page integer := coalesce((p->>'decalage')::integer,0);
BEGIN
  IF p->>'type'='fiche' THEN
    SELECT jsonb_build_object('objets',coalesce(jsonb_agg(vision_fiche_publique(f)||jsonb_build_object(
      'items',coalesce((SELECT jsonb_agg(a.objet) FROM (SELECT jsonb_build_object('id',i.id,'titre',i.titre,
        'stabilite',i.stabilite,'evalue_a',i.evalue_a,'evalue',i.evalue,'version',i.version,'contexte',l.contexte,'ordre',l.ordre,
        'fenetre',vision_fenetre(i.stabilite,f.priorite,coalesce(pr.intervalle_jours,90),coalesce(pr.decalage,0),i.reference_a)) AS objet
        FROM vision_liens l JOIN vision_items i ON i.utilisateur=l.utilisateur AND i.id=l.item_id
        LEFT JOIN vision_profils pr ON pr.utilisateur=u
        WHERE l.utilisateur=u AND l.fiche_id=f.id AND i.archive_a IS NULL ORDER BY l.ordre,i.id LIMIT limite OFFSET decalage_page) a),'[]'),
      'nombre_items',(SELECT count(*) FROM vision_liens l JOIN vision_items i ON i.id=l.item_id AND i.utilisateur=u
        WHERE l.utilisateur=u AND l.fiche_id=f.id AND i.archive_a IS NULL))), '[]'),
      'politique',vision_politique(u),'maintenant',now()) INTO resultat FROM vision_fiches f WHERE utilisateur=u AND id=ANY(ids);
  ELSE
    SELECT jsonb_build_object('objets',coalesce(jsonb_agg(vision_item_public(i)||jsonb_build_object(
      'fiches',coalesce((SELECT jsonb_agg(a.objet) FROM (SELECT jsonb_build_object('id',f.id,'titre',f.titre,'priorite',f.priorite,
         'contexte',l.contexte,'version',f.version,'archive_a',f.archive_a) AS objet FROM vision_liens l JOIN vision_fiches f
         ON f.utilisateur=l.utilisateur AND f.id=l.fiche_id WHERE l.utilisateur=u AND l.item_id=i.id ORDER BY f.id LIMIT limite OFFSET decalage_page) a),'[]'),
      'nombre_fiches',(SELECT count(*) FROM vision_liens l WHERE l.utilisateur=u AND l.item_id=i.id),
      'fenetre',vision_fenetre(i.stabilite,coalesce((SELECT max(f.priorite) FROM vision_liens l JOIN vision_fiches f
         ON f.utilisateur=l.utilisateur AND f.id=l.fiche_id WHERE l.utilisateur=u AND l.item_id=i.id AND f.archive_a IS NULL),0),
         coalesce(pr.intervalle_jours,90),coalesce(pr.decalage,0),i.reference_a))), '[]'),
      'politique',vision_politique(u),'maintenant',now()) INTO resultat
      FROM vision_items i LEFT JOIN vision_profils pr ON pr.utilisateur=u WHERE i.utilisateur=u AND i.id=ANY(ids);
    IF p ? 'preuve_recherche' THEN
      UPDATE vision_recherches r SET lus=ARRAY(SELECT DISTINCT unnest(r.lus||ids))
        WHERE r.utilisateur=u AND r.cle=(p->>'preuve_recherche')::uuid AND r.candidats @> ids;
    END IF;
  END IF;
  RETURN resultat;
END $$;

-- Une ligne par item distinct, priorité maximale seulement en suggestion globale.
CREATE OR REPLACE FUNCTION vision_candidats(u text,fiche bigint DEFAULT NULL,instant timestamptz DEFAULT now())
RETURNS TABLE(item_id bigint,fiche_id bigint,priorite integer,urgence numeric,fenetre jsonb)
LANGUAGE sql STABLE AS $$
  WITH liens AS (
    SELECT DISTINCT ON (l.item_id) l.item_id,l.fiche_id,f.priorite FROM vision_liens l
    JOIN vision_fiches f ON f.utilisateur=l.utilisateur AND f.id=l.fiche_id
    WHERE l.utilisateur=u AND f.archive_a IS NULL AND (fiche IS NULL OR f.id=fiche)
    ORDER BY l.item_id,f.priorite DESC,f.id
  ), candidats AS (
    SELECT i.id,liens.fiche_id,coalesce(liens.priorite,0)::integer AS priorite,
      vision_fenetre(i.stabilite,coalesce(liens.priorite,0),coalesce(pr.intervalle_jours,90),coalesce(pr.decalage,0),i.reference_a,instant) AS fenetre
    FROM vision_items i LEFT JOIN liens ON liens.item_id=i.id LEFT JOIN vision_profils pr ON pr.utilisateur=u
    WHERE i.utilisateur=u AND i.archive_a IS NULL AND (fiche IS NULL OR liens.item_id IS NOT NULL)
  ) SELECT id,fiche_id,priorite,(fenetre->>'urgence')::numeric,fenetre FROM candidats
$$;

CREATE OR REPLACE FUNCTION vision_preparer(u text,p jsonb) RETURNS jsonb LANGUAGE plpgsql AS $$
DECLARE resultat jsonb; contexte jsonb; limite integer:=coalesce((p->>'limite')::integer,8);
BEGIN
  IF p ? 'fiche_id' AND NOT EXISTS(SELECT 1 FROM vision_fiches WHERE utilisateur=u AND id=(p->>'fiche_id')::bigint AND archive_a IS NULL) THEN
    RETURN jsonb_build_object('erreur','introuvable');
  END IF;
  SELECT to_jsonb(c)-'utilisateur' INTO contexte FROM vision_contextes c
    WHERE utilisateur=u AND conversation=p->>'conversation' AND modifie_a>now()-interval '90 days';
  IF NOT p ? 'fiche_id' THEN
    WITH candidats AS (
      SELECT c.*,row_number() OVER(PARTITION BY c.fiche_id ORDER BY c.urgence DESC NULLS LAST,c.item_id) AS rang
      FROM vision_candidats(u) c WHERE c.urgence>=-1 OR c.fenetre->>'etat'='reference_inconnue'
    ), groupes AS (
      SELECT fiche_id,count(*) AS nombre,avg(least(coalesce(urgence,-1),20)) FILTER(WHERE rang<=3)
          + least(count(*),5)*0.1 AS score FROM candidats GROUP BY fiche_id
    ) SELECT coalesce(jsonb_agg(to_jsonb(a)),'[]') INTO resultat FROM (
      SELECT f.id,f.titre,g.nombre AS nombre_items,g.score FROM groupes g JOIN vision_fiches f ON f.id=g.fiche_id AND f.utilisateur=u
      ORDER BY g.score DESC,f.id LIMIT limite) a;
    RETURN jsonb_build_object('suggestions',resultat,'contexte',contexte,'maintenant',now(),
      'politique',vision_politique(u),'message','Fenêtres de planification indicatives ; aucune dette ni preuve d’oubli.');
  END IF;
  WITH candidats AS (
    SELECT c.*,i.evalue_a,i.suivi FROM vision_candidats(u,(p->>'fiche_id')::bigint) c JOIN vision_items i ON i.id=c.item_id AND i.utilisateur=u
    WHERE NOT c.item_id=ANY(ARRAY(SELECT jsonb_array_elements_text(coalesce(p->'exclus','[]'))::bigint))
      AND (coalesce((p->>'repeter')::boolean,false) OR NOT EXISTS(SELECT 1 FROM vision_episodes e WHERE e.utilisateur=u
        AND e.item_id=c.item_id AND e.enregistre_a>now()-interval '15 minutes'))
    ORDER BY (i.suivi<>'') DESC,(NOT i.evalue) DESC,c.urgence DESC NULLS LAST,c.item_id LIMIT limite
  ) SELECT coalesce(jsonb_agg(vision_item_public(i)||jsonb_build_object('fenetre',c.fenetre,
    'derniers_episodes',coalesce((SELECT jsonb_agg(to_jsonb(e)-'utilisateur') FROM (
      SELECT * FROM vision_episodes WHERE utilisateur=u AND item_id=i.id ORDER BY enregistre_a DESC LIMIT 4) e),'[]'))),'[]')
    INTO resultat FROM candidats c JOIN vision_items i ON i.id=c.item_id AND i.utilisateur=u;
  RETURN jsonb_build_object('usage_assistant',jsonb_build_object('items',resultat,'contexte',contexte,
    'fiche',(SELECT vision_fiche_publique(f) FROM vision_fiches f WHERE utilisateur=u AND id=(p->>'fiche_id')::bigint)),
    'politique',vision_politique(u),'maintenant',now(),'consigne','Poser une question sans annoncer les réponses, titres révélateurs ou difficultés ; attendre la réponse.');
END $$;

INSERT INTO vision_schema_migrations(version) VALUES(6) ON CONFLICT DO NOTHING;
COMMIT;
