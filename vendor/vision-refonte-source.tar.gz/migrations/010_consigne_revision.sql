BEGIN;

-- Rappeler la boucle d'écriture dans chaque réponse de préparation ciblée.
CREATE OR REPLACE FUNCTION vision_preparer(u text,p jsonb) RETURNS jsonb LANGUAGE plpgsql AS $$
DECLARE resultat jsonb; contexte jsonb; limite integer:=coalesce((p->>'limite')::integer,8);
BEGIN
  IF p ? 'fiche_id' AND NOT EXISTS(SELECT 1 FROM vision_fiches WHERE utilisateur=u AND id=(p->>'fiche_id')::bigint AND archive_a IS NULL) THEN
    RETURN jsonb_build_object('erreur','introuvable');
  END IF;
  SELECT to_jsonb(c)-'utilisateur' INTO contexte FROM vision_contextes c
    WHERE utilisateur=u AND conversation=p->>'conversation' AND modifie_a>now()-interval '90 days';
  IF NOT p ? 'fiche_id' THEN
    WITH candidats AS (
      SELECT c.*,row_number() OVER(PARTITION BY c.fiche_id ORDER BY c.urgence DESC NULLS LAST,c.item_id) AS rang
      FROM vision_candidats(u) c WHERE c.urgence>=-1 OR c.fenetre->>'etat'='reference_inconnue'
    ), groupes AS (
      SELECT fiche_id,count(*) AS nombre,avg(least(coalesce(urgence,-1),20)) FILTER(WHERE rang<=3)
          + least(count(*),5)*0.1 AS score FROM candidats GROUP BY fiche_id
    ) SELECT coalesce(jsonb_agg(to_jsonb(a)),'[]') INTO resultat FROM (
      SELECT f.id,f.titre,g.nombre AS nombre_items,g.score FROM groupes g JOIN vision_fiches f ON f.id=g.fiche_id AND f.utilisateur=u
      ORDER BY g.score DESC,f.id LIMIT limite) a;
    RETURN jsonb_build_object('suggestions',resultat,'contexte',contexte,'maintenant',now(),
      'politique',vision_politique(u),'message','Fenêtres de planification indicatives ; aucune dette ni preuve d’oubli.');
  END IF;
  WITH candidats AS (
    SELECT c.*,i.evalue_a,i.suivi FROM vision_candidats(u,(p->>'fiche_id')::bigint) c JOIN vision_items i ON i.id=c.item_id AND i.utilisateur=u
    WHERE NOT c.item_id=ANY(ARRAY(SELECT jsonb_array_elements_text(coalesce(p->'exclus','[]'))::bigint))
      AND (coalesce((p->>'repeter')::boolean,false) OR NOT EXISTS(SELECT 1 FROM vision_episodes e WHERE e.utilisateur=u
        AND e.item_id=c.item_id AND e.enregistre_a>now()-interval '15 minutes'))
    ORDER BY (i.suivi<>'') DESC,(NOT i.evalue) DESC,c.urgence DESC NULLS LAST,c.item_id LIMIT 1
  ) SELECT coalesce(jsonb_agg(vision_item_public(i)||jsonb_build_object('fenetre',c.fenetre,
    'derniers_episodes',coalesce((SELECT jsonb_agg(to_jsonb(e)-'utilisateur') FROM (
      SELECT * FROM vision_episodes WHERE utilisateur=u AND item_id=i.id ORDER BY enregistre_a DESC LIMIT 4) e),'[]'))),'[]')
    INTO resultat FROM candidats c JOIN vision_items i ON i.id=c.item_id AND i.utilisateur=u;
  RETURN jsonb_build_object('usage_assistant',jsonb_build_object('items',resultat,'contexte',contexte,
    'fiche',(SELECT vision_fiche_publique(f) FROM vision_fiches f WHERE utilisateur=u AND id=(p->>'fiche_id')::bigint)),
    'politique',vision_politique(u),'maintenant',now(),'consigne','Poser une seule question sans révéler les réponses ; attendre. Après CHAQUE tentative, appeler evaluer_items pour cet item avant tout nouvel énoncé, puis rappeler preparer_revision pour obtenir uniquement le prochain item.');
END $$;

INSERT INTO vision_schema_migrations(version) VALUES(10) ON CONFLICT DO NOTHING;
COMMIT;
