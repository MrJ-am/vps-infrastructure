BEGIN;

-- Une séance garde le lot préparé ; aucune réponse n'est supposée connue avant la clôture.
CREATE TABLE IF NOT EXISTS vision_seances (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  utilisateur text NOT NULL REFERENCES vision_profils,
  conversation text CHECK (char_length(conversation) BETWEEN 1 AND 100),
  fiche_id bigint NOT NULL,
  etat text NOT NULL DEFAULT 'ouverte' CHECK (etat IN ('ouverte','terminee')),
  items jsonb NOT NULL CHECK (jsonb_typeof(items)='array' AND jsonb_array_length(items) BETWEEN 1 AND 20),
  retour jsonb,
  rapport jsonb,
  cree_a timestamptz NOT NULL DEFAULT now(),
  terminee_a timestamptz,
  FOREIGN KEY (utilisateur,fiche_id) REFERENCES vision_fiches(utilisateur,id)
);
CREATE INDEX IF NOT EXISTS vision_seances_ouvertes ON vision_seances(utilisateur,cree_a DESC)
  WHERE etat='ouverte';

CREATE OR REPLACE FUNCTION vision_seances_en_attente(u text) RETURNS jsonb LANGUAGE sql STABLE AS $$
  SELECT coalesce(jsonb_agg(to_jsonb(s) ORDER BY s.cree_a DESC),'[]'::jsonb)
  FROM (SELECT id,conversation,fiche_id,cree_a FROM vision_seances
        WHERE utilisateur=u AND etat='ouverte' ORDER BY cree_a DESC LIMIT 20) s
$$;

CREATE OR REPLACE FUNCTION vision_ouvrir_seance(u text,p jsonb) RETURNS jsonb LANGUAGE plpgsql AS $$
DECLARE lot jsonb; total integer; attente jsonb; s vision_seances; f vision_fiches;
  limite integer:=coalesce((p->>'limite')::integer,8);
BEGIN
  SELECT * INTO f FROM vision_fiches WHERE utilisateur=u AND id=(p->>'fiche_id')::bigint AND archive_a IS NULL;
  IF NOT FOUND THEN PERFORM vision_refuser('introuvable'); END IF;
  attente:=vision_seances_en_attente(u);
  IF jsonb_array_length(attente)>0 AND NOT coalesce((p->>'nouvelle_seance')::boolean,false) THEN
    RETURN jsonb_build_object('enregistre',false,'confirmation_requise',true,
      'seances_en_attente',attente,
      'message','Une séance précédente attend son compte rendu. Elle peut être terminée dans sa conversation. Demander si la personne veut néanmoins commencer une nouvelle séance.');
  END IF;
  SELECT count(*) INTO total FROM vision_candidats(u,f.id) c
    WHERE c.urgence>=-1 OR c.fenetre->>'etat'='reference_inconnue';
  WITH candidats AS (
    SELECT c.item_id,c.fenetre,i.suivi,i.evalue
      FROM vision_candidats(u,f.id) c JOIN vision_items i ON i.id=c.item_id AND i.utilisateur=u
      WHERE c.urgence>=-1 OR c.fenetre->>'etat'='reference_inconnue'
      ORDER BY (i.suivi<>'') DESC,(NOT i.evalue) DESC,c.urgence DESC NULLS LAST,c.item_id
      LIMIT limite
  ) SELECT coalesce(jsonb_agg(vision_item_public(i)||jsonb_build_object('fenetre',c.fenetre)
      ORDER BY (c.suivi<>'') DESC,(NOT c.evalue) DESC,c.item_id),'[]'::jsonb)
    INTO lot FROM candidats c JOIN vision_items i ON i.id=c.item_id AND i.utilisateur=u;
  IF jsonb_array_length(lot)=0 THEN
    RETURN jsonb_build_object('enregistre',false,'nombre_items_disponibles',0,'seances_en_attente',attente);
  END IF;
  INSERT INTO vision_seances(utilisateur,conversation,fiche_id,items)
    VALUES(u,p->>'conversation',f.id,lot) RETURNING * INTO s;
  RETURN jsonb_build_object('enregistre',true,'seance_id',s.id,'etat',s.etat,
    'conversation',s.conversation,'fiche_id',s.fiche_id,'cree_a',s.cree_a,
    'nombre_questions',jsonb_array_length(lot),'nombre_items_disponibles',total,
    'usage_assistant',jsonb_build_object('fiche',vision_fiche_publique(f),'items',lot),
    'seances_en_attente',attente,
    'consigne','Annoncer une séance d’environ nombre_questions questions, demander si la personne est prête. Poser les questions une par une sans dévoiler les réponses des suivantes. Recueillir le retour final, puis appeler clore_seance une seule fois avec les évaluations et ce retour.');
END $$;

CREATE OR REPLACE FUNCTION vision_clore_seance(u text,p jsonb) RETURNS jsonb LANGUAGE plpgsql AS $$
DECLARE s vision_seances; e jsonb; retour jsonb:=p->'retour'; evaluations jsonb:=p->'evaluations';
  bilan jsonb; bilan_final jsonb;
BEGIN
  SELECT * INTO s FROM vision_seances WHERE utilisateur=u AND id=(p->>'seance_id')::uuid FOR UPDATE;
  IF NOT FOUND THEN PERFORM vision_refuser('seance_introuvable'); END IF;
  IF s.etat<>'ouverte' THEN PERFORM vision_refuser('seance_terminee'); END IF;
  IF jsonb_typeof(evaluations)<>'array' OR jsonb_array_length(evaluations)>20 THEN
    PERFORM vision_refuser('evaluations_invalides');
  END IF;
  FOR e IN SELECT value FROM jsonb_array_elements(evaluations) LOOP
    IF NOT EXISTS(SELECT 1 FROM jsonb_array_elements(s.items) i WHERE (i->>'id')::bigint=(e->>'item_id')::bigint) THEN
      PERFORM vision_refuser('item_hors_seance');
    END IF;
    IF NOT EXISTS(SELECT 1 FROM jsonb_array_elements(p->'deroulement') d
        WHERE d->>'item_id'=e->>'item_id' AND d->>'etat'='tente') THEN
      PERFORM vision_refuser('tentative_sans_deroulement');
    END IF;
  END LOOP;
  FOR e IN SELECT value FROM jsonb_array_elements(retour->'reformulations') LOOP
    IF NOT EXISTS(SELECT 1 FROM jsonb_array_elements(s.items) i WHERE (i->>'id')::bigint=(e->>'item_id')::bigint) THEN
      PERFORM vision_refuser('item_hors_seance');
    END IF;
  END LOOP;
  FOR e IN SELECT value FROM jsonb_array_elements(p->'deroulement') LOOP
    IF NOT EXISTS(SELECT 1 FROM jsonb_array_elements(s.items) i WHERE (i->>'id')::bigint=(e->>'item_id')::bigint) THEN
      PERFORM vision_refuser('item_hors_seance');
    END IF;
  END LOOP;
  IF jsonb_array_length(evaluations)>0 THEN
    bilan:=vision_evaluer(u,p||jsonb_build_object('conversation',s.conversation));
  ELSE bilan:=jsonb_build_object('enregistre',true,'evaluations','[]'::jsonb);
  END IF;
  bilan_final:=jsonb_build_object('seance_id',s.id,'fiche_id',s.fiche_id,
    'questions_preparees',jsonb_array_length(s.items),
    'tentatives_enregistrees',jsonb_array_length(evaluations),
    'evaluations',bilan->'evaluations','deroulement',p->'deroulement',
    'retour',retour,'synthese',coalesce(p->>'synthese',''),
    'propositions_en_attente',jsonb_build_object('reformulations',retour->'reformulations','ajouts',retour->'ajouts'));
  UPDATE vision_seances SET etat='terminee',retour=p->'retour',rapport=bilan_final,terminee_a=now()
    WHERE id=s.id;
  RETURN jsonb_build_object('enregistre',true,'rapport',bilan_final);
END $$;

-- preparer_revision reste la lecture des suggestions ; une séance ciblée doit être ouverte explicitement.
CREATE OR REPLACE FUNCTION vision_preparer(u text,p jsonb) RETURNS jsonb LANGUAGE plpgsql AS $$
DECLARE resultat jsonb; contexte jsonb; limite integer:=coalesce((p->>'limite')::integer,8);
BEGIN
  SELECT to_jsonb(c)-'utilisateur' INTO contexte FROM vision_contextes c
    WHERE utilisateur=u AND conversation=p->>'conversation' AND modifie_a>now()-interval '90 days';
  IF p ? 'fiche_id' THEN RETURN jsonb_build_object('erreur','utiliser_ouvrir_seance',
    'seances_en_attente',vision_seances_en_attente(u)); END IF;
  WITH candidats AS (
    SELECT c.*,row_number() OVER(PARTITION BY c.fiche_id ORDER BY c.urgence DESC NULLS LAST,c.item_id) AS rang
    FROM vision_candidats(u) c WHERE c.urgence>=-1 OR c.fenetre->>'etat'='reference_inconnue'
  ), groupes AS (
    SELECT fiche_id,count(*) AS nombre,avg(least(coalesce(urgence,-1),20)) FILTER(WHERE rang<=3)
        + least(count(*),5)*0.1 AS score FROM candidats GROUP BY fiche_id
  ) SELECT coalesce(jsonb_agg(to_jsonb(a)),'[]'::jsonb) INTO resultat FROM (
    SELECT f.id,f.titre,g.nombre AS nombre_items,g.score FROM groupes g JOIN vision_fiches f ON f.id=g.fiche_id AND f.utilisateur=u
    ORDER BY g.score DESC,f.id LIMIT limite) a;
  RETURN jsonb_build_object('suggestions',resultat,'contexte',contexte,'maintenant',now(),
    'politique',vision_politique(u),'seances_en_attente',vision_seances_en_attente(u),
    'message','Une séance ouverte attend son compte rendu ; demander si la personne veut en commencer une nouvelle. Fenêtres indicatives, aucune preuve d’oubli.');
END $$;

CREATE OR REPLACE FUNCTION vision_commande(u text,op text,p jsonb) RETURNS jsonb LANGUAGE plpgsql AS $$
DECLARE empreinte text:=encode(sha256(convert_to(op||p::text,'UTF8')),'hex'); deja vision_requetes; resultat jsonb; pr vision_profils;
BEGIN
  IF u IS NULL OR u='' THEN RETURN jsonb_build_object('erreur','identite_requise'); END IF;
  IF p->>'emise_a' IS NULL OR (p->>'emise_a')::timestamptz<now()-interval '30 days'
    OR (p->>'emise_a')::timestamptz>now()+interval '5 minutes' THEN RETURN jsonb_build_object('erreur','requete_expiree'); END IF;
  IF char_length(coalesce(p->>'cle','')) NOT BETWEEN 8 AND 100 THEN RETURN jsonb_build_object('erreur','cle_requise'); END IF;
  PERFORM pg_advisory_xact_lock(hashtextextended(u,718));
  INSERT INTO vision_profils(utilisateur) VALUES(u) ON CONFLICT DO NOTHING;
  SELECT * INTO deja FROM vision_requetes WHERE utilisateur=u AND cle=p->>'cle';
  IF FOUND THEN
    IF deja.empreinte<>empreinte THEN RETURN jsonb_build_object('erreur','cle_reutilisee'); END IF;
    RETURN deja.resultat||jsonb_build_object('rejeu',true);
  END IF;
  BEGIN
    CASE op
      WHEN 'enregistrer_fiche' THEN resultat:=vision_ecrire_fiche(u,p);
      WHEN 'enregistrer_item' THEN resultat:=vision_ecrire_item(u,p);
      WHEN 'lier_item' THEN resultat:=vision_lier(u,p);
      WHEN 'evaluer_items' THEN resultat:=vision_evaluer(u,p);
      WHEN 'enregistrer_contexte' THEN resultat:=vision_ecrire_contexte(u,p);
      WHEN 'regler_politique' THEN
        SELECT * INTO pr FROM vision_profils WHERE utilisateur=u;
        IF pr.version IS DISTINCT FROM (p->>'version')::bigint THEN PERFORM vision_refuser('conflit'); END IF;
        UPDATE vision_profils SET intervalle_jours=(p->>'intervalle_jours')::integer,budget=(p->>'budget')::integer,
          version=version+1 WHERE utilisateur=u;
        resultat:=jsonb_build_object('enregistre',true);
      WHEN 'ouvrir_seance' THEN resultat:=vision_ouvrir_seance(u,p);
      WHEN 'clore_seance' THEN resultat:=vision_clore_seance(u,p);
      ELSE PERFORM vision_refuser('operation_inconnue');
    END CASE;
    PERFORM vision_ajuster_charge(u);
    resultat:=resultat||jsonb_build_object('politique',vision_politique(u),'maintenant',now());
    INSERT INTO vision_requetes(utilisateur,cle,empreinte,resultat) VALUES(u,p->>'cle',empreinte,resultat);
    DELETE FROM vision_requetes WHERE utilisateur=u AND enregistre_a<now()-interval '35 days';
    DELETE FROM vision_episodes WHERE utilisateur=u AND enregistre_a<now()-interval '90 days';
    DELETE FROM vision_journal WHERE utilisateur=u AND (enregistre_a<now()-interval '180 days' OR id IN
      (SELECT id FROM vision_journal WHERE utilisateur=u ORDER BY id DESC OFFSET 5000));
    DELETE FROM vision_contextes WHERE utilisateur=u AND (modifie_a<now()-interval '90 days' OR conversation IN
      (SELECT conversation FROM vision_contextes WHERE utilisateur=u ORDER BY modifie_a DESC OFFSET 50));
    RETURN resultat;
  EXCEPTION WHEN raise_exception THEN RETURN jsonb_build_object('erreur',SQLERRM);
    WHEN integrity_constraint_violation OR data_exception THEN RETURN jsonb_build_object('erreur','donnees_invalides');
  END;
END $$;

INSERT INTO vision_schema_migrations(version) VALUES(11) ON CONFLICT DO NOTHING;
COMMIT;
