# Style MrJ.am dans Vision

## État au 21 septembre 2026

Le portage ElmUI est intégré à `main` et publié depuis 22:32 UTC. Les références,
preuves de CI et contrôles réels figurent dans [ETAT-PORTAGE-ELMUI.md](ETAT-PORTAGE-ELMUI.md).
La version servie est `9a4c395b24e6eb8938a3246c96f5d80c030c2d2d`, construite
avec `MrJ-am/style-mrjam` à `c7b4d6e00cd0014a0a05e5a4e77627357498faa9`.

## Architecture

L'interface dans `interface/` est écrite en ElmUI ; le serveur reste en
Common Lisp. Le style commun est intégré au moment de la compilation, à une
révision Git complète avec empreintes vérifiées. Aucun CSS partagé mutable
n'est chargé à distance. La palette commune et le logo original sont conservés.

Les appels usuels sont compacts et français : `bouton "Enregistrer" Enregistrer`.
La bibliothèque porte la décoration commune, les variantes sémantiques,
les tableaux et valeurs spécialisées, le lecteur Markdown et les dialogues.
Les décisions métier et les permissions restent dans Vision. Tout composant
commun manquant doit être ajouté à la bibliothèque puis adopté de façon coordonnée.

Franciser un nom existant seulement après compilation de la référence, un
symbole à la fois avec tous ses usages. Recompiler avant le suivant et vérifier
séparément JSON, ports, stockage et API. Les noms externes ne changent pas
silencieusement.

## Contrats indispensables

Conserver sessions, CSRF, refus anonyme, révocation et distinction entre
navigateur et API Basic/MCP. Le compte mobile jetable n'accède pas aux données.

Préserver pagination, filtres, étiquettes, tris stables, édition, conflits
HTTP 409, journal existant et archivage réversible. Ne pas recalculer les
observations ni remplacer des valeurs par des données fictives. Les limites
d'affichage des historiques sont explicites dans l'état du portage.
Les tests d'écriture utilisent une base isolée, jamais la production.

Libellés accessibles, focus, clavier, états de chargement, fenêtres et petits
écrans font partie de chaque évolution. Lire [BROWSER.md](BROWSER.md) et les
tests existants avant toute modification.

## Identité et publication

Signature reste la source du logo et de la signature, à
`17495b13cefa24473e37434b98336b27caec8cdf`. Les polices exactes sont intégrées
depuis cette source autorisée dans `interface/identite/`, avec leurs empreintes.
La signature demeure le texte sélectionnable `MrJ.am` ; tous ses usages sont réservés.

L'infrastructure publie l'artefact testé sans le reconstruire, contrôle le
manifeste servi et l'authentification réelle, puis enregistre la génération.
NixOS, Nginx, PostgreSQL et les accès système restent la responsabilité de
`vps-infrastructure`. Les opérations VPS passent par GitHub Actions.

La reprise complète de Vision a été demandée par le propriétaire pendant la
publication parallèle d'Apprendre à démontrer. Cette opération ne déclare pas
la migration collective terminée : son orchestrateur n'est pas installé.
Les évolutions futures de la version partagée doivent reconstruire et valider
tous les consommateurs concernés, avec retour applicatif préparé et sans
restauration de base pour annuler une présentation.

## Candidat documentaire du 26 septembre 2026

Le verrou de `interface/style.lock.json` est la source de la révision candidate.
`MrJam.Documents` compose les pages et `MrJam.Tableaux` les données. Vision ne
porte aucune décoration de contrôle. Les pages publiques partagent l’entrée ElmUI ;
les anciennes ressources HTML de `docs/` sont retirées. Voir le
[bilan, les captures et les validations restantes](AUDIT-INTERFACE-20260926.md).
Cette préparation ne remplace pas le relevé historique de publication ci-dessus.
