# Contrats Vision pour les assistants

Le contrat REST Basic est publié à `https://vision.mrj.am/openapi.json`.
Le endpoint MCP est `https://vision.mrj.am/mcp` ; `initialize` fournit les
instructions pédagogiques actuelles et `tools/list` les neuf schémas.

Pour un client déjà configuré, actualiser son contrat après le passage à Vision 2.
Les cinq anciens outils de fiche et les notes FSRS sont explicitement retirés.
Ne pas convertir une ancienne demande `record_review` en item choisi au hasard.

Lire [MCP.md](MCP.md) : révision ciblée prioritaire, première question sans
réponse révélée, Q contextualisé, épisodes cumulatifs, recherche globale avant
création et reprise minimale. Les clés `cle` et `emise_a` rendent le rejeu sûr ;
les versions empêchent l’écrasement d’une modification concurrente.

Le service fournit OAuth PKCE pour MCP, ainsi que Basic et des tokens Bearer
indépendants. Les choix de connexion disponibles dépendent du client. Conserver
les secrets dans son gestionnaire d’authentification, jamais dans une URL, des
instructions pédagogiques, une conversation ou Git. Les sessions navigateur et
les tokens MCP ont des usages distincts.
