# Connecter un client MCP à Vision

URL : `https://vision.mrj.am/mcp`. Pour un client acceptant Bearer, créer un token
nommé depuis le menu de Vision → Tokens d’accès, puis le copier dans son
réglage d’authentification. Plusieurs tokens indépendants peuvent coexister.
Le secret est affiché une seule fois ; la révocation est individuelle.

Un token expire après un an et seul son condensat est stocké. Le logout du
navigateur ne le révoque pas. Une rotation des identifiants du compte invalide
les tokens. OAuth PKCE et Basic restent disponibles selon les capacités du
client ; Bearer ne donne accès ni à REST ni aux sessions navigateur.

Vision 2 expose neuf outils décrits dans [MCP.md](MCP.md). Recharger `initialize`
et `tools/list` dans les connecteurs existants. Les métadonnées MCP `_meta`
restent acceptées ; les cinq anciens outils répondent `contrat_retire`.

Le journal applicatif conserve uniquement méthode, nom d’outil connu et résultat
technique. Les arguments, fiches et secrets ne sont pas journalisés. Un HTTP 401
signale un refus d’accès ; un `-32602` un contrat invalide ; un conflit impose une
relecture. Les journaux distants sont consultés par Actions dans le dépôt VPS.
Un contrôle serveur ne vaut pas un essai dans le compte d’un client tiers.
