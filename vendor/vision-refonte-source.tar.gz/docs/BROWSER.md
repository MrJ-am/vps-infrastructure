# Navigateur Vision 2

Deux entrées, Fiches et Items, donnent accès aux objets du compte connecté.
Les listes sont paginées par 20, avec recherche, état actif/archivé/tous et tri.
Les fiches proposent aussi un filtre par tags. Les liens sont paginés et
consultables dans les deux sens. Archiver ou détacher conserve les objets.

Le contenu de référence et le suivi qualitatif sont distincts. Le suivi est
facultatif. Il n’existe plus de zone synthèse, difficulté FSRS, probabilité ou
échéance propre de fiche. P et S s’affichent avec leur signe en dB. Les fenêtres
dérivées indiquent explicitement les dates inconnues et les intervalles extrêmes.

Une création d’item recherche les candidats dans tout le compte, archives
incluses, les lit et propose de les réutiliser. Créer une connaissance proche
mais distincte demande d’expliciter la différence. Les créations concurrentes
invalident les anciennes preuves de recherche. La stabilité initiale vaut −15 ;
une autre estimation doit être justifiée. L’édition de contenu ne change ni S
ni la date du dernier rappel. Les évaluations utilisent le contrat signé Q.

Les réglages permettent T (préréglages 7, 14, 30, 90 jours), un budget facultatif
d’items quotidiens et l’affichage de G. Ils ne changent jamais S. Le menu conserve
le lien `/auth/mcp` vers les tokens et autorisations OAuth.

Toutes les opérations POST `/api/web/<opération>` exigent session, origine et
CSRF. Nginx écrase les en-têtes internes et transmet `X-Mrj-User` avec les preuves
`X-Vision-Authenticated: 1` et `X-Vision-Browser: 1`. REST et MCP restent séparés.
L’application écoute exclusivement sur 127.0.0.1.

Les conflits 409 conservent la saisie pour une conciliation explicite après
relecture. Une réponse réseau perdue garde la même clé et le même corps pour le
rejeu. L’expiration de session suspend la saisie en mémoire uniquement : seul
le même compte la retrouve après connexion. Déconnexion ou changement de compte
retirent les données visibles et ignorent les réponses tardives. Aucun contenu
ni mot de passe n’est conservé dans localStorage ou sessionStorage.

Le workflow `.github/workflows/interface.yml` valide la compilation, les parcours
avec Common Lisp/PostgreSQL et le rendu aux largeurs 320, 375, 768 et 1280 px.
Les captures de test sont synthétiques ; les contrôles de production ne publient
que l’écran de connexion vide.
