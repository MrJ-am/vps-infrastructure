# Refonte documentaire de Vision — candidat du 26 septembre 2026

**État : branches candidates poussées ; validation collective suivie en CI.**
La CI PostgreSQL et la validation des artefacts collectifs restent des conditions
préalables à l’activation. Les captures utilisent exclusivement des données synthétiques.

## Résultat graphique

Vision adopte une interface documentaire : titres cliquables, tables compactes,
propriétés alignées, actions secondaires sans cadre et lecture sans cartes imbriquées.
L’inspiration Notion porte sur l’organisation visuelle d’une base documentaire,
pas sur une reproduction exacte. L’identité verte et la signature MrJ.am restent présentes.

- [Liste sur ordinateur](captures/interface-documentaire-1280.png)
- [Liste sur téléphone](captures/interface-documentaire-320.png)
- [Document et relations sur téléphone](captures/document-320.png)
- [Édition et confirmation sur téléphone](captures/edition-320.png)

Les captures ne prétendent pas représenter les données du compte réel.

## Audit et factorisation

| Constat | Traitement |
| --- | --- |
| Boutons dans les listes de résultats | Liens avec URL `#fiche/ID` ou `#item/ID`, rechargeables et ouvrables dans un autre onglet |
| Boutons surdimensionnés et décorations répétées | Un moteur `MrJam.Controles`, variantes par intention, cible nominale 34 px |
| Deux rendus de tableaux dans le style | Un moteur `MrJam.Tableaux`, ancien appel `Donnees.tableau` conservé par délégation |
| Largeurs indépendantes entre titre et cellules | `Colonne` opaque ; dimensions déterminées une seule fois par rôle |
| Cartes et sections imbriquées dans Vision | Compositions `MrJam.Documents` : document, section, en-tête, filtres, navigation et pagination |
| Libellés d’actions répétant de longs titres | `actionSur` : libellé court visible, objet nommé dans le libellé accessible |
| Chaînes « fiche » et « item » utilisées comme états | Type fermé `Nature = Fiche | Item`, conversion vers les chaînes du protocole à sa frontière |
| Définitions de brouillon paramétrées inutilement | Une valeur initiale commune ; suppression de l’argument inutilisé |
| Ancienne interface HTML/JS/CSS encore présente | Suppression de `docs/app.*` ; `/docs` et `/privacy` utilisent le même point d’entrée ElmUI |
| HTML ordinaire dans les vues de Vision | Aucun constructeur HTML ni décoration ElmUI locale ; garde-fou automatique sur les imports et appels |
| Police et marges modifiées par l’ouverture d’une modale | Suppression de la seconde feuille statique ElmUI ; tests d’invariance et de focus |
| Contour de focus affiché sur tous les boutons du détail | Focus déplacé vers le titre du document ; test navigateur dédié |

Les formulaires, permissions, validations, contenus et décisions restent dans Vision.
La bibliothèque publique n’acquiert aucune dépendance aux données ou au métier de Vision.
Le code JSON, les opérations REST/MCP et le schéma PostgreSQL restent inchangés.

Le périmètre de source d’exécution comparé comprend `style-mrjam/src`,
`vision/interface/src`, le pont et le squelette, ainsi que les cinq anciennes
ressources HTML/JS/CSS de `vision/docs`. Son volume diminue d’environ **31 ko**,
malgré les nouveaux composants et le routage. Ce décompte exclut tests, documentation,
verrous de dépendances et fichiers compilés ; il n’est pas une mesure de performance.

## HTML et interfaces spécialisées

Le style conserve les adaptateurs natifs `select` (absent d’ElmUI), `dialog`
(modalité et fond inerte) et le conteneur technique des racines ElmUI.
Le squelette HTML démarre l’application ; il ne contient pas de contrôles ordinaires.
Les lecteurs littéraux et la signature sont désormais en ElmUI.

L’audit des autres consommateurs distingue leurs interfaces ordinaires des ponts
KaTeX, vidéo, curseurs et scène géométrique. Ces moteurs spécialisés ne sont pas
transférés dans le style : cela importerait des protocoles métier et des dépendances
sans rapport avec une table ou un bouton. Leur rendu ordinaire continue de consommer
le moteur commun ; leurs contrats existants restent en vigueur.

Le service distinct `mrj-auth`, propriétaire de `/auth/mcp` et du consentement OAuth,
conserve son interface HTML. Il a été examiné en lecture seule ; il ne fait pas partie
de l’artefact Vision. Une homogénéité de cette surface d’authentification demanderait
un portage séparé du service VPS et ses tests d’autorisation. Ce candidat ne prétend
pas avoir supprimé tout HTML de l’infrastructure.

## Critères d’acceptation graphique

| Propriété | Contrôle exécuté |
| --- | --- |
| Action courte | 32–38 px de haut, cible nominale 34 px ; icône également bornée en largeur |
| Ligne courte | 32–48 px ; 39 px observés dans Vision |
| Texte long | Retour à la ligne, sans hauteur fixe ; 51 px observés sur les titres de téléphone |
| Table | Alignement des cellules et des en-têtes à moins de 1 px ; rôles accessibles |
| Navigation | Vrais liens, aucune action bouton dans la table de résultats |
| Petit écran | Largeurs 320, 375 tactile, 768 et 1280 px sans débordement global |
| Colonnes larges | Défilement horizontal local, accessible au clavier |
| Actions contextuelles | Noms accessibles complets, libellés visuels courts |
| Interaction | Clavier, menu, recherche par Entrée, filtres, tri, lecture des relations |
| Édition | Brouillon préservé si l’adresse change ; confirmation refermée par Échap |
| Pages publiques | `/docs`, `/docs/`, `/privacy` affichées sans requête de session ni de données |

La galerie commune ajoute des titres et boutons très longs, les états vides,
indisponibles, occupés et sélectionnés, ainsi que les variations de taille des dialogues.
Les seuils sont des contrats explicites ; aucun score artificiel de « ressemblance à Notion »
n’est utilisé. Les captures complètent les assertions automatiques.

## Contrôles réalisés et limites

| Ensemble | Résultat local |
| --- | --- |
| Style | Compilation de Galerie et Bibliotheque, 3 tests d’architecture ; deux suites navigateur sur 4 largeurs chacune |
| Vision | Compilation optimisée, 2 tests d’architecture, parcours graphiques sur 4 formats et pages publiques |
| Types Elm | 4 tests, dont aller-retour de 100 identifiants générés pour les deux natures ; adresses invalides et clés externes |
| Common Lisp | Binaire SBCL compilé ; quatre routes publiques réelles, CSP et refus anonyme REST/MCP vérifiés sans PostgreSQL |
| Contrats Vision | `check_openapi.py`, `check_deploy.py`, 3 tests du catalogue client réussis |
| Matheval | Reconstruction de Main, Survey, Administration et DemoCard ; 7 parcours Chromium de présentation, activation, connexion et signature |
| Logique | Reconstruction complète ; 58 exercices, 12 bilans, 12 pages vidéo, clavier, ports et 4 largeurs ; 303 rendus KaTeX observés |
| Production | Aucune activation, écriture de donnée ni validation sur les comptes réels |

Les tests vidéo emploient des doublures explicites des services externes.
Les sept tests Matheval ont été lancés sur HTTP statique avec les refus de session
simulés prévus par leurs sources ; ils ne valident pas la collecte PostgreSQL.
La reconstruction finale des cinq bundles Matheval/Logique produit les mêmes
SHA-256 que les bundles soumis à leurs parcours navigateur.

Le lancement standard `elm-test` ne peut pas ouvrir sa socket Unix dans cet atelier.
Les mêmes workers compilés ont été exécutés via leurs ports, dans un processus Node ;
les 4 résultats ont réussi. La CI conserve le lanceur officiel `elm-test`.
Chromium local provient de Playwright 1.55 ; les dépendances CI verrouillées ne sont
pas rétrogradées. Les contrôles distants doivent donc également réussir.

PostgreSQL ne peut pas être lancé ici sous un compte non privilégié. Les suites
complètes `tests/refonte.sh`, `tests/refonte.sql`, migration et navigateur
`interface/tests/base.sh`, ainsi que la collecte Matheval, ont depuis réussi en CI
(Vision 36250928606 et 36250928524 ; Matheval 36250921184). La correction
typographique finale est soumise à nouveau à toutes ces suites.
Leurs garde-fous ne sont ni contournés ni remplacés par les tests graphiques à API doublée.
Les modifications d’interaction sont reportées dans `interface/tests/refonte.py`.
L’ancien test navigateur V1, non appelé par les workflows actuels, est retiré.

## Révisions et livraison coordonnée

Références de départ vérifiées :

| Dépôt | Révision distante de départ |
| --- | --- |
| `MrJ-am/style-mrjam` | `b2177c0fd2c46c6f528266d30f7b933d3add1566` |
| `MrJ-am/vision` | `e2e8ca09a05fcc243b242e3133d2e85ee68489b2` |
| `MrJ-am/M-moire` | `f6706f8a6b6b08d797340e26f917a6cdc3bb9e5c` |
| `MrJ-am/apprendre-a-demontrer` | `c63d2a32216fa7356e194ce8ee683bf8deb526a9` |

Le style candidat est **`3aab7233465ac0abe49464fa26a360765ccb4004`**.
Les trois verrous consommateurs pointent vers ce commit complet et contrôlent
chaque module et ressource. La CI Vision lit ce verrou au lieu de recopier un SHA
à plusieurs endroits. Matheval vérifie également les branches `refonte/**`, sans
y autoriser de déploiement automatique.

1. Revoir les différences ; push autorisé par le propriétaire le 26 septembre.
2. Actualiser le registre privé de coordination, puis publier les candidats sur
   `refonte/interface-documentaire` dans les quatre dépôts ; préserver leurs histoires.
3. Attendre toutes les CI, corriger tout échec et figer les artefacts vérifiés.
4. Préparer la mise à jour collective et les versions applicatives de retour.
5. Activer via les workflows autorisés, contrôler les manifestes réellement servis,
   puis consigner les résultats. Aucune restauration de base pour annuler un style.

Les push sont autorisés, y compris sur les dépôts publics du propriétaire.
Aucune pull request ne doit être proposée en son nom. Cette clarification du
26 septembre corrige le motif de suspension initial ; elle ne vaut pas activation VPS.

## Corrections révélées par les CI

Logique testait une copie en dur de l’ancienne révision. Le verrou reste la source
unique ; son test refuse maintenant une branche et un SHA abrégé. La typographie
réelle a ensuite révélé une hauteur de signature réduite par ElmUI : le style
commun conserve la métrique fractionnaire de Signature dans un paragraphe ElmUI,
sans modifier les fontes ni leur CSS. Les tests suivent le texte à travers les
conteneurs ElmUI et vérifient toujours les dimensions, la sélection et le
copier-coller natif, caractère par caractère, dans huit contextes HTTP.

Les révisions, exécutions et artefacts de la livraison finale sont consignés dans
`operations/interface-documentaire-publication.json`. Aucune activation VPS
n’est effectuée dans cette étape de push et de validation.
