# Règles de travail de Vision

<!-- coordination-commune:v1 -->
## Coordination commune

- Identifiant de ce projet : `vision`. À chaque reprise (y compris après compaction), lire aussi le [AGENTS.md distant de référence](https://github.com/MrJ-am/vision/blob/main/AGENTS.md), même sur une ancienne branche.
- Avant de travailler, consulter dans le dépôt privé `MrJ-am/vps-infrastructure`, **branche `main` actuelle**, [coordination/CONTRATS.org](https://github.com/MrJ-am/vps-infrastructure/blob/main/coordination/CONTRATS.org) et [coordination/REGISTRE.org](https://github.com/MrJ-am/vps-infrastructure/blob/main/coordination/REGISTRE.org). Lire le protocole au début du registre à la première utilisation ; ensuite, charger la synthèse et les messages destinés à `vision`. Ne pas charger les archives par défaut.
- Reconsulter avant toute modification d'un contrat partagé, avant publication et à la clôture. La commande `python3 scripts/coordination.py lire vision`, dans une copie fraîche du dépôt VPS, produit la vue ciblée. Les outils GitHub permettent aussi cette lecture sans clone ni SSH.
- Publier les impacts globaux pour tous les projets ; pour un impact ciblé, nommer explicitement les destinataires et les actions. Informer avant le changement puis consigner le résultat avec commit et preuves. Une demande n'est pas un changement exécuté.
- Acquitter uniquement pour `vision`, après lecture réelle, avec l'empreinte du message et le dépôt@commit du contexte. Distinguer LU, BLOQUE et DONE ; DONE exige une preuve. Suivre le protocole pour publier la réponse sur le main VPS sans écraser les autres écritures.
- Si le registre est inaccessible, le dire, poursuivre les tâches indépendantes et suspendre seulement les changements partagés dont les préconditions restent inconnues. Ne pas inventer d'accusé ni demander à l'utilisateur de transporter les messages entre projets.
- Les consignes locales continuent de s'appliquer. Le registre ne donne aucun droit supplémentaire de publication ou d'administration. Après les mises à jour, vérifier l'archivage des échanges intégralement traités ; ne jamais effacer un message non acquitté.

<!-- /coordination-commune:v1 -->

Lire `README.md`, `docs/BROWSER.md` et `docs/STYLE-MRJAM.md` avant de modifier l’interface. Le portage est intégré à `main` et publié le 21 septembre 2026 ; lire `docs/ETAT-PORTAGE-ELMUI.md` pour les références effectivement servies et les limites. Toute nouvelle publication doit conserver ses propres preuves.

## Code et composants

Écrire le code, les commentaires et la documentation en français dès lors que les noms sont sous notre contrôle. Garder le code lisible et compact. Les interfaces sont destinées à ElmUI et à la bibliothèque commune `MrJ-am/style-mrjam`, consommée à une révision précise lors de la compilation.

Un composant usuel doit s’appeler simplement, par exemple `bouton "Enregistrer" Enregistrer`. Ne pas reconstruire sa bordure, son arrondi ou sa couleur dans Vision. Les variantes correspondent à des sémantiques distinctes. Les décisions métier et les permissions ne vont pas dans la bibliothèque publique de style.

Pour franciser un nom existant, compiler d’abord la référence ; modifier un seul symbole avec tous ses usages, compiler, puis vérifier les contrats externes avant de renommer le suivant. Ne pas faire de remplacement aveugle dans les clés JSON, routes, SQL, ports, noms de paquets tiers ou données stockées.

## Données et sécurité

Préserver les sessions, CSRF, le refus anonyme, les accès Basic/MCP séparés, les conflits HTTP 409, les historiques, les observations factuelles et l’archivage réversible. Ne pas créer de données fictives dans la production. Les modifications de présentation n’autorisent aucune modification silencieuse du schéma ou des données.

Le serveur reste en Common Lisp. Les changements doivent passer les validations de `.github/workflows/check.yml` et les tests d’interaction applicables. Une compilation Elm seule ne valide ni l’API ni l’authentification.

## Identité et infrastructure

Le logo et la signature sont d’utilisation strictement réservée ; `MrJ-am/Signature` demeure leur source, à une révision exacte. La signature doit rester le texte sélectionnable `MrJ.am`.

NixOS, Nginx, PostgreSQL et les accès système appartiennent à `MrJ-am/vps-infrastructure`. Les opérations distantes passent par GitHub Actions, pas par un accès SSH direct depuis ChatGPT Work. La mise à jour du style doit reconstruire et redéployer tous ses projets consommateurs après validation collective, avec retour applicatif préparé. Ne pas restaurer une base pour annuler un style.

Faire des commits français et indiquer explicitement les contrôles réalisés, les échecs éventuels et ce qui a réellement été publié.
