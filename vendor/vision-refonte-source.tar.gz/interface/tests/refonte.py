#!/usr/bin/env python3
"""Navigateur réel + Common Lisp + PostgreSQL jetable. Session/CSRF : doublure locale.
Les protections SSO/Nginx réelles sont vérifiées séparément par l'infrastructure.
"""
import argparse, copy, functools, http.cookies, json, mimetypes, os, re, secrets, threading, time
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import urllib.request, urllib.error
from playwright.sync_api import sync_playwright, expect

RACINE=Path(__file__).resolve().parents[1]
class Environnement:
 def __init__(self, port):
  self.port=port;self.utilisateur='interface-test';self.session=None;self.jeton=None
  self.appels=[];self.erreurs={};self.retards={};self.perdre=None
 def api(self, op, p, ecriture=False):
  if ecriture:p={'cle':secrets.token_hex(16),'emise_a':datetime.now(timezone.utc).isoformat(),**p}
  r=urllib.request.Request(f'http://127.0.0.1:{self.port}/api/web/{op}',json.dumps(p).encode(),
    {'Content-Type':'application/json','X-Vision-Authenticated':'1','X-Vision-Browser':'1','X-Mrj-User':self.utilisateur})
  try:s=urllib.request.urlopen(r,timeout=30)
  except urllib.error.HTTPError as e:s=e
  with s:return s.status,json.load(s)
 def ecrire(self,op,p):
  code,r=self.api(op,p,True);assert code==200,r;return r
 def preparer(self):
  self.fiches=[]
  for n in range(30):
   self.fiches.append(self.ecrire('enregistrer_fiche',dict(titre=f'Fiche de test {n:02}',contenu='**Référence**\n\n<script>window.INJECTION=true</script>',priorite=-2,tags=['analyse']))['fiche'])
  p=self.api('rechercher',dict(type='item',requete='La dérivée de la racine carrée est 1/(2√x) pour x > 0.',preparer_creation=True))[1]
  self.item=self.ecrire('enregistrer_item',dict(contenu='La dérivée de la racine carrée est 1/(2√x) pour x > 0.',alias=['sqrt'],preuve_recherche=p['preuve_recherche']))['item']
  for n in range(2):
   f=self.fiches[n];self.fiches[n]=self.ecrire('lier_item',dict(fiche_id=f['id'],version_fiche=f['version'],item_id=self.item['id'],action='rattacher'))['fiche']

class Serveur(BaseHTTPRequestHandler):
 environnement=None
 def log_message(self,*_):pass
 def retourner(self,statut,corps,mime='application/json',cookie=None):
  b=json.dumps(corps).encode() if mime=='application/json' else corps
  self.send_response(statut);self.send_header('Content-Type',mime);self.send_header('Cache-Control','no-store')
  self.send_header('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; font-src 'self'; connect-src 'self'; frame-ancestors 'none'")
  self.send_header('Content-Length',str(len(b)))
  if cookie:self.send_header('Set-Cookie',cookie)
  self.end_headers()
  try:self.wfile.write(b)
  except (BrokenPipeError,ConnectionResetError):pass
 def authentifie(self):
  c=http.cookies.SimpleCookie(self.headers.get('Cookie',''));e=self.environnement
  return e.session and c.get('session-test') and c['session-test'].value==e.session
 def do_GET(self):
  e=self.environnement
  if self.path=='/auth/session':return self.retourner(200,{'username':e.utilisateur,'csrf':e.jeton}) if self.authentifie() else self.retourner(401,{'error':'authentication_required'})
  p=(RACINE/'dist'/('app.html' if self.path in ['/', '/docs', '/docs/', '/privacy'] else self.path.lstrip('/'))).resolve()
  if not p.is_relative_to(RACINE/'dist') or not p.is_file():return self.retourner(404,{})
  self.retourner(200,p.read_bytes(),mimetypes.guess_type(p)[0] or 'application/octet-stream')
 def do_POST(self):
  e=self.environnement;p=json.loads(self.rfile.read(int(self.headers.get('Content-Length','0'))))
  if self.path=='/auth/login':
   if p!={'username':e.utilisateur,'password':'mot-de-passe-isole'}:return self.retourner(401,{'error':'invalid_credentials'})
   e.session=secrets.token_urlsafe(24);e.jeton=secrets.token_urlsafe(24)
   return self.retourner(200,{'username':e.utilisateur,'csrf':e.jeton},cookie=f'session-test={e.session}; HttpOnly; SameSite=Lax; Path=/')
  if not self.authentifie():return self.retourner(401,{'error':'authentication_required'})
  if self.headers.get('X-CSRF-Token')!=e.jeton:return self.retourner(403,{'error':'csrf_required'})
  if self.path=='/auth/logout':
   e.session=None;return self.retourner(200,{'ok':True},cookie='session-test=; Max-Age=0; Path=/')
  op=self.path.rsplit('/',1)[-1]
  assert not any(self.headers.get(h) for h in ['Authorization','X-Mrj-User','X-Vision-Authenticated','X-Vision-Browser'])
  e.appels.append((op,copy.deepcopy(p)))
  code,r=e.erreurs.pop(op) if op in e.erreurs else e.api(op,p)
  if p.get('requete') in e.retards:time.sleep(e.retards[p['requete']])
  if e.perdre==op:e.perdre=None;self.close_connection=True;return
  self.retourner(code,r)

def bouton(p,n):return p.get_by_role('button',name=n,exact=True).or_(p.get_by_role('link',name=n,exact=True))
def clic(p,n):bouton(p,n).click()
def attendre(p,op,action,statut=200):
 with p.expect_response(lambda r:r.url.endswith('/api/web/'+op)) as reponse:action()
 assert reponse.value.status==statut,(op,reponse.value.status,reponse.value.text())
 p.wait_for_timeout(80)
def connecter(p,e):
 p.get_by_label('Identifiant',exact=True).fill(e.utilisateur);p.get_by_label('Mot de passe',exact=True).fill('mot-de-passe-isole')
 attendre(p,'rechercher',lambda:clic(p,'Se connecter'))
def debordement(p):
 assert p.evaluate('document.documentElement.scrollWidth <= innerWidth + 1'),p.evaluate('[innerWidth,document.documentElement.scrollWidth]')

def verifier(p,e,url):
 erreurs=[];p.on('pageerror',lambda x:erreurs.append(str(x)));p.goto(url)
 expect(p.get_by_label('Identifiant',exact=True)).to_be_visible()
 assert not e.appels
 assert p.context.request.post(url+'api/web/rechercher',data={}).status==401
 connecter(p,e)
 assert p.context.request.post(url+'api/web/rechercher',data={}).status==403
 expect(p.get_by_text('30 résultats',exact=True)).to_be_visible()
 attendre(p,'rechercher',lambda:clic(p,'Suivant'));expect(bouton(p,'Fiche de test 20')).to_be_visible()
 attendre(p,'rechercher',lambda:clic(p,'Précédent'))
 for largeur in [320,375,768,1280]:
  p.set_viewport_size({'width':largeur,'height':900});debordement(p)
  p.get_by_label('Ouvrir le menu').click();expect(p.get_by_role('link',name='Tokens d’accès')).to_be_visible();debordement(p)
  assert p.get_by_role('link',name='Tokens d’accès').get_attribute('href')=='/auth/mcp'
  p.get_by_label('Ouvrir le menu').click();p.screenshot(path=str(RACINE/'rapports'/f'liste-{largeur}.png'),full_page=True)
 attendre(p,'lire',lambda:clic(p,'Fiche de test 00'));assert not p.evaluate('window.INJECTION || false')
 expect(p.get_by_text('Priorité -2 dB',exact=True)).to_be_visible()
 attendre(p,'lire',lambda:clic(p,'La dérivée de la racine carrée est 1/(2√x) pour x > 0.'));expect(p.get_by_text('Stabilité -15 dB',exact=True)).to_be_visible()
 expect(bouton(p,'Fiche de test 01')).to_be_visible()
 clic(p,'Modifier');p.get_by_label('Contenu de référence',exact=True).fill('  Réponse conservée\navec deux espaces et "guillemets".')
 e.erreurs['enregistrer_item']=(409,{'erreur':'conflit_version'})
 attendre(p,'enregistrer_item',lambda:clic(p,'Enregistrer'),409)
 expect(p.get_by_label('Contenu de référence',exact=True)).to_have_value('  Réponse conservée\navec deux espaces et "guillemets".')
 attendre(p,'lire',lambda:clic(p,'Enregistrer'))
 i=e.api('lire',dict(type='item',ids=[e.item['id']]))[1]['objets'][0]
 assert i['reference_a'] is None and i['stabilite']==-15 and i['contenu'].startswith('  ')
 expect(bouton(p,'Fiche de test 01')).to_be_visible()
 # Détachement depuis l'item, puis réutilisation du même item dans une fiche.
 police=p.locator('.mrjam-ecran').evaluate('(e) => getComputedStyle(e).fontFamily')
 p.get_by_role('button',name=re.compile('^Détacher : ')).first.click();p.set_viewport_size({'width':320,'height':900});debordement(p)
 assert p.locator('.mrjam-ecran').evaluate('(e) => getComputedStyle(e).fontFamily')==police, 'Police de page modifiée par le dialogue'
 assert p.get_by_role('dialog').evaluate('(e) => getComputedStyle(e).fontFamily')==police, 'Police du dialogue différente de la page'
 p.screenshot(path=str(RACINE/'rapports'/'confirmation-320.png'),full_page=True)
 attendre(p,'lire',lambda:clic(p,'Confirmer'));expect(bouton(p,'Fiche de test 00')).to_have_count(0)
 clic(p,'Ajouter un rattachement');p.get_by_label('Rechercher un objet à rattacher',exact=True).fill('Fiche de test 00')
 attendre(p,'rechercher',lambda:clic(p,'Chercher'));attendre(p,'lire',lambda:clic(p,'Rattacher : Fiche de test 00'))
 clic(p,'Archiver');attendre(p,'lire',lambda:clic(p,'Confirmer'));expect(bouton(p,'Restaurer')).to_be_visible()
 clic(p,'Restaurer');attendre(p,'lire',lambda:clic(p,'Confirmer'))
 # Une connaissance proche peut être réutilisée sans créer de doublon.
 attendre(p,'rechercher',lambda:clic(p,'Items'));clic(p,'Nouvel item')
 p.get_by_label('Contenu de référence',exact=True).fill(i['contenu'])
 attendre(p,'lire',lambda:clic(p,'Enregistrer'));expect(bouton(p,'Réutiliser cet item')).to_be_visible()
 assert not any(op=='enregistrer_item' and 'id' not in donnees for op,donnees in e.appels)
 attendre(p,'lire',lambda:clic(p,'Réutiliser cet item'));expect(bouton(p,'Fiche de test 01')).to_be_visible()
 # Une valeur négative distincte est enregistrée, sans saturation ni arrondi.
 attendre(p,'rechercher',lambda:clic(p,'Items'));clic(p,'Nouvel item')
 p.get_by_label('Contenu de référence',exact=True).fill('Un lemme indépendant relie les hypothèses à la conclusion.')
 expect(p.get_by_label('Titre',exact=True)).to_have_count(0)
 p.get_by_label('Stabilité initiale S (dB)',exact=True).fill('-129');clic(p,'Enregistrer')
 expect(p.get_by_text('La stabilité doit être un entier de −128 à +127 dB.',exact=True)).to_be_visible()
 p.get_by_label('Stabilité initiale S (dB)',exact=True).fill('-20');p.get_by_label('Justification de l’estimation (si S ≠ −15)',exact=True).fill('Estimation initiale explicitement faible.')
 attendre(p,'enregistrer_item',lambda:clic(p,'Enregistrer'));expect(p.get_by_text('Stabilité -20 dB',exact=True)).to_be_visible()
 clic(p,'Réglages');clic(p,'14 jours')
 p.get_by_label('Nombre typique de questions (1 à 20)',exact=True).fill('6')
 attendre(p,'regler_politique',lambda:clic(p,'Enregistrer la politique'))
 assert e.api('rechercher',dict(type='item',requete=''))[1]['politique']['intervalle_jours']==14
 assert e.api('rechercher',dict(type='item',requete=''))[1]['politique']['questions_typiques']==6
 assert e.api('lire',dict(type='item',ids=[e.item['id']]))[1]['objets'][0]['stabilite']==-15
 clic(p,'Réglages')
 # Après expiration, seul le même compte retrouve la saisie et la même clé.
 attendre(p,'rechercher',lambda:clic(p,'Fiches'));clic(p,'Nouvelle fiche')
 p.get_by_label('Titre',exact=True).fill('Saisie après expiration');p.get_by_label('Contenu de référence',exact=True).fill('Brouillon intact.')
 e.session=None;attendre(p,'enregistrer_fiche',lambda:clic(p,'Enregistrer'),401)
 expect(p.get_by_label('Identifiant',exact=True)).to_be_visible();connecter(p,e)
 expect(p.get_by_label('Titre',exact=True)).to_have_value('Saisie après expiration')
 attendre(p,'lire',lambda:clic(p,'Réessayer la même écriture'))
 # Réponse perdue après COMMIT : le rejeu doit conserver une seule fiche.
 attendre(p,'rechercher',lambda:clic(p,'Fiches'));clic(p,'Nouvelle fiche')
 p.get_by_label('Titre',exact=True).fill('Réponse perdue');p.get_by_label('Contenu de référence',exact=True).fill('Une seule écriture.')
 e.perdre='enregistrer_fiche';clic(p,'Enregistrer');expect(bouton(p,'Réessayer la même écriture')).to_be_visible()
 cle=e.appels[-1][1]['cle'];attendre(p,'lire',lambda:clic(p,'Réessayer la même écriture'))
 assert [v['cle'] for op,v in e.appels if op=='enregistrer_fiche'][-2:]==[cle,cle]
 assert e.api('rechercher',dict(type='fiche',requete='Réponse perdue'))[1]['total']==1
 # Réponses tardives : le filtre le plus récent reste affiché.
 attendre(p,'rechercher',lambda:clic(p,'Fiches'));e.retards['Fiche de test 0']=.5
 p.get_by_label('Recherche',exact=True).fill('Fiche de test 0');clic(p,'Rechercher')
 p.get_by_label('Recherche',exact=True).fill('Réponse perdue');attendre(p,'rechercher',lambda:clic(p,'Rechercher'))
 p.wait_for_timeout(650);expect(p.get_by_text('1 résultats',exact=True)).to_be_visible();expect(bouton(p,'Fiche de test 00')).to_have_count(0)
 # Changer de compte ne récupère ni la saisie ni les données du précédent.
 clic(p,'Nouvelle fiche');p.get_by_label('Titre',exact=True).fill('Privé');p.get_by_label('Contenu de référence',exact=True).fill('Confidentiel')
 e.session=None;attendre(p,'enregistrer_fiche',lambda:clic(p,'Enregistrer'),401);e.utilisateur='autre-interface-test';connecter(p,e)
 expect(p.get_by_text('0 résultats',exact=True)).to_be_visible();expect(p.get_by_label('Titre',exact=True)).to_have_count(0)
 clic(p,'Ouvrir le menu');clic(p,'Se déconnecter');expect(p.get_by_label('Identifiant',exact=True)).to_be_visible()
 assert not erreurs,erreurs
 print('Navigateur : mobile 320/375/768/1280, recherche, pagination, édition, partage, doublons, archivage, session, CSRF, conflits et rejeu vérifiés.')

def main():
 args=argparse.ArgumentParser();args.add_argument('--port-serveur',type=int,required=True);port=args.parse_args().port_serveur
 assert 39000<=port<40000,'Port local de test exigé.'
 e=Environnement(port);e.preparer();Serveur.environnement=e
 serveur=ThreadingHTTPServer(('127.0.0.1',0),Serveur);threading.Thread(target=serveur.serve_forever,daemon=True).start()
 (RACINE/'rapports').mkdir(exist_ok=True)
 try:
  with sync_playwright() as pw:
   navigateur=pw.chromium.launch();contexte=navigateur.new_context(viewport={'width':1280,'height':900});p=contexte.new_page()
   try:verifier(p,e,f'http://127.0.0.1:{serveur.server_port}/')
   except Exception:
    p.screenshot(path=str(RACINE/'rapports'/'echec.png'),full_page=True)
    (RACINE/'rapports'/'echec-texte.txt').write_text(p.locator('body').inner_text());raise
   finally:navigateur.close()
 finally:serveur.shutdown()
if __name__=='__main__':main()
