"""Tests navigateur HTTP, sur faux serveur local ou Common Lisp/PostgreSQL isolés.

Aucune URL distante n'est acceptée. Le service de session ci-dessous est une
DOUBLURE de contrat : ces tests ne valident pas Nginx ni le SSO de production.
"""
from __future__ import annotations
import argparse
import base64
import copy
from datetime import datetime, timezone
import functools
import http.cookies
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import mimetypes
import os
from pathlib import Path
import secrets
import subprocess
import threading
import time
import urllib.error
import urllib.request
from urllib.parse import urlsplit

from playwright.sync_api import sync_playwright, expect

RACINE = Path(__file__).resolve().parents[1]
HORS_LIGNE = os.environ.get('HORS_LIGNE') == '1'
INSTRUMENTER = '''
window.__reponsesTest = [];
const transportTest = window.fetch;
window.fetch = async (...argumentsTest) => {
  const retourTest = await transportTest(...argumentsTest);
  window.__reponsesTest.push({chemin: argumentsTest[0], statut: retourTest.status});
  return retourTest;
};
'''


class Environnement:
    def __init__(self, port_serveur: int | None):
        self.port_serveur = port_serveur
        self.session = None
        self.jeton = None
        self.utilisateur = 'lecteur-test'
        self.fiches = {}
        self.observations = []
        self.historique = []
        self.appels = []
        self.erreurs = {}
        self.retards = {}
        self.compteur = 0
        self.verrou = threading.RLock()

    def version(self):
        self.compteur += 1
        return f'2026-01-01T00:00:00.{self.compteur:06d}+00:00'

    def api(self, action, donnees):
        if self.port_serveur:
            req = urllib.request.Request(f'http://127.0.0.1:{self.port_serveur}/api/web/{action}',
                json.dumps(donnees).encode(), {'Content-Type': 'application/json',
                    'X-Vision-Authenticated': '1', 'X-Vision-Browser': '1', 'X-Mrj-User': self.utilisateur})
            try:
                reponse = urllib.request.urlopen(req, timeout=10)
            except urllib.error.HTTPError as erreur:
                reponse = erreur
            with reponse:
                return reponse.status, json.load(reponse)
        with self.verrou:
            return self.simuler(action, donnees)

    def simuler(self, action, donnees):
        if action == 'save':
            identifiant = donnees.get('sheetId', len(self.fiches) + 1)
            precedente = self.fiches.get(identifiant)
            if precedente and precedente['updatedAt'] != donnees.get('expectedUpdatedAt'):
                return 409, {'error': 'conflict'}
            version = self.version()
            fiche = {**donnees, 'id': identifiant, 'updatedAt': version,
                'createdAt': precedente['createdAt'] if precedente else version,
                'archivedAt': version if donnees['archived'] else None,
                'state': 'archived' if donnees['archived'] else 'new',
                'retrievability': None, 'reviewCount': 0, 'fsrsReviewCount': 0,
                'lastReviewedAt': None, 'lastOutcome': None}
            self.fiches[identifiant] = fiche
            self.historique.append({'id': len(self.historique) + 1, 'author': self.utilisateur, 'createdAt': version})
            return 200, {'saved': True, 'sheetId': identifiant}
        if action == 'list':
            fiches = list(self.fiches.values())
            if donnees['state'] != 'all':
                fiches = [f for f in fiches if bool(f['archivedAt']) == (donnees['state'] == 'archived')]
            compte = len(fiches)
            tags = sorted({t for f in fiches for t in f['tags']})
            terme = donnees['query'].lower()
            fiches = [f for f in fiches if terme in ' '.join([f['title'], f['body'], f['summary'], *f['tags'], *f['aliases']]).lower()]
            if donnees['tags']:
                combiner = all if donnees['tagMode'] == 'all' else any
                fiches = [f for f in fiches if combiner(t in f['tags'] for t in donnees['tags'])]
            for cle, champ, comparer in [('importance', 'importance', lambda x, y: x == y),
                    ('minStability', 'fsrsStability', lambda x, y: x >= y),
                    ('maxDifficulty', 'fsrsDifficulty', lambda x, y: x <= y),
                    ('maxRetrievability', 'retrievability', lambda x, y: x <= y)]:
                if cle in donnees:
                    fiches = [f for f in fiches if f[champ] is not None and comparer(f[champ], donnees[cle])]
            cle = donnees['sort']
            fiches.sort(key=lambda f: (f.get(cle) is not None, f.get(cle) or '', -f['id']), reverse=donnees['direction'] == 'desc')
            total = len(fiches)
            fiches = fiches[donnees['offset']:donnees['offset'] + donnees['limit']]
            return 200, {'sheets': copy.deepcopy(fiches), 'total': total,
                'tags': [{'tag': t, 'count': sum(t in f['tags'] for f in self.fiches.values())} for t in tags], 'counts': {'active': compte}}
        if action == 'get':
            fiche = self.fiches.get(donnees['sheetId'])
            if not fiche:
                return 404, {'error': 'not_found'}
            observations = self.observations if fiche['id'] == self.premiere else []
            debut = donnees.get('observationOffset', 0)
            return 200, {'found': True, 'sheet': copy.deepcopy(fiche),
                'observations': copy.deepcopy(observations[debut:debut + 50]), 'observationTotal': len(observations),
                'settings': {'modelVersion': 'fsrs-6', 'implementationVersion': 'doublure-isolee', 'desiredRetention': .9, 'parameters': [1, 2, 3]},
                'edits': copy.deepcopy(self.historique[-20:])}
        if action == 'correct':
            observation = next(o for o in self.observations if o['id'] == donnees['observationId'])
            if observation['correctionId'] != donnees['expectedCorrectionId']:
                return 409, {'error': 'conflict'}
            if not observation['original']:
                observation['original'] = {'note': observation['note'], 'context': observation['context']}
            observation.update(note=donnees['note'], context=donnees['context'], correctionId=observation['correctionId'] + 1, correctedAt=self.version())
            return 200, {'saved': True, 'sheetId': self.premiere}
        raise AssertionError(action)

    def preparer(self):
        if self.port_serveur:
            assert os.environ.get('PGDATABASE') == 'vision_interface_test', 'Base de test dédiée exigée.'
            assert os.environ.get('PGHOST') == '127.0.0.1', 'PostgreSQL local isolé exigé.'
        for numero in range(1, 31):
            fiche = {'title': f'Interface test {numero:02}', 'body': '  Deux espaces initiaux\n\n<script>window.INJECTION = true</script>\n**Texte enregistré**',
                'summary': 'Une synthèse de test', 'tags': ['analyse' if numero % 2 else 'logique', 'interface-fixture'],
                'aliases': ['autre nom'], 'importance': 3, 'dueAt': '2025-01-01T00:00:00Z',
                'fsrsStability': None, 'fsrsDifficulty': None, 'fsrsLastReviewedAt': None, 'archived': False}
            statut, retour = self.api('save', fiche)
            assert statut == 200, retour
            if numero == 1:
                self.premiere = retour['sheetId']
        if self.port_serveur:
            sql = f"INSERT INTO vision_memory_observations(sheet_id,outcome,note,context) SELECT {self.premiere},'partial','Observation '||n,'{{\"fait\":true}}'::jsonb FROM generate_series(1,111) n"
            subprocess.run(['psql', '-XAt', '-v', 'ON_ERROR_STOP=1', '-c', sql], check=True, stdout=subprocess.DEVNULL)
        else:
            self.observations = [{'id': n, 'outcome': 'partial', 'note': f'Observation {n}', 'context': {'fait': True},
                'reviewedAt': '2026-01-01T00:00:00Z', 'nextReviewAt': None, 'rating': None,
                'schedulingApplied': False, 'previousStability': None, 'newStability': None,
                'previousDifficulty': None, 'newDifficulty': None, 'elapsedDays': None, 'scheduledDays': None,
                'schedulerVersion': None, 'desiredRetention': None, 'correctionId': 0, 'original': None, 'correctedAt': None}
                for n in range(111, 0, -1)]


class Serveur(BaseHTTPRequestHandler):
    environnement: Environnement

    def log_message(self, *_):
        pass

    def retourner(self, statut, corps, type_mime='application/json', cookie=None):
        contenu = json.dumps(corps).encode() if type_mime == 'application/json' else corps
        self.send_response(statut)
        self.send_header('Content-Type', type_mime)
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('Content-Security-Policy', "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; font-src 'self'; connect-src 'self'; frame-ancestors 'none'")
        if cookie:
            self.send_header('Set-Cookie', cookie)
        self.send_header('Content-Length', str(len(contenu)))
        self.end_headers()
        try:
            self.wfile.write(contenu)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def authentifie(self):
        cookies = http.cookies.SimpleCookie(self.headers.get('Cookie', ''))
        return self.environnement.session and cookies.get('session-test') and cookies['session-test'].value == self.environnement.session

    def do_GET(self):
        chemin = urlsplit(self.path).path
        env = self.environnement
        if chemin == '/auth/session':
            if not self.authentifie():
                return self.retourner(401, {'error': 'authentication_required'})
            return self.retourner(200, {'username': env.utilisateur, 'csrf': env.jeton})
        cible = (RACINE / 'dist' / ('app.html' if chemin == '/' else chemin.lstrip('/'))).resolve()
        if not cible.is_relative_to(RACINE / 'dist') or not cible.is_file():
            return self.retourner(404, {'error': 'not_found'})
        self.retourner(200, cible.read_bytes(), mimetypes.guess_type(cible)[0] or 'application/octet-stream')

    def do_POST(self):
        env = self.environnement
        chemin = urlsplit(self.path).path
        longueur = int(self.headers.get('Content-Length', '0'))
        if longueur > 1048576:
            return self.retourner(413, {'error': 'too_large'})
        donnees = json.loads(self.rfile.read(longueur))
        if chemin == '/auth/login':
            if donnees != {'username': env.utilisateur, 'password': 'mot-de-passe-isole'}:
                return self.retourner(401, {'error': 'invalid_credentials'})
            env.session, env.jeton = secrets.token_urlsafe(24), secrets.token_urlsafe(24)
            return self.retourner(200, {'username': env.utilisateur, 'csrf': env.jeton}, cookie=f'session-test={env.session}; HttpOnly; SameSite=Lax; Path=/')
        if not self.authentifie():
            return self.retourner(401, {'error': 'authentication_required'})
        if self.headers.get('X-CSRF-Token') != env.jeton:
            return self.retourner(403, {'error': 'csrf_required'})
        if chemin == '/auth/logout':
            env.session = env.jeton = None
            return self.retourner(200, {'ok': True}, cookie='session-test=; Max-Age=0; Path=/')
        if not chemin.startswith('/api/web/'):
            return self.retourner(404, {'error': 'not_found'})
        assert not self.headers.get('Authorization')
        assert not self.headers.get('X-Vision-Authenticated')
        assert not self.headers.get('X-Vision-Browser')
        assert not self.headers.get('X-Mrj-User')
        env.appels.append((chemin, copy.deepcopy(donnees)))
        if chemin in env.erreurs:
            statut, corps = env.erreurs.pop(chemin)
        else:
            statut, corps = env.api(chemin.rsplit('/', 1)[1], donnees)
        if donnees.get('query') in env.retards:
            time.sleep(env.retards[donnees['query']])
        self.retourner(statut, corps)


def attendre_requete(page, chemin, action, statut=200):
    avant = page.evaluate('window.__reponsesTest.length')
    action()
    page.wait_for_function("([debut, chemin]) => window.__reponsesTest.slice(debut).some(r => r.chemin === chemin)", arg=[avant, chemin])
    resultat = page.evaluate("([debut, chemin]) => window.__reponsesTest.slice(debut).find(r => r.chemin === chemin).statut", [avant, chemin])
    assert resultat == statut, (chemin, resultat)
    page.wait_for_timeout(60)


def bouton(page, nom):
    return page.get_by_role('button', name=nom, exact=True)


def connecter(page, env):
    page.get_by_label('Identifiant', exact=True).fill(env.utilisateur)
    page.get_by_label('Mot de passe', exact=True).fill('mot-de-passe-isole')
    attendre_requete(page, '/api/web/list', lambda: page.get_by_label('Mot de passe', exact=True).press('Enter'))


def installer_hors_ligne(page, env):
    """Exécuter les vues et transitions en mémoire, sans contourner le blocage HTTP."""
    assert not env.port_serveur, 'Le mode hors ligne n’est pas un test HTTP/base.'
    def transport(chemin, options):
        donnees = json.loads(options.get('body', '{}'))
        entetes = options.get('headers', {})
        assert options['credentials'] == 'same-origin'
        assert not set(entetes) & {'Authorization', 'X-Vision-Authenticated', 'X-Vision-Browser', 'X-Mrj-User'}
        statut, corps = 401, {'error': 'authentication_required'}
        if chemin == '/auth/login':
            if donnees == {'username': env.utilisateur, 'password': 'mot-de-passe-isole'}:
                env.session, env.jeton = secrets.token_urlsafe(24), secrets.token_urlsafe(24)
                statut, corps = 200, {'username': env.utilisateur, 'csrf': env.jeton}
            else:
                corps = {'error': 'invalid_credentials'}
        elif env.session:
            if chemin == '/auth/session':
                statut, corps = 200, {'username': env.utilisateur, 'csrf': env.jeton}
            elif entetes.get('X-CSRF-Token') != env.jeton:
                statut, corps = 403, {'error': 'csrf_required'}
            elif chemin == '/auth/logout':
                env.session = env.jeton = None
                statut, corps = 200, {'ok': True}
            else:
                env.appels.append((chemin, copy.deepcopy(donnees)))
                statut, corps = env.erreurs.pop(chemin) if chemin in env.erreurs else env.api(chemin.rsplit('/', 1)[1], donnees)
        return {'statut': statut, 'corps': corps, 'retard': env.retards.get(donnees.get('query'), 0) * 1000}
    page.expose_function('transportMemoire', transport)
    page.set_content('<html lang="fr"><head><meta charset="utf-8"></head><body><div id="application"></div></body></html>')
    css = (RACINE / 'dist/assets/mrjam/signature.css').read_text()
    import re
    page.add_style_tag(content=re.sub(r'@font-face\{[^}]+\}', '', css))
    page.add_script_tag(content="""
window.fetch = async (chemin, options) => {
  const resultat = await window.transportMemoire(chemin, options);
  if (resultat.retard) await new Promise(resolve => setTimeout(resolve, resultat.retard));
  return new Response(JSON.stringify(resultat.corps), {status: resultat.statut, headers: {'Content-Type':'application/json'}});
};
""")
    page.add_script_tag(content=INSTRUMENTER)
    page.add_script_tag(content=(RACINE / 'dist/app.js').read_text())
    page.wait_for_selector('img[alt="Logo MrJ.am"]')
    logo = base64.b64encode((RACINE / 'dist/assets/mrjam/Echologo.svg').read_bytes()).decode()
    page.get_by_role('img', name='Logo MrJ.am').evaluate('(image, source) => image.src = source', 'data:image/svg+xml;base64,' + logo)


def executer(env, adresse, chromium):
    rapports = RACINE / 'rapports'
    rapports.mkdir(exist_ok=True)
    bilans = []
    contexte = chromium.new_context(viewport={'width': 1280, 'height': 900}, timezone_id='Europe/Paris')
    page = contexte.new_page()
    erreurs_js = []
    page.on('pageerror', lambda erreur: erreurs_js.append(str(erreur)))
    if HORS_LIGNE:
        installer_hors_ligne(page, env)
    else:
        page.add_init_script(INSTRUMENTER)
        page.goto(adresse)
    expect(page.get_by_label('Identifiant', exact=True)).to_be_visible()
    assert not env.appels, 'Lecture de données avant connexion.'
    if not HORS_LIGNE:
        assert contexte.request.post(adresse + 'api/web/list', data={}).status == 401
    page.get_by_label('Identifiant', exact=True).fill(env.utilisateur)
    page.get_by_label('Mot de passe', exact=True).fill('incorrect')
    bouton(page, 'Se connecter').click()
    expect(page.get_by_text('Erreur :', exact=False)).to_be_visible()
    connecter(page, env)
    if not HORS_LIGNE:
        assert contexte.request.post(adresse + 'api/web/list', data={}).status == 403
    bilans.append('Connexion par Entrée, refus anonyme et CSRF, aucun en-tête interne navigateur')

    bouton(page, 'Filtres et tri').click()
    attendre_requete(page, '/api/web/list', lambda: page.get_by_label('Trier les fiches', exact=True).select_option('title'))
    expect(bouton(page, 'Interface test 01')).to_be_visible()
    attendre_requete(page, '/api/web/list', lambda: bouton(page, 'Suivant').click())
    assert env.appels[-1][1]['offset'] == 25
    expect(bouton(page, 'Interface test 30')).to_be_visible()
    attendre_requete(page, '/api/web/list', lambda: bouton(page, 'Précédent').click())
    page.get_by_label('Rappel estimé maximal (%)', exact=True).fill('65')
    attendre_requete(page, '/api/web/list', lambda: bouton(page, 'Appliquer les filtres').click())
    assert env.appels[-1][1]['maxRetrievability'] == .65
    page.get_by_label('Échéance jusqu’au (AAAA-MM-JJ)', exact=True).fill('2026-09-21')
    attendre_requete(page, '/api/web/list', lambda: bouton(page, 'Appliquer les filtres').click())
    assert env.appels[-1][1]['dueBefore'] == '2026-09-21T21:59:59.999Z'
    attendre_requete(page, '/api/web/list', lambda: bouton(page, 'Réinitialiser').click())
    attendre_requete(page, '/api/web/list', lambda: page.get_by_role('checkbox', name='analyse (15)', exact=True).click())
    assert env.appels[-1][1]['tags'] == ['analyse']
    attendre_requete(page, '/api/web/list', lambda: page.get_by_role('radio', name='Au moins un des tags', exact=True).click())
    assert env.appels[-1][1]['tagMode'] == 'any'
    attendre_requete(page, '/api/web/list', lambda: bouton(page, 'Réinitialiser').click())
    bilans.append('Pagination serveur, tri, tags tous/au moins un, rappel en pourcentage, fin de journée locale')

    env.retards['aucune-ancienne-recherche'] = .4
    page.get_by_label('Rechercher dans les fiches', exact=True).fill('aucune-ancienne-recherche')
    bouton(page, 'Rechercher').click()
    page.wait_for_timeout(50)
    page.get_by_label('Rechercher dans les fiches', exact=True).fill('Interface test 01')
    attendre_requete(page, '/api/web/list', lambda: bouton(page, 'Rechercher').click())
    page.wait_for_timeout(450)
    expect(bouton(page, 'Interface test 01')).to_be_visible()
    bilans.append('Une réponse de recherche tardive ne remplace pas la recherche actuelle')

    for largeur in [320, 375, 768, 1280]:
        page.set_viewport_size({'width': largeur, 'height': 900})
        assert page.evaluate('document.documentElement.scrollWidth <= innerWidth + 1')
        page.screenshot(path=str(rapports / f'fiches-{largeur}.png'), full_page=True)
    attendre_requete(page, '/api/web/get', lambda: bouton(page, 'Interface test 01').click())
    assert not page.evaluate('Boolean(window.INJECTION)')
    assert page.locator('#detail').get_by_text('Texte enregistré', exact=True).count() == 1
    assert '  Deux espaces initiaux' in page.locator('#detail').text_content()
    assert 'Une synthèse de test' not in page.locator('#detail').text_content()
    expect(page.locator('#detail')).to_be_focused()
    bouton(page, 'Modifier').click()
    expect(page.get_by_label('Titre', exact=True)).to_be_focused()
    expect(page.get_by_label('Synthèse', exact=True)).to_have_count(0)
    original = page.get_by_label('Contenu', exact=True).input_value()
    page.get_by_label('Titre', exact=True).fill('Titre humain conservé')
    env.erreurs['/api/web/save'] = (409, {'error': 'conflict'})
    attendre_requete(page, '/api/web/save', lambda: bouton(page, 'Enregistrer').click(), 409)
    expect(page.get_by_label('Titre', exact=True)).to_have_value('Titre humain conservé')
    expect(page.get_by_text('Cette fiche ou observation a été modifiée', exact=False)).to_be_visible()
    assert env.appels[-1][1]['body'] == original
    assert 'expectedUpdatedAt' in env.appels[-1][1]
    bouton(page, 'Retour aux fiches').click()
    expect(page.get_by_role('dialog', name='Abandonner les modifications ?', exact=True)).to_be_visible()
    expect(bouton(page, 'Continuer la saisie')).to_be_visible()
    bouton(page, 'Continuer la saisie').focus()
    page.keyboard.press('Tab')
    expect(bouton(page, 'Abandonner')).to_be_focused()
    page.keyboard.press('Shift+Tab')
    expect(bouton(page, 'Continuer la saisie')).to_be_focused()
    page.locator('#edition input').first.evaluate('(e) => e.focus()')
    assert page.evaluate("document.activeElement.closest('dialog') !== null"), 'Fond du dialogue actif'
    bouton(page, 'Continuer la saisie').click()
    expect(page.get_by_label('Titre', exact=True)).to_have_value('Titre humain conservé')
    bilans.append('HTML non exécuté, espaces et contenu conservés, conflit 409 sans écrasement, abandon explicite')

    # L'expiration masque les données, et seul le même compte retrouve son brouillon.
    env.session = None
    bouton(page, 'Enregistrer').click()
    expect(page.get_by_label('Identifiant', exact=True)).to_be_visible()
    assert 'Titre humain conservé' not in page.locator('body').inner_text()
    connecter(page, env)
    expect(page.get_by_label('Titre', exact=True)).to_have_value('Titre humain conservé')
    bouton(page, 'Paramètres').click()
    page.get_by_label('Stabilité (jours)', exact=True).fill('5.75')
    page.get_by_label('Difficulté (1 à 10)', exact=True).fill('4.2')
    page.get_by_label('Date de référence du modèle (date ISO)', exact=True).fill('2026-01-01T00:00:00.123456+00:00')
    attendre_requete(page, '/api/web/save', lambda: bouton(page, 'Enregistrer').click())
    expect(bouton(page, 'Modifier')).to_be_visible()
    sauvegarde = next(d for p, d in reversed(env.appels) if p == '/api/web/save')
    assert sauvegarde['fsrsStability'] == 5.75
    assert sauvegarde['fsrsLastReviewedAt'] == '2026-01-01T00:00:00.123456+00:00'
    assert not set(sauvegarde) & {'retrievability', 'reviewCount', 'fsrsReviewCount'}
    bilans.append('Session expirée : données masquées, brouillon du même compte retrouvé, paramètres sans recalcul et précision des dates préservée')

    bouton(page, 'Observations').click()
    attendre_requete(page, '/api/web/get', lambda: bouton(page, 'Observations suivantes').click())
    assert env.appels[-1][1]['observationOffset'] == 50
    attendre_requete(page, '/api/web/get', lambda: bouton(page, 'Observations suivantes').click())
    assert env.appels[-1][1]['observationOffset'] == 100
    expect(page.get_by_role('button', name='Corriger l’observation', exact=True)).to_have_count(11)
    page.get_by_role('button', name='Corriger l’observation', exact=True).first.click()
    expect(page.get_by_label('Observation', exact=True)).to_be_focused()
    page.get_by_label('Observation', exact=True).fill('Correction humaine isolée')
    page.get_by_label('Informations complémentaires (JSON)', exact=True).fill('[]')
    bouton(page, 'Enregistrer la correction').click()
    expect(page.get_by_text('Les informations complémentaires doivent être un objet JSON valide.', exact=False)).to_be_visible()
    page.get_by_label('Informations complémentaires (JSON)', exact=True).fill('{"fait":true,"correction":"isolée"}')
    env.erreurs['/api/web/correct'] = (409, {'error': 'conflict'})
    attendre_requete(page, '/api/web/correct', lambda: bouton(page, 'Enregistrer la correction').click(), 409)
    expect(page.get_by_label('Observation', exact=True)).to_have_value('Correction humaine isolée')
    attendre_requete(page, '/api/web/correct', lambda: bouton(page, 'Enregistrer la correction').click())
    expect(page.get_by_label('Observation', exact=True)).to_have_count(0)
    expect(page.get_by_text('Correction humaine isolée', exact=True)).to_be_visible()
    assert 'Version originale' in page.locator('#observations').inner_text()
    bilans.append('111 observations accessibles, correction JSON validée, conflit conservé, original et instantanés toujours consultables')

    bouton(page, 'Modifier').click()
    bouton(page, 'Paramètres').click()
    page.get_by_role('checkbox', name='Archiver cette fiche (réversible)', exact=True).click()
    attendre_requete(page, '/api/web/save', lambda: bouton(page, 'Enregistrer').click())
    expect(bouton(page, 'Modifier')).to_be_visible()
    assert next(d for p, d in reversed(env.appels) if p == '/api/web/save')['archived'] is True
    bouton(page, 'Modifier').click()
    bouton(page, 'Paramètres').click()
    page.get_by_role('checkbox', name='Archiver cette fiche (réversible)', exact=True).click()
    attendre_requete(page, '/api/web/save', lambda: bouton(page, 'Enregistrer').click())
    expect(bouton(page, 'Modifier')).to_be_visible()
    assert next(d for p, d in reversed(env.appels) if p == '/api/web/save')['archived'] is False
    bilans.append('Archivage et restauration sans suppression')

    bouton(page, 'Paramètres').click()
    expect(page.get_by_text('Cette vue n’est pas un historique exhaustif.', exact=False)).to_be_visible()
    for largeur in [320, 375, 768, 1280]:
        page.set_viewport_size({'width': largeur, 'height': 900})
        page.wait_for_timeout(70)
        assert page.evaluate('document.documentElement.scrollWidth <= innerWidth + 1'), f'Débordement à {largeur}px'
        page.screenshot(path=str(rapports / f'parametres-{largeur}.png'), full_page=True)
    signature = page.locator('.mrjam')
    expect(signature).to_have_text('MrJ.am')
    assert signature.evaluate('(e) => getComputedStyle(e).userSelect') == 'text'
    assert page.get_by_role('img', name='Logo MrJ.am').evaluate('(e) => e.complete && e.naturalWidth > 0')
    if not HORS_LIGNE:
        assert page.evaluate("async () => (await document.fonts.load('40px MrJamSignature')).length > 0")
        assert page.evaluate("document.fonts.check('40px MrJamSignature')")
    bilans.append('Logo original, signature MrJ.am sélectionnable et police exacte chargée ; paramètres sans débordement à quatre largeurs')

    page.set_viewport_size({'width': 1280, 'height': 900})
    bouton(page, 'Retour aux fiches').click()
    bouton(page, 'Nouvelle fiche').click()
    expect(page.get_by_label('Titre', exact=True)).to_be_focused()
    page.get_by_label('Titre', exact=True).fill('Création isolée')
    page.get_by_label('Contenu', exact=True).fill('  Un contenu nouveau\n\nAvec ses espaces.')
    bouton(page, 'Paramètres').click()
    assert page.get_by_label('Prochaine échéance (date ISO)', exact=True).input_value().endswith('Z')
    page.get_by_label('Stabilité (jours)', exact=True).fill('1')
    nombre_appels = len(env.appels)
    bouton(page, 'Enregistrer').click()
    expect(page.get_by_text('Renseignez ensemble stabilité', exact=False)).to_be_visible()
    assert len(env.appels) == nombre_appels
    page.get_by_label('Stabilité (jours)', exact=True).fill('')
    attendre_requete(page, '/api/web/save', lambda: bouton(page, 'Enregistrer').click())
    expect(bouton(page, 'Modifier')).to_be_visible()
    nouvelle = next(d for p, d in reversed(env.appels) if p == '/api/web/get')['sheetId']
    bouton(page, 'Modifier').click()
    page.get_by_label('Titre', exact=True).fill('Mon brouillon concurrent')
    # Ce conflit est produit par une véritable autre écriture, pas par une réponse 409 simulée.
    statut, retour = env.api('get', {'sheetId': nouvelle})
    assert statut == 200
    precedente = next(d for p, d in reversed(env.appels) if p == '/api/web/save')
    concurrente = {**precedente, 'sheetId': nouvelle, 'expectedUpdatedAt': retour['sheet']['updatedAt'],
        'title': 'Modification concurrente de test'}
    assert env.api('save', concurrente)[0] == 200
    attendre_requete(page, '/api/web/save', lambda: bouton(page, 'Enregistrer').click(), 409)
    expect(page.get_by_label('Titre', exact=True)).to_have_value('Mon brouillon concurrent')
    assert env.api('get', {'sheetId': nouvelle})[1]['sheet']['title'] == 'Modification concurrente de test'
    bouton(page, 'Recharger la fiche').click()
    expect(page.locator('#confirmation')).to_be_focused()
    page.keyboard.press('Escape')
    expect(page.get_by_label('Titre', exact=True)).to_have_value('Mon brouillon concurrent')
    expect(page.get_by_label('Titre', exact=True)).to_be_focused()
    bouton(page, 'Recharger la fiche').click()
    attendre_requete(page, '/api/web/get', lambda: bouton(page, 'Abandonner').click())
    bouton(page, 'Modifier').click()
    expect(page.get_by_label('Titre', exact=True)).to_have_value('Modification concurrente de test')
    page.get_by_label('Titre', exact=True).fill('Saisie sans confirmation serveur')
    env.erreurs['/api/web/save'] = (200, {'saved': False, 'sheetId': nouvelle})
    attendre_requete(page, '/api/web/save', lambda: bouton(page, 'Enregistrer').click())
    expect(page.get_by_label('Titre', exact=True)).to_have_value('Saisie sans confirmation serveur')
    expect(page.get_by_text('La réponse ne respecte pas le contrat attendu', exact=False)).to_be_visible()
    bouton(page, 'Annuler').click()
    bouton(page, 'Abandonner').click()
    bilans.append('Création, échéance initiale, validation du trio mémoriel, conflit réel entre deux écritures, Échap/focus et refus des succès non confirmés')
    bouton(page, 'Modifier').click()
    page.get_by_label('Titre', exact=True).fill('Brouillon privé du premier compte')
    env.session = None
    bouton(page, 'Enregistrer').click()
    expect(page.get_by_label('Identifiant', exact=True)).to_be_visible()
    env.utilisateur = 'autre-compte-test'
    connecter(page, env)
    assert 'Brouillon privé du premier compte' not in page.locator('body').inner_text()
    bouton(page, 'Se déconnecter').click()
    expect(page.get_by_label('Identifiant', exact=True)).to_be_visible()
    assert 'Correction humaine isolée' not in page.locator('body').inner_text()
    if not HORS_LIGNE:
        assert page.evaluate('localStorage.length + sessionStorage.length') == 0
    assert not erreurs_js, erreurs_js
    bilans.append('Changement de compte et déconnexion sans fuite de brouillon ; aucune erreur JavaScript')
    if not HORS_LIGNE: bilans.append('Aucun stockage localStorage/sessionStorage de données ou de secrets')
    contexte.close()
    rapport = {'mode': 'mémoire uniquement, aucun HTTP' if HORS_LIGNE else ('Common Lisp et PostgreSQL isolés' if env.port_serveur else 'doublure HTTP locale'),
        'controles': bilans, 'sessionInfrastructureReelle': False, 'signatureTypographiqueValidee': not HORS_LIGNE,
        'stockageNavigateurControle': not HORS_LIGNE, 'cookiesHttpControles': not HORS_LIGNE}
    nom = 'hors-ligne' if HORS_LIGNE else ('base' if env.port_serveur else 'doublure')
    (rapports / f'controles-{nom}.json').write_text(json.dumps(rapport, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps(rapport, ensure_ascii=False, indent=2))


def main():
    options = argparse.ArgumentParser(description=__doc__)
    options.add_argument('--port-serveur', type=int, help='Serveur Common Lisp isolé sur 127.0.0.1 uniquement')
    options.add_argument('--chromium', default=os.environ.get('CHROMIUM_EXECUTABLE'))
    args = options.parse_args()
    if args.port_serveur and not 1024 <= args.port_serveur <= 65535:
        raise SystemExit('Port local de test invalide.')
    env = Environnement(args.port_serveur)
    env.preparer()
    gestionnaire = type('ServeurIsole', (Serveur,), {'environnement': env})
    serveur = ThreadingHTTPServer(('127.0.0.1', 0), gestionnaire)
    fil = threading.Thread(target=serveur.serve_forever, daemon=True)
    fil.start()
    try:
        with sync_playwright() as pilote:
            navigateur = pilote.chromium.launch(executable_path=args.chromium, headless=True, args=['--no-sandbox'])
            try:
                executer(env, f'http://127.0.0.1:{serveur.server_port}/', navigateur)
            finally:
                navigateur.close()
    finally:
        serveur.shutdown()
        serveur.server_close()
        fil.join()


if __name__ == '__main__':
    main()
