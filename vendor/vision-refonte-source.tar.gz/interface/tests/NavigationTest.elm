module NavigationTest exposing (tests)

import Contrat as C
import Expect
import Fuzz
import Test exposing (Test, describe, fuzz, test)


tests : Test
tests =
    describe "Destinations des fiches et items"
        [ fuzz (Fuzz.intRange 1 2147483647) "Chaque identifiant positif garde son type et sa valeur dans le lien" <|
            \id ->
                [ C.Fiche, C.Item ]
                    |> List.map (\nature -> C.depuisAdresse (C.destination nature id) == Just ( nature, id ))
                    |> Expect.equal [ True, True ]
        , test "Les adresses invalides ne déclenchent pas une lecture arbitraire" <|
            \_ ->
                List.map C.depuisAdresse [ "", "fiche/1", "xfiche/1", "#fiche/0", "#fiche/-1", "#autre/1", "#item/1/2", "#item/1.5", "#fiche/NaN", "#item/" ]
                    |> Expect.equal (List.repeat 10 Nothing)
        , test "Une relation change de table, deux relations retrouvent la table d’origine" <|
            \_ ->
                Expect.equal [ C.Item, C.Fiche, C.Fiche, C.Item ]
                    [ C.autre C.Fiche, C.autre C.Item, C.autre (C.autre C.Fiche), C.autre (C.autre C.Item) ]
        , test "Les clés JSON demeurent celles du contrat serveur" <|
            \_ ->
                Expect.equal [ "fiche", "item", "priorite", "stabilite" ]
                    [ C.nom C.Fiche, C.nom C.Item, C.grandeur C.Fiche, C.grandeur C.Item ]
        ]
