"""Garde-fous : ElmUI partagé, pas de deuxième interface historique active."""
from pathlib import Path
import re
import unittest

RACINE = Path(__file__).resolve().parents[2]


class Architecture(unittest.TestCase):
    def test_presentation_uniquement_partagee(self):
        for chemin in (RACINE / 'interface/src').rglob('*.elm'):
            source = chemin.read_text()
            # Seuls les types et les feuilles textuelles appartiennent à Vision.
            for ligne in source.splitlines():
                if re.match(r'import (?:Html|Element)\b', ligne):
                    self.assertIn(ligne, ['import Html exposing (Html)', 'import Element exposing (Element)'], chemin)
            self.assertFalse(re.search(r'Html\.|Element\.(?!(?:text|none)\b)', source), chemin)

    def test_ancienne_interface_retiree(self):
        for nom in ['app.html', 'app.js', 'app.css']:
            self.assertFalse((RACINE / 'docs' / nom).exists(), nom)


if __name__ == '__main__':
    unittest.main()
