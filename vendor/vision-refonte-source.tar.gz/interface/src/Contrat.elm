module Contrat exposing (brouillon, chaine, entier, lignes, listes, nombre, nouveau, objet, texte, vrai)

import Dict exposing (Dict)
import Json.Decode as D
import Json.Encode as E exposing (Value)


chaine : String -> Value -> String
chaine cle valeur =
    D.decodeValue (D.field cle D.string) valeur |> Result.withDefault ""


entier : String -> Value -> Int
entier cle valeur =
    D.decodeValue (D.field cle D.int) valeur |> Result.withDefault 0


nombre : String -> Value -> Maybe Float
nombre cle valeur =
    D.decodeValue (D.field cle D.float) valeur |> Result.toMaybe


vrai : String -> Value -> Bool
vrai cle valeur =
    D.decodeValue (D.field cle D.bool) valeur |> Result.withDefault False


listes : String -> Value -> List Value
listes cle valeur =
    D.decodeValue (D.field cle (D.list D.value)) valeur |> Result.withDefault []


objet : String -> Value -> Value
objet cle valeur =
    D.decodeValue (D.field cle D.value) valeur |> Result.withDefault E.null


texte : Value -> String
texte valeur =
    D.decodeValue D.string valeur |> Result.withDefault ""


lignes : String -> List String
lignes =
    String.lines >> List.map String.trim >> List.filter ((/=) "")


nouveau : String -> Dict String String
nouveau nature =
    Dict.fromList
        [ ( "titre", "" )
        , ( "contenu", "" )
        , ( "suivi", "" )
        , ( "tags", "" )
        , ( "alias", "" )
        , ( "objectifs", "" )
        , ( "sens", "direct" )
        , ( "priorite", "0" )
        , ( "stabilite", "-15" )
        , ( "reference_a", "" )
        , ( "justification", "" )
        , ( "distinction", "" )
        ]


brouillon : String -> Value -> Dict String String
brouillon nature valeur =
    let
        chaines =
            List.map (\cle -> ( cle, chaine cle valeur )) [ "titre", "contenu", "suivi" ]

        tableaux =
            List.map (\cle -> ( cle, listes cle valeur |> List.map texte |> String.join "\n" )) [ "alias", "tags", "objectifs", "sens" ]
    in
    Dict.union (Dict.fromList (chaines ++ tableaux ++ [ ( "priorite", String.fromInt (entier "priorite" valeur) ), ( "stabilite", String.fromInt (entier "stabilite" valeur) ) ])) (nouveau nature)
