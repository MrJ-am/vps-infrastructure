port module Main exposing (main)

import Browser
import Contrat as C
import Dict exposing (Dict)
import Element exposing (Element)
import Html exposing (Html)
import Html.Attributes as A
import Json.Decode as D
import Json.Encode as E exposing (Value)
import MrJam exposing (Niveau(..), actions, avis, bouton, boutonDestructif, boutonEnCours, boutonInactif, boutonSecondaire, champ, motDePasse, page, paragraphe, pile, section, selecteur, texteSecondaire, zoneTexte)
import MrJam.Donnees as Donnees
import MrJam.Fenetres as Fenetres
import MrJam.Lecture as Lecture


port requete : Value -> Cmd message


port reponse : (Value -> message) -> Sub message


port effets : Value -> Cmd message


type alias Flags =
    { cle : String, instant : String }


type alias Session =
    { compte : String, csrf : String }


type But
    = SessionInitiale
    | Connecter
    | Deconnecter
    | Lister String
    | Lire String Int
    | Enregistrer String
    | VerifierCreation
    | LireCandidats (List Int)
    | RechercherLiens
    | Lier
    | Regler


type alias Ecriture =
    { but : But, chemin : String, corps : Value }


type alias Suspension =
    { compte : String, nature : String, detail : Maybe Value, brouillon : Dict String String, ecriture : Maybe Ecriture }


type Confirmation
    = Changer String
    | Fermer
    | Quitter
    | Archiver Bool
    | Detacher Int Int Int


type alias Modele =
    { flags : Flags
    , session : Maybe Session
    , identifiant : String
    , secret : String
    , verification : Bool
    , nature : String
    , recherche : String
    , tags : String
    , etat : String
    , tri : String
    , debut : Int
    , resultats : List Value
    , total : Int
    , detail : Maybe Value
    , debutLiens : Int
    , edition : Bool
    , modifie : Bool
    , brouillon : Dict String String
    , candidats : List Value
    , preuve : Maybe String
    , creationVerifiee : Bool
    , liensOuverts : Bool
    , rechercheLiens : String
    , liensTrouves : List Value
    , politique : Value
    , intervalle : String
    , budget : String
    , reglages : Bool
    , numero : Int
    , dernierListe : Int
    , dernierDetail : Int
    , attentes : Dict Int But
    , ecriture : Maybe Ecriture
    , suspension : Maybe Suspension
    , confirmation : Maybe Confirmation
    , message : Maybe ( Niveau, String )
    }


type Message
    = Recevoir Value
    | Identifiant String
    | Secret String
    | Connexion
    | Naviguer Confirmation
    | Confirmer
    | Rester
    | Recherche String
    | Tags String
    | Filtrer
    | Etat String
    | Tri String
    | Pagination Int
    | Ouvrir String Int
    | Nouvelle
    | Editer
    | Saisir String String
    | Sauver
    | CreerDistinct
    | Reutiliser Int
    | Reessayer
    | AfficherLiens
    | RechercheLiens String
    | ChercherLiens
    | Rattacher Value
    | PageLiens Int
    | Reglages
    | Intervalle String
    | Budget String
    | SauverPolitique


initial : Flags -> Modele
initial flags =
    { flags = flags
    , session = Nothing
    , identifiant = ""
    , secret = ""
    , verification = True
    , nature = "fiche"
    , recherche = ""
    , tags = ""
    , etat = "actif"
    , tri = "titre"
    , debut = 0
    , resultats = []
    , total = 0
    , detail = Nothing
    , debutLiens = 0
    , edition = False
    , modifie = False
    , brouillon = C.nouveau "fiche"
    , candidats = []
    , preuve = Nothing
    , creationVerifiee = False
    , liensOuverts = False
    , rechercheLiens = ""
    , liensTrouves = []
    , politique = E.null
    , intervalle = "90"
    , budget = ""
    , reglages = False
    , numero = 0
    , dernierListe = 0
    , dernierDetail = 0
    , attentes = Dict.empty
    , ecriture = Nothing
    , suspension = Nothing
    , confirmation = Nothing
    , message = Nothing
    }


main : Program Flags Modele Message
main =
    Browser.element
        { init = \flags -> envoyer SessionInitiale "/auth/session" E.null (initial flags)
        , update =
            \msg m ->
                let
                    ( n, cmd ) =
                        actualiser msg m
                in
                ( n, Cmd.batch [ cmd, effet "proteger" (E.bool (n.modifie || n.ecriture /= Nothing || n.suspension /= Nothing)) ] )
        , view = vue
        , subscriptions = always (reponse Recevoir)
        }


effet : String -> Value -> Cmd Message
effet nom contenu =
    effets (E.object [ ( "nom", E.string nom ), ( "valeur", contenu ) ])


notifier : Niveau -> String -> Modele -> ( Modele, Cmd Message )
notifier niveau texte m =
    ( { m | message = Just ( niveau, texte ) }, Cmd.none )


envoyer : But -> String -> Value -> Modele -> ( Modele, Cmd Message )
envoyer but chemin corps m =
    let
        numero =
            m.numero + 1

        suite =
            { m | numero = numero, attentes = Dict.insert numero but m.attentes }

        n =
            case but of
                Lister _ ->
                    { suite | dernierListe = numero }

                Lire _ _ ->
                    { suite | dernierDetail = numero }

                _ ->
                    suite
    in
    ( n
    , requete
        (E.object
            [ ( "numero", E.int numero )
            , ( "chemin", E.string chemin )
            , ( "methode"
              , E.string
                    (if chemin == "/auth/session" then
                        "GET"

                     else
                        "POST"
                    )
              )
            , ( "csrf", m.session |> Maybe.map (.csrf >> E.string) |> Maybe.withDefault E.null )
            , ( "corps", corps )
            ]
        )
    )


api : But -> String -> List ( String, Value ) -> Modele -> ( Modele, Cmd Message )
api but operation valeurs =
    envoyer but ("/api/web/" ++ operation) (E.object valeurs)


ecrire : But -> String -> List ( String, Value ) -> Modele -> ( Modele, Cmd Message )
ecrire but operation valeurs m =
    if m.ecriture /= Nothing then
        notifier Information "Une écriture attend son résultat. Réessayez la même opération." m

    else
        let
            e =
                { but = but, chemin = "/api/web/" ++ operation, corps = E.object (( "cle", E.string (m.flags.cle ++ "-" ++ String.fromInt (m.numero + 1)) ) :: ( "emise_a", E.string m.flags.instant ) :: valeurs) }
        in
        envoyer but e.chemin e.corps { m | ecriture = Just e, message = Nothing }


lister : Modele -> ( Modele, Cmd Message )
lister m =
    api (Lister m.nature)
        "rechercher"
        [ ( "type", E.string m.nature )
        , ( "requete", E.string m.recherche )
        , ( "etat", E.string m.etat )
        , ( "tri", E.string m.tri )
        , ( "limite", E.int 20 )
        , ( "decalage", E.int m.debut )
        , ( "tags", E.list E.string (String.split "," m.tags |> List.map String.trim |> List.filter ((/=) "")) )
        ]
        m


lire : String -> Int -> Modele -> ( Modele, Cmd Message )
lire nature id m =
    api (Lire nature id) "lire" [ ( "type", E.string nature ), ( "ids", E.list E.int [ id ] ), ( "decalage", E.int m.debutLiens ), ( "limite", E.int 20 ) ] m


valeur : String -> Modele -> String
valeur cle m =
    Dict.get cle m.brouillon |> Maybe.withDefault ""


corpsEdition : Modele -> List ( String, Value )
corpsEdition m =
    let
        textes =
            List.map (\cle -> ( cle, E.string (valeur cle m) )) [ "titre", "contenu", "suivi" ]

        tableaux =
            List.map (\cle -> ( cle, E.list E.string (C.lignes (valeur cle m)) ))
                (if m.nature == "fiche" then
                    [ "alias", "tags" ]

                 else
                    [ "alias", "objectifs", "sens" ]
                )

        version =
            m.detail |> Maybe.map (\d -> [ ( "id", E.int (C.entier "id" d) ), ( "version", E.int (C.entier "version" d) ) ]) |> Maybe.withDefault []

        specifiques =
            if m.nature == "fiche" then
                [ ( "priorite", E.int (String.toInt (valeur "priorite" m) |> Maybe.withDefault 0) ) ]

            else if m.detail /= Nothing then
                []

            else
                [ ( "stabilite", E.int (String.toInt (valeur "stabilite" m) |> Maybe.withDefault -15) )
                , ( "preuve_recherche", m.preuve |> Maybe.map E.string |> Maybe.withDefault E.null )
                , ( "distinction", E.string (valeur "distinction" m) )
                , ( "justification", E.string (valeur "justification" m) )
                ]
                    ++ (if String.isEmpty (valeur "reference_a" m) then
                            []

                        else
                            [ ( "reference_a", E.string (valeur "reference_a" m) ) ]
                       )
    in
    textes ++ tableaux ++ version ++ specifiques


sauver : Modele -> ( Modele, Cmd Message )
sauver m =
    if String.isEmpty (String.trim (valeur "titre" m)) || String.isEmpty (String.trim (valeur "contenu" m)) then
        notifier Erreur "Le titre et le contenu sont requis." m

    else if m.nature == "fiche" && not (entierValide -20 20 (valeur "priorite" m)) then
        notifier Erreur "La priorité doit être un entier de −20 à +20 dB." m

    else if m.nature == "item" && m.detail == Nothing && not (entierValide -128 127 (valeur "stabilite" m)) then
        notifier Erreur "La stabilité doit être un entier de −128 à +127 dB." m

    else if m.nature == "item" && m.detail == Nothing && not m.creationVerifiee then
        api VerifierCreation "rechercher" [ ( "type", E.string "item" ), ( "requete", E.string (valeur "titre" m) ), ( "preparer_creation", E.bool True ) ] m

    else if m.nature == "item" && (List.isEmpty (C.lignes (valeur "objectifs" m)) || List.isEmpty (C.lignes (valeur "sens" m))) then
        notifier Erreur "Précisez au moins un objectif et un sens de rappel." m

    else
        ecrire (Enregistrer m.nature) ("enregistrer_" ++ m.nature) (corpsEdition m) m


entierValide : Int -> Int -> String -> Bool
entierValide minimum maximum texte =
    String.toInt texte |> Maybe.map (\nombre -> nombre >= minimum && nombre <= maximum) |> Maybe.withDefault False


executer : Confirmation -> Modele -> ( Modele, Cmd Message )
executer action m =
    let
        n =
            { m | confirmation = Nothing, message = Nothing }
    in
    case action of
        Changer nature ->
            lister { n | nature = nature, detail = Nothing, edition = False, modifie = False, resultats = [], debut = 0, tri = "titre", candidats = [], liensOuverts = False }

        Fermer ->
            lister { n | detail = Nothing, edition = False, modifie = False, candidats = [], liensOuverts = False }

        Quitter ->
            envoyer Deconnecter "/auth/logout" (E.object []) n

        Archiver archive ->
            case n.detail of
                Nothing ->
                    ( n, Cmd.none )

                Just d ->
                    ecrire (Enregistrer n.nature) ("enregistrer_" ++ n.nature) [ ( "id", E.int (C.entier "id" d) ), ( "version", E.int (C.entier "version" d) ), ( "archive", E.bool archive ) ] n

        Detacher fiche item version ->
            ecrire Lier "lier_item" [ ( "fiche_id", E.int fiche ), ( "item_id", E.int item ), ( "version_fiche", E.int version ), ( "action", E.string "detacher" ) ] n


actualiser : Message -> Modele -> ( Modele, Cmd Message )
actualiser msg m =
    case msg of
        Recevoir r ->
            recevoir r m

        Identifiant s ->
            ( { m | identifiant = s }, Cmd.none )

        Secret s ->
            ( { m | secret = s }, Cmd.none )

        Connexion ->
            envoyer Connecter "/auth/login" (E.object [ ( "username", E.string m.identifiant ), ( "password", E.string m.secret ) ]) { m | secret = "" }

        Naviguer c ->
            if m.ecriture /= Nothing then
                notifier Information "Une écriture attend son résultat." m

            else if
                m.modifie
                    || (case c of
                            Archiver _ ->
                                True

                            Detacher _ _ _ ->
                                True

                            _ ->
                                False
                       )
            then
                ( { m | confirmation = Just c }, Cmd.none )

            else
                executer c m

        Confirmer ->
            m.confirmation |> Maybe.map (\c -> executer c { m | modifie = False }) |> Maybe.withDefault ( m, Cmd.none )

        Rester ->
            ( { m | confirmation = Nothing }, Cmd.none )

        Recherche s ->
            ( { m | recherche = s }, Cmd.none )

        Tags s ->
            ( { m | tags = s }, Cmd.none )

        Filtrer ->
            lister { m | debut = 0 }

        Etat s ->
            lister { m | etat = s, debut = 0 }

        Tri s ->
            lister { m | tri = s, debut = 0 }

        Pagination pas ->
            lister { m | debut = max 0 (m.debut + 20 * pas) }

        Ouvrir nature id ->
            if m.modifie || m.ecriture /= Nothing then
                notifier Information "Enregistrez ou fermez la saisie avant de consulter un autre objet." m

            else
                lire nature id { m | nature = nature, debutLiens = 0, detail = Nothing, edition = False, liensOuverts = False, candidats = [] }

        Nouvelle ->
            if m.modifie || m.ecriture /= Nothing then
                notifier Information "Terminez la saisie en cours." m

            else
                ( { m | detail = Nothing, edition = True, modifie = False, brouillon = C.nouveau m.nature, candidats = [], preuve = Nothing, creationVerifiee = False }, effet "focus" (E.string "edition") )

        Editer ->
            m.detail |> Maybe.map (\d -> ( { m | edition = True, brouillon = C.brouillon m.nature d }, effet "focus" (E.string "edition") )) |> Maybe.withDefault ( m, Cmd.none )

        Saisir cle s ->
            if m.ecriture /= Nothing then
                ( m, Cmd.none )

            else
                ( { m
                    | brouillon = Dict.insert cle s m.brouillon
                    , modifie = True
                    , creationVerifiee =
                        if cle == "titre" then
                            False

                        else
                            m.creationVerifiee
                  }
                , Cmd.none
                )

        Sauver ->
            sauver m

        CreerDistinct ->
            if String.length (valeur "distinction" m) < 10 then
                notifier Erreur "Précisez ce qui distingue cette connaissance des items trouvés." m

            else
                sauver { m | creationVerifiee = True }

        Reutiliser id ->
            lire "item" id { m | nature = "item", modifie = False, edition = False, candidats = [], preuve = Nothing, creationVerifiee = False, debutLiens = 0 }

        Reessayer ->
            m.ecriture |> Maybe.map (\e -> envoyer e.but e.chemin e.corps m) |> Maybe.withDefault ( m, Cmd.none )

        AfficherLiens ->
            ( { m | liensOuverts = not m.liensOuverts, liensTrouves = [] }, Cmd.none )

        RechercheLiens s ->
            ( { m | rechercheLiens = s }, Cmd.none )

        ChercherLiens ->
            api RechercherLiens
                "rechercher"
                [ ( "type"
                  , E.string
                        (if m.nature == "fiche" then
                            "item"

                         else
                            "fiche"
                        )
                  )
                , ( "requete", E.string m.rechercheLiens )
                , ( "limite", E.int 20 )
                ]
                m

        Rattacher cible ->
            case m.detail of
                Nothing ->
                    ( m, Cmd.none )

                Just d ->
                    let
                        f =
                            if m.nature == "fiche" then
                                d

                            else
                                cible

                        i =
                            if m.nature == "item" then
                                d

                            else
                                cible
                    in
                    ecrire Lier "lier_item" [ ( "fiche_id", E.int (C.entier "id" f) ), ( "item_id", E.int (C.entier "id" i) ), ( "version_fiche", E.int (C.entier "version" f) ), ( "action", E.string "rattacher" ) ] m

        PageLiens pas ->
            m.detail |> Maybe.map (\d -> lire m.nature (C.entier "id" d) { m | debutLiens = max 0 (m.debutLiens + 20 * pas) }) |> Maybe.withDefault ( m, Cmd.none )

        Reglages ->
            ( { m | reglages = not m.reglages }, Cmd.none )

        Intervalle s ->
            ( { m | intervalle = s }, Cmd.none )

        Budget s ->
            ( { m | budget = s }, Cmd.none )

        SauverPolitique ->
            if not (entierValide 1 3650 m.intervalle) || (m.budget /= "" && not (entierValide 1 1000 m.budget)) then
                notifier Erreur "L’intervalle doit être un entier de 1 à 3650 jours et le budget, vide ou un entier de 1 à 1000." m

            else
                ecrire Regler
                    "regler_politique"
                    [ ( "version", E.int (C.entier "version" m.politique) )
                    , ( "intervalle_jours", E.int (String.toInt m.intervalle |> Maybe.withDefault 90) )
                    , ( "budget", String.toInt m.budget |> Maybe.map E.int |> Maybe.withDefault E.null )
                    ]
                    m


recevoir : Value -> Modele -> ( Modele, Cmd Message )
recevoir retour m =
    let
        numero =
            C.entier "numero" retour

        statut =
            C.entier "statut" retour

        corps =
            C.objet "corps" retour

        erreur =
            let
                e =
                    C.chaine "erreur" corps
            in
            if e == "" then
                C.chaine "error" corps

            else
                e
    in
    case Dict.get numero m.attentes of
        Nothing ->
            ( m, Cmd.none )

        Just but ->
            let
                n =
                    { m | attentes = Dict.remove numero m.attentes }

                obsolete =
                    case but of
                        Lister _ ->
                            numero /= m.dernierListe

                        Lire _ _ ->
                            numero /= m.dernierDetail

                        _ ->
                            False
            in
            if obsolete then
                ( n, Cmd.none )

            else if (statut == 401 || erreur == "csrf_required") && but /= Connecter then
                let
                    suspension =
                        m.session |> Maybe.map (\s -> { compte = s.compte, nature = m.nature, detail = m.detail, brouillon = m.brouillon, ecriture = m.ecriture })

                    vide =
                        initial m.flags
                in
                ( { vide
                    | numero = m.numero
                    , verification = False
                    , suspension =
                        if m.modifie || m.ecriture /= Nothing then
                            suspension

                        else
                            Nothing
                    , message = Just ( Information, "Connectez-vous pour accéder à vos fiches et items." )
                  }
                , effet "annulerRequetes" E.null
                )

            else if statut == 0 then
                notifier Erreur "La réponse n’a pas été reçue. Une écriture a pu être enregistrée : utilisez Réessayer, qui conserve sa clé." n

            else if statut < 200 || statut >= 300 || erreur /= "" then
                notifier Erreur
                    (if statut == 409 then
                        "L’objet a changé. Votre saisie est conservée ; fermez puis relisez la version actuelle avant de concilier les modifications."

                     else
                        "Opération refusée : "
                            ++ (if erreur == "" then
                                    "réponse inattendue"

                                else
                                    erreur
                               )
                    )
                    { n | ecriture = Nothing, verification = False }

            else
                appliquer but corps n


appliquer : But -> Value -> Modele -> ( Modele, Cmd Message )
appliquer but corps m =
    let
        maintenant =
            C.chaine "maintenant" corps

        flags =
            m.flags

        pr =
            C.objet "politique" corps

        n =
            { m
                | flags =
                    if maintenant == "" then
                        flags

                    else
                        { flags | instant = maintenant }
                , politique =
                    if pr == E.null then
                        m.politique

                    else
                        pr
                , intervalle =
                    if pr == E.null then
                        m.intervalle

                    else
                        String.fromInt (C.entier "intervalle_jours" pr)
                , budget =
                    if pr == E.null then
                        m.budget

                    else
                        C.nombre "budget" pr |> Maybe.map (round >> String.fromInt) |> Maybe.withDefault ""
            }

        connecter =
            case D.decodeValue (D.map2 Session (D.field "username" D.string) (D.field "csrf" D.string)) corps of
                Err _ ->
                    notifier Erreur "Réponse de session invalide." { n | verification = False }

                Ok s ->
                    if String.isEmpty s.compte || String.isEmpty s.csrf then
                        notifier Erreur "Réponse de session incomplète." { n | verification = False }

                    else
                        let
                            base =
                                { n | session = Just s, verification = False, secret = "", suspension = Nothing, message = Nothing }

                            restaure =
                                case m.suspension of
                                    Just b ->
                                        if b.compte == s.compte then
                                            { base | nature = b.nature, detail = b.detail, brouillon = b.brouillon, edition = True, modifie = True, ecriture = b.ecriture }

                                        else
                                            base

                                    Nothing ->
                                        base
                        in
                        lister restaure
    in
    case but of
        SessionInitiale ->
            connecter

        Connecter ->
            connecter

        Deconnecter ->
            ( { n | session = Nothing, detail = Nothing, resultats = [], candidats = [], liensTrouves = [], brouillon = C.nouveau "fiche", edition = False, modifie = False, ecriture = Nothing, suspension = Nothing, attentes = Dict.empty }, effet "annulerRequetes" E.null )

        Lister nature ->
            if nature == m.nature then
                ( { n | resultats = C.listes "resultats" corps, total = C.entier "total" corps }, Cmd.none )

            else
                ( n, Cmd.none )

        Lire nature _ ->
            case List.head (C.listes "objets" corps) of
                Nothing ->
                    notifier Erreur "Objet introuvable." n

                Just d ->
                    ( { n | nature = nature, detail = Just d, edition = False, modifie = False, brouillon = C.brouillon nature d }, effet "focus" (E.string "detail") )

        Enregistrer nature ->
            if not (C.vrai "enregistre" corps) then
                notifier Erreur "L’enregistrement n’est pas confirmé." n

            else
                let
                    d =
                        C.objet nature corps
                in
                lire nature (C.entier "id" d) { n | detail = Just d, edition = False, modifie = False, ecriture = Nothing, candidats = [], preuve = Nothing, creationVerifiee = False, message = Just ( Succes, "Enregistré." ) }

        VerifierCreation ->
            let
                preuve =
                    C.chaine "preuve_recherche" corps

                candidats =
                    C.listes "resultats" corps

                suite =
                    { n | preuve = Just preuve, candidats = [] }
            in
            if preuve == "" then
                notifier Erreur "Trop de candidats : précisez le titre avant de créer." n

            else if List.isEmpty candidats then
                sauver { suite | creationVerifiee = True }

            else
                lireCandidats (List.map (C.entier "id") candidats) suite

        LireCandidats reste ->
            let
                suite =
                    { n | candidats = n.candidats ++ C.listes "objets" corps }
            in
            if List.isEmpty reste then
                notifier Information "Des items proches existent. Réutilisez-les ou précisez la distinction avant de créer." suite

            else
                lireCandidats reste suite

        RechercherLiens ->
            ( { n | liensTrouves = C.listes "resultats" corps }, Cmd.none )

        Lier ->
            if not (C.vrai "enregistre" corps) then
                notifier Erreur "Le lien n’est pas confirmé." n

            else
                case n.detail of
                    Just d ->
                        lire n.nature (C.entier "id" d) { n | ecriture = Nothing, liensOuverts = False }

                    Nothing ->
                        ( { n | ecriture = Nothing }, Cmd.none )

        Regler ->
            if not (C.vrai "enregistre" corps) then
                notifier Erreur "Le réglage n’est pas confirmé." n

            else
                notifier Succes "Politique enregistrée ; les stabilités sont conservées." { n | ecriture = Nothing }


lireCandidats : List Int -> Modele -> ( Modele, Cmd Message )
lireCandidats ids m =
    api (LireCandidats (List.drop 20 ids)) "lire" [ ( "type", E.string "item" ), ( "ids", E.list E.int (List.take 20 ids) ), ( "preuve_recherche", m.preuve |> Maybe.map E.string |> Maybe.withDefault E.null ) ] m


repere : String -> Element Message -> Element Message
repere nom =
    Element.el [ Element.width Element.fill, Element.htmlAttribute (A.id nom), Element.htmlAttribute (A.tabindex -1) ]


db : Int -> String
db n =
    (if n >= 0 then
        "+"

     else
        ""
    )
        ++ String.fromInt n
        ++ " dB"


fenetre : Value -> Element Message
fenetre f =
    let
        etat =
            C.chaine "etat" f

        texte =
            case etat of
                "reference_inconnue" ->
                    "Référence inconnue — aucune date de révision inventée."

                "reference_future" ->
                    "Date de référence future : à vérifier."

                "hors_horizon" ->
                    "Intervalle hors horizon d’affichage (100 ans)."

                "intervalle_tres_court" ->
                    "Intervalle inférieur à une minute : réglage à vérifier."

                _ ->
                    "Fenêtre : " ++ String.left 10 (C.chaine "debut" f) ++ " → " ++ String.left 10 (C.chaine "fin" f)
    in
    texteSecondaire texte


vue : Modele -> Html Message
vue m =
    -- Les deux racines ElmUI (page et dialogue natif) partagent la typographie.
    Html.div [ A.style "font-family" "Inter, Aptos, Segoe UI, sans-serif" ]
        [ vueConfirmation m
        , page "Vision"
            ([ paragraphe "Vos fiches, leurs items et un suivi partagé entre les contextes." ]
                ++ (m.message |> Maybe.map (\( niveau, texte ) -> [ avis niveau texte ]) |> Maybe.withDefault [])
                ++ (if m.verification then
                        [ texteSecondaire "Vérification de la session…" ]

                    else
                        case m.session of
                            Nothing ->
                                [ section "Connexion" [ champ "Identifiant" m.identifiant Identifiant, motDePasse "Mot de passe" m.secret Secret, bouton "Se connecter" Connexion ] ]

                            Just _ ->
                                espace m
                   )
            )
        ]


vueConfirmation : Modele -> Html Message
vueConfirmation m =
    case m.confirmation of
        Nothing ->
            Html.text ""

        Just c ->
            Fenetres.modale "confirmation"
                "Confirmer"
                Rester
                [ paragraphe
                    (case c of
                        Archiver _ ->
                            "L’archivage est réversible et conserve les connaissances et leurs liens."

                        Detacher _ _ _ ->
                            "Détacher conserve cet item et ses autres rattachements."

                        _ ->
                            "Quitter abandonnera la saisie non enregistrée."
                    )
                , actions [ boutonDestructif "Confirmer" Confirmer, boutonSecondaire "Continuer" Rester ]
                ]


espace : Modele -> List (Element Message)
espace m =
    [ actions
        [ boutonSecondaire "Fiches" (Naviguer (Changer "fiche"))
        , boutonSecondaire "Items" (Naviguer (Changer "item"))
        , boutonSecondaire "Réglages" Reglages
        , Element.html (Html.details [] [ Html.summary [ A.attribute "aria-label" "Ouvrir le menu" ] [ Html.text "☰" ], Html.div [] [ Html.a [ A.href "/auth/mcp" ] [ Html.text "Tokens d’accès" ] ] ])
        , boutonSecondaire "Se déconnecter" (Naviguer Quitter)
        ]
    ]
        ++ (if m.ecriture /= Nothing && Dict.isEmpty m.attentes then
                [ bouton "Réessayer la même écriture" Reessayer ]

            else
                []
           )
        ++ (if m.reglages then
                [ section "Politique de révision"
                    [ Donnees.nombre "Intervalle de référence (jours)" m.intervalle Intervalle
                    , actions (List.map (\j -> boutonSecondaire (String.fromInt j ++ " jours") (Intervalle (String.fromInt j))) [ 7, 14, 30, 90 ])
                    , Donnees.nombre "Budget d’items par jour (facultatif)" m.budget Budget
                    , paragraphe ("Décalage de charge : " ++ db (C.entier "decalage" m.politique) ++ ". Adaptation d’au plus 1 dB par semaine à partir des items distincts.")
                    , bouton "Enregistrer la politique" SauverPolitique
                    ]
                ]

            else
                []
           )
        ++ (if m.edition then
                [ vueEdition m ]

            else
                case m.detail of
                    Just d ->
                        [ vueDetail m d ]

                    Nothing ->
                        [ vueListe m ]
           )


vueListe : Modele -> Element Message
vueListe m =
    section
        (if m.nature == "fiche" then
            "Fiches"

         else
            "Items"
        )
        [ actions
            [ bouton
                (if m.nature == "fiche" then
                    "Nouvelle fiche"

                 else
                    "Nouvel item"
                )
                Nouvelle
            ]
        , champ "Recherche" m.recherche Recherche
        , if m.nature == "fiche" then
            champ "Tags (séparés par des virgules)" m.tags Tags

          else
            Element.none
        , actions
            [ boutonSecondaire "Rechercher" Filtrer
            , selecteur "État" [ ( "actif", "Actifs" ), ( "archive", "Archivés" ), ( "tous", "Tous" ) ] m.etat Etat
            , selecteur "Tri"
                ([ ( "titre", "Titre" ), ( "modification", "Modification récente" ) ]
                    ++ (if m.nature == "fiche" then
                            [ ( "priorite", "Priorité" ) ]

                        else
                            [ ( "stabilite", "Stabilité" ) ]
                       )
                )
                m.tri
                Tri
            ]
        , Donnees.tableau "Résultats"
            [ ( "Titre", \v -> boutonSecondaire (C.chaine "titre" v) (Ouvrir m.nature (C.entier "id" v)) )
            , ( if m.nature == "fiche" then
                    "Priorité"

                else
                    "Stabilité"
              , \v ->
                    Element.text
                        (db
                            (C.entier
                                (if m.nature == "fiche" then
                                    "priorite"

                                 else
                                    "stabilite"
                                )
                                v
                            )
                        )
              )
            , ( if m.nature == "fiche" then
                    "Items"

                else
                    "Évaluation"
              , \v ->
                    Element.text
                        (if m.nature == "fiche" then
                            String.fromInt (C.entier "nombre_items" v)

                         else if C.vrai "evalue" v then
                            "Évalué"

                         else
                            "Non évalué"
                        )
              )
            ]
            m.resultats
        , texteSecondaire (String.fromInt m.total ++ " résultats")
        , actions
            [ if m.debut > 0 then
                boutonSecondaire "Précédent" (Pagination -1)

              else
                boutonInactif "Précédent"
            , if m.debut + 20 < m.total then
                boutonSecondaire "Suivant" (Pagination 1)

              else
                boutonInactif "Suivant"
            ]
        ]


vueDetail : Modele -> Value -> Element Message
vueDetail m d =
    let
        estFiche =
            m.nature == "fiche"

        archive =
            C.objet "archive_a" d /= E.null

        lies =
            C.listes
                (if estFiche then
                    "items"

                 else
                    "fiches"
                )
                d

        autre =
            if estFiche then
                "item"

            else
                "fiche"
    in
    repere "detail" <|
        section (C.chaine "titre" d)
            ([ actions
                [ boutonSecondaire "Retour à la liste" (Naviguer Fermer)
                , bouton "Modifier" Editer
                , boutonSecondaire
                    (if archive then
                        "Restaurer"

                     else
                        "Archiver"
                    )
                    (Naviguer (Archiver (not archive)))
                ]
             , texteSecondaire
                ((if estFiche then
                    "Priorité "

                  else
                    "Stabilité "
                 )
                    ++ db
                        (C.entier
                            (if estFiche then
                                "priorite"

                             else
                                "stabilite"
                            )
                            d
                        )
                )
             , if estFiche then
                texteSecondaire "Priorité positive : révisions avancées."

               else
                fenetre (C.objet "fenetre" d)
             , Lecture.markdown (C.chaine "contenu" d)
             , if C.chaine "suivi" d == "" then
                Element.none

               else
                section "Suivi actuel" [ Donnees.lecture (C.chaine "suivi" d) ]
             ]
                ++ (if estFiche then
                        []

                    else
                        [ section "Objectifs et sens"
                            [ Donnees.lecture (String.join "\n" (List.map C.texte (C.listes "objectifs" d ++ C.listes "sens" d)))
                            , texteSecondaire
                                (if C.vrai "evalue" d then
                                    "Dernière évaluation : "
                                        ++ (if C.chaine "evalue_a" d == "" then
                                                "date inconnue"

                                            else
                                                C.chaine "evalue_a" d
                                           )

                                 else
                                    "Cet item n’a pas été évalué."
                                )
                            ]
                        ]
                   )
                ++ [ section
                        (if estFiche then
                            "Items associés"

                         else
                            "Fiches associées"
                        )
                        ([ boutonSecondaire "Ajouter un rattachement" AfficherLiens ]
                            ++ List.map
                                (\v ->
                                    pile
                                        [ actions
                                            [ boutonSecondaire (C.chaine "titre" v) (Ouvrir autre (C.entier "id" v))
                                            , boutonSecondaire "Détacher"
                                                (Naviguer
                                                    (if estFiche then
                                                        Detacher (C.entier "id" d) (C.entier "id" v) (C.entier "version" d)

                                                     else
                                                        Detacher (C.entier "id" v) (C.entier "id" d) (C.entier "version" v)
                                                    )
                                                )
                                            ]
                                        , if estFiche then
                                            fenetre (C.objet "fenetre" v)

                                          else
                                            texteSecondaire (C.chaine "contexte" v)
                                        ]
                                )
                                lies
                            ++ [ actions
                                    [ if m.debutLiens > 0 then
                                        boutonSecondaire "Liens précédents" (PageLiens -1)

                                      else
                                        Element.none
                                    , if
                                        m.debutLiens
                                            + 20
                                            < C.entier
                                                (if estFiche then
                                                    "nombre_items"

                                                 else
                                                    "nombre_fiches"
                                                )
                                                d
                                      then
                                        boutonSecondaire "Liens suivants" (PageLiens 1)

                                      else
                                        Element.none
                                    ]
                               ]
                        )
                   , if m.liensOuverts then
                        section "Rattacher un objet existant"
                            ([ champ "Rechercher un objet à rattacher" m.rechercheLiens RechercheLiens, boutonSecondaire "Chercher" ChercherLiens ]
                                ++ List.map (\v -> boutonSecondaire ("Rattacher : " ++ C.chaine "titre" v) (Rattacher v)) m.liensTrouves
                            )

                     else
                        Element.none
                   ]
            )


vueEdition : Modele -> Element Message
vueEdition m =
    repere "edition" <|
        section
            (if m.detail == Nothing then
                "Créer"

             else
                "Modifier"
            )
            ([ champ "Titre" (valeur "titre" m) (Saisir "titre")
             , zoneTexte "Contenu de référence" (valeur "contenu" m) (Saisir "contenu")
             , zoneTexte "Suivi qualitatif (facultatif)" (valeur "suivi" m) (Saisir "suivi")
             , zoneTexte "Alias (un par ligne)" (valeur "alias" m) (Saisir "alias")
             ]
                ++ (if m.nature == "fiche" then
                        [ zoneTexte "Tags (un par ligne)" (valeur "tags" m) (Saisir "tags"), Donnees.nombre "Priorité P (dB, −20 à +20)" (valeur "priorite" m) (Saisir "priorite"), texteSecondaire "Priorité positive : révisions avancées." ]

                    else
                        [ zoneTexte "Objectifs de rappel (un par ligne)" (valeur "objectifs" m) (Saisir "objectifs"), zoneTexte "Sens de rappel (un par ligne)" (valeur "sens" m) (Saisir "sens") ]
                            ++ (if m.detail == Nothing then
                                    [ Donnees.nombre "Stabilité initiale S (dB)" (valeur "stabilite" m) (Saisir "stabilite"), champ "Date de départ connue (ISO 8601, facultatif)" (valeur "reference_a" m) (Saisir "reference_a"), champ "Justification de l’estimation (si S ≠ −15)" (valeur "justification" m) (Saisir "justification") ]

                                else
                                    [ texteSecondaire "La stabilité est actualisée par les évaluations ; cette édition conserve les dates de rappel." ]
                               )
                   )
                ++ [ actions
                        [ if m.ecriture /= Nothing then
                            boutonEnCours "Enregistrement…"

                          else
                            bouton "Enregistrer" Sauver
                        , boutonSecondaire "Fermer la saisie" (Naviguer Fermer)
                        ]
                   ]
                ++ (if List.isEmpty m.candidats then
                        []

                    else
                        [ section "Items proches déjà présents"
                            (List.map (\v -> pile [ paragraphe (C.chaine "titre" v), Donnees.lecture (C.chaine "contenu" v), boutonSecondaire "Réutiliser cet item" (Reutiliser (C.entier "id" v)) ]) m.candidats
                                ++ [ champ "Pourquoi s’agit-il d’une connaissance distincte ?" (valeur "distinction" m) (Saisir "distinction"), bouton "Créer cet item distinct" CreerDistinct ]
                            )
                        ]
                   )
            )
