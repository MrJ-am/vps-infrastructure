module Informations exposing (publique, vue)

import Html exposing (Html)
import MrJam
import MrJam.Documents as Documents
import MrJam.Lecture as Lecture


publique : String -> Bool
publique chemin =
    List.member chemin [ "/docs", "/docs/", "/privacy" ]


vue : String -> Html message
vue chemin =
    Documents.espace "Vision"
        [ MrJam.lien "Ouvrir Vision" "/", MrJam.lien "Documentation" "/docs", MrJam.lien "Confidentialité" "/privacy" ]
        Nothing
        [ Documents.document
            (if chemin == "/privacy" then
                "Confidentialité"

             else
                "Fiches et items"
            )
            [ Lecture.markdown
                (if chemin == "/privacy" then
                    confidentialite

                 else
                    documentation
                )
            , MrJam.lien "Contrat OpenAPI" "/openapi.json"
            ]
        ]


documentation : String
documentation =
    """Une fiche rassemble des connaissances ; chaque item possède un suivi partagé entre toutes les fiches qui le réutilisent.

## Priorité et stabilité

La fiche possède une priorité P et l’item une stabilité S, entières en dB. L’intervalle indicatif vaut I = T × 10^((S − P + G)/10), avec T = 90 jours par défaut et une fenêtre de ±1 dB. Une priorité positive avance les révisions. Ce modèle n’exprime aucune probabilité de rappel.

## MCP et API

Le catalogue tools/list expose les outils en vigueur et initialize leurs instructions. MCP accepte Basic, Bearer et OAuth PKCE. REST utilise Basic ; le navigateur utilise une session et un jeton CSRF.

Les écritures sont versionnées et idempotentes. Plusieurs séances de révision peuvent rester ouvertes ; leur compte rendu est enregistré à la clôture. Les anciens outils FSRS sont retirés explicitement, sans conversion arbitraire des évaluations.

La documentation est publique. Toute lecture ou écriture de données exige une authentification."""


confidentialite : String
confidentialite =
    """Version du 26 septembre 2026.

Vision conserve dans PostgreSQL les fiches, les items, leurs relations, les suivis et les comptes rendus de révision. Ces données servent à retrouver les connaissances pertinentes et à organiser les révisions. L’archivage est réversible et ne supprime pas les données.

Le serveur peut journaliser les métadonnées techniques nécessaires à la sécurité et à l’exploitation : adresse IP, horodatage, catégorie de route et code de réponse. Les corps MCP, mots de passe, cookies et en-têtes d’autorisation ne figurent pas dans les journaux ordinaires.

Les données restent sur le VPS administré pour Vision et ne sont pas vendues. Lorsqu’un client MCP demande des données, elles sont transmises à ce client et relèvent aussi de ses propres conditions de confidentialité.

Les brouillons de l’interface restent uniquement en mémoire pendant la session. Ils ne sont pas enregistrés dans le stockage local du navigateur."""
