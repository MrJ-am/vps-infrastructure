# Interface Vision en ElmUI

Le navigateur conserve les routes Common Lisp et la connexion partagée mrj.am.
Les composants communs sont verrouillés dans `style.lock.json`, à une révision
Git complète et avec leurs empreintes ; aucune branche mobile n'est compilée.
La référence de départ était `52ad33f` ; la reprise complète adopte `c7b4d6e0`.

## Construction et vérification

```sh
npm ci
npm run verifier
npm run compiler
python3 -m pip install -r tests/requirements.txt
python3 -m playwright install chromium
python3 tests/navigation.py
```

`compiler.py --style /chemin` accepte un cache seulement si tous les fichiers
correspondent au verrou. La compilation optimisée assemble Elm, le pont HTTP,
les dialogues communs, le logo et les polices exactes de Signature. Leur source
et leurs empreintes sont conservées dans `identite/source.json` ; les droits du
logo et de la signature restent strictement réservés. `MrJ.am` est du texte
sélectionnable, et le point reste U+002E.

`src/Contrat.elm` conserve les clés JSON et les validations. `src/Main.elm`
porte les vues et l'état ; `pont.js` porte seulement transport, dates et focus.
Les contenus Markdown interprètent un sous-ensemble sans HTML actif, images
ou liens distants. Les tableaux défilent localement sur petit écran. Les
modales natives gardent le focus, rendent le fond inerte et gèrent Échap.

## Sessions et données

Le CSRF et les brouillons restent en mémoire, sans stockage persistant. Une
expiration masque les données ; seul le même compte retrouve son brouillon.
Les réponses périmées sont écartées et les conflits HTTP 409 n'écrasent pas
les modifications concurrentes. Un statut 200 sans `saved: true` n'est pas
une confirmation d'enregistrement. Le navigateur n'invente aucun en-tête
interne ni identifiant Basic. La précision des dates stockées est conservée.

La pagination, les filtres, les dix tris, les tags, l'archivage réversible,
les observations et leur version originale gardent les contrats existants.
L'API expose vingt modifications manuelles récentes et la dernière correction
accompagnée de son original ; elle ne propose pas un historique exhaustif des
corrections intermédiaires. Aucun état mémoriel ni journal n'est recalculé.

## Portée des tests et publication

`tests/navigation.py` utilise une doublure HTTP explicite de session.
`tests/base.sh` utilise le vrai serveur Common Lisp avec PostgreSQL 17 isolé,
et refuse une autre cible que `vision_interface_test` sur `127.0.0.1`.
Les fixtures ne sont jamais chargées en production. Les tests historiques
HTTP, MCP, FSRS et PostgreSQL restent indépendants.

La vraie passerelle, le cookie partagé et CSRF doivent être contrôlés dans
l'infrastructure puis en production. L'interface publique ne contient aucune
donnée personnelle. Nginx doit servir l'artefact complet avec `font-src 'self'`
et les styles inline nécessaires à ElmUI, sans autoriser de script inline.
Lisp, PostgreSQL et les routes de sessions conservent leur fonctionnement.

La publication utilise le manifeste et l'artefact déjà contrôlés ; son état
réel et ses exécutions doivent être consignés dans `docs/ETAT-PORTAGE-ELMUI.md`.
Le retour d'interface restaure uniquement les anciens fichiers et le routage,
sans dump SQL ni réécriture des identifiants. Les autres sites sont vérifiés
et les opérations système sont sérialisées dans `vps-infrastructure`.
