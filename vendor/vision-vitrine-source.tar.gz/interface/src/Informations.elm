module Informations exposing (publique, vue)

import Element exposing (Element)
import Html exposing (Html)
import MrJam
import MrJam.Documents as Documents
import MrJam.Lecture as Lecture
import MrJam.Pictogrammes as Pictogrammes
import MrJam.Vitrine as Vitrine
import Tutoriel
import Visuels


type alias Contexte =
    { chemin : String, adresse : String, urlMcp : String, gestionAcces : String, copiee : Bool }


publique : String -> Bool
publique chemin =
    List.member chemin [ "/docs", "/docs/", "/privacy" ]


vue : Contexte -> message -> (String -> message) -> Html message
vue contexte copier choisir =
    Documents.espaceMarque "Vision"
        [ MrJam.lienActif (contexte.chemin == "/docs") "Tutoriel" "/docs"
        , Pictogrammes.lien Pictogrammes.Bouclier "Confidentialité" "/privacy"
        , Vitrine.navigation "Se connecter" "/connexion"
        ]
        Nothing
        (if contexte.chemin == "/privacy" then
            confidentialite

         else if contexte.chemin == "/" then
            accueil

         else
            tutoriel contexte copier choisir
        )


accueil : List (Element message)
accueil =
    [ Vitrine.hero
        { repere = "APPRENDRE AVEC VOTRE ASSISTANT IA"
        , titre = "Apprenez aujourd’hui. Retrouvez-le demain."
        , texte = "Transformez vos conversations en connaissances qui restent. Vision organise vos révisions avec votre assistant IA. Vous gardez la liberté de vos exercices."
        , image = "assets/mrjam/vision/memoire.webp"
        , description = "Une lumière verte accompagne des feuilles reliées par un chemin de souvenirs."
        }
        [ Vitrine.navigation "Découvrir Vision" "/docs#connexion-mcp"
        , MrJam.lien "J’ai déjà un compte" "/connexion"
        ]
    , Vitrine.benefices
        [ { icone = Pictogrammes.Dialogue, titre = "Des exercices vivants", texte = "Expliquez une idée. Traduisez une phrase. Résolvez un problème. Votre assistant adapte l’exercice à votre objectif." }
        , { icone = Pictogrammes.Horloge, titre = "Un suivi qui dure", texte = "Retrouvez vos connaissances après la conversation. Vision conserve leur suivi et propose les prochaines révisions." }
        , { icone = Pictogrammes.Reglages, titre = "Votre propre rythme", texte = "Comprenez les dates proposées. Réglez votre période cible ou votre budget quotidien. Vous gardez la main." }
        ]
    , Vitrine.partie "VOS CONNAISSANCES"
        "Un savoir peut servir partout."
        [ Vitrine.texte "Les items contiennent ce que vous voulez retenir. Les fiches donnent un contexte et une manière de le travailler. Un même item peut servir dans plusieurs fiches sans repartir de zéro."
        , Visuels.partage
        ]
    , Vitrine.partie "LE PRODUIT EN UN COUP D’ŒIL"
        "Retrouvez tout au même endroit."
        [ Vitrine.texte "Consultez vos fiches sur le site. Retrouvez les items à travailler et l’état de chacun. Votre assistant utilise ces mêmes connaissances pendant la révision."
        , Vitrine.capture
            { image = "assets/mrjam/vision/fiche.webp"
            , description = "Capture de Vision avec la fiche fictive Capitales de l’Asie et ses items. Les plages de révision apparaissent à côté des connaissances."
            , legende = "Capture de Vision. Toutes les connaissances affichées sont fictives."
            }
        ]
    , Vitrine.partie "DANS LA CONVERSATION"
        "Cherchez la réponse. Recevez juste l’aide utile."
        [ Vitrine.texte "Vous répondez avec vos mots. L’assistant signale ce qui manque puis donne un indice à la fois. Vous pouvez demander la correction ou passer. Le bilan distingue ce que vous avez retrouvé seul et ce qui a demandé de l’aide."
        , Vitrine.etapes
            [ { titre = "Vous essayez", texte = "Votre première réponse compte. Une reformulation qui garde le bon sens est acceptée." }
            , { titre = "Vous comprenez", texte = "Un indice vous aide à retrouver le sens. La correction arrive lorsque vous la demandez ou qu’elle devient nécessaire." }
            , { titre = "Vous retrouvez", texte = "Vision conserve le bilan. Votre prochaine séance repart de ce suivi." }
            ]
        ]
    , Vitrine.partie "RÉPÉTITIONS ESPACÉES"
        "Revenez au bon moment pour vous."
        [ Vitrine.texte "Vision calcule une plage de révision pour chaque item. Les intervalles évoluent avec les évaluations. Le modèle reste simple et ses réglages sont consultables."
        , Visuels.espacement
        , Vitrine.capture
            { image = "assets/mrjam/vision/items.webp"
            , description = "Capture de Vision avec trois items fictifs. Leur stabilité et leur état de révision sont visibles."
            , legende = "Capture de Vision. Le suivi appartient à chaque item. Les données sont fictives."
            }
        , MrJam.lien "Comprendre la planification" "/docs#planification"
        ]
    , Vitrine.conclusion "Votre prochaine conversation peut devenir une séance."
        "Le tutoriel vous guide pour connecter votre assistant et commencer. Un compte Vision est nécessaire. Ce service ne propose pas d’inscription publique."
        [ Vitrine.navigation "Connecter mon assistant" "/docs#connexion-mcp", MrJam.lien "Ouvrir mon compte" "/connexion" ]
    , Vitrine.details "Pourquoi le nom Vision ?"
        [ Vitrine.texte "Vision joue avec le mot révision. Le nom fait aussi un clin d’œil au personnage qui porte une pierre lumineuse au front. Ce projet n’a aucune affiliation officielle avec ce personnage."
        ]
    ]


tutoriel : Contexte -> message -> (String -> message) -> List (Element message)
tutoriel contexte copier choisir =
    let
        identifiant =
            String.dropLeft 1 contexte.adresse

        section =
            Tutoriel.sections
                |> List.filter (\s -> s.id == identifiant)
                |> List.head
                |> Maybe.withDefault (List.head Tutoriel.sections |> Maybe.withDefault { id = "", titre = "", explication = "", exemple = "", activite = "", complement = "", calcul = "", etapes = [], sources = [] })

        resoudre =
            String.replace "{{url_mcp}}" contexte.urlMcp

        connexion =
            String.startsWith "connexion-" section.id
    in
    [ Vitrine.introduction "LE TUTORIEL"
        "Découvrir Vision"
        "Connectez votre assistant. Découvrez ensuite comment organiser vos connaissances et commencer vos révisions. Ce tutoriel ne crée aucune donnée personnelle."
    , MrJam.selecteur "Chapitre" (List.map (\s -> ( s.id, s.titre )) Tutoriel.sections) section.id choisir
    , if connexion then
        Documents.section "L’adresse MCP de votre Vision"
            (if String.isEmpty contexte.urlMcp then
                [ MrJam.avis MrJam.Information "L’adresse de connexion n’est pas disponible pour le moment. Rechargez cette page avant de configurer votre assistant." ]

             else
                [ Lecture.markdown ("```text\n" ++ contexte.urlMcp ++ "\n```")
                , MrJam.actions
                    [ Pictogrammes.action Pictogrammes.Copier "Copier l’adresse MCP" copier
                    , if String.isEmpty contexte.gestionAcces then
                        Element.none

                      else
                        MrJam.lien "Accès des assistants" contexte.gestionAcces
                    ]
                , if contexte.copiee then
                    MrJam.avis MrJam.Succes "Adresse copiée."

                  else
                    Element.none
                ]
            )

      else
        Element.none
    , Vitrine.chapitre section.id
        section.titre
        ([ Vitrine.texte section.explication
         , if List.isEmpty section.etapes then
            Element.none

           else
            Vitrine.etapes section.etapes
         , if String.contains "{{url_mcp}}" section.exemple && String.isEmpty contexte.urlMcp then
            MrJam.avis MrJam.Information "Les commandes de connexion apparaîtront lorsque l’adresse MCP sera disponible."

           else
            Lecture.markdown (resoudre section.exemple)
         , if section.id == "fiches-items" then
            Visuels.partage

           else
            Element.none
         , if section.id == "planification" then
            Visuels.espacement

           else
            Element.none
         , Documents.section "À essayer" [ Vitrine.texte section.activite ]
         , if String.isEmpty section.complement then
            Element.none

           else
            Vitrine.details "En savoir plus" [ Lecture.markdown section.complement ]
         , if String.isEmpty section.calcul then
            Element.none

           else
            Vitrine.details "Voir le calcul et les exemples" [ Lecture.markdown section.calcul ]
         ]
            ++ (if List.isEmpty section.sources then
                    []

                else
                    [ MrJam.texteSecondaire "Procédure vérifiée le 6 octobre 2026. Les options de votre assistant peuvent évoluer."
                    , MrJam.actions (List.map (\s -> MrJam.lienExterne s.titre s.url) section.sources)
                    ]
               )
        )
    , MrJam.actions [ MrJam.lien "Connecter mon assistant" "/docs#connexion-mcp", MrJam.lien "Comprendre les fiches" "/docs#fiches-items", MrJam.lien "Ouvrir Vision" "/connexion" ]
    ]


confidentialite : List (Element message)
confidentialite =
    [ Vitrine.introduction "VOS DONNÉES" "Confidentialité" "Voici les informations conservées par Vision et la manière dont vous pouvez contrôler les accès. Version du 6 octobre 2026."
    , Vitrine.chapitre "donnees"
        "Ce que Vision conserve"
        [ Vitrine.texte "Vision conserve vos fiches, vos items et leurs liens. Il garde les observations, les évaluations et les bilans de révision que vous lui demandez d’enregistrer. Ces informations servent à retrouver vos connaissances et à organiser vos révisions."
        , Vitrine.texte "Ces données ne sont pas vendues. L’archivage conserve les informations et permet de les retrouver. Il ne les supprime pas."
        ]
    , Vitrine.chapitre "assistants"
        "Les assistants que vous connectez"
        [ Vitrine.texte "Un assistant connecté peut recevoir vos contenus et réaliser les actions que vous lui demandez. Les informations qui lui sont transmises relèvent aussi des règles de confidentialité de son fournisseur. Consultez ces règles avant de lui confier des données sensibles."
        , Vitrine.texte "Vous pouvez retirer les autorisations et les tokens depuis la page des accès de votre compte. Vous déconnecter du site ne retire pas les accès de vos assistants. Un lien vers une fiche reste privé. Il ne donne pas accès à son contenu sans un compte autorisé."
        , MrJam.lien "Gérer les accès de mes assistants" "/auth/mcp"
        ]
    , Vitrine.chapitre "navigateur"
        "Votre visite sur le site"
        [ Vitrine.texte "Un cookie est nécessaire pour garder votre connexion. Vision n’ajoute pas de publicité ni de traceur publicitaire. Vos brouillons restent dans la mémoire de la page. Ils ne sont pas conservés dans le stockage local du navigateur."
        , Vitrine.texte "Des informations de visite sont conservées pour la sécurité du service : adresse IP, date, catégorie de page et résultat de la requête. Leur conservation est limitée à 14 jours. Ces journaux ordinaires ne contiennent pas vos fiches, vos messages, vos mots de passe ou vos tokens."
        ]
    , Vitrine.chapitre "droits"
        "Consulter ou faire supprimer vos informations"
        [ Vitrine.texte "Vous pouvez consulter vos connaissances dans Vision et demander un export de vos fiches en Markdown à votre assistant connecté. Pour une demande de suppression ou de fermeture du compte, contactez la personne qui vous a donné accès au service."
        ]
    ]
