#!/usr/bin/env python3
"""Construire un artefact candidat, sans activation ni accès aux données."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile

RACINE = Path(__file__).resolve().parent
VERROU = json.loads((RACINE / 'style.lock.json').read_text())


def empreinte(chemin: Path) -> str:
    return hashlib.sha256(chemin.read_bytes()).hexdigest()


def verifier(source: Path) -> None:
    attendus = VERROU['fichiers']
    reels = {str(p.relative_to(source)) for p in (source / 'src').rglob('*.elm')}
    if reels != {p for p in attendus if p.startswith('src/') and p.endswith('.elm')}:
        raise SystemExit('Le jeu de modules communs ne correspond pas à la révision autorisée.')
    for nom, attendu in attendus.items():
        fichier = source / nom
        if not fichier.is_file() or fichier.is_symlink() or empreinte(fichier) != attendu:
            raise SystemExit(f'Ressource commune absente ou modifiée : {nom}')


def construire(source: Path, elm: str, formateur: str) -> None:
    verifier(source)
    subprocess.run([formateur, str(RACINE / 'src'), '--validate'], check=True)
    sortie = RACINE / 'dist'
    # Un échec ne remplace pas l'artefact précédent par une construction incomplète.
    with tempfile.TemporaryDirectory(prefix='vision-interface-') as temporaire:
        atelier = Path(temporaire)
        shutil.copytree(RACINE / 'src', atelier / 'src')
        shutil.copy(RACINE / 'elm.json', atelier / 'elm.json')
        commun = atelier / '.dependances/style-mrjam'
        for nom in VERROU['fichiers']:
            cible = commun / nom
            cible.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(source / nom, cible)
        subprocess.run([elm, 'make', 'src/Main.elm', '--optimize', '--output=elm.js'], cwd=atelier, check=True)
        candidat = atelier / 'dist'
        candidat.mkdir()
        shutil.copyfile(RACINE / 'app.html', candidat / 'app.html')
        (candidat / 'app.js').write_bytes((atelier / 'elm.js').read_bytes() + b'\n;\n' + (RACINE / 'pont.js').read_bytes() + b'\n;\n' + (commun / 'public/assets/mrjam/fenetres.js').read_bytes())
        (candidat / 'app.css').write_text('@import url("assets/mrjam/signature.css");\n@import url("assets/mrjam/vitrine.css");\n@font-face{font-family:MrJamEcriture;src:url("assets/mrjam/Parisienne-Regular.woff2") format("woff2");font-display:block}\n', encoding='utf-8')
        shutil.copytree(commun / 'public/assets/mrjam', candidat / 'assets/mrjam')
        identite = json.loads((RACINE / 'identite/source.json').read_text())
        if identite['revision'] != VERROU['signature']:
            raise SystemExit('Révision de Signature incohérente.')
        for nom, attendu in identite['fichiers'].items():
            fichier = RACINE / 'identite' / nom
            if fichier.is_symlink() or empreinte(fichier) != attendu:
                raise SystemExit('Ressource de Signature modifiée : ' + nom)
            shutil.copyfile(fichier, candidat / 'assets/mrjam' / nom)
        # Le sous-répertoire du produit utilise la route statique déjà publiée.
        # Les visuels restent locaux et inclus dans le manifeste, sans nouveau routage.
        for fichier in (RACINE / 'visuels').iterdir():
            if fichier.is_symlink() or fichier.suffix not in ['.webp', '.svg']:
                raise SystemExit('Visuel inattendu : ' + fichier.name)
            (candidat / 'assets/mrjam/vision').mkdir(exist_ok=True)
            shutil.copyfile(fichier, candidat / 'assets/mrjam/vision' / fichier.name)
        # Les documents publics partagent le même point d’entrée ElmUI.
        for nom in ['index.html', 'privacy.html']:
            shutil.copyfile(RACINE / 'app.html', candidat / nom)
        for nom in ['openapi.json', 'mobile-live-test-openapi.json']:
            shutil.copyfile(RACINE.parent / 'docs' / nom, candidat / nom)
        manifeste = {
            'revisionStyle': VERROU['revision'],
            'revisionSignature': VERROU['signature'],
            'revisionApplication': os.environ.get('GITHUB_SHA', 'atelier-local'),
            'formatVersion': 1,
            'validation': 'Les workflows identifiés attestent les tests et la publication.',
            'fichiers': {str(p.relative_to(candidat)): empreinte(p) for p in sorted(candidat.rglob('*')) if p.is_file()}
        }
        (candidat / 'manifest.json').write_text(json.dumps(manifeste, ensure_ascii=False, indent=2) + '\n')
        if sortie.exists(): shutil.rmtree(sortie)
        shutil.copytree(candidat, sortie)
    print(f'Artefact candidat : {sortie}. Aucun déploiement.')


def main() -> None:
    options = argparse.ArgumentParser(description=__doc__)
    options.add_argument('--style', type=Path, help='Cache de la révision exacte, vérifié fichier par fichier')
    options.add_argument('--elm', default=str(RACINE / 'node_modules/.bin/elm'))
    options.add_argument('--elm-format', default=str(RACINE / 'node_modules/.bin/elm-format'))
    args = options.parse_args()
    if args.style:
        construire(args.style.resolve(), str(Path(args.elm).resolve()), str(Path(args.elm_format).resolve()))
    else:
        with tempfile.TemporaryDirectory(prefix='style-mrjam-') as temporaire:
            source = Path(temporaire)
            subprocess.run(['git', 'init', '-q', str(source)], check=True)
            subprocess.run(['git', '-C', str(source), 'fetch', '--depth=1', VERROU['depot'], VERROU['revision']], check=True)
            subprocess.run(['git', '-C', str(source), 'checkout', '--detach', 'FETCH_HEAD'], check=True)
            revision = subprocess.check_output(['git', '-C', str(source), 'rev-parse', 'HEAD'], text=True).strip()
            if revision != VERROU['revision']: raise SystemExit('Révision commune inattendue.')
            construire(source, str(Path(args.elm).resolve()), str(Path(args.elm_format).resolve()))


if __name__ == '__main__':
    main()
