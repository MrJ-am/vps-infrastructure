"""Parcours d’une première visite : contenu, images, marque, MCP et confidentialité.
Les lectures publiques sont simulées ; aucune donnée personnelle n’est créée.
"""
from functools import partial
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
import json
import os
import threading
from playwright.sync_api import sync_playwright, expect

RACINE=Path(__file__).resolve().parents[1]
URL_MCP='https://assistant.exemple.test/cours/outils/mcp'

class Silencieux(SimpleHTTPRequestHandler):
    def log_message(self,*_):pass
    def do_GET(self):
        if self.path in ['/','/docs','/docs/','/privacy','/connexion']:self.path='/app.html'
        super().do_GET()


def verifier(page,base,largeur):
    demandes=[];erreurs=[]
    page.on('pageerror',lambda e:erreurs.append(str(e)))
    page.on('request',lambda r:demandes.append((r.method,r.url)))
    page.route('**/auth/session',lambda r:r.fulfill(status=401,json={'error':'authentication_required'}))
    page.route('**/mcp-config.json',lambda r:r.fulfill(status=200,json=dict(url_mcp=URL_MCP,gestion_acces='https://cours.exemple.test/vision/auth/mcp')))
    page.goto(base+'/',wait_until='networkidle')
    expect(page.get_by_role('heading',level=1)).to_have_text('Apprenez aujourd’hui. Retrouvez-le demain.')
    page.evaluate('document.fonts.ready')
    marque=page.locator('.mrjam-marque')
    expect(marque).to_have_text('Vision.MrJ.am')
    assert marque.evaluate('(e)=>getComputedStyle(e).userSelect')=='text'
    for selector,famille in [('ff-mrjamecritureserif','MrJamEcriture'),('mrjam','MrJamSignature')]:
        assert famille in page.locator('.'+selector).first.evaluate('(e)=>getComputedStyle(e).fontFamily')
        assert page.evaluate('(f)=>document.fonts.check("28px "+f)',famille)
    titre=page.get_by_role('heading',level=1)
    assert float(titre.evaluate('(e)=>getComputedStyle(e).fontSize').replace('px','')) >= (38 if largeur <=600 else 52)
    expect(page.get_by_role('link',name='Découvrir Vision',exact=True)).to_be_visible()
    assert page.get_by_role('link',name='Découvrir Vision',exact=True).bounding_box()['y']<900
    assert page.locator('footer').count()==0
    expect(page.get_by_text('Une application de',exact=False)).to_have_count(0)
    images=page.locator('main img').evaluate_all('es=>es.map(i=>({alt:i.alt,chargee:i.complete&&i.naturalWidth>0,source:i.src}))')
    assert len(images)>=5 and all(i['chargee'] and i['alt'] for i in images),images
    assert sum((RACINE/'visuels'/Path(i['source']).name).stat().st_size for i in images)<200000
    assert page.get_by_role('link',name='Agrandir la capture',exact=True).count()==2
    # Un complément ne doit pas modifier la typographie du reste de la page.
    resume=page.locator('summary').filter(has_text='Pourquoi le nom Vision ?')
    resume.focus();resume.press('Enter')
    expect(page.get_by_text('Vision joue avec le mot révision.',exact=False)).to_be_visible()
    assert float(titre.evaluate('(e)=>getComputedStyle(e).fontSize').replace('px','')) >=38
    resume.press('Enter')
    page.screenshot(path=str(RACINE/'rapports'/f'accueil-{largeur}.png'),full_page=True)
    page.get_by_role('link',name='Découvrir Vision',exact=True).click()
    expect(page.get_by_role('heading',name='Connecter votre assistant',exact=True)).to_be_visible()
    expect(page.get_by_text(URL_MCP,exact=True)).to_be_visible()
    copier=page.get_by_role('button',name='Copier l’adresse MCP',exact=True)
    copier.focus();copier.press('Enter')
    expect(page.get_by_text('Adresse copiée.',exact=True)).to_be_visible()
    assert page.evaluate('navigator.clipboard.readText()')==URL_MCP
    prive=[d for d in demandes if '/auth/' in d[1] or '/api/' in d[1]]
    assert len(prive)==1 and prive[0][1].endswith('/auth/session'),prive
    contenu=json.loads((RACINE.parent/'docs/tutoriel.json').read_text())
    for section in contenu['sections']:
        page.get_by_label('Chapitre',exact=True).select_option(section['id'])
        expect(page.get_by_role('heading',name=section['titre'],exact=True)).to_be_visible()
        assert page.url.endswith('#'+section['id']),page.url
        corps=page.locator('main').inner_text()
        assert section['explication'] in corps
        assert not any(m in corps for m in ['PostgreSQL','VPS','Nginx','CSRF'])
        assert page.evaluate('document.documentElement.scrollWidth<=innerWidth+1'),section['id']
        if section['id'] in ['connexion-gemini','connexion-codex']:
            assert URL_MCP in corps and '{{url_mcp}}' not in corps
    page.reload(wait_until='networkidle')
    expect(page.get_by_role('heading',name='Consulter et organiser',exact=True)).to_be_visible()
    page.get_by_role('link',name='Confidentialité',exact=True).click()
    expect(page.get_by_role('heading',name='Confidentialité',exact=True)).to_be_visible()
    confidentialite=page.locator('main').inner_text()
    assert not any(m in confidentialite for m in ['PostgreSQL','VPS','Nginx','CSRF','Erevan','Capitales','tutoriel'])
    assert page.locator('main img').count()==0
    assert page.locator('footer').count()==0
    assert page.evaluate('document.documentElement.scrollWidth<=innerWidth+1')
    assert not any(m=='POST' for m,_ in demandes),demandes
    assert not erreurs,erreurs
    page.screenshot(path=str(RACINE/'rapports'/f'confidentialite-{largeur}.png'),full_page=True)
    return dict(largeur=largeur,images=len(images),chapitres=len(contenu['sections']),ecritures=0)


def main():
    (RACINE/'rapports').mkdir(exist_ok=True)
    serveur=ThreadingHTTPServer(('127.0.0.1',0),partial(Silencieux,directory=str(RACINE/'dist')))
    threading.Thread(target=serveur.serve_forever,daemon=True).start()
    resultats=[]
    try:
        with sync_playwright() as pw:
            navigateur=pw.chromium.launch(**({'executable_path':os.environ['CHROMIUM']} if 'CHROMIUM' in os.environ else {}))
            for largeur in [320,375,768,1440]:
                contexte=navigateur.new_context(viewport=dict(width=largeur,height=900),has_touch=largeur<=375,permissions=['clipboard-read','clipboard-write'])
                page=contexte.new_page();page.set_default_timeout(5000)
                try:resultats.append(verifier(page,f'http://127.0.0.1:{serveur.server_port}',largeur))
                except Exception:
                    page.screenshot(path=str(RACINE/'rapports'/'vitrine-echec.png'),full_page=True)
                    raise
                finally:contexte.close()
            # Une adresse indisponible est signalée ; aucune commande vide n’est affichée.
            page=navigateur.new_page()
            page.route('**/mcp-config.json',lambda r:r.fulfill(status=503,json={'erreur':'adresse_mcp_non_configuree'}))
            page.goto(f'http://127.0.0.1:{serveur.server_port}/docs#connexion-gemini',wait_until='networkidle')
            expect(page.get_by_text('L’adresse de connexion n’est pas disponible pour le moment.',exact=False)).to_be_visible()
            assert 'gemini mcp add' not in page.locator('main').inner_text()
            navigateur.close()
    finally:serveur.shutdown()
    (RACINE/'rapports'/'vitrine.json').write_text(json.dumps(resultats,ensure_ascii=False,indent=2)+'\n')
    print('Accueil, cinq visuels locaux, marque exacte, copie MCP, onze chapitres, confidentialité et absence d’écriture : quatre formats réussis.')

if __name__=='__main__':main()
