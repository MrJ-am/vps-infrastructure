# Contrats Vision pour les assistants

Le contrat REST Basic est publié à `https://vision.mrj.am/openapi.json`.
Le endpoint MCP est `https://vision.mrj.am/mcp` ; `initialize` fournit les
instructions pédagogiques actuelles et `tools/list` les quatorze schémas.

Pour un client déjà configuré, actualiser **la définition du connecteur côté
client** après le passage à Vision 2. Une nouvelle conversation ou un appel à
`tools/list` sur le serveur ne modifie pas à lui seul une définition statique
contenant encore `search_memory_sheets` ou `record_review`. Vérifier les noms
et schémas effectivement exposés par le client avec
`python3 tests/check_client_catalog.py catalogue-client.json` avant d'affirmer
que la migration du connecteur est terminée.
Les cinq anciens outils de fiche et les notes FSRS sont explicitement retirés.
Ne pas convertir une ancienne demande `record_review` en item choisi au hasard.

Lire [MCP.md](MCP.md) : ouvrir une séance, lire tout le contexte, puis
poser une question à la fois. Une réponse ambiguë ou imprécise appelle un choix
explicite entre préciser, recevoir une aide et passer ; une erreur appelle un
accompagnement gradué et une vérification de la compréhension. Ne pas passer
automatiquement à la question suivante. Les réponses et aides sont conservées
pendant le dialogue, puis `clore_seance` enregistre le compte rendu atomique.
`evaluer_items` concerne un ajustement ponctuel hors séance. Q est contextualisé ;
les reformulations après correction ne valent pas nouveau rappel autonome.
Recherche globale avant création et reprise minimale. Les clés `cle` et
`emise_a` rendent le rejeu sûr ; les versions empêchent l’écrasement d’une
modification concurrente.

Le service fournit OAuth PKCE pour MCP, ainsi que Basic et des tokens Bearer
indépendants. Les choix de connexion disponibles dépendent du client. Conserver
les secrets dans son gestionnaire d’authentification, jamais dans une URL, des
instructions pédagogiques, une conversation ou Git. Les sessions navigateur et
les tokens MCP ont des usages distincts.
