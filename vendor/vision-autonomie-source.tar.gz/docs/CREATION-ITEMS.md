# Préparation sémantique de création d’items

## Audit et périmètre

Le contrat précédent est défini par les migrations 005–007 et le wrapper 014.
`rechercher(preparer_creation=true)` ignore le filtre de fiche, inclut les archives,
produit jusqu’à 50 candidats et une ligne dans `vision_recherches`. `lire` ajoute
les identifiants lus à cette ligne. La création compare sa recherche au titre,
désormais dérivé du début du contenu : ce protocole ne recherche pas les
paraphrases et ne lie pas la preuve au contenu exact. L’interface Elm, les tests
HTTP et les instructions MCP utilisent effectivement ce parcours. `lier_item`
permet déjà le partage entre fiches et conserve versions et historiques.

Le serveur Common Lisp reste le serveur métier. Aucune abstraction d’embeddings
ne préexistait. PostgreSQL 17 possède déjà texte français, GIN et pg_trgm ;
pgvector n’est pas activé dans le module actuel du VPS. Les rapports historiques
mentionnent 58 items à la publication de septembre : cela n’est pas un comptage
actuel de production. L’état et les ressources actuels doivent être audités via
Actions avant activation, sans lecture SSH depuis Work.

## Parcours MCP, REST et navigateur

1. `preparer_creation_item(contenu=...)` reçoit le contenu entier, 12 000 caractères
   maximum. Le serveur calcule son embedding, puis cherche tous les items du
   compte, archives comprises. La fiche courante ne limite jamais le périmètre.
2. La réponse contient `preuve_creation`, `contenu_sha256`, `expire_a`, `modele`,
   `algorithme` et jusqu’à dix `candidats`, avec contenu intégral, alias, état
   d’archive et fiches associées. Aucun texte candidat n’est tronqué.
3. Le LLM examine chaque candidat. Même connaissance : réutiliser l’item et
   `lier_item` à la nouvelle fiche. S’il est archivé, demander/appliquer sa
   restauration explicite avec `archive=false` avant rattachement : aucune
   désarchivage ni fusion automatique. Si ambigu, approfondir avec `lire` ou
   demander une distinction. Les fiches sont du contexte, jamais une frontière.
4. Si aucun candidat n’est équivalent, `enregistrer_item` reçoit le même contenu,
   la preuve et `candidats_examines` contenant exactement les identifiants
   retournés. Avec des candidats, `distinction` explique la différence. Sans
   candidat, la liste peut être omise ou vide, sans appel `lire` artificiel.

Le navigateur présente les candidats et exige une distinction explicite. Un
changement de contenu efface sa préparation. La décision du LLM ou de la personne
n’est jamais déduite d’un score : les connaissances proches mais différentes
peuvent être créées. L’accusé atteste une déclaration d’examen et l’accès aux
contenus ; le serveur ne peut vérifier une lecture mentale.

## Embeddings et fournisseur

`src/embeddings.lisp` appelle un contrat HTTP interne configurable, par défaut
`http://127.0.0.1:39004/embedding`, via curl avec un délai maximal de 30 secondes.
Le client métier ne peut transmettre ni vecteur ni modèle. Le fournisseur fourni
dans `scripts/embeddings.py` fonctionne sur CPU et charge un snapshot LOCAL,
sans téléchargement au démarrage et sans journaliser les contenus. Il est
remplaçable par un service respectant `{contenu} → {modele, embedding}`. La
configuration interne est de confiance ; ne pas exposer ce service sur Internet.

Modèle qualifié sur le corpus : `sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2`,
384 dimensions, spécialisé dans les paraphrases multilingues, français compris,
compact pour un service CPU. La révision qualifiée est `e8f8c211226b894fcb81acc59f3b34ba3efd5f42`.
Les onze fichiers et leurs SHA-256 sont verrouillés dans `deploy/modele.lock.json` ;
`deploy/modele.nix` construit un snapshot immuable, sans téléchargement au runtime.
La CI résout cette révision épinglée et conserve la même provenance.
L’infrastructure doit fournir un snapshot immuable avec provenance et empreinte
revues, puis construire avec son Nixpkgs installé.

Seul `contenu` est vectorisé : les alias restent un canal textuel, évitant qu’une
liste de surnoms déforme la connaissance. Le contenu entier est couvert par des
fenêtres de tokens adaptées au modèle, avec chevauchement de seize tokens ;
moyenne des embeddings normalisés puis normalisation. Il n’y a ni restriction
aux premiers caractères ni extraction naïve de mots-clés. La moyenne peut diluer
un texte très long ; un item doit rester atomique. Cette stratégie doit aussi
être qualifiée si les contenus longs deviennent fréquents.

L’identité `contenu-fenetres-1:<SHA-256 du snapshot>` inclut les fichiers du modèle
et la version de vectorisation. Des modèles/algorithmes différents ne partagent
jamais une recherche vectorielle. Une nouvelle identité exige un nouveau backfill.

## Recherche hybride

Distance cosinus pgvector, recherche exacte filtrée par compte ; vingt voisins
internes. Pas de HNSW au petit volume historiquement attesté : éviter un rappel
approximatif et des filtres de compte délicats. Le schéma `vector` et la clé
`(utilisateur,item_id,modele)` permettent ensuite un index HNSW avec expression
dimensionnée et modèle partiel, après mesures sur volume réel et tests de rappel.

Deux autres listes internes (vingt au plus) récupèrent le texte français et les
quasi-copies par pg_trgm. Le full-text utilise les lexèmes du contenu entier
en disjonction pour privilégier le rappel ; les trigrammes utilisent 0,15 comme
seuil permissif. Fusion RRF explicable : poids vectoriel 2, texte 1, trigrammes 1,
constante 60, déduplication par identifiant, dix sorties maximum. Les cinq premiers
voisins sémantiques sont réservés pour éviter que le vocabulaire commun masque
une paraphrase. Le corpus retrouve ses six paraphrases au premier rang avec dix candidats ;
ce choix privilégie le rappel, sans prétendre à une précision universelle. `qualite_creation.py`
mesure rappel, rang et faux positifs sur un corpus dépassant cette limite.

## Preuve et concurrence

Migration 016 : `vision_preparations_items` stocke une UUID aléatoire, le compte,
SHA-256 UTF-8 du contenu exact (espaces et accents compris), la génération du
catalogue, la liste ordonnée des candidats, le modèle, le vecteur proposé,
l’algorithme, création/expiration et consommation. Expiration après trente minutes.
La création conserve le vecteur préparé plutôt que recalculer le même contenu.

La préparation et les écritures partagent le verrou transactionnel du compte.
Une modification de contenu, alias ou archive invalide les preuves du catalogue.
Les versions/corrections mémorielles n’invalident pas inutilement l’anti-doublon.
La consommation, l’item, son embedding et le journal sont atomiques. La clé
d’écriture existante conserve le rejeu exact après consommation ; une autre clé
ne peut réutiliser la preuve. Les lignes expirées restent disponibles pour un
diagnostic explicite et sont purgées après trente-cinq jours.

Erreurs : `preuve_creation_requise`, `preuve_creation_inconnue`,
`preuve_creation_expiree`, `preuve_creation_utilisee`,
`preuve_creation_contenu_different`, `preuve_creation_catalogue_modifie`,
`candidats_non_examines`, `distinction_requise`. Le fournisseur indisponible et
l’index incomplet renvoient HTTP 503, sans délivrer de preuve ni conclure à une
absence de doublon. Les erreurs apparaissent aussi dans MCP structuredContent.

## Migration, backfill et infrastructure

016 ajoute deux tables et un trigger ; données, liens, observations et mémoires
existants sont conservés. Les anciens fichiers historiques restent en Git.
Le vieux drapeau de préparation reste accepté par validation mais renvoie
`protocole_creation_remplace`, avec le nom de la nouvelle opération. Une ancienne
`preuve_recherche` ne permet plus de créer. Les clients doivent recharger MCP et
migrer ; aucune compatibilité lexicale silencieuse ne contourne la protection.
Les recherches de navigation et `lire` restent disponibles. Quinze outils actifs.

Ordre de mise en service :

1. Auditer ressources, Nixpkgs/PostgreSQL 17, sauvegarde/restauration, génération
   active et tous les sites via Actions VPS. Évaluer le module proposé, construire
   le candidat avec le Nixpkgs installé et préparer un retour autonome.
2. Activer pgvector dans la seule base Vision par postgres. Le rôle applicatif
   ne devient pas superuser. Le candidat VPS ajoute l’option explicitement activable
   `infrastructure.postgresql.visionSemantique`, désactivée par défaut.
3. Importer le module revu `deploy/embeddings.nix`, fournir source Vision et snapshot
   exacts. Service séparé, boucle locale seulement, budget maximal 2 Gio ; mesurer
   consommation réelle avant activation. Il injecte le chemin curl dans Vision.
4. Appliquer 016 et lancer le fournisseur. Backfill par lots avec le rôle Vision :
   `python3 scripts/backfill_embeddings.py --limite 100`. Répéter jusqu’à zéro,
   archives incluses. Le module fournit aussi `vision-embeddings-backfill.service`,
   un lot manuel de cent items lancé via Actions. Ce calcul n’est pas dans la
   transaction de migration.
5. Chaque lot utilise un compare-and-set sur le contenu et n’expose pas les données
   dans les logs. Il est relançable après interruption ; une préparation est
   refusée tant qu’un item du compte n’a pas de vecteur du modèle courant.
6. Valider création, réutilisation, liens, identités, sessions/CSRF et MCP sur une
   sauvegarde restaurée, puis publier avec preuves. Aucune donnée fictive en
   production. Ne jamais restaurer une base pour revenir à l’ancienne application.

Les créations stockent leur vecteur ; une modification du contenu le remplace
dans la même transaction. Les alias seuls ne le recalculent pas. Une écriture SQL
historique invalide le vecteur périmé : le backfill le reconstruit. La publication
de code n’atteste pas une activation système, d’extension ou d’application.

## Vérifications

`tests/check_creation.py` vérifie HTTP/SQL, preuve, exactitude au-delà du début du
texte, concurrence/catalogue, zéro candidat, contenu complet, archives, examen,
usage unique, rejeu et refus des vecteurs client. Les tests métier et interface
emploient une doublure de transport explicitement non sémantique.

Le workflow `creation-semantique.yml` charge le vrai modèle CPU, migre PostgreSQL
17 avec pgvector et lance le vrai serveur Lisp. `tests/qualite_creation.py` vérifie
capitales, dévolution, savoir fonctionnel, vocabulaire divergent, connaissances
lexicalement proches distinctes, réutilisation par lien, archives, alias et
mise à jour d’embedding. Le rapport conserve le modèle exact et les mesures.
Il faut lire son résultat, pas seulement constater une compilation.

Résultat de qualification au commit `88b0131522e5ceab685fb8bc65448844928b8468` :
les six paraphrases attendues sont retrouvées au premier rang (rappel 100 % sur
ce corpus), avec neuf autres propositions en moyenne. Le corpus contient aussi
des négations et relations voisines : leurs items restent distincts. Il ne
représente pas tous les domaines ; ce chiffre ne garantit pas un rappel global.
Workflow sémantique 37164088661 et backend 37164088700 réussis. Les contrôles
interface et Nix doivent aussi passer sur le commit final. Aucun déploiement
applicatif ou système n’est attesté par ces tests.
