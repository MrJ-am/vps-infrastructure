/* Transport de l'interface : aucune présentation, donnée persistée ou règle pédagogique. */
(() => {
  'use strict';
  if (location.pathname === '/docs/') history.replaceState(null, '', '/docs' + location.hash);
  const application = Elm.Main.init({node: document.getElementById('application'),
    flags: {cle: crypto.randomUUID(), instant: new Date().toISOString(), adresse: location.hash, chemin: location.pathname}});
  window.addEventListener("hashchange", () => application.ports.adresse.send(location.hash));
  const requetes = new Map();
  const chemins = new Set(['/auth/session', '/auth/login', '/auth/logout',
    ...['rechercher', 'lire', 'preparer_creation_item', 'preparer_revision', 'enregistrer_fiche', 'enregistrer_item',
      'lire_politique', 'lier_item', 'evaluer_items', 'enregistrer_contexte', 'regler_politique'].map(n => `/api/web/${n}`)]);
  let protege = false;

  application.ports.requete.subscribe(async demande => {
    const numero = demande.numero;
    const controle = new AbortController();
    requetes.set(numero, controle);
    const minuterie = setTimeout(() => controle.abort(), 30000);
    let statut = 0;
    let corps = {error: 'transport_indisponible'};
    try {
      if (!chemins.has(demande.chemin)
          || demande.methode !== (demande.chemin === '/auth/session' ? 'GET' : 'POST')) {
        throw new Error('contrat_invalide');
      }
      if (demande.chemin.startsWith('/api/web/') && !demande.csrf) throw new Error('csrf_required');
      const entetes = {Accept: 'application/json'};
      if (demande.methode === 'POST') entetes['Content-Type'] = 'application/json';
      if (demande.csrf) entetes['X-CSRF-Token'] = demande.csrf;
      const resultat = await fetch(demande.chemin, {
        method: demande.methode, credentials: 'same-origin', cache: 'no-store',
        redirect: 'error', headers: entetes, signal: controle.signal,
        body: demande.methode === 'POST' ? JSON.stringify(demande.corps) : undefined
      });
      statut = resultat.status;
      try { corps = await resultat.json(); }
      catch { corps = {error: 'reponse_inattendue'}; if (resultat.ok) statut = 502; }
    } catch (erreur) {
      if (['date_invalide', 'csrf_required', 'contrat_invalide'].includes(erreur.message)) {
        statut = 400;
        corps = {error: erreur.message};
      }
    } finally {
      clearTimeout(minuterie);
      // Une expiration/déconnexion retire les requêtes, y compris leurs réponses tardives.
      if (requetes.delete(numero)) application.ports.reponse.send({numero, statut, corps});
    }
  });

  application.ports.effets.subscribe(({nom, valeur}) => {
    if (nom === 'adresse') history.replaceState(null, '', location.pathname + location.search + valeur);
    if (nom === 'proteger') protege = valeur === true;
    if (nom === 'annulerRequetes') {
      for (const controle of requetes.values()) controle.abort();
      requetes.clear();
    }
    if (nom === 'focus') {
      requestAnimationFrame(() => requestAnimationFrame(() => {
        const zone = document.getElementById(valeur);
        // Ne pas voler le focus si la personne a déjà commencé sa saisie.
        if (!zone || zone.contains(document.activeElement)) return;
        const cible = ['connexion', 'edition', 'correction'].includes(valeur)
          ? zone.querySelector('input,textarea') || zone
          : zone.querySelector('[role="heading"],h1,h2,h3') || zone;
        cible.focus();
      }));
    }
  });
  window.addEventListener('beforeunload', evenement => {
    if (protege) { evenement.preventDefault(); evenement.returnValue = ''; }
  });
})();

