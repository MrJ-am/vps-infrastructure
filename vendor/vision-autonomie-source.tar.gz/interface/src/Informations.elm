module Informations exposing (publique, vue)

import Html exposing (Html)
import MrJam
import MrJam.Documents as Documents
import MrJam.Lecture as Lecture
import Tutoriel
import Visuels


publique : String -> Bool
publique chemin =
    List.member chemin [ "/docs", "/docs/", "/privacy" ]


vue : String -> Html message
vue chemin =
    Documents.espace "Vision"
        [ MrJam.lien "Se connecter" "/connexion", MrJam.lien "Ouvrir Vision" "/", MrJam.lien "Tutoriel" "/docs", MrJam.lien "Confidentialité" "/privacy" ]
        Nothing
        [ Documents.document
            (if chemin == "/privacy" then
                "Confidentialité"

             else if chemin == "/" then
                "Apprendre avec un LLM, retrouver ce qui compte"

             else
                "Découvrir Vision"
            )
            [ Lecture.markdown
                (if chemin == "/privacy" then
                    confidentialite

                 else if chemin == "/" then
                    accueil

                 else
                    Tutoriel.contenu
                )
            , Visuels.partage
            , Visuels.espacement
            , MrJam.lien "Contrat OpenAPI" "/openapi.json"
            ]
        ]


accueil : String
accueil =
    """Vision associe la liberté du dialogue avec un LLM à une planification persistante. Vos connaissances et leur état restent disponibles d’une séance à l’autre : vous pouvez reprendre, comprendre les choix de révision et régler un modèle volontairement simple.

## Des connaissances, des exercices vivants

Les fiches donnent un contexte et un objectif. Les items décrivent des connaissances autonomes, réutilisables dans plusieurs fiches avec une seule stabilité. L’assistant peut proposer une question, une explication ou une phrase nouvelle et contextualisée : les répétitions espacées ne vous enferment pas dans des cartes rigides.

## Une planification que vous pouvez comprendre

Vision suit la stabilité de chaque item, la priorité des fiches et une période cible. Les fenêtres sont indicatives ; elles ne prédisent pas avec certitude ce que vous avez oublié. Vous pouvez consulter les réglages, choisir un budget et comprendre les effets d’une évaluation ou d’une aide avant de modifier votre politique.

## Commencer à votre rythme

Le tutoriel public explique fiches, items, langues, stabilité et séances avec des exemples fictifs. Le lire ne crée aucune donnée et ne change aucun réglage. Après connexion, le site permet de consulter et d’organiser vos connaissances. Un client MCP connecté permet de réviser en dialogue ; Basic, tokens Bearer ou OAuth PKCE sont proposés selon le client. Le service ne propose pas ici d’inscription publique : utilisez votre compte Vision existant.

## Pourquoi « Vision » ?

Le nom joue avec « révision » et fait un clin d’œil au personnage portant une pierre lumineuse au front. Il ne suggère aucune affiliation officielle. Ici, la lumière évoque un souvenir que l’on retrouve ; elle ne promet ni une efficacité supérieure démontrée ni une absence d’oubli."""


confidentialite : String
confidentialite =
    """Version du 26 septembre 2026.

Vision conserve dans PostgreSQL les fiches, les items, leurs relations, les suivis et les comptes rendus de révision. Ces données servent à retrouver les connaissances pertinentes et à organiser les révisions. L’archivage est réversible et ne supprime pas les données.

Le serveur peut journaliser les métadonnées techniques nécessaires à la sécurité et à l’exploitation : adresse IP, horodatage, catégorie de route et code de réponse. Les corps MCP, mots de passe, cookies et en-têtes d’autorisation ne figurent pas dans les journaux ordinaires.

Les données restent sur le VPS administré pour Vision et ne sont pas vendues. Lorsqu’un client MCP demande des données, elles sont transmises à ce client et relèvent aussi de ses propres conditions de confidentialité.

Les brouillons de l’interface restent uniquement en mémoire pendant la session. Ils ne sont pas enregistrés dans le stockage local du navigateur."""
