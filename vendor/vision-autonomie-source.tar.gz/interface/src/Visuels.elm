module Visuels exposing (espacement, partage)

{-| Schémas métier textuels : lisibles au clavier et par les lecteurs d’écran,
sans fonte externe, image nécessaire au sens ou animation.
-}

import Element exposing (Element)
import MrJam
import MrJam.Donnees as Donnees


partage : Element message
partage =
    MrJam.pile
        [ Donnees.lecture "Capitales de l’Asie ──┐\n                     ├── Erevan est la capitale de l’Arménie.\nVoyage en Arménie ───┘   Une seule stabilité, des observations communes."
        , MrJam.paragraphe "Deux fiches partagent le même item. Chaque fiche garde ses propres consignes d’exercice ; l’état mémoriel de l’item reste unique."
        ]


espacement : Element message
espacement =
    MrJam.pile
        [ Donnees.lecture "●──●────●────────●\nDes rappels, puis des espaces qui peuvent grandir."
        , MrJam.paragraphe "Ce schéma illustre l’espacement possible des rappels. Les dates réelles dépendent des évaluations et des réglages ; les points ne représentent pas une promesse de mémorisation."
        ]
