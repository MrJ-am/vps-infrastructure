module Contrat exposing (Nature(..), autre, brouillon, chaine, depuisAdresse, destination, entier, grandeur, lignes, listes, nom, nombre, nouveau, objet, pluriel, texte, vrai)

import Dict exposing (Dict)
import Json.Decode as D
import Json.Encode as E exposing (Value)


chaine : String -> Value -> String
chaine cle valeur =
    D.decodeValue (D.field cle D.string) valeur |> Result.withDefault ""


entier : String -> Value -> Int
entier cle valeur =
    D.decodeValue (D.field cle D.int) valeur |> Result.withDefault 0


nombre : String -> Value -> Maybe Float
nombre cle valeur =
    D.decodeValue (D.field cle D.float) valeur |> Result.toMaybe


vrai : String -> Value -> Bool
vrai cle valeur =
    D.decodeValue (D.field cle D.bool) valeur |> Result.withDefault False


listes : String -> Value -> List Value
listes cle valeur =
    D.decodeValue (D.field cle (D.list D.value)) valeur |> Result.withDefault []


objet : String -> Value -> Value
objet cle valeur =
    D.decodeValue (D.field cle D.value) valeur |> Result.withDefault E.null


texte : Value -> String
texte valeur =
    D.decodeValue D.string valeur |> Result.withDefault ""


lignes : String -> List String
lignes =
    String.lines >> List.map String.trim >> List.filter ((/=) "")


nouveau : Dict String String
nouveau =
    Dict.fromList
        [ ( "titre", "" )
        , ( "contenu", "" )
        , ( "suivi", "" )
        , ( "tags", "" )
        , ( "alias", "" )
        , ( "priorite", "0" )
        , ( "stabilite", "-15" )
        , ( "reference_a", "" )
        , ( "justification", "" )
        , ( "distinction", "" )
        ]


brouillon : Value -> Dict String String
brouillon valeur =
    let
        chaines =
            List.map (\cle -> ( cle, chaine cle valeur )) [ "titre", "contenu", "suivi" ]

        tableaux =
            List.map (\cle -> ( cle, listes cle valeur |> List.map texte |> String.join "\n" )) [ "alias", "tags" ]
    in
    Dict.union (Dict.fromList (chaines ++ tableaux ++ [ ( "priorite", String.fromInt (entier "priorite" valeur) ), ( "stabilite", String.fromInt (entier "stabilite" valeur) ) ])) nouveau



-- Les chaînes du protocole sont confinées à cette frontière.


type Nature
    = Fiche
    | Item


nom : Nature -> String
nom nature =
    case nature of
        Fiche ->
            "fiche"

        Item ->
            "item"


pluriel : Nature -> String
pluriel nature =
    case nature of
        Fiche ->
            "Fiches"

        Item ->
            "Items"


autre : Nature -> Nature
autre nature =
    case nature of
        Fiche ->
            Item

        Item ->
            Fiche


grandeur : Nature -> String
grandeur nature =
    case nature of
        Fiche ->
            "priorite"

        Item ->
            "stabilite"


destination : Nature -> Int -> String
destination nature id =
    "#" ++ nom nature ++ "/" ++ String.fromInt id


depuisAdresse : String -> Maybe ( Nature, Int )
depuisAdresse adresse =
    if not (String.startsWith "#" adresse) then
        Nothing

    else
        case String.split "/" (String.dropLeft 1 adresse) of
            [ nature, identifiant ] ->
                Maybe.map2 Tuple.pair
                    (case nature of
                        "fiche" ->
                            Just Fiche

                        "item" ->
                            Just Item

                        _ ->
                            Nothing
                    )
                    (String.toInt identifiant
                        |> Maybe.andThen
                            (\id ->
                                if id > 0 then
                                    Just id

                                else
                                    Nothing
                            )
                    )

            _ ->
                Nothing
