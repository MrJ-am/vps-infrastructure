#!/bin/sh
# Ne lancer que dans le service PostgreSQL jetable de la CI.
set -eu
cd "$(dirname "$0")/../.."
[ "${PGHOST:-}" = 127.0.0.1 ] && [ "${PGDATABASE:-}" = vision_interface_test ] || {
  echo 'Tests refusés : PostgreSQL local et base vision_interface_test exigés.' >&2
  exit 1
}
[ "$(psql -XAt -v ON_ERROR_STOP=1 -c 'SELECT current_database()')" = vision_interface_test ]
port=39003
temporaire=$(mktemp -d)
processus=''
embeddings=''
nettoyer() {
  if [ -n "$embeddings" ]; then kill "$embeddings" 2>/dev/null || true; fi
  if [ -n "$processus" ]; then
    kill "$processus" 2>/dev/null || true
    wait "$processus" 2>/dev/null || true
  fi
  cp "$temporaire/serveur.log" interface/rapports/serveur-isole.log 2>/dev/null || true
  rm -rf "$temporaire"
}
trap nettoyer EXIT INT TERM
mkdir -p interface/rapports
psql -X -v ON_ERROR_STOP=1 -c 'CREATE EXTENSION IF NOT EXISTS vector'
python3 tests/embeddings_fixture.py >"$temporaire/embeddings.log" 2>&1 &
embeddings=$!
sh scripts/migrate.sh
sh build.sh
IP=127.0.0.1 PORT="$port" VISION_PSQL="$(command -v psql)" VISION_DOCUMENT_ROOT="$PWD/docs" \
  ./vision >"$temporaire/serveur.log" 2>&1 &
processus=$!
for essai in $(seq 1 50); do
  if curl --fail --silent --max-time 1 "http://127.0.0.1:$port/healthz" >/dev/null; then break; fi
  sleep 0.1
done
curl --fail --silent --max-time 1 "http://127.0.0.1:$port/healthz" >/dev/null
python3 interface/tests/refonte.py --port-serveur "$port"

