#!/usr/bin/env python3
"""Contrats MCP et OpenAPI générés depuis une seule définition française."""
import json
from pathlib import Path
RACINE=Path(__file__).resolve().parent.parent

def texte(maximum=4000, **kw):return dict(type='string',maxLength=maximum,**kw)
def entier(minimum=0,maximum=2147483647,**kw):return dict(type='integer',minimum=minimum,maximum=maximum,**kw)
def tableau(elements,maximum=50,minimum=0):return dict(type='array',items=elements,minItems=minimum,maxItems=maximum)
def objet(proprietes=None,obligatoires=(),libre=False):return dict(type='object',properties=proprietes or {},required=list(obligatoires),additionalProperties=libre)
def choix(*valeurs):return texte(40,enum=list(valeurs))
def date():return texte(40,format='date-time')
def nullable(schema):return {**schema,'type':[schema['type'],'null']}
BOOLEEN={'type':'boolean'}
ID=entier(1)
OBSERVATION=objet({'id':ID,'texte':texte(4000),'source':texte(40),'details':objet(libre=True),
 'evenement_a':nullable(date()),'enregistre_a':date(),'rectifie_id':nullable(ID)},
 ['id','texte','source','details','enregistre_a'],libre=True)
FICHE_SEANCE=objet({'id':ID,'titre':texte(200),'contenu':texte(50000),'suivi':texte(),
 'observations':tableau(OBSERVATION,100000)},['id','titre','contenu','observations'],libre=True)
ITEM_SEANCE=objet({'id':ID,'version':entier(1),'contenu':texte(12000),
 'observations':tableau(OBSERVATION,100000),'fenetre':objet(libre=True)},
 ['id','version','contenu','observations','fenetre'],libre=True)
USAGE_SEANCE=objet({'fiche':FICHE_SEANCE,'items':tableau(ITEM_SEANCE,20)},
 ['fiche','items'],libre=True)
COMMUN={'cle':texte(100,minLength=8,description='Clé stable pour tous les rejeux du même enregistrement ; ne pas la changer après un délai réseau.'),'emise_a':date()}
SORTIE_COMMUNE={'erreur':texte(100),'enregistre':BOOLEEN,'rejeu':BOOLEEN,'maintenant':date(),'politique':objet(libre=True)}
CONTRAT=(RACINE/'docs/CONTRAT-SEANCE.md').read_text()
OUTILS=[]
def outil(nom,titre,description,proprietes,obligatoires,sortie,ecriture=False):
 if nom in ('preparer_revision','ouvrir_seance','lire_seance','clore_seance','evaluer_items'):
  description += '\n\n' + CONTRAT
  sortie={**sortie,'contrat_pedagogique':texte(16000),'consigne':texte(16000)}
 if ecriture:proprietes={**COMMUN,**proprietes};obligatoires=['cle','emise_a',*obligatoires]
 OUTILS.append(dict(name=nom,title=titre,description=description,inputSchema=objet(proprietes,obligatoires),outputSchema=objet({**SORTIE_COMMUNE,**sortie},libre=True),annotations=dict(readOnlyHint=not ecriture,destructiveHint=False,idempotentHint=True,openWorldHint=False)))

outil('rechercher','Rechercher des fiches et des items',
 'Recherche paginée pour naviguer. Pour créer un item, utiliser preparer_creation_item avec le contenu complet. preparer_creation est déprécié et renvoie protocole_creation_remplace ; aucune preuve lexicale ne permet désormais une création.',
 {'type':choix('fiche','item'),'requete':texte(200),'tags':tableau(texte(64)),'etat':choix('actif','archive','tous'),'tri':choix('titre','alphabetique','priorite','stabilite','modification'),'limite':entier(1,50),'decalage':entier(0,1000000),'fiche_id':ID,'preparer_creation':BOOLEEN},['type','requete'],
 {'resultats':tableau(objet(libre=True)),'total':entier(),'limite':entier(),'decalage':entier(),'suite':BOOLEEN,'preuve_recherche':nullable(texte(40))})
outil('preparer_creation_item','Préparer la création d’une connaissance',
 'Envoyer le contenu COMPLET envisagé. Recherche hybride globale dans tous les items du compte, archives incluses. Les candidats (au plus dix) incluent leur contenu intégral, alias et fiches de contexte. Examiner chacun : même connaissance, réutiliser cet item avec lier_item ; ambiguïté, approfondir ou demander une distinction ; sinon enregistrer_item avec preuve_creation, candidats_examines contenant exactement leurs identifiants et une distinction explicite. Aucun appel lire obligatoire, notamment sans candidat. Preuve liée au SHA-256 exact du contenu, au compte, au catalogue et au modèle ; expiration trente minutes, usage unique sauf rejeu identique. Une absence d’index sémantique complet est une erreur, pas une absence de doublon.',
 {'contenu':texte(12000,minLength=1)},['contenu'],
 {'preuve_creation':texte(36),'contenu_sha256':texte(64),'expire_a':date(),'algorithme':texte(100),'modele':texte(250),'candidats':tableau(objet(libre=True),10),'consigne':texte(),'nombre_manquants':entier()})
outil('lire','Lire les objets utiles',
 'Lire jusqu’à 20 fiches ou items ciblés avec contenu, observations horodatées et relations ; le suivi synthétique appartient à la fiche. Les relations d’une fiche sont filtrées et triées avant pagination : tri_liens=echeance privilégie la fermeture la plus proche ; filtre_liens distingue retard, fenêtre, nouveaux et à venir. nombre_items est le total et nombre_items_filtres celui du filtre. Les observations d’un item sont communes à toutes ses fiches. En révision, garder ces données comme contexte : ne pas afficher les réponses avant la question.',
 {'type':choix('fiche','item'),'ids':tableau(ID,20,1),'limite':entier(1,50),'decalage':entier(0,1000000),'preuve_recherche':texte(40),'tri_liens':choix('echeance','alphabetique','ordre','stabilite'),'filtre_liens':choix('tous','retard','dans_fenetre','nouveau','a_venir')},['type','ids'],{'objets':tableau(objet(libre=True),20)})
evaluation=objet({'item_id':ID,'version':entier(1),'episode':texte(100,minLength=1),'version_episode':entier(),'q':entier(-20,20),'sens':texte(300,description='Description libre de la question ; aucune liste de sens à consulter dans l’item.'),'aide':choix('aucune','indice','correction'),'type_evenement':choix('rappel','apprentissage','suivi'),'evenement_a':date(),'date_inconnue':BOOLEEN,'date_rappel':texte(10),'fuseau':texte(6),'precision':choix('instant','jour','approximative'),'provenance':texte(200),'production_initiale':choix('correcte','incorrecte','incomplete','ambigue','non_verifiee'),'justification':texte(1000)},['item_id','version','episode','version_episode','q','sens','aide'])
outil('preparer_revision','Suggérer des fiches à réviser',
 'Dès que la personne veut réviser sans préciser de fiche, appeler cet outil. Chaque suggestion distingue les items en retard, ceux dans la fenêtre et les nouveaux. Annoncer total_en_retard et proposer de commencer par ces fiches lorsqu’il est positif. Proposer quelques thèmes pertinents et demander si elle a une envie particulière ou préfère une suggestion. Si des séances sont ouvertes, demander : « Voulez-vous ouvrir une nouvelle séance ou obtenir des informations sur les séances ouvertes ? » Attendre le choix. Nouvelle séance : appeler ouvrir_seance avec nouvelle_seance=true ; informations : appeler lister_seances. Ne pas exposer les réponses ni les identifiants techniques.',
 {'fiche_id':ID,'conversation':texte(100,minLength=1),'limite':entier(1,20)},[],
 {'usage_assistant':objet(libre=True),'suggestions':tableau(objet(libre=True),20),'contexte':nullable(objet(libre=True)),'seances_en_attente':tableau(objet(libre=True),20),'total_seances_ouvertes':entier(),'consigne':texte(),'message':texte(),'total_en_retard':entier(),'message_retard':texte()})
outil('lister_seances','Lister les séances ouvertes',
 'Lister les séances ouvertes par pages, avec thème, date de début et nombre de questions. Le total est complet, suite indique une autre page. Présenter thème et date, pas les identifiants techniques. Sur demande de reprise ou clôture, appeler lire_seance avec l’identifiant retourné.',
 {'limite':entier(1,50,default=20),'decalage':entier(0,2147483647,default=0)},[],
 {'seances':tableau(objet(libre=True),50),'total':entier(),'decalage':entier(),'suite':BOOLEEN})
outil('lire_seance','Lire une séance identifiée',
 'Lire une séance identifiée depuis lister_seances : thème, date, état et lot initial. Vision ne connaît aucune réponse avant clôture. Ne pas présenter le lot entier comme des réponses à la personne. Reprendre à partir des faits connus ; une clôture sans évaluation est possible sur demande explicite.',
 {'seance_id':texte(36,minLength=36)},['seance_id'],
 {'seance':objet(libre=True),'usage_assistant':USAGE_SEANCE,'rapport':nullable(objet(libre=True)),'message':texte()})
outil('ouvrir_seance','Ouvrir une séance de révision',
 'Choisir la fiche, lire son contenu, les items, leurs contenus autonomes et leurs observations datées. Tout ce contexte structuré figure dans usage_assistant : le lire entièrement avant la première question. Si nombre_items_a_reviser dépasse le nombre typique, aucun lot n’est créé : annoncer ce nombre et demander combien de questions (1 à 20), puis rappeler avec nombre_questions. Trier les items évalués par date de fermeture croissante de leur fenêtre ; les items non évalués complètent un petit lot. Si des séances sont déjà ouvertes, demander : « Voulez-vous ouvrir une nouvelle séance ou obtenir des informations sur les séances ouvertes ? » Première réponse : rappeler avec nouvelle_seance=true ; seconde : lister_seances. Il n’y a aucune limite au nombre de séances ouvertes. Annoncer le nombre de questions, attendre que la personne soit prête, puis interroger une question à la fois sans afficher les réponses du lot. Après une réponse ambiguë ou imprécise, rester sur le même item et demander si la personne veut préciser, recevoir une aide ou passer. En cas d’erreur, accompagner une nouvelle tentative par étapes, puis vérifier la compréhension avant de continuer ; respecter le souhait de passer ou d’arrêter.',
 {'fiche_id':ID,'conversation':texte(100,minLength=1,description='Identifiant stable fourni par le client si disponible ; ne jamais prétendre créer un lien vers une conversation privée.'),'limite':entier(1,20,description='Remplacement ponctuel du nombre typique enregistré dans la politique.'),'nombre_questions':entier(1,20,description='Choix explicite de la personne après annonce du nombre à réviser.'),'hors_fenetre':BOOLEEN,'nouvelle_seance':BOOLEEN},['fiche_id'],
 {'confirmation_requise':BOOLEEN,'choix_nombre_requis':BOOLEEN,'hors_fenetre_possible':BOOLEEN,'nombre_items_a_reviser':entier(),'nombre_items_non_evalues':entier(),'seance_id':texte(36),'nombre_questions':entier(),'nombre_items_disponibles':entier(),'usage_assistant':USAGE_SEANCE,'seances_en_attente':tableau(objet(libre=True),20),'total_seances_ouvertes':entier(),'suite_seances_ouvertes':BOOLEEN,'consigne':texte(),'message':texte()},True)
retour=objet({'difficulte':choix('facile','adaptee','difficile','non_indiquee'),'commentaire':texte(2000),'reformulations':tableau(objet({'item_id':ID,'suggestion':texte(1000,minLength=1)},['item_id','suggestion']),20),'ajouts':tableau(texte(500,minLength=1),20)},['difficulte','reformulations','ajouts'])
echange=objet({'item_id':ID,'question':texte(500,minLength=1),'etat':choix('tente','saute'),
 'reponse':texte(2000),'correction':texte(1000),'aide':choix('aucune','indice','correction'),
 'sens':texte(300),'episode':texte(100),
 'observation':texte(2000,description='Constat pédagogique spécifique à cette tentative, éventuellement vide.'),
 'posee_a':date(),'reponse_initiale':texte(2000),'erreur_ou_manque':texte(1000),'aides':tableau(texte(1000),20),'reponse_finale':texte(2000),'abandon':BOOLEEN,'verification_effective':texte(2000)},['item_id','question','etat'])
evaluation_seance={**evaluation,'required':['item_id','q','aide']}
retour_seance={**retour,'required':[]}
outil('clore_seance','Enregistrer le compte rendu de séance',
 'Enregistrer en un appel les évaluations connues. Dans chaque évaluation, seuls item_id, q et aide sont requis ; Vision fournit les versions et épisodes. sens est un texte libre facultatif. Le déroulement et le retour sont facultatifs : fournir les faits disponibles sans inventer ni exiger de copie d’un autre chat. Pour une remédiation, garder la réponse initiale, le point manquant, l’aide, la reformulation vérifiée et l’incertitude dans l’observation ; évaluer le rappel initial, sans créditer comme autonome la reprise après correction. Ne pas retarder la clôture pour obtenir un bilan ; un retour déjà donné suffit. Vision enregistre atomiquement, signale les gains limités et les traces manquantes. Rejouer la même requête si la réponse est perdue ; la séance protège aussi contre le double crédit si la clé change. Sans réponses connues, clore avec evaluations=[] seulement sur demande explicite.',
 {'seance_id':texte(36,minLength=36),'accepter_datation_cloture':BOOLEEN,'datations_groupes':tableau(objet({'item_ids':tableau(ID,20,1),'evenement_a':date(),'date_rappel':texte(10),'fuseau':texte(6),'precision':choix('instant','jour','approximative'),'provenance':texte(200)},['item_ids','provenance']),20),'evaluations':tableau(evaluation_seance,20),'deroulement':tableau(echange,40),'retour':retour_seance,'synthese':texte(2000),'observation_fiche':texte(2000,description='Constat facultatif sur les liens entre items ou la compréhension d’ensemble.')},['seance_id','evaluations'],{'rapport':objet(libre=True)},True)

outil('enregistrer_fiche','Créer ou modifier une fiche',
 'Création seulement sur demande explicite : titre et contenu requis. Pour modifier, fournir id et version lus et uniquement les champs à changer. suivi est une synthèse actuelle, sans chronologie redondante. P entière entre −20 et +20 dB ; positive avance la révision. Ne changer une priorité personnelle qu’à la demande. archive est réversible. Aucun état mémoriel de fiche.',
 {'id':ID,'version':entier(1),'titre':texte(200,minLength=1),'contenu':texte(50000,minLength=1),'suivi':texte(),'alias':tableau(texte(120)),'tags':tableau(texte(64)),'priorite':entier(-20,20),'archive':BOOLEEN},[],{'fiche':objet(libre=True)},True)
outil('enregistrer_item','Créer ou modifier un item',
 'Un item se réduit à une connaissance atomique intelligible seule. Le contenu explicite la relation, les termes et la langue : « Lisbonne est la capitale du Portugal » et « Je t’aime se dit Ti amo en italien ». Ne mettre aucun titre, objectif de séance, sens de rappel ni suivi dans l’item : ces consignes appartiennent à la fiche, les constats datés aux observations. Avant création, preparer_creation_item reçoit le contenu complet. Examiner intégralement tous ses candidats ; même connaissance, réutiliser et lier. Sinon transmettre preuve_creation, candidats_examines et distinction. Une preuve ne permet jamais un contenu différent. preuve_recherche est dépréciée et refusée pour créer. Création : contenu requis ; S=-15 dB par défaut. Toute autre initialisation exige justification. Modification avec id et version : pas de changement de S ou de date mémoire. Observations communes à toutes les fiches.',
 {'id':ID,'version':entier(1),'contenu':texte(12000,minLength=1),'alias':tableau(texte(120)),'stabilite':entier(-128,127),'reference_a':nullable(date()),'justification':texte(1000),'preuve_recherche':texte(40,description='Déprécié : utiliser preuve_creation.'),'preuve_creation':texte(36),'candidats_examines':tableau(ID,10),'distinction':texte(1000),'archive':BOOLEEN},[],{'item':objet(libre=True)},True)
outil('lier_item','Rattacher ou détacher un item',
 'Réutiliser un item existant dans une autre fiche. Fournir la version courante de la fiche. Le lien porte seulement ordre et contexte propre à la fiche. Détacher ne supprime ni l’item ni ses autres liens et ne change jamais S ou sa date. Répéter un rattachement identique ne crée aucun doublon.',
 {'fiche_id':ID,'item_id':ID,'version_fiche':entier(1),'action':choix('rattacher','detacher'),'ordre':entier(0,1000000),'contexte':texte(1000)},['fiche_id','item_id','version_fiche','action'],{'fiche':objet(libre=True),'item_id':ID,'modifie':BOOLEEN},True)
outil('evaluer_items','Actualiser les items après une tentative',
 'Écriture ponctuelle hors séance pour un ajustement explicite. Pour une séance interactive, utiliser ouvrir_seance puis clore_seance avec toutes les évaluations et le retour final, sans écriture entre les réponses. Une précision et une reformulation après aide restent dans la même tentative ; seul le rappel initial autonome justifie un gain. Les évaluations sont atomiques, versionnées et idempotentes.',
 {'conversation':texte(100,minLength=1),'evaluations':tableau(evaluation,20,1)},['evaluations'],{'evaluations':tableau(objet(libre=True),20)},True)
outil('ajouter_observation','Consigner une observation pédagogique',
 'Ajouter un constat horodaté à un item ou une fiche, sans modifier S, P ni les échéances. L’item est transversal à toutes ses fiches ; une observation de fiche concerne les liens et la compréhension d’ensemble. Les lignes sont immuables et auditables ; pour rectifier, ajouter une nouvelle observation avec rectifie_id. evenement_a est la date du fait si elle est réellement connue ; sinon omettre et conserver uniquement la date d’enregistrement serveur. Ne pas inventer une date.',
 {'objet':choix('item','fiche'),'objet_id':ID,'texte':texte(2000,minLength=1),'evenement_a':date(),'rectifie_id':ID},['objet','objet_id','texte'],
 {'observation':objet(libre=True)},True)
question=objet({'item_id':ID,'question':texte(500),'sens':texte(300),'aide':choix('aucune','indice','correction')},['item_id','question'])
outil('enregistrer_contexte','Conserver un contexte minimal de reprise',
 'Conserver uniquement fiche, items actifs, jusqu’à 12 questions/aides et une synthèse de reprise ≤2000 caractères ; aucune conversation complète. Version=0 à la création, puis version lue dans preparer_revision. Une conversation n’est pas une séance. Fin de séance : consolider sans rejouer les gains ni créer de nouveaux items. Contexte conservé 90 jours, au plus 50 conversations actives par compte.',
 {'conversation':texte(100,minLength=1),'version':entier(),'fiche_id':nullable(ID),'items':tableau(ID,20),'reprise':texte(2000),'questions':tableau(question,12)},['conversation','version'],{'contexte':objet(libre=True)},True)
outil('regler_politique','Régler l’intervalle et le budget de révision',
 'Modification partielle uniquement sur demande explicite : fournir la version lue et les seuls champs à changer. duree_seance_courte_minutes (1–10080, défaut 60) : durée strictement inférieure = courte ; à la borne ou au-delà = longue. Consulter tutoriel ou lire_politique ne modifie rien. T est une politique, 90 jours par défaut (1–3650), pas une probabilité de rappel. budget est un nombre d’items distincts par jour, null désactive l’adaptation. questions_typiques (1 à 20, défaut 8) complète les petits lots avec des items non évalués ; il ne tronque pas silencieusement les items dans la fenêtre. G augmente les intervalles lorsque la charge estimée dépasse ce budget ; déplacement d’au plus 1 dB par semaine, entre 0 et 30. Aucun changement de S. Fournir la version du profil renvoyée par une lecture.',
 {'version':entier(),'intervalle_jours':entier(1,3650),'budget':nullable(entier(1,1000)),'questions_typiques':entier(1,20),'duree_seance_courte_minutes':entier(1,10080)},['version'],{},True)

outil('lire_politique','Consulter les réglages effectifs',
 'Lecture seule : valeurs effectives et version, unités, bornes, défauts et paramètres automatiques. Ne pas appeler regler_politique sans demande explicite.',
 {},[],{'parametres':objet(libre=True),'automatiques':objet(libre=True)})
outil('lien_fiche','Obtenir le lien privé d’une fiche',
 'Vision construit l’URL depuis sa configuration publique et la route réelle #fiche/ID. Vérifie les droits, ne contient aucun token, ne change aucun partage. Ne jamais deviner le domaine. Après connexion, le fragment retrouve la fiche.',
 {'fiche_id':ID},['fiche_id'],{'url':texte(2000),'fiche_id':ID,'prive':BOOLEEN})
outil('etat_fiche','Consulter et exporter une fiche en Markdown',
 'Contenu intégral de la fiche et des items de la page, stabilité par item, dernier rappel connu et fenêtre calculée. Aucun état mémoriel de fiche. Lire les pages jusqu’à suite=false pour présenter une fiche complète. markdown est un segment de l’export, pas un export complet si suite=true. Les observations ont des volets séparés paginés ; les totaux sont explicites. Ne pas inventer les dates inconnues ni les évaluations.',
 {'fiche_id':ID,'limite':entier(1,20),'decalage':entier(0,1000000),'volet':choix('items','observations_fiche','observations_item'),'item_id':ID},['fiche_id'],
 {'fiche':objet(libre=True),'items':tableau(objet(libre=True),20),'observations':tableau(OBSERVATION,20),'total':entier(),'suite':BOOLEEN,'complet':BOOLEEN,'continuation':nullable(objet(libre=True)),'markdown':texte(400000),'etat':objet(libre=True)})
outil('bilan_fiches','Consulter le bilan synthétique des fiches',
 'Synthèse paginée des fiches et nombres d’items par état, sans stabilité de fiche. Approfondir avec etat_fiche ; total et continuation signalent les pages restantes.',
 {'limite':entier(1,50),'decalage':entier(0,1000000)},[],
 {'fiches':tableau(objet(libre=True),50),'total':entier(),'suite':BOOLEEN,'continuation':nullable(objet(libre=True))})
outil('tutoriel','Découvrir Vision ou approfondir une section',
 'Tutoriel partagé avec le site. Sans section : objectifs et index ; avec une section : explication, exemple fictif et activité. Accompagner la découverte, sans créer ni modifier de données personnelles. Sections : fiches-items, langues, planification, seances, actions.',
 {'section':choix('fiches-items','langues','planification','seances','actions')},[],
 {'version':entier(),'sections':tableau(objet(libre=True),5),'section':objet(libre=True),'usage_assistant':texte()})

def generer():
 from contenus import generer as generer_contenus
 generer_contenus()
 (RACINE/'docs/outils.json').write_text(json.dumps(OUTILS,ensure_ascii=False,indent=2)+'\n')
 chemins={}
 for outil in OUTILS:
  chemins['/api/v1/'+outil['name']]={'post':{'operationId':outil['name'],'summary':outil['title'],'description':outil['description'],'requestBody':{'required':True,'content':{'application/json':{'schema':outil['inputSchema']}}},'responses':{'200':{'description':'Résultat de l’opération ; vérifier erreur et enregistre.','content':{'application/json':{'schema':outil['outputSchema']}}},'400':{'description':'Paramètres ou règle métier invalides.'},'401':{'description':'Authentification Basic et identité interne requises.'},'409':{'description':'Version périmée ou clé réutilisée ; relire sans écraser.'},'503':{'description':'Base indisponible.'}}}}
 doc={'openapi':'3.1.0','info':{'title':'Vision — fiches et items','version':'2.6.0'},'servers':[{'url':'/'}],'security':[{'basicAuth':[]}],'paths':chemins,'components':{'securitySchemes':{'basicAuth':{'type':'http','scheme':'basic'}}}}
 (RACINE/'docs/openapi.json').write_text(json.dumps(doc,ensure_ascii=False,indent=2)+'\n')
if __name__=='__main__':generer()


