#!/usr/bin/env python3
"""Backfill progressif et relançable, compare-and-set sur le contenu exact.

Utilise le rôle applicatif et le fournisseur déjà configurés. Ne conserve aucune
donnée métier sur disque. Un échec laisse les lots précédents valides ; une
préparation est refusée tant qu'un item du compte n'est pas vectorisé.
"""
import argparse
import json
import os
import subprocess
import urllib.request


def sql(requete, **variables):
    commande = [os.environ.get('VISION_PSQL', 'psql'), '-XqAt', '-v', 'ON_ERROR_STOP=1']
    for nom, valeur in variables.items():
        commande += ['-v', nom + '=' + str(valeur)]
    resultat = subprocess.run(commande, input=requete, text=True, capture_output=True)
    if resultat.returncode:
        # PostgreSQL peut citer des valeurs métier : ne pas exposer stderr.
        raise RuntimeError('Échec PostgreSQL du backfill')
    return json.loads(resultat.stdout)


def embedding(contenu):
    url = os.environ.get('VISION_EMBEDDINGS_URL', 'http://127.0.0.1:39004/embedding')
    appel = urllib.request.Request(url, data=json.dumps({'contenu': contenu}).encode(),
                                   headers={'Content-Type': 'application/json'})
    with urllib.request.urlopen(appel, timeout=30) as reponse:
        return json.load(reponse)


def backfill(limite):
    modele = embedding('Initialisation du fournisseur')['modele']
    objets = sql("""SELECT coalesce(json_agg(x),'[]') FROM (
        SELECT i.utilisateur,i.id,i.contenu FROM vision_items i WHERE NOT EXISTS(
          SELECT 1 FROM vision_embeddings e WHERE e.utilisateur=i.utilisateur AND e.item_id=i.id
            AND e.modele=:'modele' AND e.contenu_sha256=vision_hash_contenu(i.contenu))
        ORDER BY i.utilisateur,i.id LIMIT :'limite'::integer) x;""", modele=modele, limite=limite)
    total = 0
    for objet in objets:
        v = embedding(objet['contenu'])
        if v['modele'] != modele:
            raise RuntimeError('Le modèle a changé pendant le backfill')
        total += sql("SELECT to_json(vision_stocker_embedding(:'utilisateur', :'id'::bigint, :'contenu', :'modele', :'v'::vector));",
                     utilisateur=objet['utilisateur'], id=objet['id'], contenu=objet['contenu'],
                     modele=modele, v=json.dumps(v['embedding']))
    return total


if __name__ == '__main__':
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument('--limite', type=int, default=100)
    args = cli.parse_args()
    if not 1 <= args.limite <= 1000:
        cli.error('limite entre 1 et 1000')
    print(json.dumps({'embeddings_calcules': backfill(args.limite)}))
