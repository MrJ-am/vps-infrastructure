"""Générer uniquement les vues du tutoriel partagé ; aucune donnée personnelle."""
import json
from pathlib import Path

RACINE = Path(__file__).resolve().parents[1]


def markdown(section):
    """Composer la même section pour Elm et les exports du MCP."""
    return '\n\n'.join(['## ' + section['titre'], '**Objectif :** ' + section['objectif'],
        section['explication'], section['exemple'], '**À essayer :** ' + section['activite'],
        *([section['complement']] if 'complement' in section else [])])


def generer():
    """Figer une représentation Elm des données communes lues par le serveur Lisp."""
    tutoriel = json.loads((RACINE / 'docs/tutoriel.json').read_text())
    sections = '\n\n'.join(markdown(s) for s in tutoriel['sections'])
    source = ('module Tutoriel exposing (contenu)\n\n'
        '-- Généré par scripts/contenus.py depuis docs/tutoriel.json.\n\n\n'
        'contenu : String\ncontenu =\n    ' + json.dumps(sections, ensure_ascii=False) + '\n')
    (RACINE / 'interface/src/Tutoriel.elm').write_text(source)


if __name__ == '__main__':
    generer()
