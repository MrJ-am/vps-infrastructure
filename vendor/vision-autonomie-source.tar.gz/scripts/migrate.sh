#!/bin/sh
set -eu
cd -- "$(dirname -- "$0")/.."
: "${PGHOST:=/run/postgresql}"
: "${PGDATABASE:=vision}"
: "${PGUSER:=vision}"
export PGHOST PGDATABASE PGUSER
# Un seul processus garde le verrou pendant toute la migration. Chaque fichier
# conserve sa transaction ; une migration enregistrée ne se rejoue plus au démarrage.
{
  printf '%s\n' 'SELECT pg_advisory_lock(718, 15);'
  printf '%s\n' "SELECT to_regclass('vision_schema_migrations') IS NOT NULL AS presente \\gset" '\if :presente' '\else' '\i migrations/001_initial.sql' '\endif'
  for migration in migrations/*.sql; do
    numero=${migration#migrations/}; numero=${numero%%_*}
    printf "SELECT EXISTS(SELECT 1 FROM vision_schema_migrations WHERE version=%s) AS appliquee \\gset\n" "$numero"
    printf '%s\n' '\if :appliquee' '\else'
    printf '\\i %s\n' "$migration"
    printf '%s\n' '\endif'
  done
} | psql --no-psqlrc --set=ON_ERROR_STOP=1
