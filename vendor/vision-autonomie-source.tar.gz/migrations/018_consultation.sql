BEGIN;
CREATE OR REPLACE FUNCTION vision_lien_fiche(u text,p jsonb) RETURNS jsonb LANGUAGE sql STABLE AS $$
 SELECT CASE WHEN EXISTS(SELECT 1 FROM vision_fiches WHERE utilisateur=u AND id=(p->>'fiche_id')::bigint)
   THEN jsonb_build_object('fiche_id',(p->>'fiche_id')::bigint,'prive',true)
   ELSE jsonb_build_object('erreur','introuvable') END
$$;

CREATE OR REPLACE FUNCTION vision_resume_fiche(u text,f vision_fiches) RETURNS jsonb LANGUAGE sql STABLE AS $$
 SELECT jsonb_build_object('nombre_items',count(*),'non_evalues',count(*) FILTER(WHERE NOT i.evalue),
   'dates_inconnues',count(*) FILTER(WHERE i.evalue_a IS NULL),
   'references_inconnues',count(*) FILTER(WHERE i.reference_a IS NULL),
   'en_retard',count(*) FILTER(WHERE v.fenetre->>'etat'='fenetre_depassee'),
   'dans_fenetre',count(*) FILTER(WHERE v.fenetre->>'etat'='dans_fenetre'))
 FROM vision_liens l JOIN vision_items i ON i.utilisateur=l.utilisateur AND i.id=l.item_id
 LEFT JOIN vision_profils pr ON pr.utilisateur=u
 CROSS JOIN LATERAL (SELECT vision_fenetre(i.stabilite,f.priorite,
   coalesce(pr.intervalle_jours,90),coalesce(pr.decalage,0),i.reference_a) AS fenetre) v
 WHERE l.utilisateur=u AND l.fiche_id=f.id
$$;

CREATE OR REPLACE FUNCTION vision_etat_fiche(u text,p jsonb) RETURNS jsonb LANGUAGE plpgsql STABLE AS $$
DECLARE f vision_fiches; pr jsonb:=vision_politique(u); objets jsonb; observations jsonb;
  limite integer:=coalesce((p->>'limite')::integer,10); decalage integer:=coalesce((p->>'decalage')::integer,0);
  volet text:=coalesce(p->>'volet','items'); total integer; md text; x jsonb; suite boolean;
BEGIN
 SELECT * INTO f FROM vision_fiches WHERE utilisateur=u AND id=(p->>'fiche_id')::bigint;
 IF NOT FOUND THEN RETURN jsonb_build_object('erreur','introuvable'); END IF;
 IF limite NOT BETWEEN 1 AND 20 OR decalage<0 THEN PERFORM vision_refuser('pagination_invalide'); END IF;
 IF volet IN ('observations_item','observations_fiche') THEN
   IF volet='observations_item' AND NOT EXISTS(SELECT 1 FROM vision_liens WHERE utilisateur=u AND fiche_id=f.id AND item_id=(p->>'item_id')::bigint) THEN
     RETURN jsonb_build_object('erreur','introuvable');
   END IF;
   observations:=vision_observations_objet(u,CASE WHEN volet='observations_item' THEN 'item' ELSE 'fiche' END,
     CASE WHEN volet='observations_item' THEN (p->>'item_id')::bigint ELSE f.id END);
   total:=jsonb_array_length(observations);
   SELECT coalesce(jsonb_agg(value ORDER BY rang),'[]') INTO objets
     FROM (SELECT value,rang FROM jsonb_array_elements(observations) WITH ORDINALITY a(value,rang) ORDER BY rang LIMIT limite OFFSET decalage) a;
   RETURN jsonb_build_object('fiche_id',f.id,'volet',volet,'observations',objets,'total',total,
     'limite',limite,'decalage',decalage,'suite',decalage+limite<total,'complet',decalage=0 AND decalage+limite>=total,
     'continuation',CASE WHEN decalage+limite<total THEN p||jsonb_build_object('limite',limite,'decalage',decalage+limite) END);
 END IF;
 IF volet<>'items' THEN PERFORM vision_refuser('volet_invalide'); END IF;
 SELECT count(*) INTO total FROM vision_liens WHERE utilisateur=u AND fiche_id=f.id;
 SELECT coalesce(jsonb_agg(objet ORDER BY ordre,id),'[]') INTO objets FROM (
   SELECT i.id,l.ordre,vision_item_public(i)||jsonb_build_object('contexte',l.contexte,'ordre',l.ordre,
     'dernier_rappel_connu',i.evalue_a,'dernier_enregistrement',i.modifie_a,
     'nombre_observations',jsonb_array_length(vision_observations_objet(u,'item',i.id)),
     'fenetre',vision_fenetre(i.stabilite,f.priorite,(pr->>'intervalle_jours')::integer,(pr->>'decalage')::integer,i.reference_a),
     'etat_evaluation',CASE WHEN i.evalue THEN 'evalue' ELSE 'non_evalue' END) AS objet
   FROM vision_liens l JOIN vision_items i ON i.utilisateur=u AND i.id=l.item_id
   WHERE l.utilisateur=u AND l.fiche_id=f.id ORDER BY l.ordre,i.id LIMIT limite OFFSET decalage) a;
 suite:=decalage+limite<total;
 md:=CASE WHEN decalage=0 THEN '# '||f.titre||E'\n\n'||f.contenu||E'\n\n' ELSE '' END
   ||format(E'## Items — segment %s à %s sur %s\n\n',least(decalage+1,total),least(decalage+limite,total),total);
 FOR x IN SELECT value FROM jsonb_array_elements(objets) LOOP
   md:=md||format(E'### Item %s\n\n%s\n\n',x->>'id',x->>'contenu');
 END LOOP;
 md:=md||E'| Item | Stabilité S (dB) | Dernier rappel connu | Fenêtre et état |\n| --- | ---: | --- | --- |\n';
 FOR x IN SELECT value FROM jsonb_array_elements(objets) LOOP
   md:=md||format(E'| %s | %s | %s | %s ; %s → %s |\n',x->>'id',x->>'stabilite',
     coalesce(x->>'dernier_rappel_connu','inconnu'),x->>'etat_evaluation',
     coalesce(x#>>'{fenetre,debut}','inconnue'),coalesce(x#>>'{fenetre,fin}','inconnue'));
 END LOOP;
 md:=md||CASE WHEN suite THEN E'\nExport partiel : lire la continuation avant de présenter la fiche complète.'
   ELSE E'\nDernier segment. Les observations se consultent dans leurs volets paginés distincts.' END;
 RETURN jsonb_build_object('fiche',vision_fiche_publique(f),'items',objets,'etat',vision_resume_fiche(u,f),
   'volet','items','total',total,'limite',limite,'decalage',decalage,'suite',suite,'complet',decalage=0 AND NOT suite,
   'continuation',CASE WHEN suite THEN p||jsonb_build_object('limite',limite,'decalage',decalage+limite) END,
   'nombre_observations_fiche',jsonb_array_length(vision_observations_objet(u,'fiche',f.id)),
   'markdown',md,'politique',pr,'maintenant',now());
END $$;

CREATE OR REPLACE FUNCTION vision_bilan_fiches(u text,p jsonb) RETURNS jsonb LANGUAGE plpgsql STABLE AS $$
DECLARE limite integer:=coalesce((p->>'limite')::integer,20); decalage integer:=coalesce((p->>'decalage')::integer,0);
  total integer; fiches jsonb;
BEGIN
 SELECT count(*) INTO total FROM vision_fiches WHERE utilisateur=u;
 SELECT coalesce(jsonb_agg(objet ORDER BY titre,id),'[]') INTO fiches FROM (
   SELECT f.id,f.titre,jsonb_build_object('fiche_id',f.id,'titre',f.titre,'priorite',f.priorite,
     'archive_a',f.archive_a,'etat',vision_resume_fiche(u,f)) AS objet
   FROM vision_fiches f WHERE utilisateur=u ORDER BY f.titre,f.id LIMIT limite OFFSET decalage) a;
 RETURN jsonb_build_object('fiches',fiches,'total',total,'decalage',decalage,'limite',limite,
   'suite',decalage+limite<total,'continuation',CASE WHEN decalage+limite<total THEN jsonb_build_object('limite',limite,'decalage',decalage+limite) END,
   'politique',vision_politique(u),'maintenant',now());
END $$;

INSERT INTO vision_schema_migrations(version) VALUES(18) ON CONFLICT DO NOTHING;
COMMIT;
