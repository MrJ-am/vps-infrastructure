BEGIN;

ALTER TABLE vision_profils ADD COLUMN IF NOT EXISTS questions_typiques smallint NOT NULL DEFAULT 8
  CHECK (questions_typiques BETWEEN 1 AND 20);
CREATE OR REPLACE FUNCTION vision_politique(u text) RETURNS jsonb LANGUAGE sql STABLE AS $$
  SELECT coalesce((SELECT to_jsonb(p)-'utilisateur'-'catalogue' FROM vision_profils p WHERE utilisateur=u),
    jsonb_build_object('intervalle_jours',90,'budget',null,'decalage',0,
      'questions_typiques',8,'version',1))
$$;

-- Historique pédagogique permanent : la date du fait et la date de saisie
-- sont distinctes. Une date historique inconnue reste NULL.
CREATE TABLE IF NOT EXISTS vision_observations (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  utilisateur text NOT NULL REFERENCES vision_profils,
  item_id bigint,
  fiche_id bigint,
  texte text NOT NULL CHECK (char_length(texte) <= 4000),
  source text NOT NULL CHECK (source IN ('explicite','seance','suivi_anterieur','evaluation_historique')),
  details jsonb NOT NULL DEFAULT '{}'::jsonb CHECK (jsonb_typeof(details)='object'),
  evenement_a timestamptz,
  enregistre_a timestamptz NOT NULL DEFAULT now(),
  rectifie_id bigint REFERENCES vision_observations(id),
  CHECK ((item_id IS NULL) <> (fiche_id IS NULL)),
  CHECK (texte <> '' OR source IN ('seance','evaluation_historique')),
  FOREIGN KEY (utilisateur,item_id) REFERENCES vision_items(utilisateur,id),
  FOREIGN KEY (utilisateur,fiche_id) REFERENCES vision_fiches(utilisateur,id)
);
CREATE INDEX IF NOT EXISTS vision_observations_item
  ON vision_observations(utilisateur,item_id,enregistre_a,id) WHERE item_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS vision_observations_fiche
  ON vision_observations(utilisateur,fiche_id,enregistre_a,id) WHERE fiche_id IS NOT NULL;

CREATE OR REPLACE FUNCTION vision_observation_immuable() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE precedente vision_observations;
BEGIN
  IF TG_OP <> 'INSERT' THEN RAISE EXCEPTION 'observation_immuable'; END IF;
  IF NEW.rectifie_id IS NOT NULL THEN
    SELECT * INTO precedente FROM vision_observations WHERE id=NEW.rectifie_id;
    IF precedente.id IS NULL OR precedente.utilisateur<>NEW.utilisateur
      OR precedente.item_id IS DISTINCT FROM NEW.item_id
      OR precedente.fiche_id IS DISTINCT FROM NEW.fiche_id THEN
      RAISE EXCEPTION 'rectification_invalide';
    END IF;
  END IF;
  IF NEW.evenement_a>now()+interval '5 minutes' THEN RAISE EXCEPTION 'date_future'; END IF;
  RETURN NEW;
END $$;
DROP TRIGGER IF EXISTS vision_observation_immuable ON vision_observations;
CREATE TRIGGER vision_observation_immuable BEFORE INSERT OR UPDATE OR DELETE
  ON vision_observations FOR EACH ROW EXECUTE FUNCTION vision_observation_immuable();

-- Reprendre les changements de suivi effectivement datés dans le journal v2.
-- Les observations 1.x restent dans leur table source ; leurs liens attribués
-- lors de l'import v2 permettent aussi de les lire sur les nouveaux items.
INSERT INTO vision_observations(utilisateur,item_id,texte,source,details,evenement_a)
SELECT j.utilisateur,j.objet_id,o.note,'evaluation_historique',
  jsonb_build_object('legacy_observation_id',o.id,'issue',o.outcome,'contexte',o.context),
  o.reviewed_at
FROM vision_journal j
CROSS JOIN LATERAL jsonb_array_elements_text(
  CASE WHEN jsonb_typeof(j.apres->'observations_source')='array'
    THEN j.apres->'observations_source' ELSE '[]'::jsonb END) identifiant
JOIN vision_memory_observations o ON o.id=identifiant::bigint
WHERE j.objet='item' AND j.operation='migration'
  AND NOT EXISTS (SELECT 1 FROM vision_observations v
    WHERE v.utilisateur=j.utilisateur AND v.item_id=j.objet_id
      AND v.details->>'legacy_observation_id'=o.id::text
      AND NOT v.details ? 'legacy_correction_id');

INSERT INTO vision_observations(utilisateur,item_id,texte,source,details,
  evenement_a,rectifie_id)
SELECT v.utilisateur,v.item_id,c.note,'evaluation_historique',
  jsonb_build_object('legacy_observation_id',c.observation_id,
    'legacy_correction_id',c.id,'contexte',c.context,'auteur',c.author),
  c.created_at,v.id
FROM vision_observation_corrections c JOIN vision_observations v
  ON v.details->>'legacy_observation_id'=c.observation_id::text
  AND NOT v.details ? 'legacy_correction_id'
WHERE NOT EXISTS (SELECT 1 FROM vision_observations suivante
  WHERE suivante.utilisateur=v.utilisateur AND suivante.item_id=v.item_id
    AND suivante.details->>'legacy_correction_id'=c.id::text);

INSERT INTO vision_observations(utilisateur,item_id,texte,source,evenement_a)
SELECT j.utilisateur,j.objet_id,j.apres->>'suivi','evaluation_historique',
  j.evenement_a
FROM vision_journal j JOIN vision_items i ON i.utilisateur=j.utilisateur AND i.id=j.objet_id
WHERE j.objet='item' AND j.operation='evaluer'
  AND coalesce(j.apres->>'suivi','')<>'' AND j.apres->>'suivi' IS DISTINCT FROM j.avant->>'suivi'
  AND NOT EXISTS (SELECT 1 FROM vision_observations o WHERE o.utilisateur=j.utilisateur
    AND o.item_id=j.objet_id AND o.source='evaluation_historique'
    AND o.evenement_a IS NOT DISTINCT FROM j.evenement_a
    AND o.texte=j.apres->>'suivi')
  AND NOT EXISTS (SELECT 1 FROM vision_schema_migrations WHERE version=13);

-- Un suivi existant sans source chronologique reste consultable, avec date du fait inconnue.
INSERT INTO vision_observations(utilisateur,item_id,texte,source)
SELECT i.utilisateur,i.id,i.suivi,'suivi_anterieur' FROM vision_items i
WHERE i.suivi<>'' AND NOT EXISTS
  (SELECT 1 FROM vision_observations o WHERE o.utilisateur=i.utilisateur
    AND o.item_id=i.id AND o.texte=i.suivi);
INSERT INTO vision_observations(utilisateur,fiche_id,texte,source)
SELECT f.utilisateur,f.id,f.suivi,'suivi_anterieur' FROM vision_fiches f
WHERE f.suivi<>'' AND NOT EXISTS
  (SELECT 1 FROM vision_observations o WHERE o.utilisateur=f.utilisateur
    AND o.fiche_id=f.id AND o.texte=f.suivi);

CREATE OR REPLACE FUNCTION vision_observations_objet(u text,kind text,identifiant bigint)
RETURNS jsonb LANGUAGE sql STABLE AS $$
  SELECT coalesce(jsonb_agg(jsonb_build_object('id',o.id,'texte',o.texte,
    'source',o.source,'details',o.details,'evenement_a',o.evenement_a,
    'enregistre_a',o.enregistre_a,'rectifie_id',o.rectifie_id)
    ORDER BY o.enregistre_a,o.id),'[]'::jsonb)
  FROM (
    SELECT v.*,row_number() OVER (
      PARTITION BY v.utilisateur,v.item_id,v.fiche_id,v.texte,v.source,v.evenement_a,v.details
      ORDER BY v.id) AS occurrence
    FROM vision_observations v WHERE v.utilisateur=u
      AND ((kind='item' AND v.item_id=identifiant) OR (kind='fiche' AND v.fiche_id=identifiant))
  ) o
  WHERE o.source<>'evaluation_historique' OR o.details<>'{}'::jsonb OR o.occurrence=1
$$;

CREATE OR REPLACE FUNCTION vision_ajouter_observation(u text,p jsonb)
RETURNS jsonb LANGUAGE plpgsql AS $$
DECLARE o vision_observations; kind text:=p->>'objet'; identifiant bigint:=(p->>'objet_id')::bigint;
BEGIN
  IF kind='item' THEN
    IF NOT EXISTS (SELECT 1 FROM vision_items WHERE utilisateur=u AND id=identifiant) THEN
      PERFORM vision_refuser('introuvable'); END IF;
  ELSIF kind='fiche' THEN
    IF NOT EXISTS (SELECT 1 FROM vision_fiches WHERE utilisateur=u AND id=identifiant) THEN
      PERFORM vision_refuser('introuvable'); END IF;
  ELSE PERFORM vision_refuser('objet_invalide'); END IF;
  INSERT INTO vision_observations(utilisateur,item_id,fiche_id,texte,source,evenement_a,rectifie_id)
    VALUES(u,CASE WHEN kind='item' THEN identifiant END,
      CASE WHEN kind='fiche' THEN identifiant END,p->>'texte','explicite',
      (p->>'evenement_a')::timestamptz,(p->>'rectifie_id')::bigint) RETURNING * INTO o;
  RETURN jsonb_build_object('enregistre',true,'observation',to_jsonb(o)-'utilisateur');
END $$;

-- Les identifiants, états mémoriels et séances restent intacts. La formulation
-- éditoriale des items existants devient autonome, dans les deux collections connues.
WITH capitales AS (
  SELECT i.utilisateur,i.id,split_part(i.titre,' — ',1) AS pays,
    split_part(i.titre,' — ',2) AS ville
  FROM vision_items i JOIN vision_liens l ON l.utilisateur=i.utilisateur AND l.item_id=i.id
  JOIN vision_fiches f ON f.utilisateur=l.utilisateur AND f.id=l.fiche_id
  WHERE f.titre='Capitales européennes' AND i.titre LIKE '% — %'
    AND NOT EXISTS (SELECT 1 FROM vision_schema_migrations WHERE version=13)
), formulations AS (
  SELECT c.*,CASE
    WHEN c.pays IN ('Albanie','Allemagne','Arménie','Autriche','Azerbaïdjan',
      'Espagne','Estonie','Irlande','Islande','Italie','Ukraine') THEN 'de l'''
    WHEN c.pays='Andorre' THEN 'd'''
    WHEN c.pays IN ('Malte','Chypre','Monaco','Saint-Marin') THEN 'de '
    WHEN c.pays='Pays-Bas' THEN 'des '
    WHEN c.pays IN ('France','Géorgie','Grèce','Hongrie','Lettonie','Lituanie',
      'Moldavie','Norvège','Pologne','Roumanie','Russie','Serbie','Slovaquie',
      'Slovénie','Suède','Suisse','Finlande','Croatie','Biélorussie',
      'Bulgarie','Macédoine du Nord','République tchèque') THEN 'de la '
    ELSE 'du ' END AS preposition
  FROM capitales c
) UPDATE vision_items i SET
  titre='Capitale ('||c.pays||') : '||c.ville,
  contenu=c.ville||' est la capitale '||c.preposition||c.pays||'.',
  version=i.version+1,modifie_a=now()
FROM formulations c WHERE i.utilisateur=c.utilisateur AND i.id=c.id
  AND (i.titre,i.contenu) IS DISTINCT FROM
    ('Capitale ('||c.pays||') : '||c.ville,
     c.ville||' est la capitale '||c.preposition||c.pays||'.');

UPDATE vision_items i SET
  titre='TSD — '||i.titre,
  contenu='Dans la théorie des situations didactiques de Guy Brousseau, le terme « '||
    i.titre||' » désigne : '||i.contenu,
  version=i.version+1,modifie_a=now()
FROM vision_liens l JOIN vision_fiches f ON f.utilisateur=l.utilisateur AND f.id=l.fiche_id
WHERE l.utilisateur=i.utilisateur AND l.item_id=i.id
  AND f.titre='TSD — Théorie des situations didactiques'
  AND i.titre NOT LIKE 'TSD — %'
  AND NOT EXISTS (SELECT 1 FROM vision_schema_migrations WHERE version=13);
UPDATE vision_profils p SET catalogue=catalogue+1
WHERE NOT EXISTS (SELECT 1 FROM vision_schema_migrations WHERE version=13)
  AND EXISTS(SELECT 1 FROM vision_items i WHERE i.utilisateur=p.utilisateur
  AND i.modifie_a>=transaction_timestamp()-interval '1 second');

-- L'ancien suivi reste une synthèse éditable ; la chronique ne se supprime jamais.
DO $$
BEGIN
  IF to_regprocedure('vision_lire_v2(text,jsonb)') IS NULL THEN
    ALTER FUNCTION vision_lire(text,jsonb) RENAME TO vision_lire_v2;
  END IF;
END $$;
CREATE OR REPLACE FUNCTION vision_lire(u text,p jsonb) RETURNS jsonb LANGUAGE plpgsql AS $$
DECLARE resultat jsonb; enrichis jsonb;
BEGIN
  resultat:=vision_lire_v2(u,p);
  SELECT coalesce(jsonb_agg(objet||jsonb_build_object('observations',
    vision_observations_objet(u,p->>'type',(objet->>'id')::bigint))),'[]'::jsonb)
    INTO enrichis FROM jsonb_array_elements(resultat->'objets') AS e(objet);
  RETURN jsonb_set(resultat,'{objets}',enrichis);
END $$;

DO $$
BEGIN
  IF to_regprocedure('vision_ouvrir_seance_v2(text,jsonb)') IS NULL THEN
    ALTER FUNCTION vision_ouvrir_seance(text,jsonb) RENAME TO vision_ouvrir_seance_v2;
    ALTER FUNCTION vision_lire_seance(text,jsonb) RENAME TO vision_lire_seance_v2;
    ALTER FUNCTION vision_clore_seance(text,jsonb) RENAME TO vision_clore_seance_v2;
  END IF;
END $$;

CREATE OR REPLACE FUNCTION vision_ouvrir_seance_v2(u text,p jsonb) RETURNS jsonb LANGUAGE plpgsql AS $$
DECLARE lot jsonb; total integer; attente jsonb; s vision_seances; f vision_fiches;
  limite integer:=coalesce((p->>'limite')::integer,8);
BEGIN
  SELECT * INTO f FROM vision_fiches WHERE utilisateur=u AND id=(p->>'fiche_id')::bigint AND archive_a IS NULL;
  IF NOT FOUND THEN PERFORM vision_refuser('introuvable'); END IF;
  attente:=vision_lister_seances(u,20,0);
  IF (attente->>'total')::integer>0 AND NOT coalesce((p->>'nouvelle_seance')::boolean,false) THEN
    RETURN jsonb_build_object('enregistre',false,'confirmation_requise',true,
      'seances_en_attente',attente->'seances','total_seances_ouvertes',attente->'total',
      'suite_seances_ouvertes',attente->'suite',
      'message','Des séances sont ouvertes. Demander : voulez-vous ouvrir une nouvelle séance ou obtenir des informations sur les séances ouvertes ? Pour la première réponse, rappeler ouvrir_seance avec nouvelle_seance=true ; pour la seconde, appeler lister_seances.');
  END IF;
  SELECT count(*) INTO total FROM vision_candidats(u,f.id) c
    WHERE c.urgence>=-1 OR c.fenetre->>'etat'='reference_inconnue'
      OR coalesce((p->>'hors_fenetre')::boolean,false);
  WITH candidats AS (
    SELECT c.item_id,c.fenetre,i.suivi,i.evalue
      FROM vision_candidats(u,f.id) c JOIN vision_items i ON i.id=c.item_id AND i.utilisateur=u
      WHERE c.urgence>=-1 OR c.fenetre->>'etat'='reference_inconnue'
        OR coalesce((p->>'hors_fenetre')::boolean,false)
      ORDER BY (i.evalue AND c.urgence>=-1) DESC,(i.suivi<>'') DESC,
        (NOT i.evalue) DESC,c.urgence DESC NULLS LAST,c.item_id
      LIMIT limite
  ) SELECT coalesce(jsonb_agg(vision_item_public(i)||jsonb_build_object('fenetre',c.fenetre)
      ORDER BY (c.evalue AND (c.fenetre->>'urgence')::numeric>=-1) DESC,
        (c.suivi<>'') DESC,(NOT c.evalue) DESC,c.item_id),'[]'::jsonb)
    INTO lot FROM candidats c JOIN vision_items i ON i.id=c.item_id AND i.utilisateur=u;
  IF jsonb_array_length(lot)=0 THEN
    RETURN jsonb_build_object('enregistre',false,'nombre_items_disponibles',0,'seances_en_attente',attente->'seances');
  END IF;
  INSERT INTO vision_seances(utilisateur,conversation,fiche_id,items)
    VALUES(u,p->>'conversation',f.id,lot) RETURNING * INTO s;
  RETURN jsonb_build_object('enregistre',true,'seance_id',s.id,'etat',s.etat,
    'conversation',s.conversation,'fiche_id',s.fiche_id,'cree_a',s.cree_a,
    'nombre_questions',jsonb_array_length(lot),'nombre_items_disponibles',total,
    'usage_assistant',jsonb_build_object('fiche',vision_fiche_publique(f),'items',lot),
    'seances_en_attente',attente->'seances','total_seances_ouvertes',attente->'total',
    'consigne','Annoncer une séance d’environ nombre_questions questions, demander si la personne est prête. Poser les questions une par une sans dévoiler les réponses des suivantes. Recueillir le retour final, puis appeler clore_seance une seule fois avec les évaluations et ce retour.');
END $$;


CREATE OR REPLACE FUNCTION vision_ouvrir_seance(u text,p jsonb) RETURNS jsonb LANGUAGE plpgsql AS $$
DECLARE resultat jsonb; fiche vision_fiches; dus integer; nouveaux integer;
  typique integer; enrichi jsonb;
BEGIN
  SELECT coalesce((p->>'limite')::integer,questions_typiques) INTO typique
    FROM vision_profils WHERE utilisateur=u;
  typique:=coalesce(typique,(p->>'limite')::integer,8);
  SELECT * INTO fiche FROM vision_fiches WHERE utilisateur=u AND id=(p->>'fiche_id')::bigint AND archive_a IS NULL;
  IF NOT FOUND THEN PERFORM vision_refuser('introuvable'); END IF;
  -- Le choix des séances ouvertes précède le choix du nombre : ne jamais en clore une.
  IF (vision_lister_seances(u,1,0)->>'total')::integer>0
     AND NOT coalesce((p->>'nouvelle_seance')::boolean,false) THEN
    RETURN vision_ouvrir_seance_v2(u,p);
  END IF;
  SELECT count(*) FILTER (WHERE i.evalue),count(*) FILTER (WHERE NOT i.evalue)
    INTO dus,nouveaux
  FROM vision_candidats(u,fiche.id) c JOIN vision_items i ON i.utilisateur=u AND i.id=c.item_id
  WHERE c.urgence>=-1 OR c.fenetre->>'etat'='reference_inconnue';
  IF dus=0 AND nouveaux=0 AND NOT coalesce((p->>'hors_fenetre')::boolean,false) THEN
    RETURN jsonb_build_object('enregistre',false,'hors_fenetre_possible',true,
      'nombre_items_a_reviser',0,'nombre_items_non_evalues',0,
      'message','Aucun item de cette fiche n’est actuellement dans la fenêtre. Souhaitez-vous réviser quand même hors fenêtre ?');
  END IF;
  IF dus>typique AND NOT p ? 'nombre_questions' THEN
    RETURN jsonb_build_object('enregistre',false,'choix_nombre_requis',true,
      'nombre_items_a_reviser',dus,'nombre_items_non_evalues',nouveaux,
      'total_seances_ouvertes',vision_lister_seances(u,1,0)->'total',
      'message',format('%s items de cette fiche sont dans la plage de révision. Combien souhaitez-vous en réviser aujourd’hui (1 à 20) ?',dus));
  END IF;
  resultat:=vision_ouvrir_seance_v2(u,p||jsonb_build_object('limite',
    coalesce((p->>'nombre_questions')::integer,typique)));
  IF coalesce((resultat->>'enregistre')::boolean,false) THEN
    SELECT coalesce(jsonb_agg(x||jsonb_build_object('observations',
      vision_observations_objet(u,'item',(x->>'id')::bigint)) ORDER BY rang),'[]'::jsonb)
      INTO enrichi
    FROM jsonb_array_elements(resultat#>'{usage_assistant,items}') WITH ORDINALITY a(x,rang);
    -- Le lot et son contexte sont persistés pour être retrouvés après une interruption.
    UPDATE vision_seances SET items=enrichi WHERE utilisateur=u AND id=(resultat->>'seance_id')::uuid;
    resultat:=jsonb_set(resultat,'{usage_assistant,items}',enrichi);
    resultat:=jsonb_set(resultat,'{usage_assistant,fiche}',
      (resultat#>'{usage_assistant,fiche}')||jsonb_build_object('observations',
        vision_observations_objet(u,'fiche',fiche.id)));
    resultat:=resultat||jsonb_build_object('nombre_items_a_reviser',dus,
      'nombre_items_non_evalues',nouveaux,
      'consigne','Lire toute la fiche, chaque item et son historique. Préparer des questions difficiles mais faisables ; varier les sens et les formulations selon les erreurs et les questions antérieures. Une seule question à la fois, sans révéler la réponse avant tentative. Adapter les indices à la réponse, puis recueillir le retour et clore la séance.');
  ELSE
    resultat:=resultat||jsonb_build_object('nombre_items_a_reviser',dus,
      'nombre_items_non_evalues',nouveaux);
  END IF;
  RETURN resultat;
END $$;

CREATE OR REPLACE FUNCTION vision_lire_seance(u text,p jsonb) RETURNS jsonb LANGUAGE plpgsql STABLE AS $$
DECLARE resultat jsonb; enrichis jsonb; fiche_id bigint;
BEGIN
  resultat:=vision_lire_seance_v2(u,p);
  IF resultat ? 'erreur' THEN RETURN resultat; END IF;
  fiche_id:=(resultat#>>'{seance,fiche_id}')::bigint;
  -- Une séance antérieure à la migration peut contenir l'ancienne formulation.
  SELECT coalesce(jsonb_agg(vision_item_public(i)||jsonb_build_object(
    'fenetre',element->'fenetre','observations',vision_observations_objet(u,'item',i.id))
    ORDER BY rang),'[]'::jsonb) INTO enrichis
  FROM jsonb_array_elements(resultat#>'{usage_assistant,items}') WITH ORDINALITY a(element,rang)
  JOIN vision_items i ON i.utilisateur=u AND i.id=(element->>'id')::bigint;
  resultat:=jsonb_set(resultat,'{usage_assistant,items}',enrichis);
  resultat:=jsonb_set(resultat,'{usage_assistant,fiche}',
    (resultat#>'{usage_assistant,fiche}')||jsonb_build_object('observations',
      vision_observations_objet(u,'fiche',fiche_id)));
  RETURN resultat;
END $$;

CREATE OR REPLACE FUNCTION vision_clore_seance(u text,p jsonb) RETURNS jsonb LANGUAGE plpgsql AS $$
DECLARE resultat jsonb; ligne jsonb; identifiant bigint;
BEGIN
  resultat:=vision_clore_seance_v2(u,p);
  IF NOT coalesce((resultat->>'enregistre')::boolean,false) THEN RETURN resultat; END IF;
  FOR ligne IN SELECT value FROM jsonb_array_elements(p->'deroulement') LOOP
    identifiant:=(ligne->>'item_id')::bigint;
    INSERT INTO vision_observations(utilisateur,item_id,texte,source,details,evenement_a)
      VALUES(u,identifiant,coalesce(ligne->>'observation',''),'seance',
        (ligne-'observation')||jsonb_build_object('seance_id',p->>'seance_id',
          'evaluation',(SELECT e.value FROM jsonb_array_elements(p->'evaluations') e
            WHERE e.value->>'item_id'=ligne->>'item_id' LIMIT 1)),
        (ligne->>'posee_a')::timestamptz);
  END LOOP;
  IF coalesce(btrim(p->>'observation_fiche'),'')<>'' THEN
    INSERT INTO vision_observations(utilisateur,fiche_id,texte,source,details)
      VALUES(u,(resultat#>>'{rapport,fiche_id}')::bigint,p->>'observation_fiche',
        'seance',jsonb_build_object('seance_id',p->>'seance_id'));
  END IF;
  RETURN resultat;
END $$;

DO $$
BEGIN
  IF to_regprocedure('vision_preparer_v2(text,jsonb)') IS NULL THEN
    ALTER FUNCTION vision_preparer(text,jsonb) RENAME TO vision_preparer_v2;
  END IF;
END $$;
CREATE OR REPLACE FUNCTION vision_preparer(u text,p jsonb) RETURNS jsonb LANGUAGE plpgsql AS $$
DECLARE resultat jsonb; suggestions jsonb; limite integer:=coalesce((p->>'limite')::integer,8);
BEGIN
  resultat:=vision_preparer_v2(u,p);
  IF resultat ? 'erreur' THEN RETURN resultat; END IF;
  WITH candidats AS (
    SELECT f.id AS fiche_id,f.titre,i.id AS item_id,i.evalue,
      (v.fenetre->>'urgence')::numeric AS urgence,v.fenetre->>'etat' AS etat
    FROM vision_liens l JOIN vision_fiches f ON f.id=l.fiche_id AND f.utilisateur=l.utilisateur
      JOIN vision_items i ON i.id=l.item_id AND i.utilisateur=l.utilisateur
      LEFT JOIN vision_profils pr ON pr.utilisateur=u
      CROSS JOIN LATERAL (SELECT vision_fenetre(i.stabilite,f.priorite,
        coalesce(pr.intervalle_jours,90),coalesce(pr.decalage,0),i.reference_a) AS fenetre) v
    WHERE l.utilisateur=u AND f.archive_a IS NULL AND i.archive_a IS NULL
  ), retenus AS (
    SELECT *,row_number() OVER (PARTITION BY fiche_id ORDER BY evalue DESC,
      urgence DESC NULLS LAST,item_id) AS rang
    FROM candidats WHERE (evalue AND (urgence>=-1 OR etat='reference_inconnue')) OR NOT evalue
  ), groupes AS (
    SELECT fiche_id,min(titre) AS titre,
      count(*) FILTER (WHERE evalue) AS nombre_a_reviser,
      count(*) FILTER (WHERE NOT evalue) AS nombre_non_evalues,
      count(*) AS nombre_items,
      coalesce(avg(least(coalesce(urgence,-1),20)) FILTER (WHERE rang<=3 AND evalue),-1)
        + least(count(*) FILTER (WHERE evalue),5)*0.1 AS score
    FROM retenus GROUP BY fiche_id
  ) SELECT coalesce(jsonb_agg(to_jsonb(g) ORDER BY g.score DESC,g.fiche_id),'[]'::jsonb)
    INTO suggestions FROM (SELECT * FROM groupes ORDER BY score DESC,fiche_id LIMIT limite) g;
  RETURN jsonb_set(resultat,'{suggestions}',suggestions);
END $$;

CREATE OR REPLACE FUNCTION vision_evaluer(u text,p jsonb) RETURNS jsonb LANGUAGE plpgsql AS $$
DECLARE e jsonb; i vision_items; ancien vision_items; episode vision_episodes;
  q integer; delta integer; instant timestamptz; rapproche boolean; precedent integer; resultat jsonb:='[]';
  type_evenement text; sens text; aide text; total integer; distincts integer;
BEGIN
  SELECT count(*),count(DISTINCT x->>'item_id') INTO total,distincts FROM jsonb_array_elements(p->'evaluations') x;
  IF total<>distincts OR total NOT BETWEEN 1 AND 20 THEN PERFORM vision_refuser('items_distincts_requis'); END IF;
  FOR e IN SELECT value FROM jsonb_array_elements(p->'evaluations') LOOP
    SELECT * INTO i FROM vision_items WHERE utilisateur=u AND id=(e->>'item_id')::bigint FOR UPDATE;
    IF NOT FOUND THEN PERFORM vision_refuser('introuvable'); END IF;
    IF i.archive_a IS NOT NULL THEN PERFORM vision_refuser('objet_archive'); END IF;
    IF i.version IS DISTINCT FROM (e->>'version')::bigint THEN PERFORM vision_refuser('conflit'); END IF;
    ancien:=i;
    SELECT * INTO episode FROM vision_episodes WHERE utilisateur=u AND item_id=i.id AND cle=e->>'episode';
    IF coalesce(episode.version,0) IS DISTINCT FROM (e->>'version_episode')::bigint THEN PERFORM vision_refuser('conflit_episode'); END IF;
    IF episode.cle IS NOT NULL AND episode.enregistre_a<now()-interval '30 days' THEN PERFORM vision_refuser('episode_expire'); END IF;
    q:=(e->>'q')::integer;
    IF q IS NULL OR q NOT BETWEEN -20 AND 20 THEN PERFORM vision_refuser('ajustement_invalide'); END IF;
    IF abs(q)>5 AND char_length(coalesce(e->>'justification',''))<10 THEN PERFORM vision_refuser('ajustement_a_justifier'); END IF;
    type_evenement:=coalesce(e->>'type_evenement','rappel');
    instant:=CASE WHEN coalesce((e->>'date_inconnue')::boolean,false) THEN NULL
      WHEN e ? 'evenement_a' THEN (e->>'evenement_a')::timestamptz ELSE now() END;
    IF instant>now()+interval '5 minutes' OR instant<'1900-01-01'::timestamptz THEN PERFORM vision_refuser('date_invalide'); END IF;
    IF episode.cle IS NOT NULL THEN
      -- Une précision conserve la date de la tentative originale.
      IF e ? 'evenement_a' AND instant IS DISTINCT FROM episode.evenement_a THEN PERFORM vision_refuser('date_episode_immuable'); END IF;
      instant:=episode.evenement_a;
    END IF;
    sens:=coalesce(e->>'sens',''); aide:=coalesce(e->>'aide','aucune');
    IF NOT sens=ANY(i.sens) THEN PERFORM vision_refuser('sens_invalide'); END IF;
    IF aide NOT IN ('aucune','indice','correction') THEN PERFORM vision_refuser('aide_invalide'); END IF;
    IF type_evenement NOT IN ('rappel','apprentissage','suivi') THEN PERFORM vision_refuser('evenement_invalide'); END IF;
    IF type_evenement IN ('apprentissage','suivi') AND q<>0 THEN PERFORM vision_refuser('rappel_requis'); END IF;
    IF aide='correction' AND q>0 OR aide='indice' AND q>1 THEN PERFORM vision_refuser('gain_aide_excessif'); END IF;
    rapproche:=CASE WHEN episode.cle IS NOT NULL THEN episode.rapproche
      ELSE instant IS NULL OR i.reference_a IS NULL OR instant-i.reference_a<interval '1 day' END;
    delta:=q-coalesce(episode.q,0);
    IF rapproche AND q>1 THEN PERFORM vision_refuser('gain_rapproche_excessif'); END IF;
    IF rapproche AND delta>0 THEN
      SELECT coalesce(sum(greatest(a.q,0)),0) INTO precedent FROM vision_episodes a WHERE a.utilisateur=u
        AND a.item_id=i.id AND a.rapproche AND a.enregistre_a>now()-interval '1 day' AND a.cle<>e->>'episode';
      IF precedent+greatest(q,0)>1 THEN PERFORM vision_refuser('gain_rapproche_deja_applique'); END IF;
    END IF;
    IF i.stabilite+delta NOT BETWEEN -128 AND 127 THEN PERFORM vision_refuser('borne_stabilite'); END IF;
    -- Un ancien événement est daté honnêtement ; il ne remplace pas la référence récente.
    UPDATE vision_items SET stabilite=stabilite+delta,suivi=coalesce(e->>'suivi',suivi),
      reference_a=CASE WHEN type_evenement<>'suivi' AND instant IS NOT NULL THEN greatest(reference_a,instant) ELSE reference_a END,
      origine_reference=CASE WHEN type_evenement<>'suivi' AND instant IS NOT NULL AND (reference_a IS NULL OR instant>=reference_a)
        THEN type_evenement ELSE origine_reference END,
      evalue=evalue OR type_evenement='rappel',
      evalue_a=CASE WHEN type_evenement='rappel' AND instant IS NOT NULL THEN greatest(evalue_a,instant) ELSE evalue_a END,
      version=version+1,modifie_a=now() WHERE utilisateur=u AND id=i.id RETURNING * INTO i;
    INSERT INTO vision_episodes(utilisateur,item_id,cle,conversation,q,stabilite_avant,evenement_a,sens,aide,rapproche)
      VALUES(u,i.id,e->>'episode',p->>'conversation',q,ancien.stabilite,instant,sens,aide,rapproche)
      ON CONFLICT(utilisateur,item_id,cle) DO UPDATE SET q=excluded.q,version=vision_episodes.version+1,
        sens=excluded.sens,aide=excluded.aide RETURNING * INTO episode;
    INSERT INTO vision_journal(utilisateur,objet,objet_id,operation,episode,delta,avant,apres,evenement_a,justification)
      VALUES(u,'item',i.id,'evaluer',episode.cle,delta,
        jsonb_build_object('stabilite',ancien.stabilite,'suivi',ancien.suivi,'reference_a',ancien.reference_a),
        jsonb_build_object('stabilite',i.stabilite,'suivi',i.suivi,'reference_a',i.reference_a),instant,coalesce(e->>'justification',''));
    IF e ? 'suivi' AND coalesce(e->>'suivi','')<>'' AND ancien.suivi IS DISTINCT FROM e->>'suivi' THEN
      INSERT INTO vision_observations(utilisateur,item_id,texte,source,evenement_a)
        VALUES(u,i.id,e->>'suivi','evaluation_historique',instant);
    END IF;
    resultat:=resultat||jsonb_build_array(jsonb_build_object('item',vision_item_public(i),'episode',episode.cle,
      'version_episode',episode.version,'q_cumulatif',q,'delta_applique',delta,
      'horodatage',CASE WHEN instant IS NULL THEN 'inconnu' WHEN e ? 'evenement_a' THEN 'fourni' ELSE 'echange_courant_serveur' END));
  END LOOP;
  RETURN jsonb_build_object('enregistre',true,'evaluations',resultat);
END $$;


CREATE OR REPLACE FUNCTION vision_commande(u text,op text,p jsonb) RETURNS jsonb LANGUAGE plpgsql AS $$
DECLARE empreinte text:=encode(sha256(convert_to(op||p::text,'UTF8')),'hex'); deja vision_requetes; resultat jsonb; pr vision_profils;
BEGIN
  IF u IS NULL OR u='' THEN RETURN jsonb_build_object('erreur','identite_requise'); END IF;
  IF p->>'emise_a' IS NULL OR (p->>'emise_a')::timestamptz<now()-interval '30 days'
    OR (p->>'emise_a')::timestamptz>now()+interval '5 minutes' THEN RETURN jsonb_build_object('erreur','requete_expiree'); END IF;
  IF char_length(coalesce(p->>'cle','')) NOT BETWEEN 8 AND 100 THEN RETURN jsonb_build_object('erreur','cle_requise'); END IF;
  PERFORM pg_advisory_xact_lock(hashtextextended(u,718));
  INSERT INTO vision_profils(utilisateur) VALUES(u) ON CONFLICT DO NOTHING;
  SELECT * INTO deja FROM vision_requetes WHERE utilisateur=u AND cle=p->>'cle';
  IF FOUND THEN
    IF deja.empreinte<>empreinte THEN RETURN jsonb_build_object('erreur','cle_reutilisee'); END IF;
    RETURN deja.resultat||jsonb_build_object('rejeu',true);
  END IF;
  BEGIN
    CASE op
      WHEN 'ajouter_observation' THEN resultat:=vision_ajouter_observation(u,p);
      WHEN 'enregistrer_fiche' THEN resultat:=vision_ecrire_fiche(u,p);
      WHEN 'enregistrer_item' THEN resultat:=vision_ecrire_item(u,p);
      WHEN 'lier_item' THEN resultat:=vision_lier(u,p);
      WHEN 'evaluer_items' THEN resultat:=vision_evaluer(u,p);
      WHEN 'enregistrer_contexte' THEN resultat:=vision_ecrire_contexte(u,p);
      WHEN 'regler_politique' THEN
        SELECT * INTO pr FROM vision_profils WHERE utilisateur=u;
        IF pr.version IS DISTINCT FROM (p->>'version')::bigint THEN PERFORM vision_refuser('conflit'); END IF;
        UPDATE vision_profils SET intervalle_jours=(p->>'intervalle_jours')::integer,budget=(p->>'budget')::integer,
          questions_typiques=coalesce((p->>'questions_typiques')::integer,questions_typiques),
          version=version+1 WHERE utilisateur=u;
        resultat:=jsonb_build_object('enregistre',true);
      WHEN 'ouvrir_seance' THEN resultat:=vision_ouvrir_seance(u,p);
      WHEN 'clore_seance' THEN resultat:=vision_clore_seance(u,p);
      ELSE PERFORM vision_refuser('operation_inconnue');
    END CASE;
    PERFORM vision_ajuster_charge(u);
    resultat:=resultat||jsonb_build_object('politique',vision_politique(u),'maintenant',now());
    INSERT INTO vision_requetes(utilisateur,cle,empreinte,resultat) VALUES(u,p->>'cle',empreinte,resultat);
    DELETE FROM vision_requetes WHERE utilisateur=u AND enregistre_a<now()-interval '35 days';
    DELETE FROM vision_episodes WHERE utilisateur=u AND enregistre_a<now()-interval '90 days';
    DELETE FROM vision_journal WHERE utilisateur=u AND (enregistre_a<now()-interval '180 days' OR id IN
      (SELECT id FROM vision_journal WHERE utilisateur=u ORDER BY id DESC OFFSET 5000));
    DELETE FROM vision_contextes WHERE utilisateur=u AND (modifie_a<now()-interval '90 days' OR conversation IN
      (SELECT conversation FROM vision_contextes WHERE utilisateur=u ORDER BY modifie_a DESC OFFSET 50));
    RETURN resultat;
  EXCEPTION WHEN raise_exception THEN RETURN jsonb_build_object('erreur',SQLERRM);
    WHEN integrity_constraint_violation OR data_exception THEN RETURN jsonb_build_object('erreur','donnees_invalides');
  END;
END $$;


INSERT INTO vision_schema_migrations(version) VALUES(13) ON CONFLICT DO NOTHING;
COMMIT;
