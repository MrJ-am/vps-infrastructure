BEGIN;

-- Conserver les anciennes colonnes pour les journaux et les séances ouvertes ;
-- elles ne constituent plus le contrat d'un item. Les observations restent intactes.
UPDATE vision_items SET titre=left(contenu,200),modifie_a=now()
WHERE titre IS DISTINCT FROM left(contenu,200);

CREATE OR REPLACE FUNCTION vision_item_public(i vision_items) RETURNS jsonb
LANGUAGE sql STABLE AS $$
  SELECT to_jsonb(i)-'utilisateur'-'recherche'-'texte_recherche'
    -'titre'-'objectifs'-'sens'-'suivi'
$$;

DO $$ BEGIN
  IF to_regprocedure('vision_ecrire_item_ancien(text,jsonb)') IS NULL THEN
    ALTER FUNCTION vision_ecrire_item(text,jsonb) RENAME TO vision_ecrire_item_ancien;
  END IF;
END $$;
CREATE OR REPLACE FUNCTION vision_ecrire_item(u text,p jsonb) RETURNS jsonb LANGUAGE plpgsql AS $$
DECLARE contenu text; enrichi jsonb;
BEGIN
  contenu:=p->>'contenu';
  IF NOT p ? 'id' AND coalesce(btrim(contenu),'')='' THEN
    PERFORM vision_refuser('contenu_requis');
  END IF;
  enrichi:=p;
  IF p ? 'contenu' THEN enrichi:=enrichi||jsonb_build_object('titre',left(contenu,200)); END IF;
  IF NOT p ? 'id' THEN
    enrichi:=enrichi||jsonb_build_object('objectifs',jsonb_build_array('Connaissance autonome'),
      'sens',jsonb_build_array('direct','inverse'));
  END IF;
  RETURN vision_ecrire_item_ancien(u,enrichi);
END $$;

CREATE OR REPLACE FUNCTION vision_ouvrir_seance_v2(u text,p jsonb) RETURNS jsonb LANGUAGE plpgsql AS $$
DECLARE lot jsonb; total integer; attente jsonb; s vision_seances; f vision_fiches;
  limite integer:=coalesce((p->>'limite')::integer,8);
BEGIN
  SELECT * INTO f FROM vision_fiches WHERE utilisateur=u AND id=(p->>'fiche_id')::bigint AND archive_a IS NULL;
  IF NOT FOUND THEN PERFORM vision_refuser('introuvable'); END IF;
  attente:=vision_lister_seances(u,20,0);
  IF (attente->>'total')::integer>0 AND NOT coalesce((p->>'nouvelle_seance')::boolean,false) THEN
    RETURN jsonb_build_object('enregistre',false,'confirmation_requise',true,
      'seances_en_attente',attente->'seances','total_seances_ouvertes',attente->'total',
      'suite_seances_ouvertes',attente->'suite',
      'message','Des séances sont ouvertes. Demander : voulez-vous ouvrir une nouvelle séance ou obtenir des informations sur les séances ouvertes ? Pour la première réponse, rappeler ouvrir_seance avec nouvelle_seance=true ; pour la seconde, appeler lister_seances.');
  END IF;
  SELECT count(*) INTO total FROM vision_candidats(u,f.id) c
    WHERE c.urgence>=-1 OR c.fenetre->>'etat'='reference_inconnue'
      OR coalesce((p->>'hors_fenetre')::boolean,false);
  WITH candidats AS (
    SELECT c.item_id,c.fenetre,i.evalue
      FROM vision_candidats(u,f.id) c JOIN vision_items i ON i.id=c.item_id AND i.utilisateur=u
      WHERE c.urgence>=-1 OR c.fenetre->>'etat'='reference_inconnue'
        OR coalesce((p->>'hors_fenetre')::boolean,false)
      ORDER BY CASE WHEN (c.fenetre->>'fin')::timestamptz<now() THEN 0 WHEN i.evalue THEN 1 ELSE 2 END,
        (c.fenetre->>'fin')::timestamptz ASC NULLS LAST,c.item_id
      LIMIT limite
  ) SELECT coalesce(jsonb_agg(vision_item_public(i)||jsonb_build_object('fenetre',c.fenetre)
      ORDER BY CASE WHEN (c.fenetre->>'fin')::timestamptz<now() THEN 0 WHEN c.evalue THEN 1 ELSE 2 END,
        (c.fenetre->>'fin')::timestamptz ASC NULLS LAST,c.item_id),'[]'::jsonb)
    INTO lot FROM candidats c JOIN vision_items i ON i.id=c.item_id AND i.utilisateur=u;
  IF jsonb_array_length(lot)=0 THEN
    RETURN jsonb_build_object('enregistre',false,'nombre_items_disponibles',0,'seances_en_attente',attente->'seances');
  END IF;
  INSERT INTO vision_seances(utilisateur,conversation,fiche_id,items)
    VALUES(u,p->>'conversation',f.id,lot) RETURNING * INTO s;
  RETURN jsonb_build_object('enregistre',true,'seance_id',s.id,'etat',s.etat,
    'conversation',s.conversation,'fiche_id',s.fiche_id,'cree_a',s.cree_a,
    'nombre_questions',jsonb_array_length(lot),'nombre_items_disponibles',total,
    'usage_assistant',jsonb_build_object(
      'fiche',coalesce((vision_lire(u,jsonb_build_object('type','fiche','ids',jsonb_build_array(f.id)))->'objets'->0)-'items',vision_fiche_publique(f)),
      'items',(SELECT coalesce(jsonb_agg(x.item||jsonb_build_object('observations',
        coalesce((SELECT o.value->'observations' FROM jsonb_array_elements(
          vision_lire(u,jsonb_build_object('type','item','ids',jsonb_build_array((x.item->>'id')::bigint)))->'objets') AS o(value) LIMIT 1),'[]'::jsonb)) ORDER BY x.rang),'[]'::jsonb)
        FROM jsonb_array_elements(lot) WITH ORDINALITY x(item,rang))),
    'seances_en_attente',attente->'seances','total_seances_ouvertes',attente->'total',
    'consigne','Annoncer une séance d’environ nombre_questions questions, demander si la personne est prête. Poser les questions une par une sans dévoiler les réponses des suivantes. Recueillir le retour final, puis appeler clore_seance une seule fois avec les évaluations et ce retour.');
END $$;

CREATE OR REPLACE FUNCTION vision_preparer(u text,p jsonb) RETURNS jsonb LANGUAGE plpgsql AS $$
DECLARE resultat jsonb; suggestions jsonb; limite integer:=coalesce((p->>'limite')::integer,8);
  retard integer;
BEGIN
  resultat:=vision_preparer_v2(u,p);
  IF resultat ? 'erreur' THEN RETURN resultat; END IF;
  WITH candidats AS (
    SELECT f.id AS fiche_id,f.titre,i.id AS item_id,i.evalue,
      (v.fenetre->>'urgence')::numeric AS urgence,v.fenetre->>'etat' AS etat,
      (v.fenetre->>'fin')::timestamptz AS fin
    FROM vision_liens l JOIN vision_fiches f ON f.id=l.fiche_id AND f.utilisateur=l.utilisateur
      JOIN vision_items i ON i.id=l.item_id AND i.utilisateur=l.utilisateur
      LEFT JOIN vision_profils pr ON pr.utilisateur=u
      CROSS JOIN LATERAL (SELECT vision_fenetre(i.stabilite,f.priorite,
        coalesce(pr.intervalle_jours,90),coalesce(pr.decalage,0),i.reference_a) AS fenetre) v
    WHERE l.utilisateur=u AND f.archive_a IS NULL AND i.archive_a IS NULL
  ), retenus AS (
    SELECT * FROM candidats
    WHERE (evalue AND (urgence>=-1 OR etat='reference_inconnue')) OR NOT evalue
  ), groupes AS (
    SELECT fiche_id,min(titre) AS titre,
      count(*) FILTER (WHERE evalue) AS nombre_a_reviser,
      count(*) FILTER (WHERE NOT evalue) AS nombre_non_evalues,
      count(*) FILTER (WHERE fin<now()) AS nombre_en_retard,
      count(*) FILTER (WHERE fin>=now() AND urgence>=-1) AS nombre_dans_fenetre,
      count(*) AS nombre_items,
      min(fin) FILTER (WHERE evalue OR fin<now()) AS premiere_fermeture
    FROM retenus GROUP BY fiche_id
  ) SELECT coalesce(jsonb_agg(to_jsonb(g) ORDER BY
      (g.nombre_en_retard>0) DESC,g.premiere_fermeture ASC NULLS LAST,g.fiche_id),'[]'::jsonb)
    INTO suggestions FROM (
      SELECT * FROM groupes ORDER BY (nombre_en_retard>0) DESC,
        premiere_fermeture ASC NULLS LAST,fiche_id LIMIT limite
    ) g;
  SELECT count(DISTINCT item_id) INTO retard FROM vision_candidats(u) c
    WHERE (c.fenetre->>'fin')::timestamptz<now();
  RETURN jsonb_set(jsonb_set(resultat,'{suggestions}',suggestions),
    '{total_en_retard}',to_jsonb(retard))
    ||jsonb_build_object('message_retard',CASE WHEN retard>0 THEN
      format('Vous avez %s révisions en retard. Peut-être souhaitez-vous commencer par revoir ces fiches ?',retard)
      ELSE '' END);
END $$;

DO $$ BEGIN
  IF to_regprocedure('vision_rechercher_ancien(text,jsonb)') IS NULL THEN
    ALTER FUNCTION vision_rechercher(text,jsonb) RENAME TO vision_rechercher_ancien;
    ALTER FUNCTION vision_lire(text,jsonb) RENAME TO vision_lire_ancien;
  END IF;
END $$;
CREATE OR REPLACE FUNCTION vision_rechercher(u text,p jsonb) RETURNS jsonb LANGUAGE plpgsql AS $$
DECLARE resultat jsonb; objets jsonb;
BEGIN
  resultat:=vision_rechercher_ancien(u,CASE WHEN p->>'type'='item' AND p->>'tri'='alphabetique'
    THEN jsonb_set(p,'{tri}','"titre"'::jsonb) ELSE p END);
  IF p->>'type'='item' THEN
    SELECT coalesce(jsonb_agg((x.objet-'titre')||jsonb_build_object('contenu',i.contenu)
      ORDER BY x.rang),'[]'::jsonb) INTO objets
    FROM jsonb_array_elements(resultat->'resultats') WITH ORDINALITY x(objet,rang)
    JOIN vision_items i ON i.id=(x.objet->>'id')::bigint AND i.utilisateur=u;
    resultat:=jsonb_set(resultat,'{resultats}',objets);
  END IF;
  RETURN resultat;
END $$;
CREATE OR REPLACE FUNCTION vision_liens_fiche(u text,fiche bigint,p jsonb) RETURNS jsonb
LANGUAGE plpgsql STABLE AS $$
DECLARE resultat jsonb; tri text:=coalesce(p->>'tri_liens','echeance');
  filtre text:=coalesce(p->>'filtre_liens','tous');
  limite integer:=coalesce((p->>'limite')::integer,50);
  decalage integer:=coalesce((p->>'decalage')::integer,0);
BEGIN
  IF tri NOT IN ('echeance','alphabetique','ordre','stabilite')
    OR filtre NOT IN ('tous','retard','dans_fenetre','nouveau','a_venir') THEN
    PERFORM vision_refuser('filtre_invalide');
  END IF;
  WITH candidats AS (
    SELECT i.id,i.contenu,i.version,i.stabilite,i.evalue,i.evalue_a,
      l.contexte,l.ordre,
      vision_fenetre(i.stabilite,f.priorite,coalesce(pr.intervalle_jours,90),
        coalesce(pr.decalage,0),i.reference_a) AS fenetre
    FROM vision_liens l JOIN vision_items i ON i.id=l.item_id AND i.utilisateur=l.utilisateur
      JOIN vision_fiches f ON f.id=l.fiche_id AND f.utilisateur=l.utilisateur
      LEFT JOIN vision_profils pr ON pr.utilisateur=u
    WHERE l.utilisateur=u AND l.fiche_id=fiche AND i.archive_a IS NULL
  ), classes AS (
    SELECT c.*,(c.fenetre->>'fin')::timestamptz AS fermeture,
      CASE WHEN (c.fenetre->>'fin')::timestamptz<now() THEN 'retard'
        WHEN (c.fenetre->>'debut')::timestamptz<=now()
          AND (c.fenetre->>'fin')::timestamptz>=now() THEN 'dans_fenetre'
        WHEN NOT c.evalue THEN 'nouveau'
        ELSE 'a_venir' END AS statut
    FROM candidats c
  ), retenus AS (
    SELECT * FROM classes WHERE filtre='tous' OR statut=filtre
  ), page AS (
    SELECT *,row_number() OVER (ORDER BY
      CASE WHEN tri='echeance' THEN fermeture END ASC NULLS LAST,
      CASE WHEN tri='alphabetique' THEN vision_normaliser(contenu) END ASC,
      CASE WHEN tri='stabilite' THEN stabilite END ASC,
      CASE WHEN tri='ordre' THEN ordre END ASC,id) AS rang
    FROM retenus ORDER BY
      CASE WHEN tri='echeance' THEN fermeture END ASC NULLS LAST,
      CASE WHEN tri='alphabetique' THEN vision_normaliser(contenu) END ASC,
      CASE WHEN tri='stabilite' THEN stabilite END ASC,
      CASE WHEN tri='ordre' THEN ordre END ASC,id
    LIMIT limite OFFSET decalage
  )
  SELECT jsonb_build_object('items',coalesce(jsonb_agg(
    jsonb_build_object('id',x.id,'contenu',x.contenu,'version',x.version,
      'stabilite',x.stabilite,'evalue',x.evalue,'evalue_a',x.evalue_a,
      'contexte',x.contexte,'ordre',x.ordre,'fenetre',x.fenetre,'statut',x.statut)
    ORDER BY x.rang),'[]'::jsonb),
    'nombre_items_filtres',(SELECT count(*) FROM retenus))
    INTO resultat FROM page x;
  RETURN resultat;
END $$;

CREATE OR REPLACE FUNCTION vision_lire(u text,p jsonb) RETURNS jsonb LANGUAGE plpgsql AS $$
DECLARE resultat jsonb; objets jsonb; fiche jsonb; liens jsonb; accumule jsonb:='[]'::jsonb;
BEGIN
  resultat:=vision_lire_ancien(u,p);
  IF p->>'type'='fiche' THEN
    FOR fiche IN SELECT value FROM jsonb_array_elements(resultat->'objets') LOOP
      liens:=vision_liens_fiche(u,(fiche->>'id')::bigint,p);
      accumule:=accumule||jsonb_build_array(
        jsonb_set(fiche,'{items}',liens->'items')
          ||jsonb_build_object('nombre_items_filtres',liens->'nombre_items_filtres'));
    END LOOP;
    resultat:=jsonb_set(resultat,'{objets}',accumule);
  END IF;
  RETURN resultat;
END $$;

INSERT INTO vision_schema_migrations(version) VALUES(14) ON CONFLICT DO NOTHING;
COMMIT;
