BEGIN;
-- Ajouter des métadonnées, sans fabriquer de dates pour l’historique.
ALTER TABLE vision_profils ADD COLUMN IF NOT EXISTS duree_seance_courte_minutes integer NOT NULL DEFAULT 60
  CHECK (duree_seance_courte_minutes BETWEEN 1 AND 10080);
ALTER TABLE vision_items ADD COLUMN IF NOT EXISTS datation_reference jsonb;
ALTER TABLE vision_episodes ADD COLUMN IF NOT EXISTS datation jsonb;

CREATE OR REPLACE FUNCTION vision_politique(u text) RETURNS jsonb LANGUAGE sql STABLE AS $$
  SELECT coalesce((SELECT to_jsonb(p)-'utilisateur'-'catalogue' FROM vision_profils p WHERE utilisateur=u),
    jsonb_build_object('intervalle_jours',90,'budget',null,'decalage',0,
      'questions_typiques',8,'duree_seance_courte_minutes',60,'version',1))
$$;

CREATE OR REPLACE FUNCTION vision_lire_politique(u text) RETURNS jsonb LANGUAGE sql STABLE AS $$
 SELECT jsonb_build_object('politique',vision_politique(u),'maintenant',now(),
  'parametres',jsonb_build_object(
    'intervalle_jours',jsonb_build_object('sens','Période cible T ; base multiplicative, pas une fréquence commune à tous les items.','unite','jours','minimum',1,'maximum',3650,'defaut',90),
    'budget',jsonb_build_object('sens','Items distincts par jour ; null désactive l’adaptation automatique.','unite','items/jour','minimum',1,'maximum',1000,'defaut',null),
    'questions_typiques',jsonb_build_object('sens','Nombre typique d’items ; les nouveaux complètent un petit lot, le dépassement demande un choix.','unite','items','minimum',1,'maximum',20,'defaut',8),
    'duree_seance_courte_minutes',jsonb_build_object('sens','Durée serveur strictement inférieure : courte ; supérieure ou égale : longue.','unite','minutes','minimum',1,'maximum',10080,'defaut',60)),
  'automatiques',jsonb_build_object('decalage',jsonb_build_object('symbole','G','unite','dB','minimum',0,'maximum',30,
    'sens','Adaptation à la charge estimée : déplacement d’au plus 1 dB par semaine ; ne change pas S.'),
    'largeur_fenetre_db',1,'formule_intervalle','T × 10^((S − P + G)/10)',
    'modifiables',false))
$$;

CREATE OR REPLACE FUNCTION vision_instant(texte text) RETURNS timestamptz LANGUAGE plpgsql IMMUTABLE AS $$
BEGIN
  IF texte IS NULL OR texte !~ '^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d+)?(Z|[+-]\d{2}:\d{2})$' THEN
    PERFORM vision_refuser('fuseau_requis');
  END IF;
  RETURN texte::timestamptz;
END $$;

CREATE OR REPLACE FUNCTION vision_date_civile(source jsonb) RETURNS timestamptz LANGUAGE plpgsql IMMUTABLE AS $$
BEGIN
  IF source->>'date_rappel' IS NULL OR source->>'date_rappel' !~ '^\d{4}-\d{2}-\d{2}$' OR source->>'fuseau' IS NULL
    OR source->>'fuseau' !~ '^[+-](0\d|1[0-4]):[0-5]\d$'
    OR coalesce(btrim(source->>'provenance'),'')='' THEN PERFORM vision_refuser('date_civile_a_preciser'); END IF;
  RETURN vision_instant((source->>'date_rappel')||'T12:00:00'||(source->>'fuseau'));
END $$;

CREATE OR REPLACE FUNCTION vision_dater_seance(s vision_seances,p jsonb,cloture timestamptz,seuil integer)
RETURNS jsonb LANGUAGE plpgsql AS $$
DECLARE e jsonb; g jsonb; source jsonb; ligne jsonb; instant timestamptz; datation jsonb;
  evaluations jsonb:='[]'; traces jsonb:='[]'; manquantes jsonb:='[]'; invalides jsonb:='[]';
  courte boolean:=cloture-s.cree_a<make_interval(mins=>seuil); groupes integer; origine text;
BEGIN
  IF cloture<s.cree_a THEN PERFORM vision_refuser('bornes_seance_invalides'); END IF;
  FOR g IN SELECT value FROM jsonb_array_elements(coalesce(p->'datations_groupes','[]')) LOOP
    IF NOT (g ? 'evenement_a' OR g ? 'date_rappel') OR g ? 'evenement_a' AND g ? 'date_rappel'
       OR coalesce(btrim(g->>'provenance'),'')='' THEN PERFORM vision_refuser('datation_groupe_invalide'); END IF;
    FOR ligne IN SELECT value FROM jsonb_array_elements(g->'item_ids') LOOP
      IF NOT EXISTS(SELECT 1 FROM jsonb_array_elements(p->'evaluations') x WHERE x->'item_id'=ligne) THEN
        PERFORM vision_refuser('item_hors_evaluations');
      END IF;
    END LOOP;
  END LOOP;
  FOR e IN SELECT value FROM jsonb_array_elements(p->'evaluations') LOOP
    SELECT count(*) INTO groupes FROM jsonb_array_elements(coalesce(p->'datations_groupes','[]')) x
      WHERE x->'item_ids' @> jsonb_build_array(e->'item_id');
    IF groupes>1 THEN PERFORM vision_refuser('datations_groupes_ambigues'); END IF;
    SELECT value INTO source FROM jsonb_array_elements(coalesce(p->'datations_groupes','[]')) x
      WHERE x->'item_ids' @> jsonb_build_array(e->'item_id');
    IF source IS NOT NULL AND (e ? 'evenement_a' OR e ? 'date_rappel' OR coalesce((e->>'date_inconnue')::boolean,false)) THEN
      PERFORM vision_refuser('datations_contradictoires');
    END IF;
    source:=coalesce(source,e);
    instant:=NULL;
    IF coalesce((e->>'date_inconnue')::boolean,false) THEN
      IF e ? 'evenement_a' OR e ? 'date_rappel' THEN PERFORM vision_refuser('datations_contradictoires'); END IF;
      datation:=jsonb_build_object('precision','inconnue','provenance','date_inconnue_declaree');
    ELSIF source ? 'evenement_a' THEN
      IF source ? 'date_rappel' THEN PERFORM vision_refuser('datations_contradictoires'); END IF;
      instant:=vision_instant(source->>'evenement_a');
      datation:=jsonb_build_object('precision',coalesce(source->>'precision','instant'),
        'provenance',coalesce(source->>'provenance','client_non_precise'));
    ELSIF source ? 'date_rappel' THEN
      instant:=vision_date_civile(source);
      datation:=jsonb_build_object('precision','jour','provenance',source->>'provenance',
        'date_rappel',source->>'date_rappel','fuseau',source->>'fuseau','regle','midi_dans_le_fuseau_declare');
    ELSIF courte OR coalesce((p->>'accepter_datation_cloture')::boolean,false) THEN
      instant:=cloture;
      datation:=jsonb_build_object('precision','approximative','provenance',
        CASE WHEN courte THEN 'approximation_seance_courte' ELSE 'cloture_acceptee_explicitement' END,
        'duree_seance_courte_minutes',seuil);
    ELSE
      manquantes:=manquantes||jsonb_build_array(e->'item_id');
    END IF;
    IF instant IS NOT NULL AND (instant<s.cree_a OR instant>cloture) THEN
      invalides:=invalides||jsonb_build_array(jsonb_build_object('item_id',e->'item_id',
        'champ','evenement_a','date_proposee',source,'instant_retenu',instant));
    END IF;
    evaluations:=evaluations||jsonb_build_array(e||jsonb_build_object('evenement_a',instant,
      'date_inconnue',instant IS NULL,'_datation',datation));
  END LOOP;
  -- La date de question est contrôlée, mais n’est jamais assimilée à celle du rappel.
  FOR ligne IN SELECT value FROM jsonb_array_elements(coalesce(p->'deroulement','[]')) LOOP
    IF ligne ? 'posee_a' THEN
      instant:=vision_instant(ligne->>'posee_a');
      IF instant<s.cree_a OR instant>cloture OR EXISTS(SELECT 1 FROM jsonb_array_elements(evaluations) ev(valeur)
        WHERE ev.valeur->>'item_id'=ligne->>'item_id' AND ev.valeur#>>'{_datation,precision}'='instant'
          AND (ev.valeur->>'evenement_a')::timestamptz<instant) THEN
        invalides:=invalides||jsonb_build_array(jsonb_build_object('item_id',ligne->'item_id',
          'champ','posee_a','date_proposee',ligne->'posee_a','instant_retenu',instant));
      END IF;
    END IF;
  END LOOP;
  IF jsonb_array_length(invalides)>0 THEN
    RETURN jsonb_build_object('erreur','dates_hors_seance','tentatives',invalides,
      'ouverture_a',s.cree_a,'cloture_a',cloture,'message','Signaler l’incohérence ; aucune réparation inventée ni écriture partielle.');
  END IF;
  IF jsonb_array_length(manquantes)>0 THEN
    RETURN jsonb_build_object('erreur','dates_rappel_manquantes','item_ids',manquantes,
      'ouverture_a',s.cree_a,'cloture_a',cloture,'seance_courte',false,
      'resolutions',jsonb_build_array('dates_accessibles_par_item_ou_groupes','date_civile_avec_fuseau',
        'date_inconnue_sans_deplacement_memoire','cloture_avec_accord_explicite'));
  END IF;
  RETURN jsonb_build_object('evaluations',evaluations,'seance_courte',courte,
    'ouverture_a',s.cree_a,'cloture_a',cloture,'duree_seance_courte_minutes',seuil);
END $$;

CREATE OR REPLACE FUNCTION vision_evaluer(u text,p jsonb) RETURNS jsonb LANGUAGE plpgsql AS $$
DECLARE e jsonb; i vision_items; ancien vision_items; episode vision_episodes;
  q integer; delta integer; instant timestamptz; rapproche boolean; precedent integer; resultat jsonb:='[]';
  type_evenement text; sens text; aide text; total integer; distincts integer; seance vision_seances; datation jsonb; invalides jsonb:='[]';
BEGIN
  SELECT count(*),count(DISTINCT x->>'item_id') INTO total,distincts FROM jsonb_array_elements(p->'evaluations') x;
  IF total<>distincts OR total NOT BETWEEN 1 AND 20 THEN PERFORM vision_refuser('items_distincts_requis'); END IF;
  -- Prévalider tous les horodatages de rectification avant la première écriture.
  -- Le contrôle rend les dates plausibles, sans authentifier leur provenance.
  FOR e IN SELECT value FROM jsonb_array_elements(p->'evaluations') LOOP
    IF NOT e ? '_datation' THEN
    IF (e ? 'evenement_a' OR e ? 'date_rappel') AND coalesce((e->>'date_inconnue')::boolean,false) THEN
      PERFORM vision_refuser('datations_contradictoires');
    END IF;
    IF e ? 'evenement_a' AND e ? 'date_rappel' THEN PERFORM vision_refuser('datations_contradictoires'); END IF;
    END IF;
    IF e->>'episode' LIKE 'seance:%' AND (e ? 'evenement_a' OR e ? 'date_rappel') THEN
      SELECT * INTO seance FROM vision_seances WHERE utilisateur=u AND id=split_part(e->>'episode',':',2)::uuid;
      IF FOUND AND seance.etat<>'ouverte' THEN
        instant:=CASE WHEN e ? 'evenement_a' THEN vision_instant(e->>'evenement_a') ELSE vision_date_civile(e) END;
        IF instant<seance.cree_a OR instant>seance.terminee_a THEN
          invalides:=invalides||jsonb_build_array(jsonb_build_object('item_id',e->'item_id',
            'date_proposee',e,'instant_retenu',instant,'ouverture_a',seance.cree_a,'cloture_a',seance.terminee_a));
        END IF;
      END IF;
    END IF;
  END LOOP;
  IF jsonb_array_length(invalides)>0 THEN
    RETURN jsonb_build_object('erreur','dates_hors_seance','tentatives',invalides,
      'message','Signaler l’incohérence ; aucune réparation inventée ni écriture partielle.');
  END IF;
  FOR e IN SELECT value FROM jsonb_array_elements(p->'evaluations') LOOP
    SELECT * INTO i FROM vision_items WHERE utilisateur=u AND id=(e->>'item_id')::bigint FOR UPDATE;
    IF NOT FOUND THEN PERFORM vision_refuser('introuvable'); END IF;
    IF i.archive_a IS NOT NULL THEN PERFORM vision_refuser('objet_archive'); END IF;
    IF i.version IS DISTINCT FROM (e->>'version')::bigint THEN PERFORM vision_refuser('conflit'); END IF;
    ancien:=i;
    SELECT * INTO episode FROM vision_episodes WHERE utilisateur=u AND item_id=i.id AND cle=e->>'episode';
    IF coalesce(episode.version,0) IS DISTINCT FROM (e->>'version_episode')::bigint THEN PERFORM vision_refuser('conflit_episode'); END IF;
    IF episode.cle IS NOT NULL AND episode.enregistre_a<now()-interval '30 days' THEN PERFORM vision_refuser('episode_expire'); END IF;
    IF e->>'episode' LIKE 'seance:%' THEN
      SELECT * INTO seance FROM vision_seances WHERE utilisateur=u
        AND id=split_part(e->>'episode',':',2)::uuid;
      IF NOT FOUND OR (p->>'seance_id' IS DISTINCT FROM seance.id::text AND episode.cle IS NULL) THEN
        PERFORM vision_refuser('rectification_episode_inconnu');
      END IF;
    END IF;
    q:=(e->>'q')::integer;
    IF q IS NULL OR q NOT BETWEEN -20 AND 20 THEN PERFORM vision_refuser('ajustement_invalide'); END IF;
    IF abs(q)>5 AND char_length(coalesce(e->>'justification',''))<10 THEN PERFORM vision_refuser('ajustement_a_justifier'); END IF;
    type_evenement:=coalesce(e->>'type_evenement','rappel');
    instant:=CASE WHEN coalesce((e->>'date_inconnue')::boolean,false) THEN NULL
      WHEN e ? 'evenement_a' THEN vision_instant(e->>'evenement_a') WHEN e ? 'date_rappel' THEN vision_date_civile(e) ELSE now() END;
    IF instant>now()+interval '5 minutes' OR instant<'1900-01-01'::timestamptz THEN PERFORM vision_refuser('date_invalide'); END IF;
    IF episode.cle IS NOT NULL THEN
      -- Une précision conserve la date de la tentative originale.
      IF (e ? 'evenement_a' OR e ? 'date_rappel') AND instant IS DISTINCT FROM episode.evenement_a THEN PERFORM vision_refuser('date_episode_immuable'); END IF;
      instant:=episode.evenement_a;
    END IF;
    datation:=CASE WHEN episode.cle IS NOT NULL THEN episode.datation WHEN e ? 'date_rappel' THEN jsonb_build_object('precision','jour','provenance',e->>'provenance','date_rappel',e->>'date_rappel','fuseau',e->>'fuseau','regle','midi_dans_le_fuseau_declare') ELSE coalesce(e->'_datation',jsonb_build_object('precision',CASE WHEN instant IS NULL THEN 'inconnue' ELSE coalesce(e->>'precision','instant') END,'provenance',CASE WHEN instant IS NULL THEN 'date_inconnue_declaree' ELSE coalesce(e->>'provenance',CASE WHEN e ? 'evenement_a' THEN 'client_non_precise' ELSE 'echange_courant_serveur' END) END)) END;
    sens:=coalesce(e->>'sens',''); aide:=coalesce(e->>'aide','aucune');
    IF aide='aucune' AND jsonb_array_length(coalesce(e#>'{deroulement,aides}','[]'))>0 THEN aide:='indice'; END IF;
    -- Le sens décrit la question, jamais une liste historique masquée de l'item.
    IF char_length(sens)>300 THEN PERFORM vision_refuser('sens_invalide'); END IF;
    IF aide NOT IN ('aucune','indice','correction') THEN PERFORM vision_refuser('aide_invalide'); END IF;
    IF type_evenement NOT IN ('rappel','apprentissage','suivi') THEN PERFORM vision_refuser('evenement_invalide'); END IF;
    IF type_evenement IN ('apprentissage','suivi') AND q<>0 THEN PERFORM vision_refuser('rappel_requis'); END IF;
    IF e->>'production_initiale' IN ('incorrecte','incomplete','ambigue','non_verifiee') AND q>0 THEN PERFORM vision_refuser('gain_sans_reussite_autonome'); END IF;
    IF aide='correction' AND q>0 OR aide='indice' AND q>1 THEN PERFORM vision_refuser('gain_aide_excessif'); END IF;
    rapproche:=CASE WHEN episode.cle IS NOT NULL THEN episode.rapproche
      ELSE instant IS NULL OR i.reference_a IS NULL OR instant-i.reference_a<interval '1 day' END;
    delta:=q-coalesce(episode.q,0);
    IF rapproche AND q>1 THEN PERFORM vision_refuser('gain_rapproche_excessif'); END IF;
    IF rapproche AND delta>0 THEN
      SELECT coalesce(sum(greatest(a.q,0)),0) INTO precedent FROM vision_episodes a WHERE a.utilisateur=u
        AND a.item_id=i.id AND a.rapproche AND a.enregistre_a>now()-interval '1 day' AND a.cle<>e->>'episode';
      IF precedent+greatest(q,0)>1 THEN PERFORM vision_refuser('gain_rapproche_deja_applique'); END IF;
    END IF;
    IF i.stabilite+delta NOT BETWEEN -128 AND 127 THEN PERFORM vision_refuser('borne_stabilite'); END IF;
    -- Un ancien événement est daté honnêtement ; il ne remplace pas la référence récente.
    UPDATE vision_items SET stabilite=stabilite+delta,suivi=coalesce(e->>'suivi',suivi),
      reference_a=CASE WHEN type_evenement<>'suivi' AND instant IS NOT NULL THEN greatest(reference_a,instant) ELSE reference_a END,
      origine_reference=CASE WHEN type_evenement<>'suivi' AND instant IS NOT NULL AND (reference_a IS NULL OR instant>=reference_a)
        THEN type_evenement ELSE origine_reference END,
      datation_reference=CASE WHEN type_evenement<>'suivi' AND instant IS NOT NULL AND (reference_a IS NULL OR instant>=reference_a) THEN datation ELSE datation_reference END,
      evalue=evalue OR type_evenement='rappel',
      evalue_a=CASE WHEN type_evenement='rappel' AND instant IS NOT NULL THEN greatest(evalue_a,instant) ELSE evalue_a END,
      version=version+1,modifie_a=now() WHERE utilisateur=u AND id=i.id RETURNING * INTO i;
    INSERT INTO vision_episodes(utilisateur,item_id,cle,conversation,q,stabilite_avant,evenement_a,sens,aide,rapproche,datation)
      VALUES(u,i.id,e->>'episode',p->>'conversation',q,ancien.stabilite,instant,sens,aide,rapproche,datation)
      ON CONFLICT(utilisateur,item_id,cle) DO UPDATE SET q=excluded.q,version=vision_episodes.version+1,
        sens=excluded.sens,aide=excluded.aide RETURNING * INTO episode;
    INSERT INTO vision_journal(utilisateur,objet,objet_id,operation,episode,delta,avant,apres,evenement_a,justification)
      VALUES(u,'item',i.id,'evaluer',episode.cle,delta,
        jsonb_build_object('stabilite',ancien.stabilite,'suivi',ancien.suivi,'reference_a',ancien.reference_a),
        jsonb_build_object('stabilite',i.stabilite,'suivi',i.suivi,'reference_a',i.reference_a),instant,coalesce(e->>'justification',''));
    IF e ? 'suivi' AND coalesce(e->>'suivi','')<>'' AND ancien.suivi IS DISTINCT FROM e->>'suivi' THEN
      INSERT INTO vision_observations(utilisateur,item_id,texte,source,evenement_a)
        VALUES(u,i.id,e->>'suivi','evaluation_historique',instant);
    END IF;
    IF e ? 'deroulement' THEN
      -- Une observation immuable garde aussi les faits des évaluations ponctuelles
      -- et de leurs rectifications ; le même épisode conserve sa date originale.
      INSERT INTO vision_observations(utilisateur,item_id,texte,source,details,evenement_a)
        VALUES(u,i.id,'Compte rendu de tentative.','evaluation_historique',
          (e->'deroulement')||jsonb_build_object('episode',episode.cle,'version_episode',episode.version,
            'production_initiale',e->'production_initiale','aide',aide,'q',q,'datation',datation),instant);
    END IF;
    resultat:=resultat||jsonb_build_array(jsonb_build_object('item',vision_item_public(i),'episode',episode.cle,
      'version_episode',episode.version,'q_cumulatif',q,'delta_applique',delta,
      'evenement_a',instant,'enregistre_a',episode.enregistre_a,'datation',datation,'deroulement',e->'deroulement',
      'horodatage',CASE WHEN instant IS NULL THEN 'inconnu' WHEN datation->>'precision' IN ('jour','approximative') THEN 'approximatif' WHEN e ? 'evenement_a' THEN 'fourni' ELSE 'echange_courant_serveur' END));
  END LOOP;
  RETURN jsonb_build_object('enregistre',true,'evaluations',resultat);
END $$;

CREATE OR REPLACE FUNCTION vision_clore_seance_v2(u text,p jsonb) RETURNS jsonb LANGUAGE plpgsql AS $$
DECLARE s vision_seances; e jsonb; retour jsonb:=p->'retour'; evaluations jsonb:=p->'evaluations';
  bilan jsonb; bilan_final jsonb; normalisees jsonb:='[]'::jsonb; ajustements jsonb:='[]'::jsonb;
  item_courant vision_items; version_preparee bigint; q_demande integer; q_applique integer;
  maximum integer; precedent integer; instant timestamptz; rapproche boolean; motif text;
BEGIN
  SELECT * INTO s FROM vision_seances WHERE utilisateur=u AND id=(p->>'seance_id')::uuid FOR UPDATE;
  IF NOT FOUND THEN PERFORM vision_refuser('seance_introuvable'); END IF;
  IF s.etat<>'ouverte' THEN
    IF s.rapport->>'empreinte_cloture'=p->>'empreinte_cloture' THEN
      RETURN jsonb_build_object('enregistre',true,'rejeu',true,'rapport',s.rapport);
    END IF;
    PERFORM vision_refuser('cloture_differente');
  END IF;
  IF jsonb_typeof(evaluations)<>'array' OR jsonb_array_length(evaluations)>20 THEN
    PERFORM vision_refuser('evaluations_invalides');
  END IF;
  FOR e IN SELECT value FROM jsonb_array_elements(evaluations) LOOP
    IF NOT EXISTS(SELECT 1 FROM jsonb_array_elements(s.items) i WHERE (i->>'id')::bigint=(e->>'item_id')::bigint) THEN
      PERFORM vision_refuser('item_hors_seance');
    END IF;
  END LOOP;
  FOR e IN SELECT value FROM jsonb_array_elements(retour->'reformulations') LOOP
    IF NOT EXISTS(SELECT 1 FROM jsonb_array_elements(s.items) i WHERE (i->>'id')::bigint=(e->>'item_id')::bigint) THEN
      PERFORM vision_refuser('item_hors_seance');
    END IF;
  END LOOP;
  FOR e IN SELECT value FROM jsonb_array_elements(p->'deroulement') LOOP
    IF NOT EXISTS(SELECT 1 FROM jsonb_array_elements(s.items) i WHERE (i->>'id')::bigint=(e->>'item_id')::bigint) THEN
      PERFORM vision_refuser('item_hors_seance');
    END IF;
  END LOOP;
  -- Le lot peut avoir vieilli pendant que d'autres séances sur les mêmes items ont été closes.
  -- Les évaluations indépendantes sont recalculées sur l'état courant, sans modifier la trace demandée.
  FOR e IN SELECT value FROM jsonb_array_elements(evaluations) LOOP
    SELECT * INTO item_courant FROM vision_items WHERE utilisateur=u AND id=(e->>'item_id')::bigint FOR UPDATE;
    SELECT (x->>'version')::bigint INTO version_preparee
      FROM jsonb_array_elements(s.items) x WHERE x->>'id'=e->>'item_id' LIMIT 1;
    IF item_courant.id IS NULL OR ((e->>'version')::bigint<>version_preparee AND
                        (e->>'version')::bigint<>item_courant.version) THEN
      PERFORM vision_refuser('conflit');
    END IF;
    q_demande:=(e->>'q')::integer;
    q_applique:=CASE WHEN e->>'production_initiale' IN ('incorrecte','incomplete','ambigue','non_verifiee') THEN least(q_demande,0) ELSE q_demande END;
    motif:='';
    IF coalesce(e->>'type_evenement','rappel')='rappel' AND q_demande>0 THEN
      instant:=CASE WHEN coalesce((e->>'date_inconnue')::boolean,false) THEN NULL
        WHEN e ? 'evenement_a' THEN (e->>'evenement_a')::timestamptz ELSE now() END;
      rapproche:=instant IS NULL OR item_courant.reference_a IS NULL OR instant-item_courant.reference_a<interval '1 day';
      maximum:=CASE WHEN e->>'aide'='correction' THEN 0
        WHEN rapproche OR e->>'aide'='indice' THEN 1 ELSE 20 END;
      IF rapproche THEN
        SELECT coalesce(sum(greatest(a.q,0)),0) INTO precedent FROM vision_episodes a
          WHERE a.utilisateur=u AND a.item_id=item_courant.id AND a.rapproche
            AND a.enregistre_a>now()-interval '1 day' AND a.cle<>e->>'episode';
        maximum:=least(maximum,greatest(0,1-precedent));
      END IF;
      q_applique:=least(q_applique,maximum);
      IF q_applique<q_demande THEN
        motif:=CASE WHEN e->>'aide'='correction' THEN 'correction_devoilee'
          WHEN rapproche THEN 'gain_rapproche_limite' ELSE 'indice' END;
      END IF;
    END IF;
    IF q_applique<>q_demande OR item_courant.version<>(e->>'version')::bigint THEN
      ajustements:=ajustements||jsonb_build_array(jsonb_build_object('item_id',item_courant.id,
        'q_demande',q_demande,'q_applique',q_applique,'motif',motif,
        'version_demandee',(e->>'version')::bigint,'version_appliquee',item_courant.version));
    END IF;
    normalisees:=normalisees||jsonb_build_array(e||jsonb_build_object('q',q_applique,'version',item_courant.version));
  END LOOP;
  IF jsonb_array_length(normalisees)>0 THEN
    bilan:=vision_evaluer(u,(p||jsonb_build_object('evaluations',normalisees,'conversation',s.conversation)));
  ELSE bilan:=jsonb_build_object('enregistre',true,'evaluations','[]'::jsonb);
  END IF;
  bilan_final:=jsonb_build_object('seance_id',s.id,'fiche_id',s.fiche_id,
    'empreinte_cloture',p->>'empreinte_cloture',
    'items_sans_deroulement',(SELECT coalesce(jsonb_agg(x.valeur->'item_id'),'[]'::jsonb)
      FROM jsonb_array_elements(evaluations) AS x(valeur) WHERE NOT EXISTS (
        SELECT 1 FROM jsonb_array_elements(p->'deroulement') d
        WHERE d->>'item_id'=x.valeur->>'item_id' AND d->>'etat'='tente')),
    'questions_preparees',jsonb_array_length(s.items),
    'tentatives_enregistrees',jsonb_array_length(evaluations),
    'evaluations',bilan->'evaluations','evaluations_demandees',evaluations,
    'datation_seance',p->'_datation_seance','ouverture_a',s.cree_a,'cloture_a',now(),
    'ajustements',ajustements,'deroulement',p->'deroulement',
    'retour',retour,'synthese',coalesce(p->>'synthese',''),
    'propositions_en_attente',jsonb_build_object('reformulations',retour->'reformulations','ajouts',retour->'ajouts'));
  UPDATE vision_seances SET etat='terminee',retour=p->'retour',rapport=bilan_final,terminee_a=now()
    WHERE id=s.id;
  RETURN jsonb_build_object('enregistre',true,'rapport',bilan_final);
END $$;

CREATE OR REPLACE FUNCTION vision_clore_seance(u text,p jsonb) RETURNS jsonb LANGUAGE plpgsql AS $$
DECLARE resultat jsonb; ligne jsonb; identifiant bigint; s vision_seances;
  normalise jsonb; evaluations jsonb:='[]'::jsonb; e jsonb; version_item bigint;
  empreinte text; contenu jsonb; datations jsonb; seuil integer;
BEGIN
  SELECT * INTO s FROM vision_seances WHERE utilisateur=u AND id=(p->>'seance_id')::uuid FOR UPDATE;
  IF NOT FOUND THEN PERFORM vision_refuser('seance_introuvable'); END IF;
  normalise:=p||jsonb_build_object('deroulement',coalesce(p->'deroulement','[]'::jsonb),
    'retour',jsonb_build_object('difficulte','non_indiquee','reformulations','[]'::jsonb,'ajouts','[]'::jsonb)
      ||coalesce(p->'retour','{}'::jsonb));
  -- Empreinte métier stable : un nouvel identifiant de requête après interruption
  -- n'autorise ni un double crédit ni le remplacement d'un rapport existant.
  SELECT coalesce(jsonb_agg(x.valeur-'version'-'episode'-'version_episode' ORDER BY (x.valeur->>'item_id')::bigint),'[]'::jsonb)
    INTO contenu FROM jsonb_array_elements(p->'evaluations') AS x(valeur);
  empreinte:=encode(sha256(convert_to((jsonb_build_object('evaluations',contenu,
    'deroulement',normalise->'deroulement','retour',normalise->'retour',
    'datations_groupes',coalesce(p->'datations_groupes','[]'::jsonb),
    'accepter_datation_cloture',coalesce((p->>'accepter_datation_cloture')::boolean,false),
    'synthese',coalesce(p->>'synthese',''),'observation_fiche',coalesce(p->>'observation_fiche','')))::text,'UTF8')),'hex');
  IF s.etat<>'ouverte' THEN
    IF NOT s.rapport ? 'datation_seance' AND NOT p ? 'datations_groupes' AND NOT p ? 'accepter_datation_cloture' THEN
      empreinte:=encode(sha256(convert_to(jsonb_build_object('evaluations',contenu,
        'deroulement',normalise->'deroulement','retour',normalise->'retour',
        'synthese',coalesce(p->>'synthese',''),'observation_fiche',coalesce(p->>'observation_fiche',''))::text,'UTF8')),'hex');
    END IF;
    IF s.rapport->>'empreinte_cloture'=empreinte THEN
      RETURN jsonb_build_object('enregistre',true,'rejeu',true,'rapport',s.rapport);
    END IF;
    PERFORM vision_refuser('cloture_differente');
  END IF;
  SELECT coalesce(duree_seance_courte_minutes,60) INTO seuil FROM vision_profils WHERE utilisateur=u;
  datations:=vision_dater_seance(s,p,now(),coalesce(seuil,60));
  IF datations ? 'erreur' THEN RETURN datations; END IF;
  normalise:=normalise||jsonb_build_object('_datation_seance',datations-'evaluations');
  FOR e IN SELECT value FROM jsonb_array_elements(datations->'evaluations') LOOP
    SELECT (x->>'version')::bigint INTO version_item FROM jsonb_array_elements(s.items) x
      WHERE x->>'id'=e->>'item_id';
    IF NOT FOUND THEN PERFORM vision_refuser('item_hors_seance'); END IF;
    IF EXISTS(SELECT 1 FROM jsonb_array_elements(normalise->'deroulement') d WHERE d->>'item_id'=e->>'item_id'
      AND (d->>'aide'='correction' OR coalesce(d->>'correction','')<>'')) THEN
      e:=e||jsonb_build_object('aide','correction');
    ELSIF e->>'aide'='aucune' AND EXISTS(SELECT 1 FROM jsonb_array_elements(normalise->'deroulement') d
      WHERE d->>'item_id'=e->>'item_id' AND (d->>'aide'='indice' OR jsonb_array_length(coalesce(d->'aides','[]'))>0)) THEN
      e:=e||jsonb_build_object('aide','indice');
    END IF;
    evaluations:=evaluations||jsonb_build_array(
      jsonb_build_object('version',version_item,'sens','')||e||
      jsonb_build_object('episode','seance:'||s.id::text||':'||(e->>'item_id'),'version_episode',0));
  END LOOP;
  normalise:=normalise||jsonb_build_object('evaluations',evaluations,'empreinte_cloture',empreinte);
  resultat:=vision_clore_seance_v2(u,normalise);
  IF NOT coalesce((resultat->>'enregistre')::boolean,false) OR coalesce((resultat->>'rejeu')::boolean,false) THEN RETURN resultat; END IF;
  FOR ligne IN SELECT value FROM jsonb_array_elements(normalise->'deroulement') LOOP
    identifiant:=(ligne->>'item_id')::bigint;
    INSERT INTO vision_observations(utilisateur,item_id,texte,source,details,evenement_a)
      VALUES(u,identifiant,coalesce(ligne->>'observation',''),'seance',
        (ligne-'observation')||jsonb_build_object('seance_id',p->>'seance_id',
          'evaluation',(SELECT e.value FROM jsonb_array_elements(datations->'evaluations') e
            WHERE e.value->>'item_id'=ligne->>'item_id' LIMIT 1)),
        (SELECT (e.value->>'evenement_a')::timestamptz FROM jsonb_array_elements(datations->'evaluations') e WHERE e.value->>'item_id'=ligne->>'item_id' LIMIT 1));
  END LOOP;
  IF coalesce(btrim(p->>'observation_fiche'),'')<>'' THEN
    INSERT INTO vision_observations(utilisateur,fiche_id,texte,source,details)
      VALUES(u,(resultat#>>'{rapport,fiche_id}')::bigint,p->>'observation_fiche',
        'seance',jsonb_build_object('seance_id',p->>'seance_id'));
  END IF;
  RETURN resultat;
END $$;

CREATE OR REPLACE FUNCTION vision_commande(u text,op text,p jsonb) RETURNS jsonb LANGUAGE plpgsql AS $$
DECLARE empreinte text:=encode(sha256(convert_to(op||p::text,'UTF8')),'hex'); deja vision_requetes; resultat jsonb; pr vision_profils;
BEGIN
  IF u IS NULL OR u='' THEN RETURN jsonb_build_object('erreur','identite_requise'); END IF;
  IF p->>'emise_a' IS NULL OR (p->>'emise_a')::timestamptz<now()-interval '30 days'
    OR (p->>'emise_a')::timestamptz>now()+interval '5 minutes' THEN RETURN jsonb_build_object('erreur','requete_expiree'); END IF;
  IF char_length(coalesce(p->>'cle','')) NOT BETWEEN 8 AND 100 THEN RETURN jsonb_build_object('erreur','cle_requise'); END IF;
  PERFORM pg_advisory_xact_lock(hashtextextended(u,718));
  INSERT INTO vision_profils(utilisateur) VALUES(u) ON CONFLICT DO NOTHING;
  SELECT * INTO deja FROM vision_requetes WHERE utilisateur=u AND cle=p->>'cle';
  IF FOUND THEN
    IF deja.empreinte<>empreinte THEN RETURN jsonb_build_object('erreur','cle_reutilisee'); END IF;
    RETURN deja.resultat||jsonb_build_object('rejeu',true);
  END IF;
  BEGIN
    CASE op
      WHEN 'ajouter_observation' THEN resultat:=vision_ajouter_observation(u,p);
      WHEN 'enregistrer_fiche' THEN resultat:=vision_ecrire_fiche(u,p);
      WHEN 'enregistrer_item' THEN resultat:=vision_ecrire_item(u,p);
      WHEN 'lier_item' THEN resultat:=vision_lier(u,p);
      WHEN 'evaluer_items' THEN resultat:=vision_evaluer(u,p);
      WHEN 'enregistrer_contexte' THEN resultat:=vision_ecrire_contexte(u,p);
      WHEN 'regler_politique' THEN
        SELECT * INTO pr FROM vision_profils WHERE utilisateur=u;
        IF pr.version IS DISTINCT FROM (p->>'version')::bigint THEN PERFORM vision_refuser('conflit'); END IF;
        IF NOT p ?| ARRAY['intervalle_jours','budget','questions_typiques','duree_seance_courte_minutes'] THEN PERFORM vision_refuser('modification_requise'); END IF;
        UPDATE vision_profils SET intervalle_jours=coalesce((p->>'intervalle_jours')::integer,intervalle_jours),
          budget=CASE WHEN p ? 'budget' THEN (p->>'budget')::integer ELSE budget END,
          duree_seance_courte_minutes=coalesce((p->>'duree_seance_courte_minutes')::integer,duree_seance_courte_minutes),
          questions_typiques=coalesce((p->>'questions_typiques')::integer,questions_typiques),
          version=version+1 WHERE utilisateur=u;
        resultat:=jsonb_build_object('enregistre',true);
      WHEN 'ouvrir_seance' THEN resultat:=vision_ouvrir_seance(u,p);
      WHEN 'clore_seance' THEN resultat:=vision_clore_seance(u,p);
      ELSE PERFORM vision_refuser('operation_inconnue');
    END CASE;
    IF resultat ? 'erreur' THEN RETURN resultat; END IF;
    PERFORM vision_ajuster_charge(u);
    resultat:=resultat||jsonb_build_object('politique',vision_politique(u),'maintenant',now());
    INSERT INTO vision_requetes(utilisateur,cle,empreinte,resultat) VALUES(u,p->>'cle',empreinte,resultat);
    DELETE FROM vision_requetes WHERE utilisateur=u AND enregistre_a<now()-interval '35 days';
    DELETE FROM vision_episodes WHERE utilisateur=u AND enregistre_a<now()-interval '90 days';
    DELETE FROM vision_journal WHERE utilisateur=u AND (enregistre_a<now()-interval '180 days' OR id IN
      (SELECT id FROM vision_journal WHERE utilisateur=u ORDER BY id DESC OFFSET 5000));
    DELETE FROM vision_contextes WHERE utilisateur=u AND (modifie_a<now()-interval '90 days' OR conversation IN
      (SELECT conversation FROM vision_contextes WHERE utilisateur=u ORDER BY modifie_a DESC OFFSET 50));
    RETURN resultat;
  EXCEPTION WHEN raise_exception THEN RETURN jsonb_build_object('erreur',SQLERRM);
    WHEN integrity_constraint_violation OR data_exception THEN RETURN jsonb_build_object('erreur','donnees_invalides');
  END;
END $$;



-- Le démarrage contrôle l’ensemble des fonctions de temps et d’écriture effectives.
DO $$
DECLARE empreinte text; lecture text;
BEGIN
  lecture:=$sql$SELECT md5(string_agg(pg_get_functiondef(oid),'' ORDER BY proname))
    FROM pg_proc WHERE pronamespace='public'::regnamespace
      AND proname IN ('vision_evaluer','vision_clore_seance','vision_clore_seance_v2',
        'vision_dater_seance','vision_instant','vision_date_civile','vision_commande','vision_politique')$sql$;
  EXECUTE lecture INTO empreinte;
  EXECUTE format('CREATE OR REPLACE FUNCTION vision_revision_contrat() RETURNS integer LANGUAGE sql STABLE AS %L',
    format('SELECT CASE WHEN (%s)=%L THEN 7 ELSE 0 END',lecture,empreinte));
END $$;
INSERT INTO vision_schema_migrations(version) VALUES(17) ON CONFLICT DO NOTHING;
COMMIT;
