BEGIN;

-- L'extension non trusted est installée par l'infrastructure, comme superuser.
DO $$ BEGIN
  IF NOT EXISTS(SELECT 1 FROM pg_extension WHERE extname='vector') THEN
    RAISE EXCEPTION 'extension_vector_requise : installer pgvector dans la base Vision avant migration';
  END IF;
END $$;

CREATE TABLE IF NOT EXISTS vision_embeddings (
  utilisateur text NOT NULL,
  item_id bigint NOT NULL,
  modele text NOT NULL,
  contenu_sha256 text NOT NULL CHECK(length(contenu_sha256)=64),
  representation vector NOT NULL CHECK(vector_norm(representation)>0),
  calcule_a timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY(utilisateur,item_id,modele),
  FOREIGN KEY(utilisateur,item_id) REFERENCES vision_items(utilisateur,id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS vision_preparations_items (
  cle uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  utilisateur text NOT NULL REFERENCES vision_profils,
  contenu_sha256 text NOT NULL,
  catalogue bigint NOT NULL,
  candidats bigint[] NOT NULL,
  modele text NOT NULL,
  representation vector NOT NULL,
  algorithme text NOT NULL DEFAULT 'hybride-rrf-1',
  cree_a timestamptz NOT NULL DEFAULT now(),
  expire_a timestamptz NOT NULL DEFAULT now()+interval '30 minutes',
  utilisee_a timestamptz
);
CREATE INDEX IF NOT EXISTS preparations_items_utilisateur ON vision_preparations_items(utilisateur,cree_a);

CREATE OR REPLACE FUNCTION vision_hash_contenu(contenu text) RETURNS text
LANGUAGE sql IMMUTABLE STRICT AS $$ SELECT encode(sha256(convert_to(contenu,'UTF8')),'hex') $$;

CREATE OR REPLACE FUNCTION vision_invalider_embedding() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF TG_OP='INSERT' OR NEW.contenu IS DISTINCT FROM OLD.contenu
    OR NEW.alias IS DISTINCT FROM OLD.alias OR NEW.archive_a IS DISTINCT FROM OLD.archive_a THEN
    UPDATE vision_profils SET catalogue=catalogue+1 WHERE utilisateur=NEW.utilisateur;
  END IF;
  IF TG_OP='UPDATE' AND NEW.contenu IS DISTINCT FROM OLD.contenu THEN
    DELETE FROM vision_embeddings WHERE utilisateur=NEW.utilisateur AND item_id=NEW.id;
  END IF;
  RETURN NEW;
END $$;
DROP TRIGGER IF EXISTS invalider_embedding ON vision_items;
CREATE TRIGGER invalider_embedding AFTER INSERT OR UPDATE OF contenu,alias,archive_a
  ON vision_items FOR EACH ROW EXECUTE FUNCTION vision_invalider_embedding();

CREATE OR REPLACE FUNCTION vision_stocker_embedding(u text,identifiant bigint,contenu text,modele_embedding text,v vector)
RETURNS boolean LANGUAGE plpgsql AS $$
BEGIN
  -- Compare-and-set : un backfill concurrent ne peut publier un vecteur périmé.
  PERFORM 1 FROM vision_items WHERE utilisateur=u AND id=identifiant AND vision_items.contenu=vision_stocker_embedding.contenu FOR UPDATE;
  IF NOT FOUND THEN RETURN false; END IF;
  INSERT INTO vision_embeddings(utilisateur,item_id,modele,contenu_sha256,representation)
    VALUES(u,identifiant,modele_embedding,vision_hash_contenu(vision_stocker_embedding.contenu),v)
    ON CONFLICT(utilisateur,item_id,modele) DO UPDATE SET contenu_sha256=excluded.contenu_sha256,
      representation=excluded.representation,calcule_a=now();
  RETURN true;
END $$;

CREATE OR REPLACE FUNCTION vision_preparer_creation_item(u text,p jsonb,v vector,modele_embedding text)
RETURNS jsonb LANGUAGE plpgsql AS $$
DECLARE proposition text:=p->>'contenu'; ids bigint[]; candidats jsonb; preuve vision_preparations_items;
  termes tsquery; manquants integer;
BEGIN
  IF coalesce(btrim(proposition),'')='' THEN RETURN jsonb_build_object('erreur','contenu_requis'); END IF;
  PERFORM pg_advisory_xact_lock(hashtextextended(u,718));
  INSERT INTO vision_profils(utilisateur) VALUES(u) ON CONFLICT DO NOTHING;
  SELECT count(*) INTO manquants FROM vision_items i WHERE i.utilisateur=u AND NOT EXISTS(
    SELECT 1 FROM vision_embeddings e WHERE e.utilisateur=u AND e.item_id=i.id AND e.modele=modele_embedding
      AND e.contenu_sha256=vision_hash_contenu(i.contenu) AND vector_dims(e.representation)=vector_dims(v));
  IF manquants>0 THEN RETURN jsonb_build_object('erreur','index_semantique_incomplet','nombre_manquants',manquants); END IF;
  -- OR des lexèmes français du contenu entier : rappel élevé, sans mots inventés par le client.
  SELECT string_agg(quote_literal(lexeme),' | ')::tsquery INTO termes
    FROM unnest(tsvector_to_array(to_tsvector('french',vision_normaliser(proposition)))) lexeme;
  WITH semantiques AS (
    SELECT e.item_id AS id,row_number() OVER(ORDER BY e.representation <=> v,e.item_id) AS rang
    FROM vision_embeddings e WHERE e.utilisateur=u AND e.modele=modele_embedding
    ORDER BY e.representation <=> v,e.item_id LIMIT 20
  ), textuels AS (
    SELECT i.id,row_number() OVER(ORDER BY ts_rank_cd(i.texte_recherche,termes) DESC,i.id) AS rang
    FROM vision_items i WHERE i.utilisateur=u AND i.texte_recherche @@ termes
    ORDER BY ts_rank_cd(i.texte_recherche,termes) DESC,i.id LIMIT 20
  ), trigrammes AS (
    SELECT i.id,row_number() OVER(ORDER BY similarity(i.recherche,vision_normaliser(proposition)) DESC,i.id) AS rang
    FROM vision_items i WHERE i.utilisateur=u AND similarity(i.recherche,vision_normaliser(proposition))>=0.15
    ORDER BY similarity(i.recherche,vision_normaliser(proposition)) DESC,i.id LIMIT 20
  ), fusion AS (
    SELECT id,sum(score) AS score FROM (
      SELECT id,2.0/(60+rang) AS score FROM semantiques
      UNION ALL SELECT id,1.0/(60+rang) FROM textuels
      UNION ALL SELECT id,1.0/(60+rang) FROM trigrammes
    ) x GROUP BY id
  ), retenus AS (
    -- Garder au moins les cinq premiers voisins sémantiques, même si le texte diverge.
    SELECT f.*,EXISTS(SELECT 1 FROM semantiques s WHERE s.id=f.id AND s.rang<=5) AS protege
    FROM fusion f ORDER BY protege DESC,score DESC,id LIMIT 10
  ) SELECT coalesce(array_agg(id ORDER BY protege DESC,score DESC,id),'{}') INTO ids FROM retenus;
  SELECT coalesce(jsonb_agg(vision_item_public(i)||jsonb_build_object('fiches',
      coalesce((SELECT jsonb_agg(jsonb_build_object('id',f.id,'titre',f.titre,'contexte',l.contexte)
        ORDER BY f.id) FROM vision_liens l JOIN vision_fiches f ON f.utilisateur=l.utilisateur AND f.id=l.fiche_id
        WHERE l.utilisateur=u AND l.item_id=i.id),'[]')) ORDER BY a.rang),'[]') INTO candidats
    FROM unnest(ids) WITH ORDINALITY a(id,rang) JOIN vision_items i ON i.utilisateur=u AND i.id=a.id;
  INSERT INTO vision_preparations_items(utilisateur,contenu_sha256,catalogue,candidats,modele,representation)
    SELECT u,vision_hash_contenu(proposition),catalogue,ids,modele_embedding,v FROM vision_profils WHERE utilisateur=u
    RETURNING * INTO preuve;
  DELETE FROM vision_preparations_items WHERE utilisateur=u AND cree_a<now()-interval '35 days';
  RETURN jsonb_build_object('preuve_creation',preuve.cle,'contenu_sha256',preuve.contenu_sha256,
    'expire_a',preuve.expire_a,'algorithme',preuve.algorithme,'modele',preuve.modele,'candidats',candidats,
    'consigne','Lire intégralement tous les candidats. Même connaissance : réutiliser et lier ; sinon créer avec candidats_examines et distinction. Aucun score ne vaut une décision sémantique.');
END $$;

CREATE OR REPLACE FUNCTION vision_ecrire_item(u text,p jsonb) RETURNS jsonb LANGUAGE plpgsql AS $$
DECLARE ancien vision_items; nouveau vision_items; preuve vision_preparations_items;
  examines bigint[]:=ARRAY(SELECT jsonb_array_elements_text(coalesce(p->'candidats_examines','[]'))::bigint);
  v vector; modele_embedding text;
BEGIN
  IF p ? 'id' THEN
    IF p ?| ARRAY['stabilite','reference_a'] THEN PERFORM vision_refuser('utiliser_evaluation'); END IF;
    SELECT * INTO ancien FROM vision_items WHERE utilisateur=u AND id=(p->>'id')::bigint FOR UPDATE;
    IF NOT FOUND THEN PERFORM vision_refuser('introuvable'); END IF;
    IF ancien.version IS DISTINCT FROM (p->>'version')::bigint THEN PERFORM vision_refuser('conflit'); END IF;
    IF p ? 'contenu' AND p->>'contenu' IS DISTINCT FROM ancien.contenu THEN
      v:=(p->>'_embedding')::vector; modele_embedding:=p->>'_modele';
      IF v IS NULL OR modele_embedding IS NULL THEN PERFORM vision_refuser('embedding_requis'); END IF;
    END IF;
    UPDATE vision_items SET contenu=coalesce(p->>'contenu',contenu),
      titre=left(coalesce(p->>'contenu',contenu),200),
      alias=CASE WHEN p ? 'alias' THEN ARRAY(SELECT jsonb_array_elements_text(p->'alias')) ELSE alias END,
      archive_a=CASE WHEN p ? 'archive' THEN CASE WHEN (p->>'archive')::boolean THEN coalesce(archive_a,now()) END ELSE archive_a END,
      version=version+1,modifie_a=now() WHERE utilisateur=u AND id=ancien.id RETURNING * INTO nouveau;
  ELSE
    IF NOT p ? 'preuve_creation' THEN
      PERFORM vision_refuser(CASE WHEN p ? 'preuve_recherche' THEN 'protocole_creation_remplace' ELSE 'preuve_creation_requise' END);
    END IF;
    SELECT * INTO preuve FROM vision_preparations_items WHERE utilisateur=u AND cle=(p->>'preuve_creation')::uuid FOR UPDATE;
    IF NOT FOUND THEN PERFORM vision_refuser('preuve_creation_inconnue'); END IF;
    IF preuve.utilisee_a IS NOT NULL THEN PERFORM vision_refuser('preuve_creation_utilisee'); END IF;
    IF preuve.expire_a<=now() THEN PERFORM vision_refuser('preuve_creation_expiree'); END IF;
    IF preuve.contenu_sha256 IS DISTINCT FROM vision_hash_contenu(p->>'contenu') THEN PERFORM vision_refuser('preuve_creation_contenu_different'); END IF;
    IF preuve.catalogue IS DISTINCT FROM (SELECT catalogue FROM vision_profils WHERE utilisateur=u) THEN PERFORM vision_refuser('preuve_creation_catalogue_modifie'); END IF;
    IF NOT examines @> preuve.candidats OR NOT preuve.candidats @> examines
      OR cardinality(examines)<>cardinality(preuve.candidats) THEN PERFORM vision_refuser('candidats_non_examines'); END IF;
    IF cardinality(preuve.candidats)>0 AND char_length(btrim(coalesce(p->>'distinction','')))<10 THEN PERFORM vision_refuser('distinction_requise'); END IF;
    IF (p->>'reference_a')::timestamptz>now() THEN PERFORM vision_refuser('date_future'); END IF;
    IF coalesce((p->>'stabilite')::integer,-15)<>-15 AND char_length(coalesce(p->>'justification',''))<10 THEN PERFORM vision_refuser('initialisation_a_justifier'); END IF;
    v:=preuve.representation; modele_embedding:=preuve.modele;
    INSERT INTO vision_items(utilisateur,titre,contenu,alias,objectifs,sens,stabilite,reference_a,origine_reference)
      VALUES(u,left(p->>'contenu',200),p->>'contenu',ARRAY(SELECT jsonb_array_elements_text(coalesce(p->'alias','[]'))),
        ARRAY['Connaissance autonome'],ARRAY['direct','inverse'],coalesce((p->>'stabilite')::integer,-15),
        (p->>'reference_a')::timestamptz,CASE WHEN p->>'reference_a' IS NULL THEN 'inconnue' ELSE 'declaree' END)
      RETURNING * INTO nouveau;
    UPDATE vision_preparations_items SET utilisee_a=now() WHERE cle=preuve.cle;
  END IF;
  IF v IS NOT NULL THEN PERFORM vision_stocker_embedding(u,nouveau.id,nouveau.contenu,modele_embedding,v); END IF;
  INSERT INTO vision_journal(utilisateur,objet,objet_id,operation,avant,apres,justification)
    VALUES(u,'item',nouveau.id,'enregistrer',coalesce(vision_item_public(ancien),'{}'),vision_item_public(nouveau),coalesce(p->>'justification',''));
  RETURN jsonb_build_object('enregistre',true,'item',vision_item_public(nouveau));
END $$;

-- L'ancienne recherche reste utilisable pour naviguer, mais ne délivre plus de preuve.
DO $$ BEGIN
  IF to_regprocedure('vision_rechercher_navigation(text,jsonb)') IS NULL THEN
    ALTER FUNCTION vision_rechercher(text,jsonb) RENAME TO vision_rechercher_navigation;
  END IF;
END $$;
CREATE OR REPLACE FUNCTION vision_rechercher(u text,p jsonb) RETURNS jsonb LANGUAGE plpgsql AS $$
BEGIN
  IF coalesce((p->>'preparer_creation')::boolean,false) THEN
    RETURN jsonb_build_object('erreur','protocole_creation_remplace','operation','preparer_creation_item');
  END IF;
  RETURN vision_rechercher_navigation(u,p);
END $$;

-- Un ancien retour applicatif ne doit pas réinstaller silencieusement le
-- protocole lexical tout en conservant le numéro de migration.
DO $$
DECLARE empreinte text; lecture text;
BEGIN
  lecture:=$sql$SELECT md5(string_agg(pg_get_functiondef(oid),'' ORDER BY proname))
    FROM pg_proc WHERE pronamespace='public'::regnamespace
      AND proname IN ('vision_ecrire_item','vision_rechercher','vision_preparer_creation_item',
        'vision_stocker_embedding','vision_invalider_embedding')$sql$;
  EXECUTE lecture INTO empreinte;
  EXECUTE format('CREATE OR REPLACE FUNCTION vision_creation_contrat() RETURNS integer LANGUAGE sql STABLE AS %L',
    format('SELECT CASE WHEN (%s)=%L THEN 1 ELSE 0 END',lecture,empreinte));
END $$;
INSERT INTO vision_schema_migrations(version) VALUES(16) ON CONFLICT DO NOTHING;
COMMIT;
