#!/usr/bin/env python3
"""Préparer un snapshot et consigner la révision exacte pour la qualification CI.

Après qualification, fixer cette révision dans VISION_MODELE_REVISION. La
résolution initiale de main n'est jamais effectuée par le serveur de production.
"""
import hashlib
import json
import os
from pathlib import Path
from huggingface_hub import HfApi, snapshot_download

nom='sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2'
revision=os.environ.get('VISION_MODELE_REVISION', 'e8f8c211226b894fcb81acc59f3b34ba3efd5f42')
if len(revision)!=40 or any(c not in '0123456789abcdef' for c in revision):
    raise RuntimeError('Révision complète exigée')
snapshot_download(nom,revision=revision,local_dir='.modele-test',
                  allow_patterns=['*.json','*.txt','*.model','*.safetensors'])
fichiers=[]
for chemin in sorted(Path('.modele-test').rglob('*')):
    if chemin.is_file() and '.cache' not in chemin.parts:
        h=hashlib.sha256()
        with chemin.open('rb') as f:
            for bloc in iter(lambda:f.read(1024*1024),b''):
                h.update(bloc)
        fichiers.append(dict(chemin=str(chemin.relative_to('.modele-test')),sha256=h.hexdigest()))
verrou=dict(modele=nom,revision=revision,fichiers=fichiers)
Path('modele-qualification.json').write_text(json.dumps(verrou,indent=2)+'\n')
print(json.dumps(verrou))
