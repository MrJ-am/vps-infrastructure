#!/usr/bin/env python3
"""Mesure avec le VRAI modèle, PostgreSQL/pgvector et l'API Common Lisp.

Le corpus est déterministe ; le snapshot exact et l'identité du fournisseur
figurent dans le rapport. Aucune donnée ou séance de test en production.
"""
import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'scripts'))
from backfill_embeddings import embedding, sql
from check_refonte import appel, requete, identifiant, maintenant


def preparer(contenu, utilisateur):
    return appel('preparer_creation_item', {'contenu': contenu}, utilisateur)


def creer(contenu, utilisateur, preparation=None, **champs):
    p = preparation or preparer(contenu, utilisateur)
    return appel('enregistrer_item', dict(contenu=contenu, preuve_creation=p['preuve_creation'],
        candidats_examines=[c['id'] for c in p['candidats']], distinction='Connaissance distincte, explicitement conservée pour ce test.', **champs), utilisateur, True)['item']


def mesurer():
    if os.environ.get('PGHOST') != '127.0.0.1' or os.environ.get('PGDATABASE') != 'vision_semantique_test':
        raise RuntimeError('Base locale vision_semantique_test exigée')
    corpus = json.loads(Path('tests/corpus_creation.json').read_text())
    u = 'qualite_' + identifiant()[:12]
    objets = {}
    for entree in corpus:
        objets[entree['id']] = creer(entree['contenu'], u)
        for contenu in entree['differents']:
            # Connaissances différentes, même lexicalement proches : jamais fusionnées.
            different = creer(contenu, u)
            assert different['id'] != objets[entree['id']]['id']
    # Bruit de domaines différents : le corpus dépasse la taille du résultat.
    for contenu in ['Le cuivre conduit le courant électrique', 'Un triangle possède trois côtés',
                    'La Terre tourne autour du Soleil', 'Une année bissextile compte 366 jours',
                    'Le chat est un mammifère', 'Le participe passé suit des règles grammaticales',
                    'La pression atmosphérique diminue avec l’altitude', 'La mitochondrie produit de l’ATP']:
        creer(contenu, u)
    mesures = []
    for entree in corpus:
        for contenu in entree['paraphrases']:
            p = preparer(contenu, u)
            ids = [c['id'] for c in p['candidats']]
            attendu = objets[entree['id']]['id']
            rang = ids.index(attendu) + 1 if attendu in ids else None
            assert len(ids) <= 10
            mesures.append(dict(cas=entree['id'],requete=contenu,rang=rang,
                                faux_positifs=len(ids)-(rang is not None)))
            assert rang is not None, (entree['id'], contenu, p['candidats'])
            # Détection par le LLM simulée explicitement : réutiliser, sans créer.
            f = appel('enregistrer_fiche', dict(titre='Nouvelle fiche de contexte',contenu='Contexte'), u, True)['fiche']
            lien = appel('lier_item',dict(fiche_id=f['id'],version_fiche=f['version'],item_id=attendu,action='rattacher'),u,True)
            assert lien['item_id'] == attendu
    # Archives incluses ; aucune restriction à une fiche.
    i = objets['capitale']
    archive = appel('enregistrer_item', dict(id=i['id'],version=i['version'],archive=True),u,True)['item']
    assert any(c['id']==i['id'] and c['archive_a'] for c in preparer(corpus[0]['paraphrases'][0],u)['candidats'])
    avant = sql("SELECT row_to_json(e) FROM vision_embeddings e WHERE utilisateur=:'u' AND item_id=:'id'::bigint",u=u,id=i['id'])
    alias = appel('enregistrer_item',dict(id=i['id'],version=archive['version'],alias=['capitale lusitanienne']),u,True)['item']
    apres_alias = sql("SELECT row_to_json(e) FROM vision_embeddings e WHERE utilisateur=:'u' AND item_id=:'id'::bigint",u=u,id=i['id'])
    assert avant == apres_alias
    contenu = 'La capitale espagnole est Madrid'
    appel('enregistrer_item',dict(id=i['id'],version=alias['version'],contenu=contenu),u,True)
    apres = sql("SELECT row_to_json(e) FROM vision_embeddings e WHERE utilisateur=:'u' AND item_id=:'id'::bigint",u=u,id=i['id'])
    assert apres['contenu_sha256']==hashlib.sha256(contenu.encode()).hexdigest()
    assert apres['representation'] != avant['representation']
    assert objets['capitale']['id'] in [c['id'] for c in preparer('Madrid est la capitale de l’Espagne',u)['candidats']]
    # Isolation : aucune fuite de contenu ni de candidats entre comptes.
    assert preparer(contenu,'vide_'+identifiant()[:12])['candidats']==[]
    rapport = dict(modele=embedding('Identité du fournisseur')['modele'],mesures=mesures,
                   rappel=sum(m['rang'] is not None for m in mesures)/len(mesures),
                   rang_moyen=sum(m['rang'] for m in mesures)/len(mesures),
                   faux_positifs_moyens=sum(m['faux_positifs'] for m in mesures)/len(mesures))
    Path('qualite-creation.json').write_text(json.dumps(rapport,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(rapport,ensure_ascii=False))


if __name__ == '__main__':
    mesurer()
