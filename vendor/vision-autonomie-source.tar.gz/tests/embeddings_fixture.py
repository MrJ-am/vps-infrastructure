#!/usr/bin/env python3
"""Doublure déterministe de transport, SANS prétention sémantique.

Uniquement pour les tests métier/HTTP. La qualité emploie le vrai modèle dans
qualite_creation.py, jamais ces vecteurs synthétiques.
"""
import hashlib
import math
import sys
sys.path.insert(0, 'scripts')
from embeddings import servir


class Doublure:
    def calculer(self, contenu):
        valeurs = [b / 127.5 - 1 for b in hashlib.sha256(contenu.encode()).digest()]
        norme = math.sqrt(sum(v*v for v in valeurs))
        return {'modele': 'fixture-transport-1', 'embedding': [v / norme for v in valeurs]}


if __name__ == '__main__':
    servir(Doublure(), 39004)
