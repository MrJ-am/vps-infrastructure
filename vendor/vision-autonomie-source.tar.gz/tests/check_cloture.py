"""Régressions des clôtures réelles, données synthétiques en base isolée."""
import subprocess,unittest
from check_refonte import appel,fiche,item,lire,requete,identifiant,maintenant

class Cloture(unittest.TestCase):
 def preparer(self):
  f=fiche('Clôture historique '+identifiant()[:8]);i=item('Paris est la capitale de la France',reference_a=maintenant(-8))
  # Valeurs effectivement produites par l'import historique, masquées en 2.4.
  subprocess.run(['psql','-Xq','-v','ON_ERROR_STOP=1','-c',
   "UPDATE vision_items SET sens=ARRAY['pays → capitale','capitale → pays'] WHERE utilisateur='alice' AND id="+str(i['id'])],check=True)
  appel('lier_item',dict(fiche_id=f['id'],version_fiche=f['version'],item_id=i['id'],action='rattacher'),ecriture=True)
  s=appel('ouvrir_seance',dict(fiche_id=f['id'],nouvelle_seance=True),ecriture=True)
  return i,s
 def cloture(self,i,s):
  return dict(cle=identifiant(),emise_a=maintenant(),seance_id=s['seance_id'],
   evaluations=[dict(item_id=i['id'],q=2,aide='aucune')])
 def test_ancien_catalogue_et_sens_libre(self):
  i,s=self.preparer();p=self.cloture(i,s)
  p['evaluations'][0].update(version=i['version'],episode=identifiant(),version_episode=0,sens='capitale vers pays')
  p.update(deroulement=[dict(item_id=i['id'],question='Paris est la capitale de quel pays ?',etat='tente',reponse='France')],
   retour=dict(difficulte='facile',reformulations=[],ajouts=[]))
  r=appel('clore_seance',p)
  self.assertTrue(r['enregistre']);self.assertEqual(lire(i)['stabilite'],i['stabilite']+2)
 def test_cloture_mcp_minimale_et_rejeu_sans_double_credit(self):
  i,s=self.preparer();p=self.cloture(i,s)
  def rpc(p):
   code,r=requete('/mcp',dict(jsonrpc='2.0',id=1,method='tools/call',params=dict(name='clore_seance',arguments=p)))
   self.assertEqual(code,200);self.assertNotIn('error',r,r)
   self.assertFalse(r['result']['isError'],r)
   return r['result']['structuredContent']
  a=rpc(p);self.assertTrue(a['enregistre']);avant={k:v for k,v in lire(i).items() if k!='fenetre'}
  self.assertTrue(rpc(p)['rejeu'])
  p.update(cle=identifiant(),emise_a=maintenant())
  self.assertTrue(rpc(p)['rejeu']);self.assertEqual({k:v for k,v in lire(i).items() if k!='fenetre'},avant)
  self.assertEqual(a['rapport']['deroulement'],[])
  self.assertEqual(a['rapport']['retour']['difficulte'],'non_indiquee')
  self.assertEqual(a['rapport']['items_sans_deroulement'],[i['id']])
  p['evaluations'][0]['q']=3;p['cle']=identifiant()
  self.assertEqual(requete('/api/v1/clore_seance',p)[1]['erreur'],'cloture_differente')
  self.assertEqual({k:v for k,v in lire(i).items() if k!='fenetre'},avant)
 def test_anciennes_cles_episode_reutilisees_entre_deux_seances(self):
  i,s=self.preparer()
  autre=appel('ouvrir_seance',dict(fiche_id=s['usage_assistant']['fiche']['id'],nouvelle_seance=True),ecriture=True)
  rapports=[]
  for seance in (s,autre):
   p=self.cloture(i,seance)
   p['evaluations'][0].update(q=0,episode='ancien-client-meme-cle',version_episode=0)
   rapports.append(appel('clore_seance',p)['rapport'])
  self.assertNotEqual(rapports[0]['evaluations'][0]['episode'],rapports[1]['evaluations'][0]['episode'])
  self.assertEqual(lire(i)['stabilite'],i['stabilite'])
 def test_trace_partielle_ne_fabrique_aucune_reponse(self):
  i,s=self.preparer();p=self.cloture(i,s)
  p['retour']=dict(commentaire='La question était facile.')
  r=appel('clore_seance',p)['rapport']
  self.assertEqual(r['deroulement'],[]);self.assertEqual(r['tentatives_enregistrees'],1)
  self.assertEqual(r['retour']['commentaire'],'La question était facile.')
 def test_hors_lot_et_isolation_restent_refuses(self):
  i,s=self.preparer();p=self.cloture(i,s);p['evaluations'][0]['item_id']=item('Hors lot')['id']
  self.assertEqual(requete('/api/v1/clore_seance',p)[1]['erreur'],'item_hors_seance')
  self.assertEqual(lire(i)['version'],i['version'])
  p=self.cloture(i,s)
  self.assertEqual(requete('/api/v1/clore_seance',p,'bob')[1]['erreur'],'seance_introuvable')
  self.assertTrue(appel('clore_seance',p)['enregistre'])
 def test_cloture_vide_sans_evaluation(self):
  i,s=self.preparer();p=self.cloture(i,s);p['evaluations']=[]
  r=appel('clore_seance',p)
  self.assertTrue(r['enregistre']);self.assertEqual(lire(i)['version'],i['version'])
 def test_sens_libre_hors_seance(self):
  i,s=self.preparer()
  e=dict(item_id=i['id'],version=i['version'],episode=identifiant(),version_episode=0,q=0,
   sens='retrouver le pays à partir de sa capitale',aide='aucune')
  self.assertTrue(appel('evaluer_items',dict(evaluations=[e]),ecriture=True)['enregistre'])
  p=self.cloture(i,s);p['evaluations']=[];appel('clore_seance',p)

if __name__=='__main__':unittest.main()
