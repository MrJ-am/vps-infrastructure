-- Exécuter exclusivement en base isolée. Vérifier les items réellement restaurés
-- sans toucher aux séances d'origine ; toutes les tentatives sont annulées.
BEGIN;
DO $$
DECLARE i vision_items; s vision_seances; f bigint; p jsonb; r jsonb; avant bigint;
BEGIN
  IF vision_revision_contrat()<>7 THEN RAISE EXCEPTION 'Contrat SQL incohérent'; END IF;
  FOR i IN SELECT * FROM vision_items WHERE archive_a IS NULL ORDER BY utilisateur,id LOOP
    SELECT fiche_id INTO f FROM vision_liens WHERE utilisateur=i.utilisateur AND item_id=i.id LIMIT 1;
    IF f IS NULL THEN CONTINUE; END IF;
    INSERT INTO vision_seances(utilisateur,fiche_id,items)
      VALUES(i.utilisateur,f,jsonb_build_array(vision_item_public(i))) RETURNING * INTO s;
    p:=jsonb_build_object('cle','controle:'||s.id::text,'emise_a',now(),'seance_id',s.id,
      'evaluations',jsonb_build_array(jsonb_build_object('item_id',i.id,'q',0,'aide','aucune',
        'sens','description libre indépendante du sens historique','date_inconnue',true)));
    r:=vision_commande(i.utilisateur,'clore_seance',p);
    IF NOT coalesce((r->>'enregistre')::boolean,false) THEN
      RAISE EXCEPTION 'Clôture isolée refusée : %',r->>'erreur';
    END IF;
    SELECT version INTO avant FROM vision_items WHERE utilisateur=i.utilisateur AND id=i.id;
    r:=vision_commande(i.utilisateur,'clore_seance',p||jsonb_build_object('cle','rejeu:'||s.id::text));
    IF NOT coalesce((r->>'rejeu')::boolean,false) OR avant<>(SELECT version FROM vision_items WHERE utilisateur=i.utilisateur AND id=i.id) THEN
      RAISE EXCEPTION 'Rejeu de clôture incohérent';
    END IF;
  END LOOP;
END $$;
ROLLBACK;

