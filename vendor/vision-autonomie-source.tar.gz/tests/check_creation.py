#!/usr/bin/env python3
"""Protocole complet sur HTTP/PostgreSQL isolés, vecteurs de transport simulés."""
import json
import os
import sys
import unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'scripts'))
from backfill_embeddings import sql, backfill
from check_refonte import appel, requete, identifiant, maintenant


class Creation(unittest.TestCase):
    def setUp(self):
        self.u = 'creation_' + identifiant()[:12]

    def preparer(self, contenu):
        return appel('preparer_creation_item', {'contenu': contenu}, self.u)

    def requete_creation(self, contenu, p, **champs):
        return dict(cle=identifiant(), emise_a=maintenant(), contenu=contenu,
                    preuve_creation=p['preuve_creation'],
                    candidats_examines=[c['id'] for c in p['candidats']],
                    distinction='Relation différente explicitement examinée.', **champs)

    def test_zero_candidat_et_usage_unique_et_rejeu(self):
        contenu = 'Lisbonne est la capitale du Portugal'
        p = self.preparer(contenu)
        self.assertEqual(p['candidats'], [])
        corps = self.requete_creation(contenu, p)
        code, r = requete('/api/v1/enregistrer_item', corps, self.u)
        self.assertEqual(code, 200, r)
        self.assertTrue(appel('enregistrer_item', corps, self.u)['rejeu'])
        corps['cle'] = identifiant()
        self.assertEqual(requete('/api/v1/enregistrer_item', corps, self.u)[1]['erreur'], 'preuve_creation_utilisee')
        i = r['item']
        vecteur = sql("SELECT to_json(count(*)) FROM vision_embeddings WHERE utilisateur=:'u' AND item_id=:'id'::bigint", u=self.u,id=i['id'])
        self.assertEqual(vecteur, 1)

    def test_contenu_exact_y_compris_apres_200_caracteres(self):
        contenu = 'Connaissance autonome complète. ' * 20
        p = self.preparer(contenu)
        for autre in [contenu+' Sens différent.', contenu+' ', contenu.replace('complète','complete')]:
            code, r = requete('/api/v1/enregistrer_item', self.requete_creation(autre,p),self.u)
            self.assertEqual(code,400,r)
            self.assertEqual(r['erreur'],'preuve_creation_contenu_different')
        self.assertTrue(appel('enregistrer_item',self.requete_creation(contenu,p),self.u)['enregistre'])

    def test_expiration_identite_et_absence(self):
        contenu='Un triangle possède trois côtés'
        p=self.preparer(contenu)
        self.assertEqual(requete('/api/v1/enregistrer_item', self.requete_creation(contenu,p),'autre_'+identifiant()[:8])[1]['erreur'],'preuve_creation_inconnue')
        sql("UPDATE vision_preparations_items SET expire_a=now()-interval '1 second' WHERE cle=:'cle'::uuid; SELECT to_json(true);",cle=p['preuve_creation'])
        self.assertEqual(requete('/api/v1/enregistrer_item',self.requete_creation(contenu,p),self.u)[1]['erreur'],'preuve_creation_expiree')
        q=self.requete_creation(contenu,p);del q['preuve_creation']
        self.assertEqual(requete('/api/v1/enregistrer_item',q,self.u)[1]['erreur'],'preuve_creation_requise')

    def test_candidats_complets_examen_et_archives(self):
        contenu='Lisbonne est la capitale du Portugal'
        i=appel('enregistrer_item',self.requete_creation(contenu,self.preparer(contenu)),self.u)['item']
        i=appel('enregistrer_item',dict(id=i['id'],version=i['version'],archive=True,alias=['capitale lusitanienne']),self.u,True)['item']
        autre='La capitale portugaise est Lisbonne'
        p=self.preparer(autre)
        candidat=next(c for c in p['candidats'] if c['id']==i['id'])
        self.assertEqual(candidat['contenu'],contenu)
        self.assertEqual(candidat['alias'],['capitale lusitanienne'])
        self.assertTrue(candidat['archive_a'])
        q=self.requete_creation(autre,p);q['candidats_examines']=[]
        self.assertEqual(requete('/api/v1/enregistrer_item',q,self.u)[1]['erreur'],'candidats_non_examines')
        # lire ne vaut plus une décision : l'accusé explicite est dans l'écriture.
        appel('lire',dict(type='item',ids=[i['id']]),self.u)
        self.assertEqual(requete('/api/v1/enregistrer_item',q,self.u)[1]['erreur'],'candidats_non_examines')
        q['candidats_examines']=[i['id']];q['distinction']=''
        self.assertEqual(requete('/api/v1/enregistrer_item',q,self.u)[1]['erreur'],'distinction_requise')

    def test_catalogue_et_index_incomplet(self):
        contenu='Le cuivre est conducteur'
        p=self.preparer(contenu)
        autre='La Terre tourne autour du Soleil'
        i=appel('enregistrer_item',self.requete_creation(autre,self.preparer(autre)),self.u)['item']
        self.assertEqual(requete('/api/v1/enregistrer_item',self.requete_creation(contenu,p),self.u)[1]['erreur'],'preuve_creation_catalogue_modifie')
        # Simuler une ancienne importation, sans inventer de vecteur sémantique.
        sql("DELETE FROM vision_embeddings WHERE utilisateur=:'u'; SELECT to_json(true);",u=self.u)
        code,r=requete('/api/v1/preparer_creation_item',dict(contenu=contenu),self.u)
        self.assertEqual(code,503,r);self.assertEqual(r['erreur'],'index_semantique_incomplet')
        self.assertNotIn('preuve_creation',r)
        self.assertGreaterEqual(backfill(100),1)
        self.assertEqual(backfill(100),0)
        self.assertIn('preuve_creation',self.preparer(contenu))
        self.assertFalse(sql("SELECT to_json(vision_stocker_embedding(:'u', :'id'::bigint, 'Contenu périmé', 'fixture-transport-1', '[1,0]'::vector));",u=self.u,id=i['id']))

    def test_protocole_deprecie_et_injection_vecteur_refusee(self):
        code,r=requete('/api/v1/rechercher',dict(type='item',requete='Lisbonne',preparer_creation=True),self.u)
        self.assertEqual(code,400);self.assertEqual(r['erreur'],'protocole_creation_remplace')
        code,r=requete('/api/v1/preparer_creation_item',dict(contenu='Lisbonne',_embedding='[1,0]'),self.u)
        self.assertEqual(code,400);self.assertEqual(r['erreur'],'parametres_invalides')


if __name__ == '__main__':
    if os.environ.get('PGHOST')!='127.0.0.1':
        raise RuntimeError('Base locale de test exigée')
    unittest.main()
