"""Contrat livré et calculs documentés ; ces tests n’évaluent pas un comportement LLM."""
import importlib.util
import json
import math
from pathlib import Path
import unittest

RACINE = Path(__file__).resolve().parents[1]


class Contenus(unittest.TestCase):
    def test_contrat_unique_dans_les_outils(self):
        contrat = (RACINE / 'docs/CONTRAT-SEANCE.md').read_text().strip()
        outils = json.loads((RACINE / 'docs/outils.json').read_text())
        for nom in ['preparer_revision', 'ouvrir_seance', 'lire_seance', 'clore_seance', 'evaluer_items']:
            outil = next(o for o in outils if o['name'] == nom)
            self.assertIn(contrat, outil['description'])
        for prescription in ['validation globale est interdite', '« Non »', 'Il manque un élément',
            'sémantiquement équivalente', 'indice sémantique faible', 'première production autonome',
            'reponse_initiale', 'aides effectivement fournies', 'données fiables effectivement accessibles']:
            self.assertIn(prescription, contrat)

    def test_exemples_calcules_du_modele(self):
        self.assertAlmostEqual(90 * 10 ** (-10/10), 9)
        self.assertAlmostEqual(9 * 10 ** (-.1), 7.149, places=3)
        self.assertAlmostEqual(9 * 10 ** (.1), 11.330, places=3)
        self.assertAlmostEqual(90 * 10 ** (-1.5), 2.846, places=3)
        self.assertAlmostEqual(10 * math.log10(2), 3.010, places=3)
        sql = (RACINE / 'migrations/005_fiches_items.sql').read_text()
        self.assertIn('t * power(10::numeric,(s-p+g)::numeric/10)', sql)
        tutoriel = json.loads((RACINE / 'docs/tutoriel.json').read_text())
        self.assertEqual(len(tutoriel['sections']), 5)
        self.assertEqual(len({s['id'] for s in tutoriel['sections']}), 5)
        for s in tutoriel['sections']:
            self.assertTrue(all(s.get(k) for k in ['objectif', 'explication', 'exemple', 'activite']))

    def test_source_tutoriel_partagee(self):
        spec = importlib.util.spec_from_file_location('contenus', RACINE / 'scripts/contenus.py')
        m = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(m)
        avant = (RACINE / 'interface/src/Tutoriel.elm').read_text()
        m.generer()
        self.assertEqual(avant, (RACINE / 'interface/src/Tutoriel.elm').read_text())
        self.assertIn('docs/tutoriel.json', (RACINE / 'src/contenus.lisp').read_text())


if __name__ == '__main__':
    unittest.main()
