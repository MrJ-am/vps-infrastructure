#!/bin/sh
set -eu
cd -- "$(dirname -- "$0")/.."
psql -X -v ON_ERROR_STOP=1 -c 'CREATE EXTENSION IF NOT EXISTS vector'
sh scripts/migrate.sh
sh scripts/migrate.sh
python3 tests/embeddings_fixture.py >/tmp/vision-embeddings-fixture.log 2>&1 &
embeddings=$!
sh build.sh
chmod +x vision
VISION_PUBLIC_MCP_URL=https://exemple.test/vision/mcp PORT=39003 IP=127.0.0.1 VISION_DOCUMENT_ROOT="$PWD/docs" ./vision > /tmp/vision-refonte-tests.log 2>&1 &
serveur=$!
trap 'kill "$embeddings" "$serveur" 2>/dev/null || true' EXIT INT TERM
for tentative in $(seq 1 50); do
  if curl -fsS http://127.0.0.1:39003/healthz >/dev/null 2>&1; then break; fi
  sleep 0.1
done
python3 tests/check_refonte.py
python3 tests/check_cloture.py

python3 tests/check_creation.py


python3 tests/check_autonomie.py
sbcl --script tests/check_liens.lisp
