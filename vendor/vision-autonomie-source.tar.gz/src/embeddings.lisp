(in-package #:vision)

(define-condition embedding-error (error) ())

(defun calculer-embedding (contenu)
  ;; Le fournisseur est un service local configurable. Aucun vecteur client
  ;; n'est accepté par le contrat public ; modèle et dimensions viennent du service.
  (handler-case
      (multiple-value-bind (sortie code)
          (run-database-process
           (list (or (sb-ext:posix-getenv "VISION_CURL") "curl")
                 "--silent" "--show-error" "--fail" "--max-time" "30"
                 "--noproxy" "127.0.0.1,localhost" "--header" "Content-Type: application/json"
                 "--data-binary" "@-"
                 (or (sb-ext:posix-getenv "VISION_EMBEDDINGS_URL") "http://127.0.0.1:39004/embedding"))
           (json-encode (jobject "contenu" contenu)))
        (unless (zerop code) (error 'embedding-error))
        (let* ((resultat (parse-json sortie))
               (v (json-object-get resultat "embedding"))
               (modele (json-object-get resultat "modele")))
          (unless (and (stringp modele) (<= 1 (length modele) 250)
                       (json-array-p v) (<= 1 (length (json-array-items v)) 4096)
                       (every (lambda (x) (and (realp x) (<= -1 x 1))) (json-array-items v))
                       (some (lambda (x) (/= x 0)) (json-array-items v)))
            (error 'embedding-error))
          (values (json-encode v) modele)))
    (error () (error 'embedding-error))))
