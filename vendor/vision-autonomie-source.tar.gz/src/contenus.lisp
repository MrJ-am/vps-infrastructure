(in-package #:vision)

(defparameter *contrat-pedagogique*
  (uiop:read-file-string (asdf:system-relative-pathname :vision "docs/CONTRAT-SEANCE.md") :external-format :utf-8))
(defparameter *tutoriel*
  (parse-json (uiop:read-file-string (asdf:system-relative-pathname :vision "docs/tutoriel.json") :external-format :utf-8)))

(defun consulter-tutoriel (arguments)
  "Retourner l’index ou une section, sans écriture ni injection systématique du tutoriel."
  (let* ((identifiant (json-object-get arguments "section"))
         (sections (json-array-items (json-object-get *tutoriel* "sections"))))
    (jobject "version" (json-object-get *tutoriel* "version")
      "usage_assistant" (json-object-get *tutoriel* "usage_assistant")
      (if identifiant "section" "sections")
      (if identifiant
          (find identifiant sections :test #'equal :key (lambda (s) (json-object-get s "id")))
          (%make-json-array (mapcar (lambda (s) (jobject "id" (json-object-get s "id")
            "titre" (json-object-get s "titre") "objectif" (json-object-get s "objectif"))) sections))))))

(defun base-publique-valide-p (url)
  "N’accepter qu’une URL configurée sans identifiants, query, fragment ni caractères ambigus."
  (and (stringp url)
       (let ((debut (cond ((and (>= (length url) 8) (string= "https://" url :end2 8)) 8)
                          ((and (>= (length url) 7) (string= "http://" url :end2 7)) 7))))
         (and debut (< debut (length url))
              (let* ((fin (or (position #\/ url :start debut) (length url)))
                     (hote (subseq url debut fin)))
                (and (plusp (length hote))
                     (every (lambda (c) (find c "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789.-:[]")) hote)
                     (not (find-if (lambda (c) (or (<= (char-code c) 32)
                       (find c "@?#\\%"))) url))))))))

(defun chemin-public-valide-p (chemin)
  "Les préfixes sont une configuration de routage, jamais un en-tête fourni par le client."
  (and (stringp chemin) (plusp (length chemin)) (char= (char chemin 0) #\/)
       (not (search ".." chemin))
       (every (lambda (c) (or (alphanumericp c) (find c "/-_"))) chemin)))

(defun construire-base-web (mcp-url mcp-chemin web-chemin &optional web-url)
  "Dériver le préfixe public du service MCP en vérifiant le suffixe configuré exact."
  (when web-url
    (return-from construire-base-web (and (base-publique-valide-p web-url)
      (concatenate 'string (string-right-trim "/" web-url) "/"))))
  (when (and (base-publique-valide-p mcp-url)
             (chemin-public-valide-p mcp-chemin) (chemin-public-valide-p web-chemin)
             (and (<= (length mcp-chemin) (length mcp-url))
               (string= mcp-chemin mcp-url :start2 (- (length mcp-url) (length mcp-chemin)))))
    (let ((prefixe (subseq mcp-url 0 (- (length mcp-url) (length mcp-chemin)))))
      ;; Le préfixe restant doit encore désigner une origine absolue valide.
      (when (base-publique-valide-p prefixe)
        (concatenate 'string (string-right-trim "/" prefixe)
          (string-right-trim "/" web-chemin) "/")))))

(defun base-web-configuree ()
  "Ignorer Host et Forwarded : les déploiements configurent l’adresse publique à partir du routage."
  (construire-base-web (sb-ext:posix-getenv "VISION_PUBLIC_MCP_URL")
    (or (sb-ext:posix-getenv "VISION_MCP_PATH") "/mcp")
    (or (sb-ext:posix-getenv "VISION_WEB_PATH") "/")
    (sb-ext:posix-getenv "VISION_PUBLIC_WEB_URL")))

(defun enrichir-contrat (nom resultat)
  "Livrer intégralement le même contrat aux démarrages/reprises et remplacer les anciennes consignes."
  (if (and (member nom '("preparer_revision" "ouvrir_seance" "lire_seance" "clore_seance" "evaluer_items") :test #'equal)
           (not (json-object-get resultat "erreur")))
      (%make-json-object
        (append (remove-if (lambda (entree) (member (car entree) '("consigne" "contrat_pedagogique") :test #'equal))
                          (json-object-entries resultat))
                (list (cons "consigne" *contrat-pedagogique*) (cons "contrat_pedagogique" *contrat-pedagogique*))))
      resultat))
