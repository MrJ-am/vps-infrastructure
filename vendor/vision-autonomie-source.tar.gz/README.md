# Vision 2.6

Vision organise des **fiches** de référence et des **items** de connaissance.
Un item peut appartenir à plusieurs fiches : son suivi et sa stabilité restent
uniques. Son contenu décrit une connaissance atomique intelligible sans la fiche ; la fiche précise le contexte et la manière de réviser. Les
observations horodatées, immuables et consultables sont propres à l'item ou à
la fiche ; celles d'un item traversent tous ses rattachements. Le serveur est
en Common Lisp/SBCL, l’interface en ElmUI et les données
dans PostgreSQL 17. Nginx et mrj-auth assurent les accès authentifiés.

Le [contrat pédagogique commun](docs/CONTRAT-SEANCE.md) accompagne chaque
ouverture et reprise. Le [tutoriel structuré](docs/tutoriel.json) alimente le
site public et l’outil `tutoriel`, sans création de données de démonstration.
`lire_politique` expose les valeurs effectives ; `regler_politique` accepte
une modification partielle versionnée. `etat_fiche` exporte le Markdown et
les items par pages explicites ; `bilan_fiches` donne leur synthèse.

Les rappels sans date peuvent être approximés à la clôture uniquement sous
le seuil de séance courte (60 minutes par défaut, borne exclue). Au-delà,
les dates réelles ou approximations déclarées sont nécessaires ; les traces
inconnues restent non datées, et l’approximation à la clôture exige un accord
explicite. Les historiques existants ne sont pas réhorodatés.

Les liens privés de `lien_fiche` utilisent `VISION_PUBLIC_MCP_URL`, fourni
par le module de déploiement depuis son domaine configuré. Un routage atypique
peut préciser `VISION_MCP_PATH`, `VISION_WEB_PATH` et
`VISION_PUBLIC_WEB_URL`. Host et Forwarded ne déterminent jamais cette adresse.
L’accueil est public ; `/connexion` conserve l’accès direct à l’authentification.

Une fiche possède une priorité entière P ; un item possède une stabilité
entière S en dB. L’intervalle indicatif est `I = T × 10^((S − P + G)/10)`, avec
T=90 jours par défaut et une fenêtre de ±1 dB. Une priorité positive avance la
révision. Le modèle n’exprime aucune probabilité de rappel. La mise à jour
`S ← S + Q` utilise un Q entier contextualisé, jamais une note FSRS.

Le [modèle et ses choix](docs/REFONTE.md) explicitent les limites. Les
[instructions MCP](docs/MCP.md), incorporées au binaire, définissent le
calibrage pédagogique et le démarrage d’une révision sans révéler les réponses.
Le [navigateur](docs/BROWSER.md) permet recherche, édition, rattachement et
archivage réversible. Les références de publication effective sont consignées
dans le [rapport de publication du 25 septembre 2026](rapports/REFONTE-20260925.md),
avec la migration réelle et les contrôles HTTPS.

## Contrats

Les quinze opérations de [docs/outils.json](docs/outils.json) sont communes aux
outils MCP et aux routes POST `/api/v1/<opération>` et `/api/web/<opération>` :
`rechercher`, `preparer_creation_item`, `lire`, `preparer_revision`, `lister_seances`, `lire_seance`,
`ouvrir_seance`, `clore_seance`, `enregistrer_fiche`,
`enregistrer_item`, `lier_item`, `evaluer_items`, `ajouter_observation`, `enregistrer_contexte`,
`regler_politique`. [OpenAPI](docs/openapi.json) est généré depuis la même source
par `python3 scripts/contrats.py`. Les requêtes SQL sont fixes et paramétrées.

REST utilise Basic. MCP accepte Basic, des tokens Bearer indépendants ou OAuth
PKCE fourni par l’infrastructure. Le navigateur utilise session et CSRF.
L’identité est issue du proxy et obligatoire ; les données sont isolées par
compte. Les anciens outils de fiches/FSRS répondent `contrat_retire` ; aucun
`rating` n’est converti en évaluation arbitraire. Recharger les contrats clients.

## Vérifications et publication

`sh build.sh` compile le serveur. `sh tests/refonte.sh` utilise une base de test
isolée ; `tests/refonte.sql` vérifie les formules, `tests/check_migration.py`
vérifie simulation, idempotence et protection des données historiques.
`tests/mesures.py` mesure 5, 500 et 5 000 fiches avec des items partagés.

`npm ci --prefix interface`, puis `python3 interface/compiler.py --style CACHE`
compilent l’interface avec la révision exacte du style. Le workflow interface
exécute Playwright contre le vrai serveur Lisp/PostgreSQL jetable, avec une
doublure locale du service de session. L’authentification HTTPS réelle est
vérifiée ensuite par le dépôt VPS. Aucune donnée fictive en production. Les [critères graphiques et le bilan du
candidat documentaire](docs/AUDIT-INTERFACE-20260926.md) précisent les tests
locaux, les captures et les validations CI restant nécessaires.

Les migrations 001–004 et l’ancien code/tests FSRS conservés dans Git documentent
l’historique ; ils ne constituent plus le contrat actif. Les migrations 005–008
sont additives. Le plan métier conserve une copie intégrale des anciennes
fiches et observations. Voir [la procédure de migration](docs/REFONTE.md).
Toute opération distante passe par Actions dans `MrJ-am/vps-infrastructure`,
avec sauvegarde restaurée en base isolée, sources exactes et retour autonome.



## Création sémantique des items

La [préparation de création](docs/CREATION-ITEMS.md) transmet le contenu complet
au serveur. Le moteur hybride renvoie dix candidats au plus, archives incluses,
avec contenu intégral et alias. Le LLM décide de réutiliser ou créer ; Vision ne
fusionne jamais sur un score. Migration 016, pgvector et fournisseur local
d’embeddings sont requis. Les anciens clients de préparation reçoivent
`protocole_creation_remplace` et doivent recharger le catalogue MCP.

