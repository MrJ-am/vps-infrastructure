#!/usr/bin/env python3
"""Contrats MCP et OpenAPI générés depuis une seule définition française."""
import json
from pathlib import Path
RACINE=Path(__file__).resolve().parent.parent

def texte(maximum=4000, **kw):return dict(type='string',maxLength=maximum,**kw)
def entier(minimum=0,maximum=2147483647,**kw):return dict(type='integer',minimum=minimum,maximum=maximum,**kw)
def tableau(elements,maximum=50,minimum=0):return dict(type='array',items=elements,minItems=minimum,maxItems=maximum)
def objet(proprietes=None,obligatoires=(),libre=False):return dict(type='object',properties=proprietes or {},required=list(obligatoires),additionalProperties=libre)
def choix(*valeurs):return texte(40,enum=list(valeurs))
def date():return texte(40,format='date-time')
def nullable(schema):return {**schema,'type':[schema['type'],'null']}
BOOLEEN={'type':'boolean'}
ID=entier(1)
COMMUN={'cle':texte(100,minLength=8,description='Clé stable pour tous les rejeux du même enregistrement ; ne pas la changer après un délai réseau.'),'emise_a':date()}
SORTIE_COMMUNE={'erreur':texte(100),'enregistre':BOOLEEN,'rejeu':BOOLEEN,'maintenant':date(),'politique':objet(libre=True)}
OUTILS=[]
def outil(nom,titre,description,proprietes,obligatoires,sortie,ecriture=False):
 if ecriture:proprietes={**COMMUN,**proprietes};obligatoires=['cle','emise_a',*obligatoires]
 OUTILS.append(dict(name=nom,title=titre,description=description,inputSchema=objet(proprietes,obligatoires),outputSchema=objet({**SORTIE_COMMUNE,**sortie}),annotations=dict(readOnlyHint=not ecriture,destructiveHint=False,idempotentHint=True,openWorldHint=False)))

outil('rechercher','Rechercher des fiches et des items',
 'Recherche paginée. Avant CHAQUE création d’item : type=item, requete=intitulé envisagé, preparer_creation=true. Cette recherche globale inclut les archives et renvoie au plus 50 candidats et une preuve, valable 30 minutes. Lire TOUS ces candidats avec lire et la preuve. Si aucun jeton n’est retourné ou s’il reste une page, préciser la recherche ; ne pas conclure à une absence. Même connaissance : réutiliser et lier. Les homonymes distincts exigent une distinction explicite. La préparation écrit uniquement une preuve technique temporaire.',
 {'type':choix('fiche','item'),'requete':texte(200),'tags':tableau(texte(64)),'etat':choix('actif','archive','tous'),'tri':choix('titre','priorite','stabilite','modification'),'limite':entier(1,50),'decalage':entier(0,1000000),'fiche_id':ID,'preparer_creation':BOOLEEN},['type','requete'],
 {'resultats':tableau(objet(libre=True)),'total':entier(),'limite':entier(),'decalage':entier(),'suite':BOOLEEN,'preuve_recherche':nullable(texte(40))})
outil('lire','Lire les objets utiles',
 'Lire jusqu’à 20 fiches ou items ciblés avec contenu, suivi, versions et relations. Les relations d’une fiche sont paginées ; nombre_items indique le total. Pour examiner des doublons, fournir la preuve de rechercher. En révision, garder ces données comme contexte : ne pas afficher les réponses ou les titres révélateurs avant la question.',
 {'type':choix('fiche','item'),'ids':tableau(ID,20,1),'limite':entier(1,50),'decalage':entier(0,1000000),'preuve_recherche':texte(40)},['type','ids'],{'objets':tableau(objet(libre=True),20)})
evaluation=objet({'item_id':ID,'version':entier(1),'episode':texte(100,minLength=1),'version_episode':entier(),'q':entier(-20,20),'sens':texte(300,minLength=1),'aide':choix('aucune','indice','correction'),'type_evenement':choix('rappel','apprentissage','suivi'),'evenement_a':date(),'date_inconnue':BOOLEEN,'suivi':texte(),'justification':texte(1000)},['item_id','version','episode','version_episode','q','sens','aide'])
outil('preparer_revision','Suggérer des fiches à réviser',
 'Lire les suggestions et le nombre de séances ouvertes. Si des séances sont ouvertes, demander : « Voulez-vous ouvrir une nouvelle séance ou obtenir des informations sur les séances ouvertes ? » Attendre le choix. Nouvelle séance : appeler ouvrir_seance avec nouvelle_seance=true ; informations : appeler lister_seances. Ne pas exposer les identifiants techniques à la personne.',
 {'fiche_id':ID,'conversation':texte(100,minLength=1),'limite':entier(1,20)},[],
 {'usage_assistant':objet(libre=True),'suggestions':tableau(objet(libre=True),20),'contexte':nullable(objet(libre=True)),'seances_en_attente':tableau(objet(libre=True),20),'total_seances_ouvertes':entier(),'consigne':texte(),'message':texte()})
outil('lister_seances','Lister les séances ouvertes',
 'Lister les séances ouvertes par pages, avec thème, date de début et nombre de questions. Le total est complet, suite indique une autre page. Présenter thème et date, pas les identifiants techniques. Sur demande de reprise ou clôture, appeler lire_seance avec l’identifiant retourné.',
 {'limite':entier(1,50,default=20),'decalage':entier(0,2147483647,default=0)},[],
 {'seances':tableau(objet(libre=True),50),'total':entier(),'decalage':entier(),'suite':BOOLEEN})
outil('lire_seance','Lire une séance identifiée',
 'Lire une séance identifiée depuis lister_seances : thème, date, état et lot initial. Vision ne connaît aucune réponse avant clôture. Ne pas présenter le lot entier comme des réponses à la personne. Reprendre à partir des faits connus ; une clôture sans évaluation est possible sur demande explicite.',
 {'seance_id':texte(36,minLength=36)},['seance_id'],
 {'seance':objet(libre=True),'usage_assistant':objet(libre=True),'rapport':nullable(objet(libre=True)),'message':texte()})
outil('ouvrir_seance','Ouvrir une séance de révision',
 'Créer une séance persistée et fournir un lot borné d’items dans usage_assistant. Si des séances sont déjà ouvertes, demander : « Voulez-vous ouvrir une nouvelle séance ou obtenir des informations sur les séances ouvertes ? » Première réponse : rappeler avec nouvelle_seance=true ; seconde : lister_seances. Il n’y a aucune limite au nombre de séances ouvertes. Annoncer environ nombre_questions questions, demander si la personne est prête, puis poser les questions une par une. Ne pas afficher les réponses du lot avant chaque tentative.',
 {'fiche_id':ID,'conversation':texte(100,minLength=1,description='Identifiant stable fourni par le client si disponible ; ne jamais prétendre créer un lien vers une conversation privée.'),'limite':entier(1,20,default=8),'nouvelle_seance':BOOLEEN},['fiche_id'],
 {'confirmation_requise':BOOLEEN,'seance_id':texte(36),'nombre_questions':entier(),'nombre_items_disponibles':entier(),'usage_assistant':objet(libre=True),'seances_en_attente':tableau(objet(libre=True),20),'total_seances_ouvertes':entier(),'suite_seances_ouvertes':BOOLEEN,'consigne':texte(),'message':texte()},True)
retour=objet({'difficulte':choix('facile','adaptee','difficile','non_indiquee'),'commentaire':texte(2000),'reformulations':tableau(objet({'item_id':ID,'suggestion':texte(1000,minLength=1)},['item_id','suggestion']),20),'ajouts':tableau(texte(500,minLength=1),20)},['difficulte','reformulations','ajouts'])
echange=objet({'item_id':ID,'question':texte(500,minLength=1),'etat':choix('tente','saute'),
 'reponse':texte(2000),'correction':texte(1000),'aide':choix('aucune','indice','correction')},['item_id','question','etat'])
outil('clore_seance','Enregistrer le compte rendu de séance',
 'Après les questions, envoyer en UN appel les évaluations, le déroulement factuel, le retour et une synthèse. Vision enregistre le tout atomiquement. Un gain rapproché ou aidé trop élevé est réduit explicitement à la valeur admissible dans rapport.ajustements ; annoncer la correction. Les versions vieillies par une autre séance sont rafraîchies dans le rapport. Sans réponses connues, ne rien inventer : sur demande explicite, clore avec évaluations=[], déroulement=[] et retour non_indiquee. En cas de réponse réseau perdue, rejouer exactement la même requête.',
 {'seance_id':texte(36,minLength=36),'evaluations':tableau(evaluation,20),'deroulement':tableau(echange,40),'retour':retour,'synthese':texte(2000)},['seance_id','evaluations','deroulement','retour'],{'rapport':objet(libre=True)},True)
outil('enregistrer_fiche','Créer ou modifier une fiche',
 'Création seulement sur demande explicite : titre et contenu requis. Pour modifier, fournir id et version lus et uniquement les champs à changer. suivi est une synthèse actuelle, sans chronologie redondante. P entière entre −20 et +20 dB ; positive avance la révision. Ne changer une priorité personnelle qu’à la demande. archive est réversible. Aucun état mémoriel de fiche.',
 {'id':ID,'version':entier(1),'titre':texte(200,minLength=1),'contenu':texte(50000,minLength=1),'suivi':texte(),'alias':tableau(texte(120)),'tags':tableau(texte(64)),'priorite':entier(-20,20),'archive':BOOLEEN},[],{'fiche':objet(libre=True)},True)
outil('enregistrer_item','Créer ou modifier un item',
 'Avant création, rechercher globalement avec le même titre puis lire les candidats ; preuve_recherche requise. Réutiliser une même connaissance au lieu de la recréer. S’il s’agit d’un homonyme distinct, expliquer distinction (au moins 10 caractères). Création : titre, contenu, objectifs et sens requis ; S=-15 dB par défaut. Toute autre initialisation exige justification. reference_a est un départ déclaré, pas une évaluation inventée ; omettre si inconnue. Modification avec id et version : pas de changement de S ou de date mémoire, utiliser evaluer_items. Ne pas fusionner automatiquement. Un seul S pour tous les sens ; conserver les asymétries dans suivi.',
 {'id':ID,'version':entier(1),'titre':texte(200,minLength=1),'contenu':texte(12000,minLength=1),'suivi':texte(),'alias':tableau(texte(120)),'objectifs':tableau(texte(500),12,1),'sens':tableau(texte(300),12,1),'stabilite':entier(-128,127),'reference_a':nullable(date()),'justification':texte(1000),'preuve_recherche':texte(40),'distinction':texte(1000),'archive':BOOLEEN},[],{'item':objet(libre=True)},True)
outil('lier_item','Rattacher ou détacher un item',
 'Réutiliser un item existant dans une autre fiche. Fournir la version courante de la fiche. Le lien porte seulement ordre et contexte propre à la fiche. Détacher ne supprime ni l’item ni ses autres liens et ne change jamais S ou sa date. Répéter un rattachement identique ne crée aucun doublon.',
 {'fiche_id':ID,'item_id':ID,'version_fiche':entier(1),'action':choix('rattacher','detacher'),'ordre':entier(0,1000000),'contexte':texte(1000)},['fiche_id','item_id','version_fiche','action'],{'fiche':objet(libre=True),'item_id':ID,'modifie':BOOLEEN},True)
outil('evaluer_items','Actualiser les items après une tentative',
 'Écriture ponctuelle hors séance pour un ajustement explicite. Pour une séance interactive, utiliser ouvrir_seance puis clore_seance avec toutes les évaluations et le retour final, sans écriture entre les réponses. Les évaluations sont atomiques, versionnées et idempotentes.',
 {'conversation':texte(100,minLength=1),'evaluations':tableau(evaluation,20,1)},['evaluations'],{'evaluations':tableau(objet(libre=True),20)},True)
question=objet({'item_id':ID,'question':texte(500),'sens':texte(300),'aide':choix('aucune','indice','correction')},['item_id','question'])
outil('enregistrer_contexte','Conserver un contexte minimal de reprise',
 'Conserver uniquement fiche, items actifs, jusqu’à 12 questions/aides et une synthèse de reprise ≤2000 caractères ; aucune conversation complète. Version=0 à la création, puis version lue dans preparer_revision. Une conversation n’est pas une séance. Fin de séance : consolider sans rejouer les gains ni créer de nouveaux items. Contexte conservé 90 jours, au plus 50 conversations actives par compte.',
 {'conversation':texte(100,minLength=1),'version':entier(),'fiche_id':nullable(ID),'items':tableau(ID,20),'reprise':texte(2000),'questions':tableau(question,12)},['conversation','version'],{'contexte':objet(libre=True)},True)
outil('regler_politique','Régler l’intervalle et le budget de révision',
 'Uniquement sur demande de l’utilisateur. T est une politique, 90 jours par défaut (1–3650), pas une probabilité de rappel. budget est un nombre d’items distincts par jour, null désactive l’adaptation. G augmente les intervalles lorsque la charge estimée dépasse ce budget ; déplacement d’au plus 1 dB par semaine, entre 0 et 30. Aucun changement de S. Fournir la version du profil renvoyée par une lecture.',
 {'version':entier(),'intervalle_jours':entier(1,3650),'budget':nullable(entier(1,1000))},['version','intervalle_jours','budget'],{},True)

def generer():
 (RACINE/'docs/outils.json').write_text(json.dumps(OUTILS,ensure_ascii=False,indent=2)+'\n')
 chemins={}
 for outil in OUTILS:
  chemins['/api/v1/'+outil['name']]={'post':{'operationId':outil['name'],'summary':outil['title'],'description':outil['description'],'requestBody':{'required':True,'content':{'application/json':{'schema':outil['inputSchema']}}},'responses':{'200':{'description':'Résultat de l’opération ; vérifier erreur et enregistre.','content':{'application/json':{'schema':outil['outputSchema']}}},'400':{'description':'Paramètres ou règle métier invalides.'},'401':{'description':'Authentification Basic et identité interne requises.'},'409':{'description':'Version périmée ou clé réutilisée ; relire sans écraser.'},'503':{'description':'Base indisponible.'}}}}
 doc={'openapi':'3.1.0','info':{'title':'Vision — fiches et items','version':'2.2.0'},'servers':[{'url':'https://vision.mrj.am'}],'security':[{'basicAuth':[]}],'paths':chemins,'components':{'securitySchemes':{'basicAuth':{'type':'http','scheme':'basic'}}}}
 (RACINE/'docs/openapi.json').write_text(json.dumps(doc,ensure_ascii=False,indent=2)+'\n')
if __name__=='__main__':generer()
