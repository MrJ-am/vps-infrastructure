"""Critères documentaires mesurés dans Chromium ; données synthétiques, API doublée.
Ces tests complètent les parcours PostgreSQL de refonte.py sans les remplacer.
"""
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import json
import os
import threading
from playwright.sync_api import sync_playwright, expect

RACINE = Path(__file__).resolve().parents[1]


class Silencieux(SimpleHTTPRequestHandler):
    def log_message(self, *_):
        pass

    def do_GET(self):
        if self.path in ["/docs", "/docs/", "/privacy"]:
            self.path = "/app.html"
        super().do_GET()


def verifier(page, url, largeur, tactile=False):
    appels = []
    fiches = [dict(id=i+1, titre=t, priorite=-2, nombre_items=2, version=1,
                    contenu='Un contenu de référence.\n\n**Une distinction essentielle.**', suivi='', items=[], nombre_fiches=0)
              for i, t in enumerate(['Théorie des situations didactiques', 'Capitales européennes',
                                     'Raisonnement et démonstration', 'Algèbre linéaire', 'Probabilités'])]
    items = [dict(id=101+i, titre=t, stabilite=-15, version=1, contenu="Un objectif précis.",
                  fiches=[fiches[0]], nombre_fiches=1)
             for i,t in enumerate(["Distinguer situation et milieu", "Formuler les conditions de validation"])]
    for fiche in fiches:
        fiche["items"] = [dict(item, fiches=[]) for item in items]
    def api(route):
        op = route.request.url.rsplit('/', 1)[-1]
        parametres = route.request.post_data_json or {}
        appels.append((op, parametres))
        if op == 'session':
            resultat = dict(username='compte-synthetique', csrf='test-local')
        elif op == 'rechercher':
            resultat = dict(resultats=fiches, total=5, politique={})
        elif op == 'lire':
            resultat = dict(objets=[next(f for f in (fiches if parametres['type']=='fiche' else items) if f['id'] == parametres['ids'][0])])
        else:
            raise AssertionError(f'Écriture inattendue : {op}')
        route.fulfill(status=200, json=resultat)
    page.route('**/auth/session', api)
    page.route('**/api/web/**', api)
    page.goto(url)
    table = page.get_by_role('table', name='Résultats', exact=True)
    expect(table.get_by_role('row')).to_have_count(6)
    page.evaluate('document.fonts.ready')
    expect(table.get_by_role('link')).to_have_count(5)
    expect(table.get_by_role('button')).to_have_count(0)
    lien = table.get_by_role('link').first
    expect(lien).to_have_attribute('href', '#fiche/1')
    mesures = table.evaluate('''table => {
      const lignes = [...table.querySelectorAll('[role=row]')];
      return {hauteurs:lignes.map(e=>e.getBoundingClientRect().height),
        cellules:lignes.map(e=>[...e.children].map(c=>({x:c.getBoundingClientRect().x,largeur:c.getBoundingClientRect().width}))),
        rayons:[...table.querySelectorAll('a')].map(e=>parseFloat(getComputedStyle(e).borderRadius))};
    }''')
    # Ni cartes ni boutons dans les lignes ; une vraie densité de lecture.
    assert all(30 <= h <= 64 for h in mesures['hauteurs']), mesures
    assert all(mesures['hauteurs'][i] <= 48 for i in [0,2,4,5]), mesures
    assert all(r <= 4 for r in mesures['rayons']), mesures
    for ligne in mesures['cellules'][1:]:
        assert all(abs(a['x']-b['x']) < 1 and abs(a['largeur']-b['largeur']) < 1
                   for a,b in zip(ligne, mesures['cellules'][0])), mesures
    action = page.get_by_role('button', name='Nouvelle fiche', exact=True)
    assert 32 <= action.bounding_box()['height'] <= 38, action.evaluate('(e)=>[e.outerHTML,getComputedStyle(e).width,getComputedStyle(e).height]')
    assert page.evaluate('document.documentElement.scrollWidth <= innerWidth + 1'), page.evaluate('[...document.querySelectorAll("body *")].filter(e=>e.getBoundingClientRect().right>innerWidth+1 && getComputedStyle(e).position!=="absolute").map(e=>[e.tagName,e.className,e.getBoundingClientRect().x,e.getBoundingClientRect().width]).slice(0,12)')
    if largeur >= 768:
        assert mesures['cellules'][0][0]['largeur'] > mesures['cellules'][0][1]['largeur'] * 1.5
    # Les menus restent atteignables au clavier, à 320 px et avec pointeur tactile.
    menu = page.get_by_role('button', name='Ouvrir le menu', exact=True)
    assert 32 <= menu.bounding_box()['width'] <= 38
    menu.focus(); menu.press('Enter')
    expect(menu).to_have_attribute('aria-expanded', 'true')
    expect(page.get_by_role('link', name='Tokens d’accès', exact=True)).to_be_visible()
    assert page.evaluate('document.documentElement.scrollWidth <= innerWidth + 1')
    menu.press('Escape')
    expect(menu).to_have_attribute('aria-expanded', 'false')
    filtres=page.get_by_role('button',name='Filtres et tri',exact=True)
    filtres.click()
    with page.expect_response('**/api/web/rechercher'):
        page.get_by_label('État',exact=True).select_option('archive')
    assert appels[-1][1]['etat']=='archive'
    with page.expect_response('**/api/web/rechercher'):
        page.get_by_label('Tri',exact=True).select_option('priorite')
    assert appels[-1][1]['tri']=='priorite'
    filtres.click()
    page.get_by_label('Recherche', exact=True).fill('didactique')
    with page.expect_response('**/api/web/rechercher'):
        page.get_by_label('Recherche', exact=True).press('Enter')
    assert appels[-1][1]['requete'] == 'didactique'
    page.screenshot(path=str(RACINE/'rapports'/f'documentaire-{largeur}{"-tactile" if tactile else ""}.png'), full_page=True)
    lien.focus(); lien.press('Enter')
    expect(page.get_by_role('heading', name=fiches[0]['titre'], exact=True)).to_be_visible()
    assert page.url.endswith('#fiche/1')
    expect(page.get_by_role('heading', name=fiches[0]['titre'], exact=True)).to_be_focused()
    assert page.get_by_role('button').evaluate_all('es => es.every(e => getComputedStyle(e).boxShadow === "none")')
    relations=page.get_by_role('table',name='Rattachements',exact=True)
    expect(relations.get_by_role('link')).to_have_count(2)
    expect(relations.get_by_role('button').first).to_have_text('Détacher')
    page.screenshot(path=str(RACINE/'rapports'/f'detail-{largeur}.png'), full_page=True)
    relations.get_by_role('link').first.click()
    expect(page.get_by_role('heading',name=items[0]['titre'],exact=True)).to_be_visible()
    assert page.url.endswith('#item/101')
    page.get_by_role('table',name='Rattachements',exact=True).get_by_role('link').click()
    expect(page.get_by_role('heading',name=fiches[0]['titre'],exact=True)).to_be_visible()
    # Un lien profond survit au rechargement et ne produit aucune écriture.
    page.reload()
    expect(page.get_by_role('heading', name=fiches[0]['titre'], exact=True)).to_be_visible()
    page.get_by_role('button', name='Modifier', exact=True).click()
    page.get_by_label('Titre', exact=True).fill('Brouillon à préserver')
    page.evaluate('location.hash="#fiche/2"')
    expect(page.get_by_label('Titre', exact=True)).to_have_value('Brouillon à préserver')
    expect(page).to_have_url(url+'#fiche/1')
    page.get_by_role('button', name='Fermer la saisie', exact=True).click()
    dialogue = page.get_by_role('dialog', name='Confirmer', exact=True)
    expect(dialogue).to_be_visible()
    assert page.evaluate('document.documentElement.scrollWidth <= innerWidth + 1'), page.evaluate('[innerWidth,document.documentElement.scrollWidth,[...document.querySelectorAll("body *")].filter(e=>e.getBoundingClientRect().right>innerWidth+1 && !e.closest("[role=region]")).map(e=>[e.tagName,e.className,e.getBoundingClientRect().x,e.getBoundingClientRect().width]).slice(0,15)]')
    page.screenshot(path=str(RACINE/'rapports'/f'edition-{largeur}.png'), full_page=True)
    dialogue.press('Escape')
    expect(dialogue).to_have_count(0)
    expect(page.get_by_label('Titre', exact=True)).to_have_value('Brouillon à préserver')
    return dict(largeur=largeur, tactile=tactile, **mesures)


def main():
    (RACINE/'rapports').mkdir(exist_ok=True)
    serveur = ThreadingHTTPServer(('127.0.0.1', 0), partial(Silencieux, directory=str(RACINE/'dist')))
    threading.Thread(target=serveur.serve_forever, daemon=True).start()
    resultats=[]
    try:
        with sync_playwright() as pw:
            navigateur=pw.chromium.launch(**({'executable_path':os.environ['CHROMIUM']} if 'CHROMIUM' in os.environ else {}))
            for largeur,tactile in [(320,False),(375,True),(768,False),(1280,False)]:
                contexte=navigateur.new_context(viewport=dict(width=largeur,height=900),has_touch=tactile)
                page=contexte.new_page()
                page.set_default_timeout(5000)
                try:
                    resultats.append(verifier(page, f'http://127.0.0.1:{serveur.server_port}/', largeur, tactile))
                except Exception:
                    page.screenshot(path=str(RACINE/'rapports'/'graphisme-echec.png'),full_page=True)
                    raise
                finally:
                    contexte.close()
            page=navigateur.new_page()
            appels_prives=[]
            page.on('request',lambda r:appels_prives.append(r.url) if '/auth/' in r.url or '/api/' in r.url else None)
            for chemin,titre in [('/docs','Fiches et items'),('/docs/','Fiches et items'),('/privacy','Confidentialité')]:
                page.goto(f'http://127.0.0.1:{serveur.server_port}'+chemin,wait_until='networkidle')
                expect(page.get_by_role('heading',name=titre,exact=True)).to_be_visible()
            assert not appels_prives,appels_prives
            navigateur.close()
    finally:
        serveur.shutdown()
    (RACINE/'rapports'/'graphisme.json').write_text(json.dumps(resultats,ensure_ascii=False,indent=2)+'\n')
    print('Densité, alignement, liens profonds, clavier, tactile, menus et brouillons : 4 formats réussis.')


if __name__ == '__main__':
    main()
