# État du portage ElmUI — mise à jour du 23 septembre 2026

Le menu de l’interface `cb92ffa7e4ea5b547e09c9ad1d6dbe01c7e93ccf` donne accès à la gestion des tokens sur `/auth/mcp`. Son artefact validé par la CI 35801855474 a été préparé sur le VPS par 35805254157 puis publié et vérifié par 35805299046. Le manifeste, les fichiers servis, la connexion, la lecture et le lien du menu ont été contrôlés. La page gère des tokens indépendants sans révoquer celui de Mistral. Les références ci-dessous décrivent la publication initiale du portage le 21 septembre.


## Interface publiée

L'interface ElmUI est **déployée et enregistrée depuis 22:32 UTC** sur
[vision.mrj.am](https://vision.mrj.am/). La
[bascule VPS nº 35663052741](https://github.com/MrJ-am/vps-infrastructure/actions/runs/35663052741)
a vérifié les fichiers servis, le navigateur réel et l'authentification avant
d'enregistrer la génération. Les sources validées sont intégrées à `main`.

| Élément | Révision exacte |
|---|---|
| Interface Vision publiée | `9a4c395b24e6eb8938a3246c96f5d80c030c2d2d` |
| Bibliothèque style-mrjam | `c7b4d6e00cd0014a0a05e5a4e77627357498faa9` |
| Signature | `17495b13cefa24473e37434b98336b27caec8cdf` |
| Candidat d'infrastructure activé | `d224ab32928c43ef7f9445804077a2dbfb0fdfba` |
| Serveur Common Lisp conservé | `151ab64bd5c9c5c54297e88dbe4d548343cc4928` — 1.3.0 |

Le portage réside dans `interface/`. Nginx sert son artefact immuable depuis
`/srv/vision-interface/current` ; le serveur Lisp, ses migrations et ses
données sont conservés. Les fichiers historiques `docs/app.*` restent dans
les sources, mais ne sont plus l'interface servie à la racine. Le manifeste
public est [interface-manifest.json](https://vision.mrj.am/interface-manifest.json).

## Compléments intégrés

Les composants communs `MrJam.Donnees`, `MrJam.Lecture` et `MrJam.Fenetres`
sont publiés dans la bibliothèque et effectivement consommés par Vision :
tableaux accessibles, nombres et dates spécialisés, lecture Markdown et
fenêtres de confirmation/correction. Les filtres d'état et de tri utilisent
les sélecteurs compacts communs. Les dates du modèle conservent leur précision.

Le Markdown prend en charge les titres, listes, citations, blocs de code et
mises en forme en ligne prévues par le lecteur commun. Le HTML brut et les
ressources externes ne sont pas exécutés. Les dialogues utilisent `dialog`
avec fond inerte, focus initial, boucle Tab/Maj+Tab, Échap et restitution du focus.

Les polices exactes sont récupérées de Signature dans le dépôt privé, avec
leurs empreintes et leur provenance. La signature reste le texte sélectionnable
`MrJ.am`. Aucun remplacement typographique n'est utilisé dans la publication ;
toute utilisation du logo et de la signature reste strictement réservée.

## Vérifications réussies

- [Bibliothèque : 35660762183](https://github.com/MrJ-am/style-mrjam/actions/runs/35660762183) :
  compilation, galerie HTTP, données, Markdown et dialogues accessibles.
- [Interface : 35661734934](https://github.com/MrJ-am/vision/actions/runs/35661734934) :
  installation neuve, empreintes, compilation optimisée, Chromium avec doublures,
  puis Common Lisp et PostgreSQL isolés ; quatre largeurs d'écran.
- [Serveur historique : 35661734943](https://github.com/MrJ-am/vision/actions/runs/35661734943) :
  contrats OpenAPI, module de déploiement, FSRS-6, HTTP, MCP et PostgreSQL.
- [Préparation VPS : 35662657824](https://github.com/MrJ-am/vps-infrastructure/actions/runs/35662657824)
  et [simulation complète : 35662944719](https://github.com/MrJ-am/vps-infrastructure/actions/runs/35662944719) :
  sauvegardes chiffrées, invariants conservés, vrai test Nginx, timer indépendant ;
  seul Nginx devait redémarrer.
- [Production : 35663052741](https://github.com/MrJ-am/vps-infrastructure/actions/runs/35663052741) :
  les 13 empreintes et le manifeste correspondent à l'artefact validé ; rendu
  à 375 et 1280 pixels, police, connexion avec le compte permanent, cookie
  Secure/HttpOnly/SameSite, CSRF, refus d'origine étrangère, lecture PostgreSQL,
  Basic et révocation. Nouvelle connexion SSH, six services et 22 contrôles HTTP/TLS.

Les tests d'interaction conservent pagination, recherche et réponses tardives,
conflits sans écrasement, restauration d'un brouillon pour le même compte,
absence de fuite vers un autre compte, création, édition, archivage réversible,
corrections et version originale. Les écritures d'essai utilisent seulement
PostgreSQL isolé. Aucune donnée fictive ni écriture métier en production.
Les seules captures de production montrent une page de connexion vide.

## Artefact et limites

L'artefact `interface-vision-verifiee`, identifiant `10667189503`, provient
de la CI applicative ci-dessus. SHA-256 de son ZIP :
`fd945480853899899cd40bf8b3bdbc92ade6d72feb46af2949e706a18b1560c3`.
Le JavaScript est publié tel qu'il a été testé ; aucune reconstruction pendant
l'activation. Les modalités de compilation sont dans [interface/README.md](../interface/README.md).

Les historiques affichés restent ceux de l'API actuelle : 20 modifications
manuelles récentes et, pour une observation, la dernière correction et l'original.
Les anciennes entrées ne sont ni supprimées ni réécrites ; les observations
restent toutes accessibles par pagination. Il ne s'agit pas d'un navigateur
exhaustif des corrections intermédiaires.

Cette publication termine le portage et la mise en service de Vision demandés
par le propriétaire. Elle n'atteste pas la migration des autres applications
ni l'installation d'un orchestrateur collectif. Apprendre à démontrer est traité
en parallèle ; toute évolution suivante du style suit la coordination décrite
dans la bibliothèque. Le retour applicatif ne restaure jamais une base.
