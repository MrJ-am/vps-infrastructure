# Modèle fiches–items, version db-1

## Représentation et planification

Fiche : titre, contenu structuré, alias, tags, priorité P, suivi facultatif,
version, archive. Item : connaissance, objectifs, sens, alias, stabilité S,
suivi facultatif, référence temporelle, état évalué et version. Une relation
porte ordre et contexte ; elle ne duplique jamais S. P est bornée à −20…+20,
S à −128…+127. Les bornes sont vérifiées, jamais appliquées par saturation.

`I = T × 10^((S − P + G)/10)` ; `U = 10 log10(Δt/T) − S + P − G`.
La fenêtre vaut exactement `[T × 10^((S−P+G−1)/10), T × 10^((S−P+G+1)/10)]`
depuis la référence. U=−1 et U=+1 sont ses bornes. Une date absente ne devient
pas artificiellement « maintenant » ; une date future est signalée. Au-delà
100 ans, les durées restent calculables mais aucune date débordante n’est créée.
Les intervalles de moins d’une minute sont signalés.

T vaut 90 jours et peut être explicitement changé entre 1 et 3650 jours ; les
préréglages usuels sont 7, 14, 30 et 90. Un item neuf commence à −15 dB, sans
référence si aucune date pertinente n’est connue. +3 dB multiplie I par 1,995 ;
+5 par 3,162. Ces valeurs sont une échelle de suivi heuristique, sans promesse
scientifique de durabilité. Le calibrage complet de Q est dans [MCP.md](MCP.md).

Une révision demandée utilise P de la fiche et reste possible hors fenêtre.
Sans cible, chaque item actif est compté une fois, à la P maximale des fiches
actives ; en cas d’égalité, l’identifiant départage. Chaque fiche suggérée reçoit
la moyenne des trois U les plus hauts, plafonnés à 20, plus un bonus d’au plus
0,5 lié au nombre d’items. Le volume brut d’une grande fiche ne décide donc pas
seul. Les références inconnues restent sélectionnables. La sélection ciblée
privilégie le suivi utile, les items non évalués, puis U ; les épisodes de moins
de quinze minutes sont exclus sauf demande explicite de répétition.

Le budget facultatif estime la demande depuis les items distincts, à partir de
`Σ 1/max(1 jour,I sans G)`. G cible vaut le plafond de `10 log10(demande/budget)`,
borné à 0…30 ; il évolue d’au plus 1 dB/semaine lors d’une écriture. La suppression
du budget remet G à zéro. Ce réglage collectif ne change aucune stabilité.

## Épisodes, concurrences et confidentialité

Une tentative et ses précisions partagent une clé d’épisode. Le Q enregistré
est cumulatif : +2 puis +3 ajoute +1. Une tentative ultérieure crée un épisode
distinct, même dans le même fil. Date et S avant sont préservées. Le journal
minimal documente la correction ; la synthèse qualitative n’est pas un journal
de conversation. Une édition ou un suivi seul ne repousse pas la référence.
Un état évalué à date inconnue reste distinct de jamais évalué.

Version d’item, version d’épisode et verrou transactionnel par compte protègent
les écritures. Les lots sont atomiques. Le rejeu reprend `cle`, `emise_a` et le
corps exact ; réutiliser une clé avec un autre corps est un conflit. Une requête
de plus de 30 jours est refusée même après purge. Les épisodes/contextes sont
conservés 90 jours, les requêtes 35 jours et le journal 180 jours/5000 entrées.
Les contextes sont limités à 50 par compte ; les recherches préalables expirent
après 30 minutes. Les sources de migration ne sont pas purgées avec ces traces.

La recherche utilise texte français et trigrammes `pg_trgm`, avec index GIN,
alias et contenu. Toute création exige une recherche globale complète et la
lecture des candidats, archives comprises. Un changement du catalogue invalide
la preuve. Cela limite les doublons concurrents sans prétendre décider de
l’identité sémantique : la réutilisation ou la distinction restent explicites.
L’extension est additive et n’exige ni version majeure nouvelle ni accès réseau SQL.

## Migration des données historiques

`scripts/refonte.py` extrait un plan des données réelles relues. Les capitales
sont séparées par association et chaque observation attribuée à son item ; TSD
conserve son contenu structuré et ses neuf concepts explicites, sans ajouter
un exemple non demandé. Une fiche inconnue ou une trace impossible à attribuer
arrête la préparation avant toute écriture.

La correspondance initiale est prudente : −20 pour un dernier oubli, −17 pour
une réussite après oubli, −16 pour un rappel partiel, −12 pour un rappel correct
sans oubli enregistré, −15 sans évaluation. Aucune valeur FSRS n’est transposée
et aucun Q historique rejoué. Les dernières dates factuelles sont conservées.
L’ancienne importance devient P=importance−3 : l’intention relative reste
explicite, sans sommer les priorités. Le rapport donne la répartition réellement
appliquée. Les items non évalués conservent une référence inconnue.

Les tables 1.x restent présentes. `vision_migrations_metier` archive leur source
JSON exacte avec le rapport. L’import vérifie l’empreinte sous verrou et est
idempotent ; une nouvelle source exige un nouveau plan. Une copie du dump est
restaurée dans une base isolée, où simulation, import et rejeu sont vérifiés.
Cette vérification est refaite sur une sauvegarde fraîche après arrêt du service
juste avant la migration réelle. Le plan de préparation n’est pas réutilisé.

Le retour autonome rétablit les anciens binaires et l’ancienne interface,
sans restaurer de base. Après import, les anciennes tables sont protégées contre
les écritures pour empêcher une divergence silencieuse. Les données Vision 2,
y compris celles entrées après bascule, restent intactes. Une reprise complète
passe par une version corrective 2.x ; restaurer un ancien dump exigerait d’abord
un export et une conciliation des écritures nouvelles, jamais une restauration
aveugle. Le passage 2.x invalide les contrats d’écriture des anciens clients.

## Vérifications et limites constatées

CI backend du 25 septembre 2026, exécution `36138948151`, PostgreSQL 17 isolé :

| Fiches | Items distincts | Liens | Suggestions, processus psql inclus | Recherche indexée SQL |
|---:|---:|---:|---:|---:|
| 5 | 40 | 120 | 49 ms | 0,08 ms |
| 500 | 4 000 | 12 000 | 316 ms | 1,69 ms |
| 5 000 | 10 000 | 30 000 | 769 ms | 3,32 ms |

Les plans `EXPLAIN ANALYZE` sont dans l’artefact `mesures-refonte`. Il s’agit de
mesures synthétiques en CI, pas d’une garantie de latence sur le VPS. La réponse
de suggestions reste inférieure à 1 Ko dans ces jeux ; les lectures et les
contextes sont bornés. La sélection globale parcourt les items du compte :
un volume beaucoup plus grand peut demander une matérialisation, à mesurer.

Les tests vérifient l’algèbre, les épisodes, les conflits, les reprises, l’isolation
et les parcours navigateur. La qualité d’une évaluation en langage naturel,
l’identification de formulations équivalentes et la discrétion du dialogue
restent dépendantes du modèle client ; ce ne sont pas des garanties SQL.
