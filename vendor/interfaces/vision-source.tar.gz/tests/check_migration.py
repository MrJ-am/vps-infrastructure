#!/usr/bin/env python3
import importlib.util,json,os,subprocess
from pathlib import Path
s=importlib.util.spec_from_file_location('refonte',Path(__file__).resolve().parents[1]/'scripts/refonte.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
# Données synthétiques propres à cette base isolée, sans copie de production.
m.sql("""INSERT INTO vision_memory_sheets(id,title,body,importance) OVERRIDING SYSTEM VALUE VALUES
(100000,'Capitales européennes','Objectif : deux sens.\n- Arménie → Erevan\n- Belgique → Bruxelles\n- Albanie → Tirana',3);
SELECT jsonb_build_object('ok',true);""")
m.sql("""INSERT INTO vision_memory_observations(sheet_id,outcome,note,reviewed_at)
SELECT id,'forgotten','Albanie → Tirana : oubli.','2026-01-01T10:00:00Z' FROM vision_memory_sheets WHERE title='Capitales européennes';
INSERT INTO vision_memory_observations(sheet_id,outcome,note,reviewed_at)
SELECT id,'recalled','Albanie → Tirana : rappel correct.','2026-01-01T10:10:00Z' FROM vision_memory_sheets WHERE title='Capitales européennes';
SELECT jsonb_build_object('ok',true);""")
plan=m.preparer();assert plan['rapport']['items_prevus']==3;assert plan['rapport']['sans_evaluation']==2
albanie=next(i for i in plan['fiches'][0]['items'] if i['titre'].startswith('Albanie'))
assert albanie['stabilite']==-17 and albanie['evalue_a'].startswith('2026-01-01T10:10')
# Une simulation ne laisse ni objets ni archivage.
r=m.appliquer('migration_test',plan,True);assert r['items_apres']==3
assert m.sql("SELECT to_jsonb(count(*)) FROM vision_items WHERE utilisateur='migration_test'")==0
r=m.appliquer('migration_test',plan);r2=m.appliquer('migration_test',plan)
assert r['items_apres']==r2['items_apres']==3 and r2['rejeu']
assert m.sql("SELECT to_jsonb(count(*)) FROM vision_migrations_metier")==1
assert m.sql("SELECT to_jsonb(bool_and(evalue_a IS NULL AND reference_a IS NULL)) FROM vision_items WHERE utilisateur='migration_test' AND titre NOT LIKE 'Albanie%'")
try:m.sql("UPDATE vision_memory_sheets SET body='écriture obsolète';SELECT '{}'::jsonb;")
except RuntimeError:pass
else:raise AssertionError('Le retour à un ancien client doit conserver les nouvelles écritures.')
print('Migration : simulation annulée, dates conservées, relance idempotente et ancien modèle protégé.')
