(function(scope){
'use strict';

function F(arity, fun, wrapper) {
  wrapper.a = arity;
  wrapper.f = fun;
  return wrapper;
}

function F2(fun) {
  return F(2, fun, function(a) { return function(b) { return fun(a,b); }; })
}
function F3(fun) {
  return F(3, fun, function(a) {
    return function(b) { return function(c) { return fun(a, b, c); }; };
  });
}
function F4(fun) {
  return F(4, fun, function(a) { return function(b) { return function(c) {
    return function(d) { return fun(a, b, c, d); }; }; };
  });
}
function F5(fun) {
  return F(5, fun, function(a) { return function(b) { return function(c) {
    return function(d) { return function(e) { return fun(a, b, c, d, e); }; }; }; };
  });
}
function F6(fun) {
  return F(6, fun, function(a) { return function(b) { return function(c) {
    return function(d) { return function(e) { return function(f) {
    return fun(a, b, c, d, e, f); }; }; }; }; };
  });
}
function F7(fun) {
  return F(7, fun, function(a) { return function(b) { return function(c) {
    return function(d) { return function(e) { return function(f) {
    return function(g) { return fun(a, b, c, d, e, f, g); }; }; }; }; }; };
  });
}
function F8(fun) {
  return F(8, fun, function(a) { return function(b) { return function(c) {
    return function(d) { return function(e) { return function(f) {
    return function(g) { return function(h) {
    return fun(a, b, c, d, e, f, g, h); }; }; }; }; }; }; };
  });
}
function F9(fun) {
  return F(9, fun, function(a) { return function(b) { return function(c) {
    return function(d) { return function(e) { return function(f) {
    return function(g) { return function(h) { return function(i) {
    return fun(a, b, c, d, e, f, g, h, i); }; }; }; }; }; }; }; };
  });
}

function A2(fun, a, b) {
  return fun.a === 2 ? fun.f(a, b) : fun(a)(b);
}
function A3(fun, a, b, c) {
  return fun.a === 3 ? fun.f(a, b, c) : fun(a)(b)(c);
}
function A4(fun, a, b, c, d) {
  return fun.a === 4 ? fun.f(a, b, c, d) : fun(a)(b)(c)(d);
}
function A5(fun, a, b, c, d, e) {
  return fun.a === 5 ? fun.f(a, b, c, d, e) : fun(a)(b)(c)(d)(e);
}
function A6(fun, a, b, c, d, e, f) {
  return fun.a === 6 ? fun.f(a, b, c, d, e, f) : fun(a)(b)(c)(d)(e)(f);
}
function A7(fun, a, b, c, d, e, f, g) {
  return fun.a === 7 ? fun.f(a, b, c, d, e, f, g) : fun(a)(b)(c)(d)(e)(f)(g);
}
function A8(fun, a, b, c, d, e, f, g, h) {
  return fun.a === 8 ? fun.f(a, b, c, d, e, f, g, h) : fun(a)(b)(c)(d)(e)(f)(g)(h);
}
function A9(fun, a, b, c, d, e, f, g, h, i) {
  return fun.a === 9 ? fun.f(a, b, c, d, e, f, g, h, i) : fun(a)(b)(c)(d)(e)(f)(g)(h)(i);
}




var _JsArray_empty = [];

function _JsArray_singleton(value)
{
    return [value];
}

function _JsArray_length(array)
{
    return array.length;
}

var _JsArray_initialize = F3(function(size, offset, func)
{
    var result = new Array(size);

    for (var i = 0; i < size; i++)
    {
        result[i] = func(offset + i);
    }

    return result;
});

var _JsArray_initializeFromList = F2(function (max, ls)
{
    var result = new Array(max);

    for (var i = 0; i < max && ls.b; i++)
    {
        result[i] = ls.a;
        ls = ls.b;
    }

    result.length = i;
    return _Utils_Tuple2(result, ls);
});

var _JsArray_unsafeGet = F2(function(index, array)
{
    return array[index];
});

var _JsArray_unsafeSet = F3(function(index, value, array)
{
    var length = array.length;
    var result = new Array(length);

    for (var i = 0; i < length; i++)
    {
        result[i] = array[i];
    }

    result[index] = value;
    return result;
});

var _JsArray_push = F2(function(value, array)
{
    var length = array.length;
    var result = new Array(length + 1);

    for (var i = 0; i < length; i++)
    {
        result[i] = array[i];
    }

    result[length] = value;
    return result;
});

var _JsArray_foldl = F3(function(func, acc, array)
{
    var length = array.length;

    for (var i = 0; i < length; i++)
    {
        acc = A2(func, array[i], acc);
    }

    return acc;
});

var _JsArray_foldr = F3(function(func, acc, array)
{
    for (var i = array.length - 1; i >= 0; i--)
    {
        acc = A2(func, array[i], acc);
    }

    return acc;
});

var _JsArray_map = F2(function(func, array)
{
    var length = array.length;
    var result = new Array(length);

    for (var i = 0; i < length; i++)
    {
        result[i] = func(array[i]);
    }

    return result;
});

var _JsArray_indexedMap = F3(function(func, offset, array)
{
    var length = array.length;
    var result = new Array(length);

    for (var i = 0; i < length; i++)
    {
        result[i] = A2(func, offset + i, array[i]);
    }

    return result;
});

var _JsArray_slice = F3(function(from, to, array)
{
    return array.slice(from, to);
});

var _JsArray_appendN = F3(function(n, dest, source)
{
    var destLen = dest.length;
    var itemsToCopy = n - destLen;

    if (itemsToCopy > source.length)
    {
        itemsToCopy = source.length;
    }

    var size = destLen + itemsToCopy;
    var result = new Array(size);

    for (var i = 0; i < destLen; i++)
    {
        result[i] = dest[i];
    }

    for (var i = 0; i < itemsToCopy; i++)
    {
        result[i + destLen] = source[i];
    }

    return result;
});



// LOG

var _Debug_log = F2(function(tag, value)
{
	return value;
});

var _Debug_log_UNUSED = F2(function(tag, value)
{
	console.log(tag + ': ' + _Debug_toString(value));
	return value;
});


// TODOS

function _Debug_todo(moduleName, region)
{
	return function(message) {
		_Debug_crash(8, moduleName, region, message);
	};
}

function _Debug_todoCase(moduleName, region, value)
{
	return function(message) {
		_Debug_crash(9, moduleName, region, value, message);
	};
}


// TO STRING

function _Debug_toString(value)
{
	return '<internals>';
}

function _Debug_toString_UNUSED(value)
{
	return _Debug_toAnsiString(false, value);
}

function _Debug_toAnsiString(ansi, value)
{
	if (typeof value === 'function')
	{
		return _Debug_internalColor(ansi, '<function>');
	}

	if (typeof value === 'boolean')
	{
		return _Debug_ctorColor(ansi, value ? 'True' : 'False');
	}

	if (typeof value === 'number')
	{
		return _Debug_numberColor(ansi, value + '');
	}

	if (value instanceof String)
	{
		return _Debug_charColor(ansi, "'" + _Debug_addSlashes(value, true) + "'");
	}

	if (typeof value === 'string')
	{
		return _Debug_stringColor(ansi, '"' + _Debug_addSlashes(value, false) + '"');
	}

	if (typeof value === 'object' && '$' in value)
	{
		var tag = value.$;

		if (typeof tag === 'number')
		{
			return _Debug_internalColor(ansi, '<internals>');
		}

		if (tag[0] === '#')
		{
			var output = [];
			for (var k in value)
			{
				if (k === '$') continue;
				output.push(_Debug_toAnsiString(ansi, value[k]));
			}
			return '(' + output.join(',') + ')';
		}

		if (tag === 'Set_elm_builtin')
		{
			return _Debug_ctorColor(ansi, 'Set')
				+ _Debug_fadeColor(ansi, '.fromList') + ' '
				+ _Debug_toAnsiString(ansi, $elm$core$Set$toList(value));
		}

		if (tag === 'RBNode_elm_builtin' || tag === 'RBEmpty_elm_builtin')
		{
			return _Debug_ctorColor(ansi, 'Dict')
				+ _Debug_fadeColor(ansi, '.fromList') + ' '
				+ _Debug_toAnsiString(ansi, $elm$core$Dict$toList(value));
		}

		if (tag === 'Array_elm_builtin')
		{
			return _Debug_ctorColor(ansi, 'Array')
				+ _Debug_fadeColor(ansi, '.fromList') + ' '
				+ _Debug_toAnsiString(ansi, $elm$core$Array$toList(value));
		}

		if (tag === '::' || tag === '[]')
		{
			var output = '[';

			value.b && (output += _Debug_toAnsiString(ansi, value.a), value = value.b)

			for (; value.b; value = value.b) // WHILE_CONS
			{
				output += ',' + _Debug_toAnsiString(ansi, value.a);
			}
			return output + ']';
		}

		var output = '';
		for (var i in value)
		{
			if (i === '$') continue;
			var str = _Debug_toAnsiString(ansi, value[i]);
			var c0 = str[0];
			var parenless = c0 === '{' || c0 === '(' || c0 === '[' || c0 === '<' || c0 === '"' || str.indexOf(' ') < 0;
			output += ' ' + (parenless ? str : '(' + str + ')');
		}
		return _Debug_ctorColor(ansi, tag) + output;
	}

	if (typeof DataView === 'function' && value instanceof DataView)
	{
		return _Debug_stringColor(ansi, '<' + value.byteLength + ' bytes>');
	}

	if (typeof File !== 'undefined' && value instanceof File)
	{
		return _Debug_internalColor(ansi, '<' + value.name + '>');
	}

	if (typeof value === 'object')
	{
		var output = [];
		for (var key in value)
		{
			var field = key[0] === '_' ? key.slice(1) : key;
			output.push(_Debug_fadeColor(ansi, field) + ' = ' + _Debug_toAnsiString(ansi, value[key]));
		}
		if (output.length === 0)
		{
			return '{}';
		}
		return '{ ' + output.join(', ') + ' }';
	}

	return _Debug_internalColor(ansi, '<internals>');
}

function _Debug_addSlashes(str, isChar)
{
	var s = str
		.replace(/\\/g, '\\\\')
		.replace(/\n/g, '\\n')
		.replace(/\t/g, '\\t')
		.replace(/\r/g, '\\r')
		.replace(/\v/g, '\\v')
		.replace(/\0/g, '\\0');

	if (isChar)
	{
		return s.replace(/\'/g, '\\\'');
	}
	else
	{
		return s.replace(/\"/g, '\\"');
	}
}

function _Debug_ctorColor(ansi, string)
{
	return ansi ? '\x1b[96m' + string + '\x1b[0m' : string;
}

function _Debug_numberColor(ansi, string)
{
	return ansi ? '\x1b[95m' + string + '\x1b[0m' : string;
}

function _Debug_stringColor(ansi, string)
{
	return ansi ? '\x1b[93m' + string + '\x1b[0m' : string;
}

function _Debug_charColor(ansi, string)
{
	return ansi ? '\x1b[92m' + string + '\x1b[0m' : string;
}

function _Debug_fadeColor(ansi, string)
{
	return ansi ? '\x1b[37m' + string + '\x1b[0m' : string;
}

function _Debug_internalColor(ansi, string)
{
	return ansi ? '\x1b[36m' + string + '\x1b[0m' : string;
}

function _Debug_toHexDigit(n)
{
	return String.fromCharCode(n < 10 ? 48 + n : 55 + n);
}


// CRASH


function _Debug_crash(identifier)
{
	throw new Error('https://github.com/elm/core/blob/1.0.0/hints/' + identifier + '.md');
}


function _Debug_crash_UNUSED(identifier, fact1, fact2, fact3, fact4)
{
	switch(identifier)
	{
		case 0:
			throw new Error('What node should I take over? In JavaScript I need something like:\n\n    Elm.Main.init({\n        node: document.getElementById("elm-node")\n    })\n\nYou need to do this with any Browser.sandbox or Browser.element program.');

		case 1:
			throw new Error('Browser.application programs cannot handle URLs like this:\n\n    ' + document.location.href + '\n\nWhat is the root? The root of your file system? Try looking at this program with `elm reactor` or some other server.');

		case 2:
			var jsonErrorString = fact1;
			throw new Error('Problem with the flags given to your Elm program on initialization.\n\n' + jsonErrorString);

		case 3:
			var portName = fact1;
			throw new Error('There can only be one port named `' + portName + '`, but your program has multiple.');

		case 4:
			var portName = fact1;
			var problem = fact2;
			throw new Error('Trying to send an unexpected type of value through port `' + portName + '`:\n' + problem);

		case 5:
			throw new Error('Trying to use `(==)` on functions.\nThere is no way to know if functions are "the same" in the Elm sense.\nRead more about this at https://package.elm-lang.org/packages/elm/core/latest/Basics#== which describes why it is this way and what the better version will look like.');

		case 6:
			var moduleName = fact1;
			throw new Error('Your page is loading multiple Elm scripts with a module named ' + moduleName + '. Maybe a duplicate script is getting loaded accidentally? If not, rename one of them so I know which is which!');

		case 8:
			var moduleName = fact1;
			var region = fact2;
			var message = fact3;
			throw new Error('TODO in module `' + moduleName + '` ' + _Debug_regionToString(region) + '\n\n' + message);

		case 9:
			var moduleName = fact1;
			var region = fact2;
			var value = fact3;
			var message = fact4;
			throw new Error(
				'TODO in module `' + moduleName + '` from the `case` expression '
				+ _Debug_regionToString(region) + '\n\nIt received the following value:\n\n    '
				+ _Debug_toString(value).replace('\n', '\n    ')
				+ '\n\nBut the branch that handles it says:\n\n    ' + message.replace('\n', '\n    ')
			);

		case 10:
			throw new Error('Bug in https://github.com/elm/virtual-dom/issues');

		case 11:
			throw new Error('Cannot perform mod 0. Division by zero error.');
	}
}

function _Debug_regionToString(region)
{
	if (region.cN.bC === region.c9.bC)
	{
		return 'on line ' + region.cN.bC;
	}
	return 'on lines ' + region.cN.bC + ' through ' + region.c9.bC;
}



// EQUALITY

function _Utils_eq(x, y)
{
	for (
		var pair, stack = [], isEqual = _Utils_eqHelp(x, y, 0, stack);
		isEqual && (pair = stack.pop());
		isEqual = _Utils_eqHelp(pair.a, pair.b, 0, stack)
		)
	{}

	return isEqual;
}

function _Utils_eqHelp(x, y, depth, stack)
{
	if (x === y)
	{
		return true;
	}

	if (typeof x !== 'object' || x === null || y === null)
	{
		typeof x === 'function' && _Debug_crash(5);
		return false;
	}

	if (depth > 100)
	{
		stack.push(_Utils_Tuple2(x,y));
		return true;
	}

	/**_UNUSED/
	if (x.$ === 'Set_elm_builtin')
	{
		x = $elm$core$Set$toList(x);
		y = $elm$core$Set$toList(y);
	}
	if (x.$ === 'RBNode_elm_builtin' || x.$ === 'RBEmpty_elm_builtin')
	{
		x = $elm$core$Dict$toList(x);
		y = $elm$core$Dict$toList(y);
	}
	//*/

	/**/
	if (x.$ < 0)
	{
		x = $elm$core$Dict$toList(x);
		y = $elm$core$Dict$toList(y);
	}
	//*/

	for (var key in x)
	{
		if (!_Utils_eqHelp(x[key], y[key], depth + 1, stack))
		{
			return false;
		}
	}
	return true;
}

var _Utils_equal = F2(_Utils_eq);
var _Utils_notEqual = F2(function(a, b) { return !_Utils_eq(a,b); });



// COMPARISONS

// Code in Generate/JavaScript.hs, Basics.js, and List.js depends on
// the particular integer values assigned to LT, EQ, and GT.

function _Utils_cmp(x, y, ord)
{
	if (typeof x !== 'object')
	{
		return x === y ? /*EQ*/ 0 : x < y ? /*LT*/ -1 : /*GT*/ 1;
	}

	/**_UNUSED/
	if (x instanceof String)
	{
		var a = x.valueOf();
		var b = y.valueOf();
		return a === b ? 0 : a < b ? -1 : 1;
	}
	//*/

	/**/
	if (typeof x.$ === 'undefined')
	//*/
	/**_UNUSED/
	if (x.$[0] === '#')
	//*/
	{
		return (ord = _Utils_cmp(x.a, y.a))
			? ord
			: (ord = _Utils_cmp(x.b, y.b))
				? ord
				: _Utils_cmp(x.c, y.c);
	}

	// traverse conses until end of a list or a mismatch
	for (; x.b && y.b && !(ord = _Utils_cmp(x.a, y.a)); x = x.b, y = y.b) {} // WHILE_CONSES
	return ord || (x.b ? /*GT*/ 1 : y.b ? /*LT*/ -1 : /*EQ*/ 0);
}

var _Utils_lt = F2(function(a, b) { return _Utils_cmp(a, b) < 0; });
var _Utils_le = F2(function(a, b) { return _Utils_cmp(a, b) < 1; });
var _Utils_gt = F2(function(a, b) { return _Utils_cmp(a, b) > 0; });
var _Utils_ge = F2(function(a, b) { return _Utils_cmp(a, b) >= 0; });

var _Utils_compare = F2(function(x, y)
{
	var n = _Utils_cmp(x, y);
	return n < 0 ? $elm$core$Basics$LT : n ? $elm$core$Basics$GT : $elm$core$Basics$EQ;
});


// COMMON VALUES

var _Utils_Tuple0 = 0;
var _Utils_Tuple0_UNUSED = { $: '#0' };

function _Utils_Tuple2(a, b) { return { a: a, b: b }; }
function _Utils_Tuple2_UNUSED(a, b) { return { $: '#2', a: a, b: b }; }

function _Utils_Tuple3(a, b, c) { return { a: a, b: b, c: c }; }
function _Utils_Tuple3_UNUSED(a, b, c) { return { $: '#3', a: a, b: b, c: c }; }

function _Utils_chr(c) { return c; }
function _Utils_chr_UNUSED(c) { return new String(c); }


// RECORDS

function _Utils_update(oldRecord, updatedFields)
{
	var newRecord = {};

	for (var key in oldRecord)
	{
		newRecord[key] = oldRecord[key];
	}

	for (var key in updatedFields)
	{
		newRecord[key] = updatedFields[key];
	}

	return newRecord;
}


// APPEND

var _Utils_append = F2(_Utils_ap);

function _Utils_ap(xs, ys)
{
	// append Strings
	if (typeof xs === 'string')
	{
		return xs + ys;
	}

	// append Lists
	if (!xs.b)
	{
		return ys;
	}
	var root = _List_Cons(xs.a, ys);
	xs = xs.b
	for (var curr = root; xs.b; xs = xs.b) // WHILE_CONS
	{
		curr = curr.b = _List_Cons(xs.a, ys);
	}
	return root;
}



var _List_Nil = { $: 0 };
var _List_Nil_UNUSED = { $: '[]' };

function _List_Cons(hd, tl) { return { $: 1, a: hd, b: tl }; }
function _List_Cons_UNUSED(hd, tl) { return { $: '::', a: hd, b: tl }; }


var _List_cons = F2(_List_Cons);

function _List_fromArray(arr)
{
	var out = _List_Nil;
	for (var i = arr.length; i--; )
	{
		out = _List_Cons(arr[i], out);
	}
	return out;
}

function _List_toArray(xs)
{
	for (var out = []; xs.b; xs = xs.b) // WHILE_CONS
	{
		out.push(xs.a);
	}
	return out;
}

var _List_map2 = F3(function(f, xs, ys)
{
	for (var arr = []; xs.b && ys.b; xs = xs.b, ys = ys.b) // WHILE_CONSES
	{
		arr.push(A2(f, xs.a, ys.a));
	}
	return _List_fromArray(arr);
});

var _List_map3 = F4(function(f, xs, ys, zs)
{
	for (var arr = []; xs.b && ys.b && zs.b; xs = xs.b, ys = ys.b, zs = zs.b) // WHILE_CONSES
	{
		arr.push(A3(f, xs.a, ys.a, zs.a));
	}
	return _List_fromArray(arr);
});

var _List_map4 = F5(function(f, ws, xs, ys, zs)
{
	for (var arr = []; ws.b && xs.b && ys.b && zs.b; ws = ws.b, xs = xs.b, ys = ys.b, zs = zs.b) // WHILE_CONSES
	{
		arr.push(A4(f, ws.a, xs.a, ys.a, zs.a));
	}
	return _List_fromArray(arr);
});

var _List_map5 = F6(function(f, vs, ws, xs, ys, zs)
{
	for (var arr = []; vs.b && ws.b && xs.b && ys.b && zs.b; vs = vs.b, ws = ws.b, xs = xs.b, ys = ys.b, zs = zs.b) // WHILE_CONSES
	{
		arr.push(A5(f, vs.a, ws.a, xs.a, ys.a, zs.a));
	}
	return _List_fromArray(arr);
});

var _List_sortBy = F2(function(f, xs)
{
	return _List_fromArray(_List_toArray(xs).sort(function(a, b) {
		return _Utils_cmp(f(a), f(b));
	}));
});

var _List_sortWith = F2(function(f, xs)
{
	return _List_fromArray(_List_toArray(xs).sort(function(a, b) {
		var ord = A2(f, a, b);
		return ord === $elm$core$Basics$EQ ? 0 : ord === $elm$core$Basics$LT ? -1 : 1;
	}));
});



// MATH

var _Basics_add = F2(function(a, b) { return a + b; });
var _Basics_sub = F2(function(a, b) { return a - b; });
var _Basics_mul = F2(function(a, b) { return a * b; });
var _Basics_fdiv = F2(function(a, b) { return a / b; });
var _Basics_idiv = F2(function(a, b) { return (a / b) | 0; });
var _Basics_pow = F2(Math.pow);

var _Basics_remainderBy = F2(function(b, a) { return a % b; });

// https://www.microsoft.com/en-us/research/wp-content/uploads/2016/02/divmodnote-letter.pdf
var _Basics_modBy = F2(function(modulus, x)
{
	var answer = x % modulus;
	return modulus === 0
		? _Debug_crash(11)
		:
	((answer > 0 && modulus < 0) || (answer < 0 && modulus > 0))
		? answer + modulus
		: answer;
});


// TRIGONOMETRY

var _Basics_pi = Math.PI;
var _Basics_e = Math.E;
var _Basics_cos = Math.cos;
var _Basics_sin = Math.sin;
var _Basics_tan = Math.tan;
var _Basics_acos = Math.acos;
var _Basics_asin = Math.asin;
var _Basics_atan = Math.atan;
var _Basics_atan2 = F2(Math.atan2);


// MORE MATH

function _Basics_toFloat(x) { return x; }
function _Basics_truncate(n) { return n | 0; }
function _Basics_isInfinite(n) { return n === Infinity || n === -Infinity; }

var _Basics_ceiling = Math.ceil;
var _Basics_floor = Math.floor;
var _Basics_round = Math.round;
var _Basics_sqrt = Math.sqrt;
var _Basics_log = Math.log;
var _Basics_isNaN = isNaN;


// BOOLEANS

function _Basics_not(bool) { return !bool; }
var _Basics_and = F2(function(a, b) { return a && b; });
var _Basics_or  = F2(function(a, b) { return a || b; });
var _Basics_xor = F2(function(a, b) { return a !== b; });



var _String_cons = F2(function(chr, str)
{
	return chr + str;
});

function _String_uncons(string)
{
	var word = string.charCodeAt(0);
	return !isNaN(word)
		? $elm$core$Maybe$Just(
			0xD800 <= word && word <= 0xDBFF
				? _Utils_Tuple2(_Utils_chr(string[0] + string[1]), string.slice(2))
				: _Utils_Tuple2(_Utils_chr(string[0]), string.slice(1))
		)
		: $elm$core$Maybe$Nothing;
}

var _String_append = F2(function(a, b)
{
	return a + b;
});

function _String_length(str)
{
	return str.length;
}

var _String_map = F2(function(func, string)
{
	var len = string.length;
	var array = new Array(len);
	var i = 0;
	while (i < len)
	{
		var word = string.charCodeAt(i);
		if (0xD800 <= word && word <= 0xDBFF)
		{
			array[i] = func(_Utils_chr(string[i] + string[i+1]));
			i += 2;
			continue;
		}
		array[i] = func(_Utils_chr(string[i]));
		i++;
	}
	return array.join('');
});

var _String_filter = F2(function(isGood, str)
{
	var arr = [];
	var len = str.length;
	var i = 0;
	while (i < len)
	{
		var char = str[i];
		var word = str.charCodeAt(i);
		i++;
		if (0xD800 <= word && word <= 0xDBFF)
		{
			char += str[i];
			i++;
		}

		if (isGood(_Utils_chr(char)))
		{
			arr.push(char);
		}
	}
	return arr.join('');
});

function _String_reverse(str)
{
	var len = str.length;
	var arr = new Array(len);
	var i = 0;
	while (i < len)
	{
		var word = str.charCodeAt(i);
		if (0xD800 <= word && word <= 0xDBFF)
		{
			arr[len - i] = str[i + 1];
			i++;
			arr[len - i] = str[i - 1];
			i++;
		}
		else
		{
			arr[len - i] = str[i];
			i++;
		}
	}
	return arr.join('');
}

var _String_foldl = F3(function(func, state, string)
{
	var len = string.length;
	var i = 0;
	while (i < len)
	{
		var char = string[i];
		var word = string.charCodeAt(i);
		i++;
		if (0xD800 <= word && word <= 0xDBFF)
		{
			char += string[i];
			i++;
		}
		state = A2(func, _Utils_chr(char), state);
	}
	return state;
});

var _String_foldr = F3(function(func, state, string)
{
	var i = string.length;
	while (i--)
	{
		var char = string[i];
		var word = string.charCodeAt(i);
		if (0xDC00 <= word && word <= 0xDFFF)
		{
			i--;
			char = string[i] + char;
		}
		state = A2(func, _Utils_chr(char), state);
	}
	return state;
});

var _String_split = F2(function(sep, str)
{
	return str.split(sep);
});

var _String_join = F2(function(sep, strs)
{
	return strs.join(sep);
});

var _String_slice = F3(function(start, end, str) {
	return str.slice(start, end);
});

function _String_trim(str)
{
	return str.trim();
}

function _String_trimLeft(str)
{
	return str.replace(/^\s+/, '');
}

function _String_trimRight(str)
{
	return str.replace(/\s+$/, '');
}

function _String_words(str)
{
	return _List_fromArray(str.trim().split(/\s+/g));
}

function _String_lines(str)
{
	return _List_fromArray(str.split(/\r\n|\r|\n/g));
}

function _String_toUpper(str)
{
	return str.toUpperCase();
}

function _String_toLower(str)
{
	return str.toLowerCase();
}

var _String_any = F2(function(isGood, string)
{
	var i = string.length;
	while (i--)
	{
		var char = string[i];
		var word = string.charCodeAt(i);
		if (0xDC00 <= word && word <= 0xDFFF)
		{
			i--;
			char = string[i] + char;
		}
		if (isGood(_Utils_chr(char)))
		{
			return true;
		}
	}
	return false;
});

var _String_all = F2(function(isGood, string)
{
	var i = string.length;
	while (i--)
	{
		var char = string[i];
		var word = string.charCodeAt(i);
		if (0xDC00 <= word && word <= 0xDFFF)
		{
			i--;
			char = string[i] + char;
		}
		if (!isGood(_Utils_chr(char)))
		{
			return false;
		}
	}
	return true;
});

var _String_contains = F2(function(sub, str)
{
	return str.indexOf(sub) > -1;
});

var _String_startsWith = F2(function(sub, str)
{
	return str.indexOf(sub) === 0;
});

var _String_endsWith = F2(function(sub, str)
{
	return str.length >= sub.length &&
		str.lastIndexOf(sub) === str.length - sub.length;
});

var _String_indexes = F2(function(sub, str)
{
	var subLen = sub.length;

	if (subLen < 1)
	{
		return _List_Nil;
	}

	var i = 0;
	var is = [];

	while ((i = str.indexOf(sub, i)) > -1)
	{
		is.push(i);
		i = i + subLen;
	}

	return _List_fromArray(is);
});


// TO STRING

function _String_fromNumber(number)
{
	return number + '';
}


// INT CONVERSIONS

function _String_toInt(str)
{
	var total = 0;
	var code0 = str.charCodeAt(0);
	var start = code0 == 0x2B /* + */ || code0 == 0x2D /* - */ ? 1 : 0;

	for (var i = start; i < str.length; ++i)
	{
		var code = str.charCodeAt(i);
		if (code < 0x30 || 0x39 < code)
		{
			return $elm$core$Maybe$Nothing;
		}
		total = 10 * total + code - 0x30;
	}

	return i == start
		? $elm$core$Maybe$Nothing
		: $elm$core$Maybe$Just(code0 == 0x2D ? -total : total);
}


// FLOAT CONVERSIONS

function _String_toFloat(s)
{
	// check if it is a hex, octal, or binary number
	if (s.length === 0 || /[\sxbo]/.test(s))
	{
		return $elm$core$Maybe$Nothing;
	}
	var n = +s;
	// faster isNaN check
	return n === n ? $elm$core$Maybe$Just(n) : $elm$core$Maybe$Nothing;
}

function _String_fromList(chars)
{
	return _List_toArray(chars).join('');
}




function _Char_toCode(char)
{
	var code = char.charCodeAt(0);
	if (0xD800 <= code && code <= 0xDBFF)
	{
		return (code - 0xD800) * 0x400 + char.charCodeAt(1) - 0xDC00 + 0x10000
	}
	return code;
}

function _Char_fromCode(code)
{
	return _Utils_chr(
		(code < 0 || 0x10FFFF < code)
			? '\uFFFD'
			:
		(code <= 0xFFFF)
			? String.fromCharCode(code)
			:
		(code -= 0x10000,
			String.fromCharCode(Math.floor(code / 0x400) + 0xD800, code % 0x400 + 0xDC00)
		)
	);
}

function _Char_toUpper(char)
{
	return _Utils_chr(char.toUpperCase());
}

function _Char_toLower(char)
{
	return _Utils_chr(char.toLowerCase());
}

function _Char_toLocaleUpper(char)
{
	return _Utils_chr(char.toLocaleUpperCase());
}

function _Char_toLocaleLower(char)
{
	return _Utils_chr(char.toLocaleLowerCase());
}



/**_UNUSED/
function _Json_errorToString(error)
{
	return $elm$json$Json$Decode$errorToString(error);
}
//*/


// CORE DECODERS

function _Json_succeed(msg)
{
	return {
		$: 0,
		a: msg
	};
}

function _Json_fail(msg)
{
	return {
		$: 1,
		a: msg
	};
}

function _Json_decodePrim(decoder)
{
	return { $: 2, b: decoder };
}

var _Json_decodeInt = _Json_decodePrim(function(value) {
	return (typeof value !== 'number')
		? _Json_expecting('an INT', value)
		:
	(-2147483647 < value && value < 2147483647 && (value | 0) === value)
		? $elm$core$Result$Ok(value)
		:
	(isFinite(value) && !(value % 1))
		? $elm$core$Result$Ok(value)
		: _Json_expecting('an INT', value);
});

var _Json_decodeBool = _Json_decodePrim(function(value) {
	return (typeof value === 'boolean')
		? $elm$core$Result$Ok(value)
		: _Json_expecting('a BOOL', value);
});

var _Json_decodeFloat = _Json_decodePrim(function(value) {
	return (typeof value === 'number')
		? $elm$core$Result$Ok(value)
		: _Json_expecting('a FLOAT', value);
});

var _Json_decodeValue = _Json_decodePrim(function(value) {
	return $elm$core$Result$Ok(_Json_wrap(value));
});

var _Json_decodeString = _Json_decodePrim(function(value) {
	return (typeof value === 'string')
		? $elm$core$Result$Ok(value)
		: (value instanceof String)
			? $elm$core$Result$Ok(value + '')
			: _Json_expecting('a STRING', value);
});

function _Json_decodeList(decoder) { return { $: 3, b: decoder }; }
function _Json_decodeArray(decoder) { return { $: 4, b: decoder }; }

function _Json_decodeNull(value) { return { $: 5, c: value }; }

var _Json_decodeField = F2(function(field, decoder)
{
	return {
		$: 6,
		d: field,
		b: decoder
	};
});

var _Json_decodeIndex = F2(function(index, decoder)
{
	return {
		$: 7,
		e: index,
		b: decoder
	};
});

function _Json_decodeKeyValuePairs(decoder)
{
	return {
		$: 8,
		b: decoder
	};
}

function _Json_mapMany(f, decoders)
{
	return {
		$: 9,
		f: f,
		g: decoders
	};
}

var _Json_andThen = F2(function(callback, decoder)
{
	return {
		$: 10,
		b: decoder,
		h: callback
	};
});

function _Json_oneOf(decoders)
{
	return {
		$: 11,
		g: decoders
	};
}


// DECODING OBJECTS

var _Json_map1 = F2(function(f, d1)
{
	return _Json_mapMany(f, [d1]);
});

var _Json_map2 = F3(function(f, d1, d2)
{
	return _Json_mapMany(f, [d1, d2]);
});

var _Json_map3 = F4(function(f, d1, d2, d3)
{
	return _Json_mapMany(f, [d1, d2, d3]);
});

var _Json_map4 = F5(function(f, d1, d2, d3, d4)
{
	return _Json_mapMany(f, [d1, d2, d3, d4]);
});

var _Json_map5 = F6(function(f, d1, d2, d3, d4, d5)
{
	return _Json_mapMany(f, [d1, d2, d3, d4, d5]);
});

var _Json_map6 = F7(function(f, d1, d2, d3, d4, d5, d6)
{
	return _Json_mapMany(f, [d1, d2, d3, d4, d5, d6]);
});

var _Json_map7 = F8(function(f, d1, d2, d3, d4, d5, d6, d7)
{
	return _Json_mapMany(f, [d1, d2, d3, d4, d5, d6, d7]);
});

var _Json_map8 = F9(function(f, d1, d2, d3, d4, d5, d6, d7, d8)
{
	return _Json_mapMany(f, [d1, d2, d3, d4, d5, d6, d7, d8]);
});


// DECODE

var _Json_runOnString = F2(function(decoder, string)
{
	try
	{
		var value = JSON.parse(string);
		return _Json_runHelp(decoder, value);
	}
	catch (e)
	{
		return $elm$core$Result$Err(A2($elm$json$Json$Decode$Failure, 'This is not valid JSON! ' + e.message, _Json_wrap(string)));
	}
});

var _Json_run = F2(function(decoder, value)
{
	return _Json_runHelp(decoder, _Json_unwrap(value));
});

function _Json_runHelp(decoder, value)
{
	switch (decoder.$)
	{
		case 2:
			return decoder.b(value);

		case 5:
			return (value === null)
				? $elm$core$Result$Ok(decoder.c)
				: _Json_expecting('null', value);

		case 3:
			if (!_Json_isArray(value))
			{
				return _Json_expecting('a LIST', value);
			}
			return _Json_runArrayDecoder(decoder.b, value, _List_fromArray);

		case 4:
			if (!_Json_isArray(value))
			{
				return _Json_expecting('an ARRAY', value);
			}
			return _Json_runArrayDecoder(decoder.b, value, _Json_toElmArray);

		case 6:
			var field = decoder.d;
			if (typeof value !== 'object' || value === null || !(field in value))
			{
				return _Json_expecting('an OBJECT with a field named `' + field + '`', value);
			}
			var result = _Json_runHelp(decoder.b, value[field]);
			return ($elm$core$Result$isOk(result)) ? result : $elm$core$Result$Err(A2($elm$json$Json$Decode$Field, field, result.a));

		case 7:
			var index = decoder.e;
			if (!_Json_isArray(value))
			{
				return _Json_expecting('an ARRAY', value);
			}
			if (index >= value.length)
			{
				return _Json_expecting('a LONGER array. Need index ' + index + ' but only see ' + value.length + ' entries', value);
			}
			var result = _Json_runHelp(decoder.b, value[index]);
			return ($elm$core$Result$isOk(result)) ? result : $elm$core$Result$Err(A2($elm$json$Json$Decode$Index, index, result.a));

		case 8:
			if (typeof value !== 'object' || value === null || _Json_isArray(value))
			{
				return _Json_expecting('an OBJECT', value);
			}

			var keyValuePairs = _List_Nil;
			// TODO test perf of Object.keys and switch when support is good enough
			for (var key in value)
			{
				if (value.hasOwnProperty(key))
				{
					var result = _Json_runHelp(decoder.b, value[key]);
					if (!$elm$core$Result$isOk(result))
					{
						return $elm$core$Result$Err(A2($elm$json$Json$Decode$Field, key, result.a));
					}
					keyValuePairs = _List_Cons(_Utils_Tuple2(key, result.a), keyValuePairs);
				}
			}
			return $elm$core$Result$Ok($elm$core$List$reverse(keyValuePairs));

		case 9:
			var answer = decoder.f;
			var decoders = decoder.g;
			for (var i = 0; i < decoders.length; i++)
			{
				var result = _Json_runHelp(decoders[i], value);
				if (!$elm$core$Result$isOk(result))
				{
					return result;
				}
				answer = answer(result.a);
			}
			return $elm$core$Result$Ok(answer);

		case 10:
			var result = _Json_runHelp(decoder.b, value);
			return (!$elm$core$Result$isOk(result))
				? result
				: _Json_runHelp(decoder.h(result.a), value);

		case 11:
			var errors = _List_Nil;
			for (var temp = decoder.g; temp.b; temp = temp.b) // WHILE_CONS
			{
				var result = _Json_runHelp(temp.a, value);
				if ($elm$core$Result$isOk(result))
				{
					return result;
				}
				errors = _List_Cons(result.a, errors);
			}
			return $elm$core$Result$Err($elm$json$Json$Decode$OneOf($elm$core$List$reverse(errors)));

		case 1:
			return $elm$core$Result$Err(A2($elm$json$Json$Decode$Failure, decoder.a, _Json_wrap(value)));

		case 0:
			return $elm$core$Result$Ok(decoder.a);
	}
}

function _Json_runArrayDecoder(decoder, value, toElmValue)
{
	var len = value.length;
	var array = new Array(len);
	for (var i = 0; i < len; i++)
	{
		var result = _Json_runHelp(decoder, value[i]);
		if (!$elm$core$Result$isOk(result))
		{
			return $elm$core$Result$Err(A2($elm$json$Json$Decode$Index, i, result.a));
		}
		array[i] = result.a;
	}
	return $elm$core$Result$Ok(toElmValue(array));
}

function _Json_isArray(value)
{
	return Array.isArray(value) || (typeof FileList !== 'undefined' && value instanceof FileList);
}

function _Json_toElmArray(array)
{
	return A2($elm$core$Array$initialize, array.length, function(i) { return array[i]; });
}

function _Json_expecting(type, value)
{
	return $elm$core$Result$Err(A2($elm$json$Json$Decode$Failure, 'Expecting ' + type, _Json_wrap(value)));
}


// EQUALITY

function _Json_equality(x, y)
{
	if (x === y)
	{
		return true;
	}

	if (x.$ !== y.$)
	{
		return false;
	}

	switch (x.$)
	{
		case 0:
		case 1:
			return x.a === y.a;

		case 2:
			return x.b === y.b;

		case 5:
			return x.c === y.c;

		case 3:
		case 4:
		case 8:
			return _Json_equality(x.b, y.b);

		case 6:
			return x.d === y.d && _Json_equality(x.b, y.b);

		case 7:
			return x.e === y.e && _Json_equality(x.b, y.b);

		case 9:
			return x.f === y.f && _Json_listEquality(x.g, y.g);

		case 10:
			return x.h === y.h && _Json_equality(x.b, y.b);

		case 11:
			return _Json_listEquality(x.g, y.g);
	}
}

function _Json_listEquality(aDecoders, bDecoders)
{
	var len = aDecoders.length;
	if (len !== bDecoders.length)
	{
		return false;
	}
	for (var i = 0; i < len; i++)
	{
		if (!_Json_equality(aDecoders[i], bDecoders[i]))
		{
			return false;
		}
	}
	return true;
}


// ENCODE

var _Json_encode = F2(function(indentLevel, value)
{
	return JSON.stringify(_Json_unwrap(value), null, indentLevel) + '';
});

function _Json_wrap_UNUSED(value) { return { $: 0, a: value }; }
function _Json_unwrap_UNUSED(value) { return value.a; }

function _Json_wrap(value) { return value; }
function _Json_unwrap(value) { return value; }

function _Json_emptyArray() { return []; }
function _Json_emptyObject() { return {}; }

var _Json_addField = F3(function(key, value, object)
{
	object[key] = _Json_unwrap(value);
	return object;
});

function _Json_addEntry(func)
{
	return F2(function(entry, array)
	{
		array.push(_Json_unwrap(func(entry)));
		return array;
	});
}

var _Json_encodeNull = _Json_wrap(null);



// TASKS

function _Scheduler_succeed(value)
{
	return {
		$: 0,
		a: value
	};
}

function _Scheduler_fail(error)
{
	return {
		$: 1,
		a: error
	};
}

function _Scheduler_binding(callback)
{
	return {
		$: 2,
		b: callback,
		c: null
	};
}

var _Scheduler_andThen = F2(function(callback, task)
{
	return {
		$: 3,
		b: callback,
		d: task
	};
});

var _Scheduler_onError = F2(function(callback, task)
{
	return {
		$: 4,
		b: callback,
		d: task
	};
});

function _Scheduler_receive(callback)
{
	return {
		$: 5,
		b: callback
	};
}


// PROCESSES

var _Scheduler_guid = 0;

function _Scheduler_rawSpawn(task)
{
	var proc = {
		$: 0,
		e: _Scheduler_guid++,
		f: task,
		g: null,
		h: []
	};

	_Scheduler_enqueue(proc);

	return proc;
}

function _Scheduler_spawn(task)
{
	return _Scheduler_binding(function(callback) {
		callback(_Scheduler_succeed(_Scheduler_rawSpawn(task)));
	});
}

function _Scheduler_rawSend(proc, msg)
{
	proc.h.push(msg);
	_Scheduler_enqueue(proc);
}

var _Scheduler_send = F2(function(proc, msg)
{
	return _Scheduler_binding(function(callback) {
		_Scheduler_rawSend(proc, msg);
		callback(_Scheduler_succeed(_Utils_Tuple0));
	});
});

function _Scheduler_kill(proc)
{
	return _Scheduler_binding(function(callback) {
		var task = proc.f;
		if (task.$ === 2 && task.c)
		{
			task.c();
		}

		proc.f = null;

		callback(_Scheduler_succeed(_Utils_Tuple0));
	});
}


/* STEP PROCESSES

type alias Process =
  { $ : tag
  , id : unique_id
  , root : Task
  , stack : null | { $: SUCCEED | FAIL, a: callback, b: stack }
  , mailbox : [msg]
  }

*/


var _Scheduler_working = false;
var _Scheduler_queue = [];


function _Scheduler_enqueue(proc)
{
	_Scheduler_queue.push(proc);
	if (_Scheduler_working)
	{
		return;
	}
	_Scheduler_working = true;
	while (proc = _Scheduler_queue.shift())
	{
		_Scheduler_step(proc);
	}
	_Scheduler_working = false;
}


function _Scheduler_step(proc)
{
	while (proc.f)
	{
		var rootTag = proc.f.$;
		if (rootTag === 0 || rootTag === 1)
		{
			while (proc.g && proc.g.$ !== rootTag)
			{
				proc.g = proc.g.i;
			}
			if (!proc.g)
			{
				return;
			}
			proc.f = proc.g.b(proc.f.a);
			proc.g = proc.g.i;
		}
		else if (rootTag === 2)
		{
			proc.f.c = proc.f.b(function(newRoot) {
				proc.f = newRoot;
				_Scheduler_enqueue(proc);
			});
			return;
		}
		else if (rootTag === 5)
		{
			if (proc.h.length === 0)
			{
				return;
			}
			proc.f = proc.f.b(proc.h.shift());
		}
		else // if (rootTag === 3 || rootTag === 4)
		{
			proc.g = {
				$: rootTag === 3 ? 0 : 1,
				b: proc.f.b,
				i: proc.g
			};
			proc.f = proc.f.d;
		}
	}
}



function _Process_sleep(time)
{
	return _Scheduler_binding(function(callback) {
		var id = setTimeout(function() {
			callback(_Scheduler_succeed(_Utils_Tuple0));
		}, time);

		return function() { clearTimeout(id); };
	});
}




// PROGRAMS


var _Platform_worker = F4(function(impl, flagDecoder, debugMetadata, args)
{
	return _Platform_initialize(
		flagDecoder,
		args,
		impl.fj,
		impl.gG,
		impl.gh,
		function() { return function() {} }
	);
});



// INITIALIZE A PROGRAM


function _Platform_initialize(flagDecoder, args, init, update, subscriptions, stepperBuilder)
{
	var result = A2(_Json_run, flagDecoder, _Json_wrap(args ? args['flags'] : undefined));
	$elm$core$Result$isOk(result) || _Debug_crash(2 /**_UNUSED/, _Json_errorToString(result.a) /**/);
	var managers = {};
	var initPair = init(result.a);
	var model = initPair.a;
	var stepper = stepperBuilder(sendToApp, model);
	var ports = _Platform_setupEffects(managers, sendToApp);

	function sendToApp(msg, viewMetadata)
	{
		var pair = A2(update, msg, model);
		stepper(model = pair.a, viewMetadata);
		_Platform_enqueueEffects(managers, pair.b, subscriptions(model));
	}

	_Platform_enqueueEffects(managers, initPair.b, subscriptions(model));

	return ports ? { ports: ports } : {};
}



// TRACK PRELOADS
//
// This is used by code in elm/browser and elm/http
// to register any HTTP requests that are triggered by init.
//


var _Platform_preload;


function _Platform_registerPreload(url)
{
	_Platform_preload.add(url);
}



// EFFECT MANAGERS


var _Platform_effectManagers = {};


function _Platform_setupEffects(managers, sendToApp)
{
	var ports;

	// setup all necessary effect managers
	for (var key in _Platform_effectManagers)
	{
		var manager = _Platform_effectManagers[key];

		if (manager.a)
		{
			ports = ports || {};
			ports[key] = manager.a(key, sendToApp);
		}

		managers[key] = _Platform_instantiateManager(manager, sendToApp);
	}

	return ports;
}


function _Platform_createManager(init, onEffects, onSelfMsg, cmdMap, subMap)
{
	return {
		b: init,
		c: onEffects,
		d: onSelfMsg,
		e: cmdMap,
		f: subMap
	};
}


function _Platform_instantiateManager(info, sendToApp)
{
	var router = {
		g: sendToApp,
		h: undefined
	};

	var onEffects = info.c;
	var onSelfMsg = info.d;
	var cmdMap = info.e;
	var subMap = info.f;

	function loop(state)
	{
		return A2(_Scheduler_andThen, loop, _Scheduler_receive(function(msg)
		{
			var value = msg.a;

			if (msg.$ === 0)
			{
				return A3(onSelfMsg, router, value, state);
			}

			return cmdMap && subMap
				? A4(onEffects, router, value.i, value.j, state)
				: A3(onEffects, router, cmdMap ? value.i : value.j, state);
		}));
	}

	return router.h = _Scheduler_rawSpawn(A2(_Scheduler_andThen, loop, info.b));
}



// ROUTING


var _Platform_sendToApp = F2(function(router, msg)
{
	return _Scheduler_binding(function(callback)
	{
		router.g(msg);
		callback(_Scheduler_succeed(_Utils_Tuple0));
	});
});


var _Platform_sendToSelf = F2(function(router, msg)
{
	return A2(_Scheduler_send, router.h, {
		$: 0,
		a: msg
	});
});



// BAGS


function _Platform_leaf(home)
{
	return function(value)
	{
		return {
			$: 1,
			k: home,
			l: value
		};
	};
}


function _Platform_batch(list)
{
	return {
		$: 2,
		m: list
	};
}


var _Platform_map = F2(function(tagger, bag)
{
	return {
		$: 3,
		n: tagger,
		o: bag
	}
});



// PIPE BAGS INTO EFFECT MANAGERS
//
// Effects must be queued!
//
// Say your init contains a synchronous command, like Time.now or Time.here
//
//   - This will produce a batch of effects (FX_1)
//   - The synchronous task triggers the subsequent `update` call
//   - This will produce a batch of effects (FX_2)
//
// If we just start dispatching FX_2, subscriptions from FX_2 can be processed
// before subscriptions from FX_1. No good! Earlier versions of this code had
// this problem, leading to these reports:
//
//   https://github.com/elm/core/issues/980
//   https://github.com/elm/core/pull/981
//   https://github.com/elm/compiler/issues/1776
//
// The queue is necessary to avoid ordering issues for synchronous commands.


// Why use true/false here? Why not just check the length of the queue?
// The goal is to detect "are we currently dispatching effects?" If we
// are, we need to bail and let the ongoing while loop handle things.
//
// Now say the queue has 1 element. When we dequeue the final element,
// the queue will be empty, but we are still actively dispatching effects.
// So you could get queue jumping in a really tricky category of cases.
//
var _Platform_effectsQueue = [];
var _Platform_effectsActive = false;


function _Platform_enqueueEffects(managers, cmdBag, subBag)
{
	_Platform_effectsQueue.push({ p: managers, q: cmdBag, r: subBag });

	if (_Platform_effectsActive) return;

	_Platform_effectsActive = true;
	for (var fx; fx = _Platform_effectsQueue.shift(); )
	{
		_Platform_dispatchEffects(fx.p, fx.q, fx.r);
	}
	_Platform_effectsActive = false;
}


function _Platform_dispatchEffects(managers, cmdBag, subBag)
{
	var effectsDict = {};
	_Platform_gatherEffects(true, cmdBag, effectsDict, null);
	_Platform_gatherEffects(false, subBag, effectsDict, null);

	for (var home in managers)
	{
		_Scheduler_rawSend(managers[home], {
			$: 'fx',
			a: effectsDict[home] || { i: _List_Nil, j: _List_Nil }
		});
	}
}


function _Platform_gatherEffects(isCmd, bag, effectsDict, taggers)
{
	switch (bag.$)
	{
		case 1:
			var home = bag.k;
			var effect = _Platform_toEffect(isCmd, home, taggers, bag.l);
			effectsDict[home] = _Platform_insert(isCmd, effect, effectsDict[home]);
			return;

		case 2:
			for (var list = bag.m; list.b; list = list.b) // WHILE_CONS
			{
				_Platform_gatherEffects(isCmd, list.a, effectsDict, taggers);
			}
			return;

		case 3:
			_Platform_gatherEffects(isCmd, bag.o, effectsDict, {
				s: bag.n,
				t: taggers
			});
			return;
	}
}


function _Platform_toEffect(isCmd, home, taggers, value)
{
	function applyTaggers(x)
	{
		for (var temp = taggers; temp; temp = temp.t)
		{
			x = temp.s(x);
		}
		return x;
	}

	var map = isCmd
		? _Platform_effectManagers[home].e
		: _Platform_effectManagers[home].f;

	return A2(map, applyTaggers, value)
}


function _Platform_insert(isCmd, newEffect, effects)
{
	effects = effects || { i: _List_Nil, j: _List_Nil };

	isCmd
		? (effects.i = _List_Cons(newEffect, effects.i))
		: (effects.j = _List_Cons(newEffect, effects.j));

	return effects;
}



// PORTS


function _Platform_checkPortName(name)
{
	if (_Platform_effectManagers[name])
	{
		_Debug_crash(3, name)
	}
}



// OUTGOING PORTS


function _Platform_outgoingPort(name, converter)
{
	_Platform_checkPortName(name);
	_Platform_effectManagers[name] = {
		e: _Platform_outgoingPortMap,
		u: converter,
		a: _Platform_setupOutgoingPort
	};
	return _Platform_leaf(name);
}


var _Platform_outgoingPortMap = F2(function(tagger, value) { return value; });


function _Platform_setupOutgoingPort(name)
{
	var subs = [];
	var converter = _Platform_effectManagers[name].u;

	// CREATE MANAGER

	var init = _Process_sleep(0);

	_Platform_effectManagers[name].b = init;
	_Platform_effectManagers[name].c = F3(function(router, cmdList, state)
	{
		for ( ; cmdList.b; cmdList = cmdList.b) // WHILE_CONS
		{
			// grab a separate reference to subs in case unsubscribe is called
			var currentSubs = subs;
			var value = _Json_unwrap(converter(cmdList.a));
			for (var i = 0; i < currentSubs.length; i++)
			{
				currentSubs[i](value);
			}
		}
		return init;
	});

	// PUBLIC API

	function subscribe(callback)
	{
		subs.push(callback);
	}

	function unsubscribe(callback)
	{
		// copy subs into a new array in case unsubscribe is called within a
		// subscribed callback
		subs = subs.slice();
		var index = subs.indexOf(callback);
		if (index >= 0)
		{
			subs.splice(index, 1);
		}
	}

	return {
		subscribe: subscribe,
		unsubscribe: unsubscribe
	};
}



// INCOMING PORTS


function _Platform_incomingPort(name, converter)
{
	_Platform_checkPortName(name);
	_Platform_effectManagers[name] = {
		f: _Platform_incomingPortMap,
		u: converter,
		a: _Platform_setupIncomingPort
	};
	return _Platform_leaf(name);
}


var _Platform_incomingPortMap = F2(function(tagger, finalTagger)
{
	return function(value)
	{
		return tagger(finalTagger(value));
	};
});


function _Platform_setupIncomingPort(name, sendToApp)
{
	var subs = _List_Nil;
	var converter = _Platform_effectManagers[name].u;

	// CREATE MANAGER

	var init = _Scheduler_succeed(null);

	_Platform_effectManagers[name].b = init;
	_Platform_effectManagers[name].c = F3(function(router, subList, state)
	{
		subs = subList;
		return init;
	});

	// PUBLIC API

	function send(incomingValue)
	{
		var result = A2(_Json_run, converter, _Json_wrap(incomingValue));

		$elm$core$Result$isOk(result) || _Debug_crash(4, name, result.a);

		var value = result.a;
		for (var temp = subs; temp.b; temp = temp.b) // WHILE_CONS
		{
			sendToApp(temp.a(value));
		}
	}

	return { send: send };
}



// EXPORT ELM MODULES
//
// Have DEBUG and PROD versions so that we can (1) give nicer errors in
// debug mode and (2) not pay for the bits needed for that in prod mode.
//


function _Platform_export(exports)
{
	scope['Elm']
		? _Platform_mergeExportsProd(scope['Elm'], exports)
		: scope['Elm'] = exports;
}


function _Platform_mergeExportsProd(obj, exports)
{
	for (var name in exports)
	{
		(name in obj)
			? (name == 'init')
				? _Debug_crash(6)
				: _Platform_mergeExportsProd(obj[name], exports[name])
			: (obj[name] = exports[name]);
	}
}


function _Platform_export_UNUSED(exports)
{
	scope['Elm']
		? _Platform_mergeExportsDebug('Elm', scope['Elm'], exports)
		: scope['Elm'] = exports;
}


function _Platform_mergeExportsDebug(moduleName, obj, exports)
{
	for (var name in exports)
	{
		(name in obj)
			? (name == 'init')
				? _Debug_crash(6, moduleName)
				: _Platform_mergeExportsDebug(moduleName + '.' + name, obj[name], exports[name])
			: (obj[name] = exports[name]);
	}
}




// HELPERS


var _VirtualDom_divertHrefToApp;

var _VirtualDom_doc = typeof document !== 'undefined' ? document : {};


function _VirtualDom_appendChild(parent, child)
{
	parent.appendChild(child);
}

var _VirtualDom_init = F4(function(virtualNode, flagDecoder, debugMetadata, args)
{
	// NOTE: this function needs _Platform_export available to work

	/**/
	var node = args['node'];
	//*/
	/**_UNUSED/
	var node = args && args['node'] ? args['node'] : _Debug_crash(0);
	//*/

	node.parentNode.replaceChild(
		_VirtualDom_render(virtualNode, function() {}),
		node
	);

	return {};
});



// TEXT


function _VirtualDom_text(string)
{
	return {
		$: 0,
		a: string
	};
}



// NODE


var _VirtualDom_nodeNS = F2(function(namespace, tag)
{
	return F2(function(factList, kidList)
	{
		for (var kids = [], descendantsCount = 0; kidList.b; kidList = kidList.b) // WHILE_CONS
		{
			var kid = kidList.a;
			descendantsCount += (kid.b || 0);
			kids.push(kid);
		}
		descendantsCount += kids.length;

		return {
			$: 1,
			c: tag,
			d: _VirtualDom_organizeFacts(factList),
			e: kids,
			f: namespace,
			b: descendantsCount
		};
	});
});


var _VirtualDom_node = _VirtualDom_nodeNS(undefined);



// KEYED NODE


var _VirtualDom_keyedNodeNS = F2(function(namespace, tag)
{
	return F2(function(factList, kidList)
	{
		for (var kids = [], descendantsCount = 0; kidList.b; kidList = kidList.b) // WHILE_CONS
		{
			var kid = kidList.a;
			descendantsCount += (kid.b.b || 0);
			kids.push(kid);
		}
		descendantsCount += kids.length;

		return {
			$: 2,
			c: tag,
			d: _VirtualDom_organizeFacts(factList),
			e: kids,
			f: namespace,
			b: descendantsCount
		};
	});
});


var _VirtualDom_keyedNode = _VirtualDom_keyedNodeNS(undefined);



// CUSTOM


function _VirtualDom_custom(factList, model, render, diff)
{
	return {
		$: 3,
		d: _VirtualDom_organizeFacts(factList),
		g: model,
		h: render,
		i: diff
	};
}



// MAP


var _VirtualDom_map = F2(function(tagger, node)
{
	return {
		$: 4,
		j: tagger,
		k: node,
		b: 1 + (node.b || 0)
	};
});



// LAZY


function _VirtualDom_thunk(refs, thunk)
{
	return {
		$: 5,
		l: refs,
		m: thunk,
		k: undefined
	};
}

var _VirtualDom_lazy = F2(function(func, a)
{
	return _VirtualDom_thunk([func, a], function() {
		return func(a);
	});
});

var _VirtualDom_lazy2 = F3(function(func, a, b)
{
	return _VirtualDom_thunk([func, a, b], function() {
		return A2(func, a, b);
	});
});

var _VirtualDom_lazy3 = F4(function(func, a, b, c)
{
	return _VirtualDom_thunk([func, a, b, c], function() {
		return A3(func, a, b, c);
	});
});

var _VirtualDom_lazy4 = F5(function(func, a, b, c, d)
{
	return _VirtualDom_thunk([func, a, b, c, d], function() {
		return A4(func, a, b, c, d);
	});
});

var _VirtualDom_lazy5 = F6(function(func, a, b, c, d, e)
{
	return _VirtualDom_thunk([func, a, b, c, d, e], function() {
		return A5(func, a, b, c, d, e);
	});
});

var _VirtualDom_lazy6 = F7(function(func, a, b, c, d, e, f)
{
	return _VirtualDom_thunk([func, a, b, c, d, e, f], function() {
		return A6(func, a, b, c, d, e, f);
	});
});

var _VirtualDom_lazy7 = F8(function(func, a, b, c, d, e, f, g)
{
	return _VirtualDom_thunk([func, a, b, c, d, e, f, g], function() {
		return A7(func, a, b, c, d, e, f, g);
	});
});

var _VirtualDom_lazy8 = F9(function(func, a, b, c, d, e, f, g, h)
{
	return _VirtualDom_thunk([func, a, b, c, d, e, f, g, h], function() {
		return A8(func, a, b, c, d, e, f, g, h);
	});
});



// FACTS


var _VirtualDom_on = F2(function(key, handler)
{
	return {
		$: 'a0',
		n: key,
		o: handler
	};
});
var _VirtualDom_style = F2(function(key, value)
{
	return {
		$: 'a1',
		n: key,
		o: value
	};
});
var _VirtualDom_property = F2(function(key, value)
{
	return {
		$: 'a2',
		n: key,
		o: value
	};
});
var _VirtualDom_attribute = F2(function(key, value)
{
	return {
		$: 'a3',
		n: key,
		o: value
	};
});
var _VirtualDom_attributeNS = F3(function(namespace, key, value)
{
	return {
		$: 'a4',
		n: key,
		o: { f: namespace, o: value }
	};
});



// XSS ATTACK VECTOR CHECKS
//
// For some reason, tabs can appear in href protocols and it still works.
// So '\tjava\tSCRIPT:alert("!!!")' and 'javascript:alert("!!!")' are the same
// in practice. That is why _VirtualDom_RE_js and _VirtualDom_RE_js_html look
// so freaky.
//
// Pulling the regular expressions out to the top level gives a slight speed
// boost in small benchmarks (4-10%) but hoisting values to reduce allocation
// can be unpredictable in large programs where JIT may have a harder time with
// functions are not fully self-contained. The benefit is more that the js and
// js_html ones are so weird that I prefer to see them near each other.


var _VirtualDom_RE_script = /^script$/i;
var _VirtualDom_RE_on_formAction = /^(on|formAction$)/i;
var _VirtualDom_RE_js = /^\s*j\s*a\s*v\s*a\s*s\s*c\s*r\s*i\s*p\s*t\s*:/i;
var _VirtualDom_RE_js_html = /^\s*(j\s*a\s*v\s*a\s*s\s*c\s*r\s*i\s*p\s*t\s*:|d\s*a\s*t\s*a\s*:\s*t\s*e\s*x\s*t\s*\/\s*h\s*t\s*m\s*l\s*(,|;))/i;


function _VirtualDom_noScript(tag)
{
	return _VirtualDom_RE_script.test(tag) ? 'p' : tag;
}

function _VirtualDom_noOnOrFormAction(key)
{
	return _VirtualDom_RE_on_formAction.test(key) ? 'data-' + key : key;
}

function _VirtualDom_noInnerHtmlOrFormAction(key)
{
	return key == 'innerHTML' || key == 'formAction' ? 'data-' + key : key;
}

function _VirtualDom_noJavaScriptUri(value)
{
	return _VirtualDom_RE_js.test(value)
		? /**/''//*//**_UNUSED/'javascript:alert("This is an XSS vector. Please use ports or web components instead.")'//*/
		: value;
}

function _VirtualDom_noJavaScriptOrHtmlUri(value)
{
	return _VirtualDom_RE_js_html.test(value)
		? /**/''//*//**_UNUSED/'javascript:alert("This is an XSS vector. Please use ports or web components instead.")'//*/
		: value;
}

function _VirtualDom_noJavaScriptOrHtmlJson(value)
{
	return (typeof _Json_unwrap(value) === 'string' && _VirtualDom_RE_js_html.test(_Json_unwrap(value)))
		? _Json_wrap(
			/**/''//*//**_UNUSED/'javascript:alert("This is an XSS vector. Please use ports or web components instead.")'//*/
		) : value;
}



// MAP FACTS


var _VirtualDom_mapAttribute = F2(function(func, attr)
{
	return (attr.$ === 'a0')
		? A2(_VirtualDom_on, attr.n, _VirtualDom_mapHandler(func, attr.o))
		: attr;
});

function _VirtualDom_mapHandler(func, handler)
{
	var tag = $elm$virtual_dom$VirtualDom$toHandlerInt(handler);

	// 0 = Normal
	// 1 = MayStopPropagation
	// 2 = MayPreventDefault
	// 3 = Custom

	return {
		$: handler.$,
		a:
			!tag
				? A2($elm$json$Json$Decode$map, func, handler.a)
				:
			A3($elm$json$Json$Decode$map2,
				tag < 3
					? _VirtualDom_mapEventTuple
					: _VirtualDom_mapEventRecord,
				$elm$json$Json$Decode$succeed(func),
				handler.a
			)
	};
}

var _VirtualDom_mapEventTuple = F2(function(func, tuple)
{
	return _Utils_Tuple2(func(tuple.a), tuple.b);
});

var _VirtualDom_mapEventRecord = F2(function(func, record)
{
	return {
		H: func(record.H),
		gf: record.gf,
		fU: record.fU
	}
});



// ORGANIZE FACTS


function _VirtualDom_organizeFacts(factList)
{
	for (var facts = {}; factList.b; factList = factList.b) // WHILE_CONS
	{
		var entry = factList.a;

		var tag = entry.$;
		var key = entry.n;
		var value = entry.o;

		if (tag === 'a2')
		{
			(key === 'className')
				? _VirtualDom_addClass(facts, key, _Json_unwrap(value))
				: facts[key] = _Json_unwrap(value);

			continue;
		}

		var subFacts = facts[tag] || (facts[tag] = {});
		(tag === 'a3' && key === 'class')
			? _VirtualDom_addClass(subFacts, key, value)
			: subFacts[key] = value;
	}

	return facts;
}

function _VirtualDom_addClass(object, key, newClass)
{
	var classes = object[key];
	object[key] = classes ? classes + ' ' + newClass : newClass;
}



// RENDER


function _VirtualDom_render(vNode, eventNode)
{
	var tag = vNode.$;

	if (tag === 5)
	{
		return _VirtualDom_render(vNode.k || (vNode.k = vNode.m()), eventNode);
	}

	if (tag === 0)
	{
		return _VirtualDom_doc.createTextNode(vNode.a);
	}

	if (tag === 4)
	{
		var subNode = vNode.k;
		var tagger = vNode.j;

		while (subNode.$ === 4)
		{
			typeof tagger !== 'object'
				? tagger = [tagger, subNode.j]
				: tagger.push(subNode.j);

			subNode = subNode.k;
		}

		var subEventRoot = { j: tagger, p: eventNode };
		var domNode = _VirtualDom_render(subNode, subEventRoot);
		domNode.elm_event_node_ref = subEventRoot;
		return domNode;
	}

	if (tag === 3)
	{
		var domNode = vNode.h(vNode.g);
		_VirtualDom_applyFacts(domNode, eventNode, vNode.d);
		return domNode;
	}

	// at this point `tag` must be 1 or 2

	var domNode = vNode.f
		? _VirtualDom_doc.createElementNS(vNode.f, vNode.c)
		: _VirtualDom_doc.createElement(vNode.c);

	if (_VirtualDom_divertHrefToApp && vNode.c == 'a')
	{
		domNode.addEventListener('click', _VirtualDom_divertHrefToApp(domNode));
	}

	_VirtualDom_applyFacts(domNode, eventNode, vNode.d);

	for (var kids = vNode.e, i = 0; i < kids.length; i++)
	{
		_VirtualDom_appendChild(domNode, _VirtualDom_render(tag === 1 ? kids[i] : kids[i].b, eventNode));
	}

	return domNode;
}



// APPLY FACTS


function _VirtualDom_applyFacts(domNode, eventNode, facts)
{
	for (var key in facts)
	{
		var value = facts[key];

		key === 'a1'
			? _VirtualDom_applyStyles(domNode, value)
			:
		key === 'a0'
			? _VirtualDom_applyEvents(domNode, eventNode, value)
			:
		key === 'a3'
			? _VirtualDom_applyAttrs(domNode, value)
			:
		key === 'a4'
			? _VirtualDom_applyAttrsNS(domNode, value)
			:
		((key !== 'value' && key !== 'checked') || domNode[key] !== value) && (domNode[key] = value);
	}
}



// APPLY STYLES


function _VirtualDom_applyStyles(domNode, styles)
{
	var domNodeStyle = domNode.style;

	for (var key in styles)
	{
		domNodeStyle[key] = styles[key];
	}
}



// APPLY ATTRS


function _VirtualDom_applyAttrs(domNode, attrs)
{
	for (var key in attrs)
	{
		var value = attrs[key];
		typeof value !== 'undefined'
			? domNode.setAttribute(key, value)
			: domNode.removeAttribute(key);
	}
}



// APPLY NAMESPACED ATTRS


function _VirtualDom_applyAttrsNS(domNode, nsAttrs)
{
	for (var key in nsAttrs)
	{
		var pair = nsAttrs[key];
		var namespace = pair.f;
		var value = pair.o;

		typeof value !== 'undefined'
			? domNode.setAttributeNS(namespace, key, value)
			: domNode.removeAttributeNS(namespace, key);
	}
}



// APPLY EVENTS


function _VirtualDom_applyEvents(domNode, eventNode, events)
{
	var allCallbacks = domNode.elmFs || (domNode.elmFs = {});

	for (var key in events)
	{
		var newHandler = events[key];
		var oldCallback = allCallbacks[key];

		if (!newHandler)
		{
			domNode.removeEventListener(key, oldCallback);
			allCallbacks[key] = undefined;
			continue;
		}

		if (oldCallback)
		{
			var oldHandler = oldCallback.q;
			if (oldHandler.$ === newHandler.$)
			{
				oldCallback.q = newHandler;
				continue;
			}
			domNode.removeEventListener(key, oldCallback);
		}

		oldCallback = _VirtualDom_makeCallback(eventNode, newHandler);
		domNode.addEventListener(key, oldCallback,
			_VirtualDom_passiveSupported
			&& { passive: $elm$virtual_dom$VirtualDom$toHandlerInt(newHandler) < 2 }
		);
		allCallbacks[key] = oldCallback;
	}
}



// PASSIVE EVENTS


var _VirtualDom_passiveSupported;

try
{
	window.addEventListener('t', null, Object.defineProperty({}, 'passive', {
		get: function() { _VirtualDom_passiveSupported = true; }
	}));
}
catch(e) {}



// EVENT HANDLERS


function _VirtualDom_makeCallback(eventNode, initialHandler)
{
	function callback(event)
	{
		var handler = callback.q;
		var result = _Json_runHelp(handler.a, event);

		if (!$elm$core$Result$isOk(result))
		{
			return;
		}

		var tag = $elm$virtual_dom$VirtualDom$toHandlerInt(handler);

		// 0 = Normal
		// 1 = MayStopPropagation
		// 2 = MayPreventDefault
		// 3 = Custom

		var value = result.a;
		var message = !tag ? value : tag < 3 ? value.a : value.H;
		var stopPropagation = tag == 1 ? value.b : tag == 3 && value.gf;
		var currentEventNode = (
			stopPropagation && event.stopPropagation(),
			(tag == 2 ? value.b : tag == 3 && value.fU) && event.preventDefault(),
			eventNode
		);
		var tagger;
		var i;
		while (tagger = currentEventNode.j)
		{
			if (typeof tagger == 'function')
			{
				message = tagger(message);
			}
			else
			{
				for (var i = tagger.length; i--; )
				{
					message = tagger[i](message);
				}
			}
			currentEventNode = currentEventNode.p;
		}
		currentEventNode(message, stopPropagation); // stopPropagation implies isSync
	}

	callback.q = initialHandler;

	return callback;
}

function _VirtualDom_equalEvents(x, y)
{
	return x.$ == y.$ && _Json_equality(x.a, y.a);
}



// DIFF


// TODO: Should we do patches like in iOS?
//
// type Patch
//   = At Int Patch
//   | Batch (List Patch)
//   | Change ...
//
// How could it not be better?
//
function _VirtualDom_diff(x, y)
{
	var patches = [];
	_VirtualDom_diffHelp(x, y, patches, 0);
	return patches;
}


function _VirtualDom_pushPatch(patches, type, index, data)
{
	var patch = {
		$: type,
		r: index,
		s: data,
		t: undefined,
		u: undefined
	};
	patches.push(patch);
	return patch;
}


function _VirtualDom_diffHelp(x, y, patches, index)
{
	if (x === y)
	{
		return;
	}

	var xType = x.$;
	var yType = y.$;

	// Bail if you run into different types of nodes. Implies that the
	// structure has changed significantly and it's not worth a diff.
	if (xType !== yType)
	{
		if (xType === 1 && yType === 2)
		{
			y = _VirtualDom_dekey(y);
			yType = 1;
		}
		else
		{
			_VirtualDom_pushPatch(patches, 0, index, y);
			return;
		}
	}

	// Now we know that both nodes are the same $.
	switch (yType)
	{
		case 5:
			var xRefs = x.l;
			var yRefs = y.l;
			var i = xRefs.length;
			var same = i === yRefs.length;
			while (same && i--)
			{
				same = xRefs[i] === yRefs[i];
			}
			if (same)
			{
				y.k = x.k;
				return;
			}
			y.k = y.m();
			var subPatches = [];
			_VirtualDom_diffHelp(x.k, y.k, subPatches, 0);
			subPatches.length > 0 && _VirtualDom_pushPatch(patches, 1, index, subPatches);
			return;

		case 4:
			// gather nested taggers
			var xTaggers = x.j;
			var yTaggers = y.j;
			var nesting = false;

			var xSubNode = x.k;
			while (xSubNode.$ === 4)
			{
				nesting = true;

				typeof xTaggers !== 'object'
					? xTaggers = [xTaggers, xSubNode.j]
					: xTaggers.push(xSubNode.j);

				xSubNode = xSubNode.k;
			}

			var ySubNode = y.k;
			while (ySubNode.$ === 4)
			{
				nesting = true;

				typeof yTaggers !== 'object'
					? yTaggers = [yTaggers, ySubNode.j]
					: yTaggers.push(ySubNode.j);

				ySubNode = ySubNode.k;
			}

			// Just bail if different numbers of taggers. This implies the
			// structure of the virtual DOM has changed.
			if (nesting && xTaggers.length !== yTaggers.length)
			{
				_VirtualDom_pushPatch(patches, 0, index, y);
				return;
			}

			// check if taggers are "the same"
			if (nesting ? !_VirtualDom_pairwiseRefEqual(xTaggers, yTaggers) : xTaggers !== yTaggers)
			{
				_VirtualDom_pushPatch(patches, 2, index, yTaggers);
			}

			// diff everything below the taggers
			_VirtualDom_diffHelp(xSubNode, ySubNode, patches, index + 1);
			return;

		case 0:
			if (x.a !== y.a)
			{
				_VirtualDom_pushPatch(patches, 3, index, y.a);
			}
			return;

		case 1:
			_VirtualDom_diffNodes(x, y, patches, index, _VirtualDom_diffKids);
			return;

		case 2:
			_VirtualDom_diffNodes(x, y, patches, index, _VirtualDom_diffKeyedKids);
			return;

		case 3:
			if (x.h !== y.h)
			{
				_VirtualDom_pushPatch(patches, 0, index, y);
				return;
			}

			var factsDiff = _VirtualDom_diffFacts(x.d, y.d);
			factsDiff && _VirtualDom_pushPatch(patches, 4, index, factsDiff);

			var patch = y.i(x.g, y.g);
			patch && _VirtualDom_pushPatch(patches, 5, index, patch);

			return;
	}
}

// assumes the incoming arrays are the same length
function _VirtualDom_pairwiseRefEqual(as, bs)
{
	for (var i = 0; i < as.length; i++)
	{
		if (as[i] !== bs[i])
		{
			return false;
		}
	}

	return true;
}

function _VirtualDom_diffNodes(x, y, patches, index, diffKids)
{
	// Bail if obvious indicators have changed. Implies more serious
	// structural changes such that it's not worth it to diff.
	if (x.c !== y.c || x.f !== y.f)
	{
		_VirtualDom_pushPatch(patches, 0, index, y);
		return;
	}

	var factsDiff = _VirtualDom_diffFacts(x.d, y.d);
	factsDiff && _VirtualDom_pushPatch(patches, 4, index, factsDiff);

	diffKids(x, y, patches, index);
}



// DIFF FACTS


// TODO Instead of creating a new diff object, it's possible to just test if
// there *is* a diff. During the actual patch, do the diff again and make the
// modifications directly. This way, there's no new allocations. Worth it?
function _VirtualDom_diffFacts(x, y, category)
{
	var diff;

	// look for changes and removals
	for (var xKey in x)
	{
		if (xKey === 'a1' || xKey === 'a0' || xKey === 'a3' || xKey === 'a4')
		{
			var subDiff = _VirtualDom_diffFacts(x[xKey], y[xKey] || {}, xKey);
			if (subDiff)
			{
				diff = diff || {};
				diff[xKey] = subDiff;
			}
			continue;
		}

		// remove if not in the new facts
		if (!(xKey in y))
		{
			diff = diff || {};
			diff[xKey] =
				!category
					? (typeof x[xKey] === 'string' ? '' : null)
					:
				(category === 'a1')
					? ''
					:
				(category === 'a0' || category === 'a3')
					? undefined
					:
				{ f: x[xKey].f, o: undefined };

			continue;
		}

		var xValue = x[xKey];
		var yValue = y[xKey];

		// reference equal, so don't worry about it
		if (xValue === yValue && xKey !== 'value' && xKey !== 'checked'
			|| category === 'a0' && _VirtualDom_equalEvents(xValue, yValue))
		{
			continue;
		}

		diff = diff || {};
		diff[xKey] = yValue;
	}

	// add new stuff
	for (var yKey in y)
	{
		if (!(yKey in x))
		{
			diff = diff || {};
			diff[yKey] = y[yKey];
		}
	}

	return diff;
}



// DIFF KIDS


function _VirtualDom_diffKids(xParent, yParent, patches, index)
{
	var xKids = xParent.e;
	var yKids = yParent.e;

	var xLen = xKids.length;
	var yLen = yKids.length;

	// FIGURE OUT IF THERE ARE INSERTS OR REMOVALS

	if (xLen > yLen)
	{
		_VirtualDom_pushPatch(patches, 6, index, {
			v: yLen,
			i: xLen - yLen
		});
	}
	else if (xLen < yLen)
	{
		_VirtualDom_pushPatch(patches, 7, index, {
			v: xLen,
			e: yKids
		});
	}

	// PAIRWISE DIFF EVERYTHING ELSE

	for (var minLen = xLen < yLen ? xLen : yLen, i = 0; i < minLen; i++)
	{
		var xKid = xKids[i];
		_VirtualDom_diffHelp(xKid, yKids[i], patches, ++index);
		index += xKid.b || 0;
	}
}



// KEYED DIFF


function _VirtualDom_diffKeyedKids(xParent, yParent, patches, rootIndex)
{
	var localPatches = [];

	var changes = {}; // Dict String Entry
	var inserts = []; // Array { index : Int, entry : Entry }
	// type Entry = { tag : String, vnode : VNode, index : Int, data : _ }

	var xKids = xParent.e;
	var yKids = yParent.e;
	var xLen = xKids.length;
	var yLen = yKids.length;
	var xIndex = 0;
	var yIndex = 0;

	var index = rootIndex;

	while (xIndex < xLen && yIndex < yLen)
	{
		var x = xKids[xIndex];
		var y = yKids[yIndex];

		var xKey = x.a;
		var yKey = y.a;
		var xNode = x.b;
		var yNode = y.b;

		var newMatch = undefined;
		var oldMatch = undefined;

		// check if keys match

		if (xKey === yKey)
		{
			index++;
			_VirtualDom_diffHelp(xNode, yNode, localPatches, index);
			index += xNode.b || 0;

			xIndex++;
			yIndex++;
			continue;
		}

		// look ahead 1 to detect insertions and removals.

		var xNext = xKids[xIndex + 1];
		var yNext = yKids[yIndex + 1];

		if (xNext)
		{
			var xNextKey = xNext.a;
			var xNextNode = xNext.b;
			oldMatch = yKey === xNextKey;
		}

		if (yNext)
		{
			var yNextKey = yNext.a;
			var yNextNode = yNext.b;
			newMatch = xKey === yNextKey;
		}


		// swap x and y
		if (newMatch && oldMatch)
		{
			index++;
			_VirtualDom_diffHelp(xNode, yNextNode, localPatches, index);
			_VirtualDom_insertNode(changes, localPatches, xKey, yNode, yIndex, inserts);
			index += xNode.b || 0;

			index++;
			_VirtualDom_removeNode(changes, localPatches, xKey, xNextNode, index);
			index += xNextNode.b || 0;

			xIndex += 2;
			yIndex += 2;
			continue;
		}

		// insert y
		if (newMatch)
		{
			index++;
			_VirtualDom_insertNode(changes, localPatches, yKey, yNode, yIndex, inserts);
			_VirtualDom_diffHelp(xNode, yNextNode, localPatches, index);
			index += xNode.b || 0;

			xIndex += 1;
			yIndex += 2;
			continue;
		}

		// remove x
		if (oldMatch)
		{
			index++;
			_VirtualDom_removeNode(changes, localPatches, xKey, xNode, index);
			index += xNode.b || 0;

			index++;
			_VirtualDom_diffHelp(xNextNode, yNode, localPatches, index);
			index += xNextNode.b || 0;

			xIndex += 2;
			yIndex += 1;
			continue;
		}

		// remove x, insert y
		if (xNext && xNextKey === yNextKey)
		{
			index++;
			_VirtualDom_removeNode(changes, localPatches, xKey, xNode, index);
			_VirtualDom_insertNode(changes, localPatches, yKey, yNode, yIndex, inserts);
			index += xNode.b || 0;

			index++;
			_VirtualDom_diffHelp(xNextNode, yNextNode, localPatches, index);
			index += xNextNode.b || 0;

			xIndex += 2;
			yIndex += 2;
			continue;
		}

		break;
	}

	// eat up any remaining nodes with removeNode and insertNode

	while (xIndex < xLen)
	{
		index++;
		var x = xKids[xIndex];
		var xNode = x.b;
		_VirtualDom_removeNode(changes, localPatches, x.a, xNode, index);
		index += xNode.b || 0;
		xIndex++;
	}

	while (yIndex < yLen)
	{
		var endInserts = endInserts || [];
		var y = yKids[yIndex];
		_VirtualDom_insertNode(changes, localPatches, y.a, y.b, undefined, endInserts);
		yIndex++;
	}

	if (localPatches.length > 0 || inserts.length > 0 || endInserts)
	{
		_VirtualDom_pushPatch(patches, 8, rootIndex, {
			w: localPatches,
			x: inserts,
			y: endInserts
		});
	}
}



// CHANGES FROM KEYED DIFF


var _VirtualDom_POSTFIX = '_elmW6BL';


function _VirtualDom_insertNode(changes, localPatches, key, vnode, yIndex, inserts)
{
	var entry = changes[key];

	// never seen this key before
	if (!entry)
	{
		entry = {
			c: 0,
			z: vnode,
			r: yIndex,
			s: undefined
		};

		inserts.push({ r: yIndex, A: entry });
		changes[key] = entry;

		return;
	}

	// this key was removed earlier, a match!
	if (entry.c === 1)
	{
		inserts.push({ r: yIndex, A: entry });

		entry.c = 2;
		var subPatches = [];
		_VirtualDom_diffHelp(entry.z, vnode, subPatches, entry.r);
		entry.r = yIndex;
		entry.s.s = {
			w: subPatches,
			A: entry
		};

		return;
	}

	// this key has already been inserted or moved, a duplicate!
	_VirtualDom_insertNode(changes, localPatches, key + _VirtualDom_POSTFIX, vnode, yIndex, inserts);
}


function _VirtualDom_removeNode(changes, localPatches, key, vnode, index)
{
	var entry = changes[key];

	// never seen this key before
	if (!entry)
	{
		var patch = _VirtualDom_pushPatch(localPatches, 9, index, undefined);

		changes[key] = {
			c: 1,
			z: vnode,
			r: index,
			s: patch
		};

		return;
	}

	// this key was inserted earlier, a match!
	if (entry.c === 0)
	{
		entry.c = 2;
		var subPatches = [];
		_VirtualDom_diffHelp(vnode, entry.z, subPatches, index);

		_VirtualDom_pushPatch(localPatches, 9, index, {
			w: subPatches,
			A: entry
		});

		return;
	}

	// this key has already been removed or moved, a duplicate!
	_VirtualDom_removeNode(changes, localPatches, key + _VirtualDom_POSTFIX, vnode, index);
}



// ADD DOM NODES
//
// Each DOM node has an "index" assigned in order of traversal. It is important
// to minimize our crawl over the actual DOM, so these indexes (along with the
// descendantsCount of virtual nodes) let us skip touching entire subtrees of
// the DOM if we know there are no patches there.


function _VirtualDom_addDomNodes(domNode, vNode, patches, eventNode)
{
	_VirtualDom_addDomNodesHelp(domNode, vNode, patches, 0, 0, vNode.b, eventNode);
}


// assumes `patches` is non-empty and indexes increase monotonically.
function _VirtualDom_addDomNodesHelp(domNode, vNode, patches, i, low, high, eventNode)
{
	var patch = patches[i];
	var index = patch.r;

	while (index === low)
	{
		var patchType = patch.$;

		if (patchType === 1)
		{
			_VirtualDom_addDomNodes(domNode, vNode.k, patch.s, eventNode);
		}
		else if (patchType === 8)
		{
			patch.t = domNode;
			patch.u = eventNode;

			var subPatches = patch.s.w;
			if (subPatches.length > 0)
			{
				_VirtualDom_addDomNodesHelp(domNode, vNode, subPatches, 0, low, high, eventNode);
			}
		}
		else if (patchType === 9)
		{
			patch.t = domNode;
			patch.u = eventNode;

			var data = patch.s;
			if (data)
			{
				data.A.s = domNode;
				var subPatches = data.w;
				if (subPatches.length > 0)
				{
					_VirtualDom_addDomNodesHelp(domNode, vNode, subPatches, 0, low, high, eventNode);
				}
			}
		}
		else
		{
			patch.t = domNode;
			patch.u = eventNode;
		}

		i++;

		if (!(patch = patches[i]) || (index = patch.r) > high)
		{
			return i;
		}
	}

	var tag = vNode.$;

	if (tag === 4)
	{
		var subNode = vNode.k;

		while (subNode.$ === 4)
		{
			subNode = subNode.k;
		}

		return _VirtualDom_addDomNodesHelp(domNode, subNode, patches, i, low + 1, high, domNode.elm_event_node_ref);
	}

	// tag must be 1 or 2 at this point

	var vKids = vNode.e;
	var childNodes = domNode.childNodes;
	for (var j = 0; j < vKids.length; j++)
	{
		low++;
		var vKid = tag === 1 ? vKids[j] : vKids[j].b;
		var nextLow = low + (vKid.b || 0);
		if (low <= index && index <= nextLow)
		{
			i = _VirtualDom_addDomNodesHelp(childNodes[j], vKid, patches, i, low, nextLow, eventNode);
			if (!(patch = patches[i]) || (index = patch.r) > high)
			{
				return i;
			}
		}
		low = nextLow;
	}
	return i;
}



// APPLY PATCHES


function _VirtualDom_applyPatches(rootDomNode, oldVirtualNode, patches, eventNode)
{
	if (patches.length === 0)
	{
		return rootDomNode;
	}

	_VirtualDom_addDomNodes(rootDomNode, oldVirtualNode, patches, eventNode);
	return _VirtualDom_applyPatchesHelp(rootDomNode, patches);
}

function _VirtualDom_applyPatchesHelp(rootDomNode, patches)
{
	for (var i = 0; i < patches.length; i++)
	{
		var patch = patches[i];
		var localDomNode = patch.t
		var newNode = _VirtualDom_applyPatch(localDomNode, patch);
		if (localDomNode === rootDomNode)
		{
			rootDomNode = newNode;
		}
	}
	return rootDomNode;
}

function _VirtualDom_applyPatch(domNode, patch)
{
	switch (patch.$)
	{
		case 0:
			return _VirtualDom_applyPatchRedraw(domNode, patch.s, patch.u);

		case 4:
			_VirtualDom_applyFacts(domNode, patch.u, patch.s);
			return domNode;

		case 3:
			domNode.replaceData(0, domNode.length, patch.s);
			return domNode;

		case 1:
			return _VirtualDom_applyPatchesHelp(domNode, patch.s);

		case 2:
			if (domNode.elm_event_node_ref)
			{
				domNode.elm_event_node_ref.j = patch.s;
			}
			else
			{
				domNode.elm_event_node_ref = { j: patch.s, p: patch.u };
			}
			return domNode;

		case 6:
			var data = patch.s;
			for (var i = 0; i < data.i; i++)
			{
				domNode.removeChild(domNode.childNodes[data.v]);
			}
			return domNode;

		case 7:
			var data = patch.s;
			var kids = data.e;
			var i = data.v;
			var theEnd = domNode.childNodes[i];
			for (; i < kids.length; i++)
			{
				domNode.insertBefore(_VirtualDom_render(kids[i], patch.u), theEnd);
			}
			return domNode;

		case 9:
			var data = patch.s;
			if (!data)
			{
				domNode.parentNode.removeChild(domNode);
				return domNode;
			}
			var entry = data.A;
			if (typeof entry.r !== 'undefined')
			{
				domNode.parentNode.removeChild(domNode);
			}
			entry.s = _VirtualDom_applyPatchesHelp(domNode, data.w);
			return domNode;

		case 8:
			return _VirtualDom_applyPatchReorder(domNode, patch);

		case 5:
			return patch.s(domNode);

		default:
			_Debug_crash(10); // 'Ran into an unknown patch!'
	}
}


function _VirtualDom_applyPatchRedraw(domNode, vNode, eventNode)
{
	var parentNode = domNode.parentNode;
	var newNode = _VirtualDom_render(vNode, eventNode);

	if (!newNode.elm_event_node_ref)
	{
		newNode.elm_event_node_ref = domNode.elm_event_node_ref;
	}

	if (parentNode && newNode !== domNode)
	{
		parentNode.replaceChild(newNode, domNode);
	}
	return newNode;
}


function _VirtualDom_applyPatchReorder(domNode, patch)
{
	var data = patch.s;

	// remove end inserts
	var frag = _VirtualDom_applyPatchReorderEndInsertsHelp(data.y, patch);

	// removals
	domNode = _VirtualDom_applyPatchesHelp(domNode, data.w);

	// inserts
	var inserts = data.x;
	for (var i = 0; i < inserts.length; i++)
	{
		var insert = inserts[i];
		var entry = insert.A;
		var node = entry.c === 2
			? entry.s
			: _VirtualDom_render(entry.z, patch.u);
		domNode.insertBefore(node, domNode.childNodes[insert.r]);
	}

	// add end inserts
	if (frag)
	{
		_VirtualDom_appendChild(domNode, frag);
	}

	return domNode;
}


function _VirtualDom_applyPatchReorderEndInsertsHelp(endInserts, patch)
{
	if (!endInserts)
	{
		return;
	}

	var frag = _VirtualDom_doc.createDocumentFragment();
	for (var i = 0; i < endInserts.length; i++)
	{
		var insert = endInserts[i];
		var entry = insert.A;
		_VirtualDom_appendChild(frag, entry.c === 2
			? entry.s
			: _VirtualDom_render(entry.z, patch.u)
		);
	}
	return frag;
}


function _VirtualDom_virtualize(node)
{
	// TEXT NODES

	if (node.nodeType === 3)
	{
		return _VirtualDom_text(node.textContent);
	}


	// WEIRD NODES

	if (node.nodeType !== 1)
	{
		return _VirtualDom_text('');
	}


	// ELEMENT NODES

	var attrList = _List_Nil;
	var attrs = node.attributes;
	for (var i = attrs.length; i--; )
	{
		var attr = attrs[i];
		var name = attr.name;
		var value = attr.value;
		attrList = _List_Cons( A2(_VirtualDom_attribute, name, value), attrList );
	}

	var tag = node.tagName.toLowerCase();
	var kidList = _List_Nil;
	var kids = node.childNodes;

	for (var i = kids.length; i--; )
	{
		kidList = _List_Cons(_VirtualDom_virtualize(kids[i]), kidList);
	}
	return A3(_VirtualDom_node, tag, attrList, kidList);
}

function _VirtualDom_dekey(keyedNode)
{
	var keyedKids = keyedNode.e;
	var len = keyedKids.length;
	var kids = new Array(len);
	for (var i = 0; i < len; i++)
	{
		kids[i] = keyedKids[i].b;
	}

	return {
		$: 1,
		c: keyedNode.c,
		d: keyedNode.d,
		e: kids,
		f: keyedNode.f,
		b: keyedNode.b
	};
}




// ELEMENT


var _Debugger_element;

var _Browser_element = _Debugger_element || F4(function(impl, flagDecoder, debugMetadata, args)
{
	return _Platform_initialize(
		flagDecoder,
		args,
		impl.fj,
		impl.gG,
		impl.gh,
		function(sendToApp, initialModel) {
			var view = impl.gI;
			/**/
			var domNode = args['node'];
			//*/
			/**_UNUSED/
			var domNode = args && args['node'] ? args['node'] : _Debug_crash(0);
			//*/
			var currNode = _VirtualDom_virtualize(domNode);

			return _Browser_makeAnimator(initialModel, function(model)
			{
				var nextNode = view(model);
				var patches = _VirtualDom_diff(currNode, nextNode);
				domNode = _VirtualDom_applyPatches(domNode, currNode, patches, sendToApp);
				currNode = nextNode;
			});
		}
	);
});



// DOCUMENT


var _Debugger_document;

var _Browser_document = _Debugger_document || F4(function(impl, flagDecoder, debugMetadata, args)
{
	return _Platform_initialize(
		flagDecoder,
		args,
		impl.fj,
		impl.gG,
		impl.gh,
		function(sendToApp, initialModel) {
			var divertHrefToApp = impl.cL && impl.cL(sendToApp)
			var view = impl.gI;
			var title = _VirtualDom_doc.title;
			var bodyNode = _VirtualDom_doc.body;
			var currNode = _VirtualDom_virtualize(bodyNode);
			return _Browser_makeAnimator(initialModel, function(model)
			{
				_VirtualDom_divertHrefToApp = divertHrefToApp;
				var doc = view(model);
				var nextNode = _VirtualDom_node('body')(_List_Nil)(doc.ez);
				var patches = _VirtualDom_diff(currNode, nextNode);
				bodyNode = _VirtualDom_applyPatches(bodyNode, currNode, patches, sendToApp);
				currNode = nextNode;
				_VirtualDom_divertHrefToApp = 0;
				(title !== doc.gA) && (_VirtualDom_doc.title = title = doc.gA);
			});
		}
	);
});



// ANIMATION


var _Browser_cancelAnimationFrame =
	typeof cancelAnimationFrame !== 'undefined'
		? cancelAnimationFrame
		: function(id) { clearTimeout(id); };

var _Browser_requestAnimationFrame =
	typeof requestAnimationFrame !== 'undefined'
		? requestAnimationFrame
		: function(callback) { return setTimeout(callback, 1000 / 60); };


function _Browser_makeAnimator(model, draw)
{
	draw(model);

	var state = 0;

	function updateIfNeeded()
	{
		state = state === 1
			? 0
			: ( _Browser_requestAnimationFrame(updateIfNeeded), draw(model), 1 );
	}

	return function(nextModel, isSync)
	{
		model = nextModel;

		isSync
			? ( draw(model),
				state === 2 && (state = 1)
				)
			: ( state === 0 && _Browser_requestAnimationFrame(updateIfNeeded),
				state = 2
				);
	};
}



// APPLICATION


function _Browser_application(impl)
{
	var onUrlChange = impl.fN;
	var onUrlRequest = impl.fO;
	var key = function() { key.a(onUrlChange(_Browser_getUrl())); };

	return _Browser_document({
		cL: function(sendToApp)
		{
			key.a = sendToApp;
			_Browser_window.addEventListener('popstate', key);
			_Browser_window.navigator.userAgent.indexOf('Trident') < 0 || _Browser_window.addEventListener('hashchange', key);

			return F2(function(domNode, event)
			{
				if (!event.ctrlKey && !event.metaKey && !event.shiftKey && event.button < 1 && !domNode.target && !domNode.hasAttribute('download'))
				{
					event.preventDefault();
					var href = domNode.href;
					var curr = _Browser_getUrl();
					var next = $elm$url$Url$fromString(href).a;
					sendToApp(onUrlRequest(
						(next
							&& curr.dM === next.dM
							&& curr.dl === next.dl
							&& curr.dJ.a === next.dJ.a
						)
							? $elm$browser$Browser$Internal(next)
							: $elm$browser$Browser$External(href)
					));
				}
			});
		},
		fj: function(flags)
		{
			return A3(impl.fj, flags, _Browser_getUrl(), key);
		},
		gI: impl.gI,
		gG: impl.gG,
		gh: impl.gh
	});
}

function _Browser_getUrl()
{
	return $elm$url$Url$fromString(_VirtualDom_doc.location.href).a || _Debug_crash(1);
}

var _Browser_go = F2(function(key, n)
{
	return A2($elm$core$Task$perform, $elm$core$Basics$never, _Scheduler_binding(function() {
		n && history.go(n);
		key();
	}));
});

var _Browser_pushUrl = F2(function(key, url)
{
	return A2($elm$core$Task$perform, $elm$core$Basics$never, _Scheduler_binding(function() {
		history.pushState({}, '', url);
		key();
	}));
});

var _Browser_replaceUrl = F2(function(key, url)
{
	return A2($elm$core$Task$perform, $elm$core$Basics$never, _Scheduler_binding(function() {
		history.replaceState({}, '', url);
		key();
	}));
});



// GLOBAL EVENTS


var _Browser_fakeNode = { addEventListener: function() {}, removeEventListener: function() {} };
var _Browser_doc = typeof document !== 'undefined' ? document : _Browser_fakeNode;
var _Browser_window = typeof window !== 'undefined' ? window : _Browser_fakeNode;

var _Browser_on = F3(function(node, eventName, sendToSelf)
{
	return _Scheduler_spawn(_Scheduler_binding(function(callback)
	{
		function handler(event)	{ _Scheduler_rawSpawn(sendToSelf(event)); }
		node.addEventListener(eventName, handler, _VirtualDom_passiveSupported && { passive: true });
		return function() { node.removeEventListener(eventName, handler); };
	}));
});

var _Browser_decodeEvent = F2(function(decoder, event)
{
	var result = _Json_runHelp(decoder, event);
	return $elm$core$Result$isOk(result) ? $elm$core$Maybe$Just(result.a) : $elm$core$Maybe$Nothing;
});



// PAGE VISIBILITY


function _Browser_visibilityInfo()
{
	return (typeof _VirtualDom_doc.hidden !== 'undefined')
		? { fb: 'hidden', eL: 'visibilitychange' }
		:
	(typeof _VirtualDom_doc.mozHidden !== 'undefined')
		? { fb: 'mozHidden', eL: 'mozvisibilitychange' }
		:
	(typeof _VirtualDom_doc.msHidden !== 'undefined')
		? { fb: 'msHidden', eL: 'msvisibilitychange' }
		:
	(typeof _VirtualDom_doc.webkitHidden !== 'undefined')
		? { fb: 'webkitHidden', eL: 'webkitvisibilitychange' }
		: { fb: 'hidden', eL: 'visibilitychange' };
}



// ANIMATION FRAMES


function _Browser_rAF()
{
	return _Scheduler_binding(function(callback)
	{
		var id = _Browser_requestAnimationFrame(function() {
			callback(_Scheduler_succeed(Date.now()));
		});

		return function() {
			_Browser_cancelAnimationFrame(id);
		};
	});
}


function _Browser_now()
{
	return _Scheduler_binding(function(callback)
	{
		callback(_Scheduler_succeed(Date.now()));
	});
}



// DOM STUFF


function _Browser_withNode(id, doStuff)
{
	return _Scheduler_binding(function(callback)
	{
		_Browser_requestAnimationFrame(function() {
			var node = document.getElementById(id);
			callback(node
				? _Scheduler_succeed(doStuff(node))
				: _Scheduler_fail($elm$browser$Browser$Dom$NotFound(id))
			);
		});
	});
}


function _Browser_withWindow(doStuff)
{
	return _Scheduler_binding(function(callback)
	{
		_Browser_requestAnimationFrame(function() {
			callback(_Scheduler_succeed(doStuff()));
		});
	});
}


// FOCUS and BLUR


var _Browser_call = F2(function(functionName, id)
{
	return _Browser_withNode(id, function(node) {
		node[functionName]();
		return _Utils_Tuple0;
	});
});



// WINDOW VIEWPORT


function _Browser_getViewport()
{
	return {
		dR: _Browser_getScene(),
		d5: {
			ea: _Browser_window.pageXOffset,
			eb: _Browser_window.pageYOffset,
			d7: _Browser_doc.documentElement.clientWidth,
			di: _Browser_doc.documentElement.clientHeight
		}
	};
}

function _Browser_getScene()
{
	var body = _Browser_doc.body;
	var elem = _Browser_doc.documentElement;
	return {
		d7: Math.max(body.scrollWidth, body.offsetWidth, elem.scrollWidth, elem.offsetWidth, elem.clientWidth),
		di: Math.max(body.scrollHeight, body.offsetHeight, elem.scrollHeight, elem.offsetHeight, elem.clientHeight)
	};
}

var _Browser_setViewport = F2(function(x, y)
{
	return _Browser_withWindow(function()
	{
		_Browser_window.scroll(x, y);
		return _Utils_Tuple0;
	});
});



// ELEMENT VIEWPORT


function _Browser_getViewportOf(id)
{
	return _Browser_withNode(id, function(node)
	{
		return {
			dR: {
				d7: node.scrollWidth,
				di: node.scrollHeight
			},
			d5: {
				ea: node.scrollLeft,
				eb: node.scrollTop,
				d7: node.clientWidth,
				di: node.clientHeight
			}
		};
	});
}


var _Browser_setViewportOf = F3(function(id, x, y)
{
	return _Browser_withNode(id, function(node)
	{
		node.scrollLeft = x;
		node.scrollTop = y;
		return _Utils_Tuple0;
	});
});



// ELEMENT


function _Browser_getElement(id)
{
	return _Browser_withNode(id, function(node)
	{
		var rect = node.getBoundingClientRect();
		var x = _Browser_window.pageXOffset;
		var y = _Browser_window.pageYOffset;
		return {
			dR: _Browser_getScene(),
			d5: {
				ea: x,
				eb: y,
				d7: _Browser_doc.documentElement.clientWidth,
				di: _Browser_doc.documentElement.clientHeight
			},
			e1: {
				ea: x + rect.left,
				eb: y + rect.top,
				d7: rect.width,
				di: rect.height
			}
		};
	});
}



// LOAD and RELOAD


function _Browser_reload(skipCache)
{
	return A2($elm$core$Task$perform, $elm$core$Basics$never, _Scheduler_binding(function(callback)
	{
		_VirtualDom_doc.location.reload(skipCache);
	}));
}

function _Browser_load(url)
{
	return A2($elm$core$Task$perform, $elm$core$Basics$never, _Scheduler_binding(function(callback)
	{
		try
		{
			_Browser_window.location = url;
		}
		catch(err)
		{
			// Only Firefox can throw a NS_ERROR_MALFORMED_URI exception here.
			// Other browsers reload the page, so let's be consistent about that.
			_VirtualDom_doc.location.reload(false);
		}
	}));
}



var _Bitwise_and = F2(function(a, b)
{
	return a & b;
});

var _Bitwise_or = F2(function(a, b)
{
	return a | b;
});

var _Bitwise_xor = F2(function(a, b)
{
	return a ^ b;
});

function _Bitwise_complement(a)
{
	return ~a;
};

var _Bitwise_shiftLeftBy = F2(function(offset, a)
{
	return a << offset;
});

var _Bitwise_shiftRightBy = F2(function(offset, a)
{
	return a >> offset;
});

var _Bitwise_shiftRightZfBy = F2(function(offset, a)
{
	return a >>> offset;
});
var $elm$core$List$cons = _List_cons;
var $elm$core$Elm$JsArray$foldr = _JsArray_foldr;
var $elm$core$Array$foldr = F3(
	function (func, baseCase, _v0) {
		var tree = _v0.c;
		var tail = _v0.d;
		var helper = F2(
			function (node, acc) {
				if (!node.$) {
					var subTree = node.a;
					return A3($elm$core$Elm$JsArray$foldr, helper, acc, subTree);
				} else {
					var values = node.a;
					return A3($elm$core$Elm$JsArray$foldr, func, acc, values);
				}
			});
		return A3(
			$elm$core$Elm$JsArray$foldr,
			helper,
			A3($elm$core$Elm$JsArray$foldr, func, baseCase, tail),
			tree);
	});
var $elm$core$Array$toList = function (array) {
	return A3($elm$core$Array$foldr, $elm$core$List$cons, _List_Nil, array);
};
var $elm$core$Dict$foldr = F3(
	function (func, acc, t) {
		foldr:
		while (true) {
			if (t.$ === -2) {
				return acc;
			} else {
				var key = t.b;
				var value = t.c;
				var left = t.d;
				var right = t.e;
				var $temp$func = func,
					$temp$acc = A3(
					func,
					key,
					value,
					A3($elm$core$Dict$foldr, func, acc, right)),
					$temp$t = left;
				func = $temp$func;
				acc = $temp$acc;
				t = $temp$t;
				continue foldr;
			}
		}
	});
var $elm$core$Dict$toList = function (dict) {
	return A3(
		$elm$core$Dict$foldr,
		F3(
			function (key, value, list) {
				return A2(
					$elm$core$List$cons,
					_Utils_Tuple2(key, value),
					list);
			}),
		_List_Nil,
		dict);
};
var $elm$core$Dict$keys = function (dict) {
	return A3(
		$elm$core$Dict$foldr,
		F3(
			function (key, value, keyList) {
				return A2($elm$core$List$cons, key, keyList);
			}),
		_List_Nil,
		dict);
};
var $elm$core$Set$toList = function (_v0) {
	var dict = _v0;
	return $elm$core$Dict$keys(dict);
};
var $elm$core$Basics$EQ = 1;
var $elm$core$Basics$GT = 2;
var $elm$core$Basics$LT = 0;
var $author$project$Main$Adresse = function (a) {
	return {$: 16, a: a};
};
var $author$project$Main$ApercuAdmission = {$: 16};
var $author$project$Main$ApercuInvitation = {$: 18};
var $author$project$Main$Configuration = function (a) {
	return {$: 0, a: a};
};
var $author$project$Main$CopieTerminee = function (a) {
	return {$: 13, a: a};
};
var $author$project$Main$ExportTermine = function (a) {
	return {$: 5, a: a};
};
var $elm$core$Maybe$Nothing = {$: 1};
var $author$project$Main$Recevoir = function (a) {
	return {$: 15, a: a};
};
var $author$project$Main$SessionInitiale = {$: 0};
var $author$project$Main$Administration = {$: 2};
var $author$project$Main$ApercuExport = {$: 13};
var $author$project$Main$Changer = function (a) {
	return {$: 0, a: a};
};
var $author$project$Main$ConfirmerAdmission = {$: 17};
var $author$project$Main$Connecter = {$: 1};
var $author$project$Main$EffacerVision = {$: 3};
var $author$project$Main$EnregistrerLigne = function (a) {
	return {$: 6, a: a};
};
var $author$project$MrJam$Erreur = 3;
var $elm$core$Basics$False = 1;
var $author$project$Contrat$Fiche = 0;
var $author$project$Main$Gerer = function (a) {
	return {$: 14, a: a};
};
var $author$project$MrJam$Information = 0;
var $author$project$Main$Inscrire = {$: 15};
var $author$project$Contrat$Item = 1;
var $elm$core$Maybe$Just = function (a) {
	return {$: 0, a: a};
};
var $author$project$Main$Lier = {$: 9};
var $author$project$Main$LireLimites = {$: 12};
var $author$project$Main$LirePolitique = {$: 11};
var $author$project$Main$MonCompte = {$: 1};
var $author$project$Main$Naviguer = function (a) {
	return {$: 22, a: a};
};
var $author$project$Main$Ouvrir = F2(
	function (a, b) {
		return {$: 31, a: a, b: b};
	});
var $author$project$Main$RechercherLiens = {$: 8};
var $author$project$Main$Regler = {$: 10};
var $author$project$Main$Session = F4(
	function (compte, csrf, administrateur, verificationRenforcee) {
		return {cU: administrateur, aF: compte, b0: csrf, d3: verificationRenforcee};
	});
var $author$project$MrJam$Succes = 1;
var $elm$core$Basics$True = 0;
var $elm$core$Basics$eq = _Utils_equal;
var $author$project$Admission$actualiser = F2(
	function (message, m) {
		switch (message.$) {
			case 0:
				var texte = message.a;
				return _Utils_update(
					m,
					{bw: texte});
			case 1:
				var texte = message.a;
				return _Utils_update(
					m,
					{bF: texte});
			case 2:
				var texte = message.a;
				return _Utils_update(
					m,
					{
						aC: texte,
						aV: (texte === 'majeur') ? '' : m.aV
					});
			case 3:
				var texte = message.a;
				return _Utils_update(
					m,
					{aV: texte});
			default:
				var texte = message.a;
				return _Utils_update(
					m,
					{bH: texte});
		}
	});
var $elm$core$Basics$add = _Basics_add;
var $elm$core$List$foldl = F3(
	function (func, acc, list) {
		foldl:
		while (true) {
			if (!list.b) {
				return acc;
			} else {
				var x = list.a;
				var xs = list.b;
				var $temp$func = func,
					$temp$acc = A2(func, x, acc),
					$temp$list = xs;
				func = $temp$func;
				acc = $temp$acc;
				list = $temp$list;
				continue foldl;
			}
		}
	});
var $elm$core$Basics$gt = _Utils_gt;
var $elm$core$List$reverse = function (list) {
	return A3($elm$core$List$foldl, $elm$core$List$cons, _List_Nil, list);
};
var $elm$core$List$foldrHelper = F4(
	function (fn, acc, ctr, ls) {
		if (!ls.b) {
			return acc;
		} else {
			var a = ls.a;
			var r1 = ls.b;
			if (!r1.b) {
				return A2(fn, a, acc);
			} else {
				var b = r1.a;
				var r2 = r1.b;
				if (!r2.b) {
					return A2(
						fn,
						a,
						A2(fn, b, acc));
				} else {
					var c = r2.a;
					var r3 = r2.b;
					if (!r3.b) {
						return A2(
							fn,
							a,
							A2(
								fn,
								b,
								A2(fn, c, acc)));
					} else {
						var d = r3.a;
						var r4 = r3.b;
						var res = (ctr > 500) ? A3(
							$elm$core$List$foldl,
							fn,
							acc,
							$elm$core$List$reverse(r4)) : A4($elm$core$List$foldrHelper, fn, acc, ctr + 1, r4);
						return A2(
							fn,
							a,
							A2(
								fn,
								b,
								A2(
									fn,
									c,
									A2(fn, d, res))));
					}
				}
			}
		}
	});
var $elm$core$List$foldr = F3(
	function (fn, acc, ls) {
		return A4($elm$core$List$foldrHelper, fn, acc, 0, ls);
	});
var $elm$core$List$filter = F2(
	function (isGood, list) {
		return A3(
			$elm$core$List$foldr,
			F2(
				function (x, xs) {
					return isGood(x) ? A2($elm$core$List$cons, x, xs) : xs;
				}),
			_List_Nil,
			list);
	});
var $elm$core$Basics$max = F2(
	function (x, y) {
		return (_Utils_cmp(x, y) > 0) ? x : y;
	});
var $elm$core$Basics$neq = _Utils_notEqual;
var $author$project$Compte$actualiser = F2(
	function (message, m) {
		switch (message.$) {
			case 0:
				var format = message.a;
				return _Utils_update(
					m,
					{bf: format});
			case 1:
				var toutes = message.a;
				return _Utils_update(
					m,
					{bm: toutes});
			case 2:
				var id = message.a;
				var oui = message.b;
				return _Utils_update(
					m,
					{
						ay: oui ? A2(
							$elm$core$List$cons,
							id,
							A2(
								$elm$core$List$filter,
								$elm$core$Basics$neq(id),
								m.ay)) : A2(
							$elm$core$List$filter,
							$elm$core$Basics$neq(id),
							m.ay)
					});
			case 3:
				var debut = message.a;
				return _Utils_update(
					m,
					{
						a9: A2($elm$core$Basics$max, 0, debut),
						bz: _List_Nil
					});
			default:
				return m;
		}
	});
var $elm$core$Basics$apR = F2(
	function (x, f) {
		return f(x);
	});
var $elm$core$Basics$append = _Utils_append;
var $elm$core$Result$Err = function (a) {
	return {$: 1, a: a};
};
var $elm$json$Json$Decode$Failure = F2(
	function (a, b) {
		return {$: 3, a: a, b: b};
	});
var $elm$json$Json$Decode$Field = F2(
	function (a, b) {
		return {$: 0, a: a, b: b};
	});
var $elm$json$Json$Decode$Index = F2(
	function (a, b) {
		return {$: 1, a: a, b: b};
	});
var $elm$core$Result$Ok = function (a) {
	return {$: 0, a: a};
};
var $elm$json$Json$Decode$OneOf = function (a) {
	return {$: 2, a: a};
};
var $elm$core$String$all = _String_all;
var $elm$core$Basics$and = _Basics_and;
var $elm$json$Json$Encode$encode = _Json_encode;
var $elm$core$String$fromInt = _String_fromNumber;
var $elm$core$String$join = F2(
	function (sep, chunks) {
		return A2(
			_String_join,
			sep,
			_List_toArray(chunks));
	});
var $elm$core$String$split = F2(
	function (sep, string) {
		return _List_fromArray(
			A2(_String_split, sep, string));
	});
var $elm$json$Json$Decode$indent = function (str) {
	return A2(
		$elm$core$String$join,
		'\n    ',
		A2($elm$core$String$split, '\n', str));
};
var $elm$core$List$length = function (xs) {
	return A3(
		$elm$core$List$foldl,
		F2(
			function (_v0, i) {
				return i + 1;
			}),
		0,
		xs);
};
var $elm$core$List$map2 = _List_map2;
var $elm$core$Basics$le = _Utils_le;
var $elm$core$Basics$sub = _Basics_sub;
var $elm$core$List$rangeHelp = F3(
	function (lo, hi, list) {
		rangeHelp:
		while (true) {
			if (_Utils_cmp(lo, hi) < 1) {
				var $temp$lo = lo,
					$temp$hi = hi - 1,
					$temp$list = A2($elm$core$List$cons, hi, list);
				lo = $temp$lo;
				hi = $temp$hi;
				list = $temp$list;
				continue rangeHelp;
			} else {
				return list;
			}
		}
	});
var $elm$core$List$range = F2(
	function (lo, hi) {
		return A3($elm$core$List$rangeHelp, lo, hi, _List_Nil);
	});
var $elm$core$List$indexedMap = F2(
	function (f, xs) {
		return A3(
			$elm$core$List$map2,
			f,
			A2(
				$elm$core$List$range,
				0,
				$elm$core$List$length(xs) - 1),
			xs);
	});
var $elm$core$Char$toCode = _Char_toCode;
var $elm$core$Char$isLower = function (_char) {
	var code = $elm$core$Char$toCode(_char);
	return (97 <= code) && (code <= 122);
};
var $elm$core$Char$isUpper = function (_char) {
	var code = $elm$core$Char$toCode(_char);
	return (code <= 90) && (65 <= code);
};
var $elm$core$Basics$or = _Basics_or;
var $elm$core$Char$isAlpha = function (_char) {
	return $elm$core$Char$isLower(_char) || $elm$core$Char$isUpper(_char);
};
var $elm$core$Char$isDigit = function (_char) {
	var code = $elm$core$Char$toCode(_char);
	return (code <= 57) && (48 <= code);
};
var $elm$core$Char$isAlphaNum = function (_char) {
	return $elm$core$Char$isLower(_char) || ($elm$core$Char$isUpper(_char) || $elm$core$Char$isDigit(_char));
};
var $elm$core$String$uncons = _String_uncons;
var $elm$json$Json$Decode$errorOneOf = F2(
	function (i, error) {
		return '\n\n(' + ($elm$core$String$fromInt(i + 1) + (') ' + $elm$json$Json$Decode$indent(
			$elm$json$Json$Decode$errorToString(error))));
	});
var $elm$json$Json$Decode$errorToString = function (error) {
	return A2($elm$json$Json$Decode$errorToStringHelp, error, _List_Nil);
};
var $elm$json$Json$Decode$errorToStringHelp = F2(
	function (error, context) {
		errorToStringHelp:
		while (true) {
			switch (error.$) {
				case 0:
					var f = error.a;
					var err = error.b;
					var isSimple = function () {
						var _v1 = $elm$core$String$uncons(f);
						if (_v1.$ === 1) {
							return false;
						} else {
							var _v2 = _v1.a;
							var _char = _v2.a;
							var rest = _v2.b;
							return $elm$core$Char$isAlpha(_char) && A2($elm$core$String$all, $elm$core$Char$isAlphaNum, rest);
						}
					}();
					var fieldName = isSimple ? ('.' + f) : ('[\'' + (f + '\']'));
					var $temp$error = err,
						$temp$context = A2($elm$core$List$cons, fieldName, context);
					error = $temp$error;
					context = $temp$context;
					continue errorToStringHelp;
				case 1:
					var i = error.a;
					var err = error.b;
					var indexName = '[' + ($elm$core$String$fromInt(i) + ']');
					var $temp$error = err,
						$temp$context = A2($elm$core$List$cons, indexName, context);
					error = $temp$error;
					context = $temp$context;
					continue errorToStringHelp;
				case 2:
					var errors = error.a;
					if (!errors.b) {
						return 'Ran into a Json.Decode.oneOf with no possibilities' + function () {
							if (!context.b) {
								return '!';
							} else {
								return ' at json' + A2(
									$elm$core$String$join,
									'',
									$elm$core$List$reverse(context));
							}
						}();
					} else {
						if (!errors.b.b) {
							var err = errors.a;
							var $temp$error = err,
								$temp$context = context;
							error = $temp$error;
							context = $temp$context;
							continue errorToStringHelp;
						} else {
							var starter = function () {
								if (!context.b) {
									return 'Json.Decode.oneOf';
								} else {
									return 'The Json.Decode.oneOf at json' + A2(
										$elm$core$String$join,
										'',
										$elm$core$List$reverse(context));
								}
							}();
							var introduction = starter + (' failed in the following ' + ($elm$core$String$fromInt(
								$elm$core$List$length(errors)) + ' ways:'));
							return A2(
								$elm$core$String$join,
								'\n\n',
								A2(
									$elm$core$List$cons,
									introduction,
									A2($elm$core$List$indexedMap, $elm$json$Json$Decode$errorOneOf, errors)));
						}
					}
				default:
					var msg = error.a;
					var json = error.b;
					var introduction = function () {
						if (!context.b) {
							return 'Problem with the given value:\n\n';
						} else {
							return 'Problem with the value at json' + (A2(
								$elm$core$String$join,
								'',
								$elm$core$List$reverse(context)) + ':\n\n    ');
						}
					}();
					return introduction + ($elm$json$Json$Decode$indent(
						A2($elm$json$Json$Encode$encode, 4, json)) + ('\n\n' + msg));
			}
		}
	});
var $elm$core$Array$branchFactor = 32;
var $elm$core$Array$Array_elm_builtin = F4(
	function (a, b, c, d) {
		return {$: 0, a: a, b: b, c: c, d: d};
	});
var $elm$core$Elm$JsArray$empty = _JsArray_empty;
var $elm$core$Basics$ceiling = _Basics_ceiling;
var $elm$core$Basics$fdiv = _Basics_fdiv;
var $elm$core$Basics$logBase = F2(
	function (base, number) {
		return _Basics_log(number) / _Basics_log(base);
	});
var $elm$core$Basics$toFloat = _Basics_toFloat;
var $elm$core$Array$shiftStep = $elm$core$Basics$ceiling(
	A2($elm$core$Basics$logBase, 2, $elm$core$Array$branchFactor));
var $elm$core$Array$empty = A4($elm$core$Array$Array_elm_builtin, 0, $elm$core$Array$shiftStep, $elm$core$Elm$JsArray$empty, $elm$core$Elm$JsArray$empty);
var $elm$core$Elm$JsArray$initialize = _JsArray_initialize;
var $elm$core$Array$Leaf = function (a) {
	return {$: 1, a: a};
};
var $elm$core$Basics$apL = F2(
	function (f, x) {
		return f(x);
	});
var $elm$core$Basics$floor = _Basics_floor;
var $elm$core$Elm$JsArray$length = _JsArray_length;
var $elm$core$Basics$mul = _Basics_mul;
var $elm$core$Array$SubTree = function (a) {
	return {$: 0, a: a};
};
var $elm$core$Elm$JsArray$initializeFromList = _JsArray_initializeFromList;
var $elm$core$Array$compressNodes = F2(
	function (nodes, acc) {
		compressNodes:
		while (true) {
			var _v0 = A2($elm$core$Elm$JsArray$initializeFromList, $elm$core$Array$branchFactor, nodes);
			var node = _v0.a;
			var remainingNodes = _v0.b;
			var newAcc = A2(
				$elm$core$List$cons,
				$elm$core$Array$SubTree(node),
				acc);
			if (!remainingNodes.b) {
				return $elm$core$List$reverse(newAcc);
			} else {
				var $temp$nodes = remainingNodes,
					$temp$acc = newAcc;
				nodes = $temp$nodes;
				acc = $temp$acc;
				continue compressNodes;
			}
		}
	});
var $elm$core$Tuple$first = function (_v0) {
	var x = _v0.a;
	return x;
};
var $elm$core$Array$treeFromBuilder = F2(
	function (nodeList, nodeListSize) {
		treeFromBuilder:
		while (true) {
			var newNodeSize = $elm$core$Basics$ceiling(nodeListSize / $elm$core$Array$branchFactor);
			if (newNodeSize === 1) {
				return A2($elm$core$Elm$JsArray$initializeFromList, $elm$core$Array$branchFactor, nodeList).a;
			} else {
				var $temp$nodeList = A2($elm$core$Array$compressNodes, nodeList, _List_Nil),
					$temp$nodeListSize = newNodeSize;
				nodeList = $temp$nodeList;
				nodeListSize = $temp$nodeListSize;
				continue treeFromBuilder;
			}
		}
	});
var $elm$core$Array$builderToArray = F2(
	function (reverseNodeList, builder) {
		if (!builder.p) {
			return A4(
				$elm$core$Array$Array_elm_builtin,
				$elm$core$Elm$JsArray$length(builder.s),
				$elm$core$Array$shiftStep,
				$elm$core$Elm$JsArray$empty,
				builder.s);
		} else {
			var treeLen = builder.p * $elm$core$Array$branchFactor;
			var depth = $elm$core$Basics$floor(
				A2($elm$core$Basics$logBase, $elm$core$Array$branchFactor, treeLen - 1));
			var correctNodeList = reverseNodeList ? $elm$core$List$reverse(builder.t) : builder.t;
			var tree = A2($elm$core$Array$treeFromBuilder, correctNodeList, builder.p);
			return A4(
				$elm$core$Array$Array_elm_builtin,
				$elm$core$Elm$JsArray$length(builder.s) + treeLen,
				A2($elm$core$Basics$max, 5, depth * $elm$core$Array$shiftStep),
				tree,
				builder.s);
		}
	});
var $elm$core$Basics$idiv = _Basics_idiv;
var $elm$core$Basics$lt = _Utils_lt;
var $elm$core$Array$initializeHelp = F5(
	function (fn, fromIndex, len, nodeList, tail) {
		initializeHelp:
		while (true) {
			if (fromIndex < 0) {
				return A2(
					$elm$core$Array$builderToArray,
					false,
					{t: nodeList, p: (len / $elm$core$Array$branchFactor) | 0, s: tail});
			} else {
				var leaf = $elm$core$Array$Leaf(
					A3($elm$core$Elm$JsArray$initialize, $elm$core$Array$branchFactor, fromIndex, fn));
				var $temp$fn = fn,
					$temp$fromIndex = fromIndex - $elm$core$Array$branchFactor,
					$temp$len = len,
					$temp$nodeList = A2($elm$core$List$cons, leaf, nodeList),
					$temp$tail = tail;
				fn = $temp$fn;
				fromIndex = $temp$fromIndex;
				len = $temp$len;
				nodeList = $temp$nodeList;
				tail = $temp$tail;
				continue initializeHelp;
			}
		}
	});
var $elm$core$Basics$remainderBy = _Basics_remainderBy;
var $elm$core$Array$initialize = F2(
	function (len, fn) {
		if (len <= 0) {
			return $elm$core$Array$empty;
		} else {
			var tailLen = len % $elm$core$Array$branchFactor;
			var tail = A3($elm$core$Elm$JsArray$initialize, tailLen, len - tailLen, fn);
			var initialFromIndex = (len - tailLen) - $elm$core$Array$branchFactor;
			return A5($elm$core$Array$initializeHelp, fn, initialFromIndex, len, _List_Nil, tail);
		}
	});
var $elm$core$Result$isOk = function (result) {
	if (!result.$) {
		return true;
	} else {
		return false;
	}
};
var $elm$json$Json$Encode$bool = _Json_wrap;
var $elm$json$Json$Decode$decodeValue = _Json_run;
var $elm$json$Json$Decode$field = _Json_decodeField;
var $elm$json$Json$Decode$string = _Json_decodeString;
var $elm$core$Result$withDefault = F2(
	function (def, result) {
		if (!result.$) {
			var a = result.a;
			return a;
		} else {
			return def;
		}
	});
var $author$project$Contrat$chaine = F2(
	function (cle, valeur) {
		return A2(
			$elm$core$Result$withDefault,
			'',
			A2(
				$elm$json$Json$Decode$decodeValue,
				A2($elm$json$Json$Decode$field, cle, $elm$json$Json$Decode$string),
				valeur));
	});
var $elm$json$Json$Decode$int = _Json_decodeInt;
var $author$project$Contrat$entier = F2(
	function (cle, valeur) {
		return A2(
			$elm$core$Result$withDefault,
			0,
			A2(
				$elm$json$Json$Decode$decodeValue,
				A2($elm$json$Json$Decode$field, cle, $elm$json$Json$Decode$int),
				valeur));
	});
var $elm$core$String$fromFloat = _String_fromNumber;
var $elm$core$Dict$RBEmpty_elm_builtin = {$: -2};
var $elm$core$Dict$empty = $elm$core$Dict$RBEmpty_elm_builtin;
var $elm$core$Dict$Black = 1;
var $elm$core$Dict$RBNode_elm_builtin = F5(
	function (a, b, c, d, e) {
		return {$: -1, a: a, b: b, c: c, d: d, e: e};
	});
var $elm$core$Dict$Red = 0;
var $elm$core$Dict$balance = F5(
	function (color, key, value, left, right) {
		if ((right.$ === -1) && (!right.a)) {
			var _v1 = right.a;
			var rK = right.b;
			var rV = right.c;
			var rLeft = right.d;
			var rRight = right.e;
			if ((left.$ === -1) && (!left.a)) {
				var _v3 = left.a;
				var lK = left.b;
				var lV = left.c;
				var lLeft = left.d;
				var lRight = left.e;
				return A5(
					$elm$core$Dict$RBNode_elm_builtin,
					0,
					key,
					value,
					A5($elm$core$Dict$RBNode_elm_builtin, 1, lK, lV, lLeft, lRight),
					A5($elm$core$Dict$RBNode_elm_builtin, 1, rK, rV, rLeft, rRight));
			} else {
				return A5(
					$elm$core$Dict$RBNode_elm_builtin,
					color,
					rK,
					rV,
					A5($elm$core$Dict$RBNode_elm_builtin, 0, key, value, left, rLeft),
					rRight);
			}
		} else {
			if ((((left.$ === -1) && (!left.a)) && (left.d.$ === -1)) && (!left.d.a)) {
				var _v5 = left.a;
				var lK = left.b;
				var lV = left.c;
				var _v6 = left.d;
				var _v7 = _v6.a;
				var llK = _v6.b;
				var llV = _v6.c;
				var llLeft = _v6.d;
				var llRight = _v6.e;
				var lRight = left.e;
				return A5(
					$elm$core$Dict$RBNode_elm_builtin,
					0,
					lK,
					lV,
					A5($elm$core$Dict$RBNode_elm_builtin, 1, llK, llV, llLeft, llRight),
					A5($elm$core$Dict$RBNode_elm_builtin, 1, key, value, lRight, right));
			} else {
				return A5($elm$core$Dict$RBNode_elm_builtin, color, key, value, left, right);
			}
		}
	});
var $elm$core$Basics$compare = _Utils_compare;
var $elm$core$Dict$insertHelp = F3(
	function (key, value, dict) {
		if (dict.$ === -2) {
			return A5($elm$core$Dict$RBNode_elm_builtin, 0, key, value, $elm$core$Dict$RBEmpty_elm_builtin, $elm$core$Dict$RBEmpty_elm_builtin);
		} else {
			var nColor = dict.a;
			var nKey = dict.b;
			var nValue = dict.c;
			var nLeft = dict.d;
			var nRight = dict.e;
			var _v1 = A2($elm$core$Basics$compare, key, nKey);
			switch (_v1) {
				case 0:
					return A5(
						$elm$core$Dict$balance,
						nColor,
						nKey,
						nValue,
						A3($elm$core$Dict$insertHelp, key, value, nLeft),
						nRight);
				case 1:
					return A5($elm$core$Dict$RBNode_elm_builtin, nColor, nKey, value, nLeft, nRight);
				default:
					return A5(
						$elm$core$Dict$balance,
						nColor,
						nKey,
						nValue,
						nLeft,
						A3($elm$core$Dict$insertHelp, key, value, nRight));
			}
		}
	});
var $elm$core$Dict$insert = F3(
	function (key, value, dict) {
		var _v0 = A3($elm$core$Dict$insertHelp, key, value, dict);
		if ((_v0.$ === -1) && (!_v0.a)) {
			var _v1 = _v0.a;
			var k = _v0.b;
			var v = _v0.c;
			var l = _v0.d;
			var r = _v0.e;
			return A5($elm$core$Dict$RBNode_elm_builtin, 1, k, v, l, r);
		} else {
			var x = _v0;
			return x;
		}
	});
var $elm$core$Dict$fromList = function (assocs) {
	return A3(
		$elm$core$List$foldl,
		F2(
			function (_v0, dict) {
				var key = _v0.a;
				var value = _v0.b;
				return A3($elm$core$Dict$insert, key, value, dict);
			}),
		$elm$core$Dict$empty,
		assocs);
};
var $elm$core$String$slice = _String_slice;
var $elm$core$String$left = F2(
	function (n, string) {
		return (n < 1) ? '' : A3($elm$core$String$slice, 0, n, string);
	});
var $author$project$Gestion$limites = _List_fromArray(
	[
		_Utils_Tuple3('fiches', 'Fiches, archives incluses', 1000),
		_Utils_Tuple3('items_par_fiche', 'Items par fiche', 500),
		_Utils_Tuple3('mots_item', 'Mots par item', 500),
		_Utils_Tuple3('octets_item', 'Octets par item', 8000),
		_Utils_Tuple3('mots_fiche', 'Mots par fiche', 2000),
		_Utils_Tuple3('octets_fiche', 'Octets par fiche', 32000),
		_Utils_Tuple3('mots_note', 'Mots par note', 200),
		_Utils_Tuple3('octets_note', 'Octets par note', 2000)
	]);
var $elm$core$List$map = F2(
	function (f, xs) {
		return A3(
			$elm$core$List$foldr,
			F2(
				function (x, acc) {
					return A2(
						$elm$core$List$cons,
						f(x),
						acc);
				}),
			_List_Nil,
			xs);
	});
var $elm$json$Json$Encode$null = _Json_encodeNull;
var $elm$json$Json$Decode$value = _Json_decodeValue;
var $author$project$Contrat$objet = F2(
	function (cle, valeur) {
		return A2(
			$elm$core$Result$withDefault,
			$elm$json$Json$Encode$null,
			A2(
				$elm$json$Json$Decode$decodeValue,
				A2($elm$json$Json$Decode$field, cle, $elm$json$Json$Decode$value),
				valeur));
	});
var $elm$core$String$replace = F3(
	function (before, after, string) {
		return A2(
			$elm$core$String$join,
			after,
			A2($elm$core$String$split, before, string));
	});
var $elm$json$Json$Decode$bool = _Json_decodeBool;
var $author$project$Contrat$vrai = F2(
	function (cle, valeur) {
		return A2(
			$elm$core$Result$withDefault,
			false,
			A2(
				$elm$json$Json$Decode$decodeValue,
				A2($elm$json$Json$Decode$field, cle, $elm$json$Json$Decode$bool),
				valeur));
	});
var $author$project$Gestion$charger = function (v) {
	return $elm$core$Dict$fromList(
		_Utils_ap(
			_List_fromArray(
				[
					_Utils_Tuple2(
					'quota',
					$elm$core$String$fromFloat(
						A2($author$project$Contrat$entier, 'quota_octets', v) / 1000000)),
					_Utils_Tuple2(
					'intitule',
					A2($author$project$Contrat$chaine, 'intitule', v)),
					_Utils_Tuple2(
					'maximum',
					$elm$core$String$fromInt(
						A2($author$project$Contrat$entier, 'maximum', v))),
					_Utils_Tuple2(
					'expire_a',
					A2(
						$elm$core$String$left,
						19,
						A3(
							$elm$core$String$replace,
							'Z',
							'',
							A2($author$project$Contrat$chaine, 'expire_a', v)))),
					_Utils_Tuple2(
					'administrateur',
					A2($author$project$Contrat$vrai, 'administrateur', v) ? 'oui' : 'non'),
					_Utils_Tuple2(
					'actif',
					A2($author$project$Contrat$vrai, 'actif', v) ? 'oui' : 'non'),
					_Utils_Tuple2('retroactif', 'oui')
				]),
			A2(
				$elm$core$List$map,
				function (_v0) {
					var k = _v0.a;
					var defaut = _v0.c;
					return _Utils_Tuple2(
						k,
						$elm$core$String$fromInt(
							_Utils_eq(v, $elm$json$Json$Encode$null) ? defaut : A2(
								$author$project$Contrat$entier,
								k,
								A2($author$project$Contrat$objet, 'limites', v))));
				},
				$author$project$Gestion$limites)));
};
var $elm$core$Basics$composeR = F3(
	function (f, g, x) {
		return g(
			f(x));
	});
var $author$project$Gestion$initial = {ap: $elm$core$Dict$empty, aJ: false, a9: 0, bh: '', aP: _List_Nil, ay: $elm$core$Maybe$Nothing, a0: 0, x: 'comptes'};
var $elm$json$Json$Encode$int = _Json_wrap;
var $elm$core$Maybe$map = F2(
	function (f, maybe) {
		if (!maybe.$) {
			var value = maybe.a;
			return $elm$core$Maybe$Just(
				f(value));
		} else {
			return $elm$core$Maybe$Nothing;
		}
	});
var $elm$json$Json$Encode$object = function (pairs) {
	return _Json_wrap(
		A3(
			$elm$core$List$foldl,
			F2(
				function (_v0, obj) {
					var k = _v0.a;
					var v = _v0.b;
					return A3(_Json_addField, k, v, obj);
				}),
			_Json_emptyObject(0),
			pairs));
};
var $elm$json$Json$Encode$string = _Json_wrap;
var $author$project$Gestion$procedure = F2(
	function (operation, m) {
		var _v0 = m.ay;
		if (!_v0.$) {
			var v = _v0.a;
			return _Utils_Tuple2(
				_Utils_update(
					m,
					{aJ: false}),
				$elm$core$Maybe$Just(
					_Utils_Tuple2(
						operation,
						$elm$json$Json$Encode$object(
							_List_fromArray(
								[
									_Utils_Tuple2(
									'utilisateur',
									$elm$json$Json$Encode$string(
										A2($author$project$Contrat$chaine, 'utilisateur', v))),
									_Utils_Tuple2(
									'version',
									$elm$json$Json$Encode$int(
										A2($author$project$Contrat$entier, 'version', v)))
								])))));
		} else {
			return _Utils_Tuple2(m, $elm$core$Maybe$Nothing);
		}
	});
var $elm$core$Basics$round = _Basics_round;
var $elm$core$String$toFloat = _String_toFloat;
var $elm$core$String$toInt = _String_toInt;
var $elm$core$Dict$foldl = F3(
	function (func, acc, dict) {
		foldl:
		while (true) {
			if (dict.$ === -2) {
				return acc;
			} else {
				var key = dict.b;
				var value = dict.c;
				var left = dict.d;
				var right = dict.e;
				var $temp$func = func,
					$temp$acc = A3(
					func,
					key,
					value,
					A3($elm$core$Dict$foldl, func, acc, left)),
					$temp$dict = right;
				func = $temp$func;
				acc = $temp$acc;
				dict = $temp$dict;
				continue foldl;
			}
		}
	});
var $elm$core$Dict$union = F2(
	function (t1, t2) {
		return A3($elm$core$Dict$foldl, $elm$core$Dict$insert, t2, t1);
	});
var $elm$core$Dict$get = F2(
	function (targetKey, dict) {
		get:
		while (true) {
			if (dict.$ === -2) {
				return $elm$core$Maybe$Nothing;
			} else {
				var key = dict.b;
				var value = dict.c;
				var left = dict.d;
				var right = dict.e;
				var _v1 = A2($elm$core$Basics$compare, targetKey, key);
				switch (_v1) {
					case 0:
						var $temp$targetKey = targetKey,
							$temp$dict = left;
						targetKey = $temp$targetKey;
						dict = $temp$dict;
						continue get;
					case 1:
						return $elm$core$Maybe$Just(value);
					default:
						var $temp$targetKey = targetKey,
							$temp$dict = right;
						targetKey = $temp$targetKey;
						dict = $temp$dict;
						continue get;
				}
			}
		}
	});
var $elm$core$Maybe$withDefault = F2(
	function (_default, maybe) {
		if (!maybe.$) {
			var value = maybe.a;
			return value;
		} else {
			return _default;
		}
	});
var $author$project$Gestion$valeur = F2(
	function (cle, m) {
		return A2(
			$elm$core$Maybe$withDefault,
			'',
			A2($elm$core$Dict$get, cle, m.ap));
	});
var $author$project$Gestion$actualiser = F2(
	function (message, m) {
		switch (message.$) {
			case 0:
				var volet = message.a;
				return _Utils_Tuple2(
					_Utils_update(
						$author$project$Gestion$initial,
						{x: volet}),
					$elm$core$Maybe$Just(
						_Utils_Tuple2(
							'lister_' + volet,
							$elm$json$Json$Encode$object(_List_Nil))));
			case 1:
				var debut = message.a;
				return _Utils_Tuple2(
					_Utils_update(
						m,
						{
							a9: A2($elm$core$Basics$max, 0, debut),
							ay: $elm$core$Maybe$Nothing
						}),
					$elm$core$Maybe$Just(
						_Utils_Tuple2(
							'lister_' + m.x,
							$elm$json$Json$Encode$object(
								_List_fromArray(
									[
										_Utils_Tuple2(
										'debut',
										$elm$json$Json$Encode$int(
											A2($elm$core$Basics$max, 0, debut)))
									])))));
			case 2:
				var v = message.a;
				return _Utils_Tuple2(
					_Utils_update(
						m,
						{
							ap: $author$project$Gestion$charger(v),
							aJ: false,
							ay: $elm$core$Maybe$Just(v)
						}),
					$elm$core$Maybe$Nothing);
			case 7:
				return _Utils_Tuple2(
					_Utils_update(
						m,
						{aJ: true}),
					$elm$core$Maybe$Nothing);
			case 8:
				return A2($author$project$Gestion$procedure, 'demander_suppression', m);
			case 9:
				return A2($author$project$Gestion$procedure, 'annuler_suppression', m);
			case 3:
				return _Utils_Tuple2(
					_Utils_update(
						m,
						{
							ap: A2(
								$elm$core$Dict$union,
								$elm$core$Dict$fromList(
									_List_fromArray(
										[
											_Utils_Tuple2('quota', '10'),
											_Utils_Tuple2('maximum', '1')
										])),
								$author$project$Gestion$charger($elm$json$Json$Encode$null)),
							bh: '',
							ay: $elm$core$Maybe$Just($elm$json$Json$Encode$null)
						}),
					$elm$core$Maybe$Nothing);
			case 4:
				var cle = message.a;
				var v = message.b;
				return _Utils_Tuple2(
					_Utils_update(
						m,
						{
							ap: A3($elm$core$Dict$insert, cle, v, m.ap)
						}),
					$elm$core$Maybe$Nothing);
			case 5:
				var v = A2($elm$core$Maybe$withDefault, $elm$json$Json$Encode$null, m.ay);
				var invitation = _List_fromArray(
					[
						_Utils_Tuple2(
						'intitule',
						$elm$json$Json$Encode$string(
							A2($author$project$Gestion$valeur, 'intitule', m))),
						_Utils_Tuple2(
						'maximum',
						$elm$json$Json$Encode$int(
							A2(
								$elm$core$Maybe$withDefault,
								0,
								$elm$core$String$toInt(
									A2($author$project$Gestion$valeur, 'maximum', m))))),
						_Utils_Tuple2(
						'expire_a',
						$elm$json$Json$Encode$string(
							A2($author$project$Gestion$valeur, 'expire_a', m) + 'Z'))
					]);
				var commun = _List_fromArray(
					[
						_Utils_Tuple2(
						'quota_octets',
						$elm$json$Json$Encode$int(
							A2(
								$elm$core$Maybe$withDefault,
								0,
								A2(
									$elm$core$Maybe$map,
									A2(
										$elm$core$Basics$composeR,
										$elm$core$Basics$mul(1000000),
										$elm$core$Basics$round),
									$elm$core$String$toFloat(
										A2($author$project$Gestion$valeur, 'quota', m)))))),
						_Utils_Tuple2(
						'limites',
						$elm$json$Json$Encode$object(
							A2(
								$elm$core$List$map,
								function (_v2) {
									var k = _v2.a;
									return _Utils_Tuple2(
										k,
										$elm$json$Json$Encode$int(
											A2(
												$elm$core$Maybe$withDefault,
												0,
												$elm$core$String$toInt(
													A2($author$project$Gestion$valeur, k, m)))));
								},
								$author$project$Gestion$limites)))
					]);
				var _v1 = (m.x === 'comptes') ? _Utils_Tuple2(
					'modifier_compte',
					_List_fromArray(
						[
							_Utils_Tuple2(
							'utilisateur',
							$elm$json$Json$Encode$string(
								A2($author$project$Contrat$chaine, 'utilisateur', v))),
							_Utils_Tuple2(
							'version',
							$elm$json$Json$Encode$int(
								A2($author$project$Contrat$entier, 'version', v))),
							_Utils_Tuple2(
							'administrateur',
							$elm$json$Json$Encode$bool(
								A2($author$project$Gestion$valeur, 'administrateur', m) === 'oui')),
							_Utils_Tuple2(
							'actif',
							$elm$json$Json$Encode$bool(
								A2($author$project$Gestion$valeur, 'actif', m) === 'oui'))
						])) : (_Utils_eq(v, $elm$json$Json$Encode$null) ? _Utils_Tuple2('creer_invitation', invitation) : _Utils_Tuple2(
					'modifier_invitation',
					_Utils_ap(
						invitation,
						_List_fromArray(
							[
								_Utils_Tuple2(
								'id',
								$elm$json$Json$Encode$string(
									A2($author$project$Contrat$chaine, 'id', v))),
								_Utils_Tuple2(
								'version',
								$elm$json$Json$Encode$int(
									A2($author$project$Contrat$entier, 'version', v))),
								_Utils_Tuple2(
								'retroactif',
								$elm$json$Json$Encode$bool(
									A2($author$project$Gestion$valeur, 'retroactif', m) === 'oui'))
							]))));
				var op = _v1.a;
				var p = _v1.b;
				return _Utils_Tuple2(
					m,
					$elm$core$Maybe$Just(
						_Utils_Tuple2(
							op,
							$elm$json$Json$Encode$object(
								_Utils_ap(commun, p)))));
			default:
				var v = A2($elm$core$Maybe$withDefault, $elm$json$Json$Encode$null, m.ay);
				return _Utils_Tuple2(
					m,
					$elm$core$Maybe$Just(
						_Utils_Tuple2(
							'modifier_invitation',
							$elm$json$Json$Encode$object(
								_List_fromArray(
									[
										_Utils_Tuple2(
										'id',
										$elm$json$Json$Encode$string(
											A2($author$project$Contrat$chaine, 'id', v))),
										_Utils_Tuple2(
										'version',
										$elm$json$Json$Encode$int(
											A2($author$project$Contrat$entier, 'version', v))),
										_Utils_Tuple2(
										'revoquer',
										$elm$json$Json$Encode$bool(true))
									])))));
		}
	});
var $elm$core$Basics$identity = function (x) {
	return x;
};
var $author$project$Main$requete = _Platform_outgoingPort('requete', $elm$core$Basics$identity);
var $author$project$Main$envoyer = F4(
	function (but, chemin, corps, m) {
		var numero = m.aQ + 1;
		var suite = _Utils_update(
			m,
			{
				af: A3($elm$core$Dict$insert, numero, but, m.af),
				aQ: numero
			});
		var n = function () {
			switch (but.$) {
				case 3:
					return _Utils_update(
						suite,
						{b2: numero});
				case 4:
					return _Utils_update(
						suite,
						{b1: numero});
				default:
					return suite;
			}
		}();
		return _Utils_Tuple2(
			n,
			$author$project$Main$requete(
				$elm$json$Json$Encode$object(
					_List_fromArray(
						[
							_Utils_Tuple2(
							'numero',
							$elm$json$Json$Encode$int(numero)),
							_Utils_Tuple2(
							'chemin',
							$elm$json$Json$Encode$string(chemin)),
							_Utils_Tuple2(
							'methode',
							$elm$json$Json$Encode$string(
								(chemin === '/auth/session') ? 'GET' : 'POST')),
							_Utils_Tuple2(
							'csrf',
							A2(
								$elm$core$Maybe$withDefault,
								$elm$json$Json$Encode$null,
								A2(
									$elm$core$Maybe$map,
									A2(
										$elm$core$Basics$composeR,
										function ($) {
											return $.b0;
										},
										$elm$json$Json$Encode$string),
									m.E))),
							_Utils_Tuple2('corps', corps)
						]))));
	});
var $author$project$Main$api = F3(
	function (but, operation, valeurs) {
		return A3(
			$author$project$Main$envoyer,
			but,
			'/api/web/' + operation,
			$elm$json$Json$Encode$object(valeurs));
	});
var $elm$core$Platform$Cmd$batch = _Platform_batch;
var $author$project$Main$effets = _Platform_outgoingPort('effets', $elm$core$Basics$identity);
var $author$project$Main$effet = F2(
	function (nom, contenu) {
		return $author$project$Main$effets(
			$elm$json$Json$Encode$object(
				_List_fromArray(
					[
						_Utils_Tuple2(
						'nom',
						$elm$json$Json$Encode$string(nom)),
						_Utils_Tuple2('valeur', contenu)
					])));
	});
var $author$project$Main$avecAdresse = F2(
	function (url, _v0) {
		var modele = _v0.a;
		var commande = _v0.b;
		return _Utils_Tuple2(
			modele,
			$elm$core$Platform$Cmd$batch(
				_List_fromArray(
					[
						commande,
						A2(
						$author$project$Main$effet,
						'adresse',
						$elm$json$Json$Encode$string(url))
					])));
	});
var $elm$json$Json$Decode$list = _Json_decodeList;
var $author$project$Contrat$listes = F2(
	function (cle, valeur) {
		return A2(
			$elm$core$Result$withDefault,
			_List_Nil,
			A2(
				$elm$json$Json$Decode$decodeValue,
				A2(
					$elm$json$Json$Decode$field,
					cle,
					$elm$json$Json$Decode$list($elm$json$Json$Decode$value)),
				valeur));
	});
var $author$project$Contrat$nouveau = $elm$core$Dict$fromList(
	_List_fromArray(
		[
			_Utils_Tuple2('titre', ''),
			_Utils_Tuple2('contenu', ''),
			_Utils_Tuple2('suivi', ''),
			_Utils_Tuple2('tags', ''),
			_Utils_Tuple2('alias', ''),
			_Utils_Tuple2('priorite', '0'),
			_Utils_Tuple2('stabilite', '-15'),
			_Utils_Tuple2('reference_a', ''),
			_Utils_Tuple2('justification', ''),
			_Utils_Tuple2('distinction', '')
		]));
var $author$project$Contrat$texte = function (valeur) {
	return A2(
		$elm$core$Result$withDefault,
		'',
		A2($elm$json$Json$Decode$decodeValue, $elm$json$Json$Decode$string, valeur));
};
var $author$project$Contrat$brouillon = function (valeur) {
	var tableaux = A2(
		$elm$core$List$map,
		function (cle) {
			return _Utils_Tuple2(
				cle,
				A2(
					$elm$core$String$join,
					'\n',
					A2(
						$elm$core$List$map,
						$author$project$Contrat$texte,
						A2($author$project$Contrat$listes, cle, valeur))));
		},
		_List_fromArray(
			['alias', 'tags']));
	var chaines = A2(
		$elm$core$List$map,
		function (cle) {
			return _Utils_Tuple2(
				cle,
				A2($author$project$Contrat$chaine, cle, valeur));
		},
		_List_fromArray(
			['titre', 'contenu', 'suivi']));
	return A2(
		$elm$core$Dict$union,
		$elm$core$Dict$fromList(
			_Utils_ap(
				chaines,
				_Utils_ap(
					tableaux,
					_List_fromArray(
						[
							_Utils_Tuple2(
							'priorite',
							$elm$core$String$fromInt(
								A2($author$project$Contrat$entier, 'priorite', valeur))),
							_Utils_Tuple2(
							'stabilite',
							$elm$core$String$fromInt(
								A2($author$project$Contrat$entier, 'stabilite', valeur)))
						])))),
		$author$project$Contrat$nouveau);
};
var $author$project$Main$changerAdresse = F2(
	function (nouvelle, flags) {
		return _Utils_update(
			flags,
			{cV: nouvelle});
	});
var $author$project$Admission$corps = F3(
	function (invitation, notice, m) {
		return $elm$json$Json$Encode$object(
			_List_fromArray(
				[
					_Utils_Tuple2(
					'invitation',
					$elm$json$Json$Encode$string(invitation)),
					_Utils_Tuple2(
					'notice',
					$elm$json$Json$Encode$string(notice)),
					_Utils_Tuple2(
					'courriel',
					$elm$json$Json$Encode$string(m.bw)),
					_Utils_Tuple2(
					'pays',
					$elm$json$Json$Encode$string(m.bF)),
					_Utils_Tuple2(
					'age',
					$elm$json$Json$Encode$string(m.aC)),
					_Utils_Tuple2(
					'parent',
					$elm$json$Json$Encode$string(m.aV)),
					_Utils_Tuple2(
					'pseudonyme',
					$elm$json$Json$Encode$string(m.bH))
				]));
	});
var $elm$core$Maybe$andThen = F2(
	function (callback, maybeValue) {
		if (!maybeValue.$) {
			var value = maybeValue.a;
			return callback(value);
		} else {
			return $elm$core$Maybe$Nothing;
		}
	});
var $elm$core$String$length = _String_length;
var $elm$core$String$dropLeft = F2(
	function (n, string) {
		return (n < 1) ? string : A3(
			$elm$core$String$slice,
			n,
			$elm$core$String$length(string),
			string);
	});
var $elm$core$Maybe$map2 = F3(
	function (func, ma, mb) {
		if (ma.$ === 1) {
			return $elm$core$Maybe$Nothing;
		} else {
			var a = ma.a;
			if (mb.$ === 1) {
				return $elm$core$Maybe$Nothing;
			} else {
				var b = mb.a;
				return $elm$core$Maybe$Just(
					A2(func, a, b));
			}
		}
	});
var $elm$core$Basics$not = _Basics_not;
var $elm$core$Tuple$pair = F2(
	function (a, b) {
		return _Utils_Tuple2(a, b);
	});
var $elm$core$String$startsWith = _String_startsWith;
var $author$project$Contrat$depuisAdresse = function (adresse) {
	if (!A2($elm$core$String$startsWith, '#', adresse)) {
		return $elm$core$Maybe$Nothing;
	} else {
		var _v0 = A2(
			$elm$core$String$split,
			'/',
			A2($elm$core$String$dropLeft, 1, adresse));
		if ((_v0.b && _v0.b.b) && (!_v0.b.b.b)) {
			var nature = _v0.a;
			var _v1 = _v0.b;
			var identifiant = _v1.a;
			return A3(
				$elm$core$Maybe$map2,
				$elm$core$Tuple$pair,
				function () {
					switch (nature) {
						case 'fiche':
							return $elm$core$Maybe$Just(0);
						case 'item':
							return $elm$core$Maybe$Just(1);
						default:
							return $elm$core$Maybe$Nothing;
					}
				}(),
				A2(
					$elm$core$Maybe$andThen,
					function (id) {
						return (id > 0) ? $elm$core$Maybe$Just(id) : $elm$core$Maybe$Nothing;
					},
					$elm$core$String$toInt(identifiant)));
		} else {
			return $elm$core$Maybe$Nothing;
		}
	}
};
var $author$project$Contrat$nom = function (nature) {
	if (!nature) {
		return 'fiche';
	} else {
		return 'item';
	}
};
var $author$project$Contrat$destination = F2(
	function (nature, id) {
		return '#' + ($author$project$Contrat$nom(nature) + ('/' + $elm$core$String$fromInt(id)));
	});
var $elm$core$Platform$Cmd$none = $elm$core$Platform$Cmd$batch(_List_Nil);
var $author$project$Main$notifier = F3(
	function (niveau, texte, m) {
		return _Utils_Tuple2(
			_Utils_update(
				m,
				{
					H: $elm$core$Maybe$Just(
						_Utils_Tuple2(niveau, texte))
				}),
			$elm$core$Platform$Cmd$none);
	});
var $author$project$Main$ecrire = F4(
	function (but, operation, valeurs, m) {
		if (!_Utils_eq(m.e, $elm$core$Maybe$Nothing)) {
			return A3($author$project$Main$notifier, 0, 'Une écriture attend son résultat. Réessayez la même opération.', m);
		} else {
			var e = {
				co: but,
				bV: '/api/web/' + operation,
				b$: $elm$json$Json$Encode$object(
					A2(
						$elm$core$List$cons,
						_Utils_Tuple2(
							'cle',
							$elm$json$Json$Encode$string(
								m.f.cq + ('-' + $elm$core$String$fromInt(m.aQ + 1)))),
						A2(
							$elm$core$List$cons,
							_Utils_Tuple2(
								'emise_a',
								$elm$json$Json$Encode$string(m.f.b8)),
							valeurs)))
			};
			return A4(
				$author$project$Main$envoyer,
				but,
				e.bV,
				e.b$,
				_Utils_update(
					m,
					{
						e: $elm$core$Maybe$Just(e),
						H: $elm$core$Maybe$Nothing
					}));
		}
	});
var $elm$core$Basics$ge = _Utils_ge;
var $author$project$Main$entierValide = F3(
	function (minimum, maximum, texte) {
		return A2(
			$elm$core$Maybe$withDefault,
			false,
			A2(
				$elm$core$Maybe$map,
				function (nombre) {
					return (_Utils_cmp(nombre, minimum) > -1) && (_Utils_cmp(nombre, maximum) < 1);
				},
				$elm$core$String$toInt(texte)));
	});
var $author$project$Main$Deconnecter = {$: 2};
var $author$project$Main$EffacerCompte = {$: 19};
var $author$project$Main$Enregistrer = function (a) {
	return {$: 5, a: a};
};
var $author$project$Main$Lister = function (a) {
	return {$: 3, a: a};
};
var $elm$json$Json$Encode$list = F2(
	function (func, entries) {
		return _Json_wrap(
			A3(
				$elm$core$List$foldl,
				_Json_addEntry(func),
				_Json_emptyArray(0),
				entries));
	});
var $elm$core$String$trim = _String_trim;
var $author$project$Main$lister = function (m) {
	return A4(
		$author$project$Main$api,
		$author$project$Main$Lister(m.a),
		'rechercher',
		_List_fromArray(
			[
				_Utils_Tuple2(
				'type',
				$elm$json$Json$Encode$string(
					$author$project$Contrat$nom(m.a))),
				_Utils_Tuple2(
				'requete',
				$elm$json$Json$Encode$string(m.bI)),
				_Utils_Tuple2(
				'etat',
				$elm$json$Json$Encode$string(m.by)),
				_Utils_Tuple2(
				'tri',
				$elm$json$Json$Encode$string(m.bn)),
				_Utils_Tuple2(
				'limite',
				$elm$json$Json$Encode$int(20)),
				_Utils_Tuple2(
				'decalage',
				$elm$json$Json$Encode$int(m.a9)),
				_Utils_Tuple2(
				'tags',
				A2(
					$elm$json$Json$Encode$list,
					$elm$json$Json$Encode$string,
					A2(
						$elm$core$List$filter,
						$elm$core$Basics$neq(''),
						A2(
							$elm$core$List$map,
							$elm$core$String$trim,
							A2($elm$core$String$split, ',', m.bK)))))
			]),
		m);
};
var $author$project$Main$executer = F2(
	function (action, m) {
		var n = _Utils_update(
			m,
			{aI: $elm$core$Maybe$Nothing, H: $elm$core$Maybe$Nothing});
		switch (action.$) {
			case 0:
				var nature = action.a;
				return A2(
					$author$project$Main$avecAdresse,
					(nature === 1) ? '#items' : '#fiches',
					$author$project$Main$lister(
						_Utils_update(
							n,
							{
								z: _List_Nil,
								aG: false,
								a9: 0,
								c: $elm$core$Maybe$Nothing,
								i: false,
								l: $elm$core$Maybe$Nothing,
								aM: false,
								aj: false,
								g: false,
								m: false,
								a: nature,
								bk: _List_Nil,
								bn: (nature === 1) ? 'alphabetique' : 'titre'
							})));
			case 1:
				return A2(
					$author$project$Main$avecAdresse,
					(n.a === 1) ? '#items' : '#fiches',
					$author$project$Main$lister(
						_Utils_update(
							n,
							{z: _List_Nil, c: $elm$core$Maybe$Nothing, i: false, l: $elm$core$Maybe$Nothing, aj: false, g: false, m: false})));
			case 3:
				return (m.aK === 'EFFACER VISION') ? A4(
					$author$project$Main$api,
					$author$project$Main$EffacerCompte,
					'effacer_compte',
					_List_fromArray(
						[
							_Utils_Tuple2(
							'confirmation',
							$elm$json$Json$Encode$string(m.aK))
						]),
					n) : A3($author$project$Main$notifier, 3, 'Saisissez EFFACER VISION pour confirmer.', m);
			case 2:
				return A4(
					$author$project$Main$envoyer,
					$author$project$Main$Deconnecter,
					'/auth/logout',
					$elm$json$Json$Encode$object(_List_Nil),
					n);
			case 4:
				var archive = action.a;
				var _v1 = n.c;
				if (_v1.$ === 1) {
					return _Utils_Tuple2(n, $elm$core$Platform$Cmd$none);
				} else {
					var d = _v1.a;
					return A4(
						$author$project$Main$ecrire,
						$author$project$Main$Enregistrer(n.a),
						'enregistrer_' + $author$project$Contrat$nom(n.a),
						_List_fromArray(
							[
								_Utils_Tuple2(
								'id',
								$elm$json$Json$Encode$int(
									A2($author$project$Contrat$entier, 'id', d))),
								_Utils_Tuple2(
								'version',
								$elm$json$Json$Encode$int(
									A2($author$project$Contrat$entier, 'version', d))),
								_Utils_Tuple2(
								'archive',
								$elm$json$Json$Encode$bool(archive))
							]),
						n);
				}
			default:
				var fiche = action.a;
				var item = action.b;
				var version = action.c;
				return A4(
					$author$project$Main$ecrire,
					$author$project$Main$Lier,
					'lier_item',
					_List_fromArray(
						[
							_Utils_Tuple2(
							'fiche_id',
							$elm$json$Json$Encode$int(fiche)),
							_Utils_Tuple2(
							'item_id',
							$elm$json$Json$Encode$int(item)),
							_Utils_Tuple2(
							'version_fiche',
							$elm$json$Json$Encode$int(version)),
							_Utils_Tuple2(
							'action',
							$elm$json$Json$Encode$string('detacher'))
						]),
					n);
		}
	});
var $elm$core$List$head = function (list) {
	if (list.b) {
		var x = list.a;
		var xs = list.b;
		return $elm$core$Maybe$Just(x);
	} else {
		return $elm$core$Maybe$Nothing;
	}
};
var $author$project$Admission$initial = {aC: '', bw: '', aV: '', bF: '', bH: ''};
var $author$project$Compte$initial = {a9: 0, bz: _List_Nil, bf: 'json', ay: _List_Nil, cf: false, bm: true};
var $author$project$Main$initial = function (flags) {
	return {a5: false, aA: $author$project$Admission$initial, aB: $elm$json$Json$Encode$null, af: $elm$core$Dict$empty, a6: '', y: $author$project$Contrat$nouveau, N: '', z: _List_Nil, ah: $author$project$Compte$initial, aG: false, aH: '', aI: $elm$core$Maybe$Nothing, D: '', c2: false, S: false, a9: 0, T: 0, b1: 0, b2: 0, c: $elm$core$Maybe$Nothing, U: '60', e: $elm$core$Maybe$Nothing, i: false, l: $elm$core$Maybe$Nothing, aK: '', by: 'actif', bc: false, bd: 'tous', be: false, f: flags, as: $author$project$Gestion$initial, cy: '', aM: false, bg: '', V: '90', W: $elm$json$Json$Encode$null, aj: false, bi: _List_Nil, bB: $elm$json$Json$Encode$null, du: false, H: $elm$core$Maybe$Nothing, g: false, m: false, a: 0, dB: $elm$json$Json$Encode$null, bE: false, aQ: 0, aT: $elm$core$Maybe$Nothing, _: $elm$json$Json$Encode$null, al: $elm$core$Maybe$Nothing, aa: '8', bI: '', bJ: '', aX: false, n: _List_Nil, bk: _List_Nil, aY: '', E: $elm$core$Maybe$Nothing, a_: $elm$core$Maybe$Nothing, bK: '', a0: 0, bn: 'titre', bo: 'echeance', bQ: '', an: true};
};
var $elm$core$List$isEmpty = function (xs) {
	if (!xs.b) {
		return true;
	} else {
		return false;
	}
};
var $elm$core$String$isEmpty = function (string) {
	return string === '';
};
var $author$project$Main$Lire = F2(
	function (a, b) {
		return {$: 4, a: a, b: b};
	});
var $author$project$Main$lire = F3(
	function (nature, id, m) {
		return A4(
			$author$project$Main$api,
			A2($author$project$Main$Lire, nature, id),
			'lire',
			_List_fromArray(
				[
					_Utils_Tuple2(
					'type',
					$elm$json$Json$Encode$string(
						$author$project$Contrat$nom(nature))),
					_Utils_Tuple2(
					'ids',
					A2(
						$elm$json$Json$Encode$list,
						$elm$json$Json$Encode$int,
						_List_fromArray(
							[id]))),
					_Utils_Tuple2(
					'decalage',
					$elm$json$Json$Encode$int(m.T)),
					_Utils_Tuple2(
					'limite',
					$elm$json$Json$Encode$int(20)),
					_Utils_Tuple2(
					'tri_liens',
					$elm$json$Json$Encode$string(m.bo)),
					_Utils_Tuple2(
					'filtre_liens',
					$elm$json$Json$Encode$string(m.bd))
				]),
			m);
	});
var $elm$json$Json$Decode$map4 = _Json_map4;
var $elm$core$List$any = F2(
	function (isOkay, list) {
		any:
		while (true) {
			if (!list.b) {
				return false;
			} else {
				var x = list.a;
				var xs = list.b;
				if (isOkay(x)) {
					return true;
				} else {
					var $temp$isOkay = isOkay,
						$temp$list = xs;
					isOkay = $temp$isOkay;
					list = $temp$list;
					continue any;
				}
			}
		}
	});
var $elm$core$List$member = F2(
	function (x, xs) {
		return A2(
			$elm$core$List$any,
			function (a) {
				return _Utils_eq(a, x);
			},
			xs);
	});
var $elm$json$Json$Decode$float = _Json_decodeFloat;
var $elm$core$Result$toMaybe = function (result) {
	if (!result.$) {
		var v = result.a;
		return $elm$core$Maybe$Just(v);
	} else {
		return $elm$core$Maybe$Nothing;
	}
};
var $author$project$Contrat$nombre = F2(
	function (cle, valeur) {
		return $elm$core$Result$toMaybe(
			A2(
				$elm$json$Json$Decode$decodeValue,
				A2($elm$json$Json$Decode$field, cle, $elm$json$Json$Decode$float),
				valeur));
	});
var $elm$json$Json$Decode$oneOf = _Json_oneOf;
var $author$project$Informations$publique = function (chemin) {
	return A2(
		$elm$core$List$member,
		chemin,
		_List_fromArray(
			['/docs', '/docs/', '/privacy']));
};
var $author$project$Compte$recevoir = F2(
	function (page, m) {
		return _Utils_update(
			m,
			{
				bz: A2($author$project$Contrat$listes, 'lignes', page),
				cf: A2($author$project$Contrat$vrai, 'suite', page)
			});
	});
var $author$project$Gestion$recevoir = F3(
	function (op, v, m) {
		return A2($elm$core$String$startsWith, 'lister_', op) ? _Utils_update(
			m,
			{
				aP: A2($author$project$Contrat$listes, m.x, v),
				a0: A2($author$project$Contrat$entier, 'total', v)
			}) : _Utils_update(
			m,
			{
				ap: $author$project$Gestion$charger(v),
				aJ: false,
				bh: A2($author$project$Contrat$chaine, 'lien', v),
				aP: (op === 'creer_invitation') ? A2($elm$core$List$cons, v, m.aP) : A2(
					$elm$core$List$map,
					function (ligne) {
						return ((_Utils_eq(
							A2($author$project$Contrat$chaine, 'utilisateur', ligne),
							A2($author$project$Contrat$chaine, 'utilisateur', v)) && (m.x === 'comptes')) || (_Utils_eq(
							A2($author$project$Contrat$chaine, 'id', ligne),
							A2($author$project$Contrat$chaine, 'id', v)) && (m.x === 'invitations'))) ? v : ligne;
					},
					m.aP),
				ay: $elm$core$Maybe$Just(v),
				a0: m.a0 + ((op === 'creer_invitation') ? 1 : 0)
			});
	});
var $elm$core$Dict$getMin = function (dict) {
	getMin:
	while (true) {
		if ((dict.$ === -1) && (dict.d.$ === -1)) {
			var left = dict.d;
			var $temp$dict = left;
			dict = $temp$dict;
			continue getMin;
		} else {
			return dict;
		}
	}
};
var $elm$core$Dict$moveRedLeft = function (dict) {
	if (((dict.$ === -1) && (dict.d.$ === -1)) && (dict.e.$ === -1)) {
		if ((dict.e.d.$ === -1) && (!dict.e.d.a)) {
			var clr = dict.a;
			var k = dict.b;
			var v = dict.c;
			var _v1 = dict.d;
			var lClr = _v1.a;
			var lK = _v1.b;
			var lV = _v1.c;
			var lLeft = _v1.d;
			var lRight = _v1.e;
			var _v2 = dict.e;
			var rClr = _v2.a;
			var rK = _v2.b;
			var rV = _v2.c;
			var rLeft = _v2.d;
			var _v3 = rLeft.a;
			var rlK = rLeft.b;
			var rlV = rLeft.c;
			var rlL = rLeft.d;
			var rlR = rLeft.e;
			var rRight = _v2.e;
			return A5(
				$elm$core$Dict$RBNode_elm_builtin,
				0,
				rlK,
				rlV,
				A5(
					$elm$core$Dict$RBNode_elm_builtin,
					1,
					k,
					v,
					A5($elm$core$Dict$RBNode_elm_builtin, 0, lK, lV, lLeft, lRight),
					rlL),
				A5($elm$core$Dict$RBNode_elm_builtin, 1, rK, rV, rlR, rRight));
		} else {
			var clr = dict.a;
			var k = dict.b;
			var v = dict.c;
			var _v4 = dict.d;
			var lClr = _v4.a;
			var lK = _v4.b;
			var lV = _v4.c;
			var lLeft = _v4.d;
			var lRight = _v4.e;
			var _v5 = dict.e;
			var rClr = _v5.a;
			var rK = _v5.b;
			var rV = _v5.c;
			var rLeft = _v5.d;
			var rRight = _v5.e;
			if (clr === 1) {
				return A5(
					$elm$core$Dict$RBNode_elm_builtin,
					1,
					k,
					v,
					A5($elm$core$Dict$RBNode_elm_builtin, 0, lK, lV, lLeft, lRight),
					A5($elm$core$Dict$RBNode_elm_builtin, 0, rK, rV, rLeft, rRight));
			} else {
				return A5(
					$elm$core$Dict$RBNode_elm_builtin,
					1,
					k,
					v,
					A5($elm$core$Dict$RBNode_elm_builtin, 0, lK, lV, lLeft, lRight),
					A5($elm$core$Dict$RBNode_elm_builtin, 0, rK, rV, rLeft, rRight));
			}
		}
	} else {
		return dict;
	}
};
var $elm$core$Dict$moveRedRight = function (dict) {
	if (((dict.$ === -1) && (dict.d.$ === -1)) && (dict.e.$ === -1)) {
		if ((dict.d.d.$ === -1) && (!dict.d.d.a)) {
			var clr = dict.a;
			var k = dict.b;
			var v = dict.c;
			var _v1 = dict.d;
			var lClr = _v1.a;
			var lK = _v1.b;
			var lV = _v1.c;
			var _v2 = _v1.d;
			var _v3 = _v2.a;
			var llK = _v2.b;
			var llV = _v2.c;
			var llLeft = _v2.d;
			var llRight = _v2.e;
			var lRight = _v1.e;
			var _v4 = dict.e;
			var rClr = _v4.a;
			var rK = _v4.b;
			var rV = _v4.c;
			var rLeft = _v4.d;
			var rRight = _v4.e;
			return A5(
				$elm$core$Dict$RBNode_elm_builtin,
				0,
				lK,
				lV,
				A5($elm$core$Dict$RBNode_elm_builtin, 1, llK, llV, llLeft, llRight),
				A5(
					$elm$core$Dict$RBNode_elm_builtin,
					1,
					k,
					v,
					lRight,
					A5($elm$core$Dict$RBNode_elm_builtin, 0, rK, rV, rLeft, rRight)));
		} else {
			var clr = dict.a;
			var k = dict.b;
			var v = dict.c;
			var _v5 = dict.d;
			var lClr = _v5.a;
			var lK = _v5.b;
			var lV = _v5.c;
			var lLeft = _v5.d;
			var lRight = _v5.e;
			var _v6 = dict.e;
			var rClr = _v6.a;
			var rK = _v6.b;
			var rV = _v6.c;
			var rLeft = _v6.d;
			var rRight = _v6.e;
			if (clr === 1) {
				return A5(
					$elm$core$Dict$RBNode_elm_builtin,
					1,
					k,
					v,
					A5($elm$core$Dict$RBNode_elm_builtin, 0, lK, lV, lLeft, lRight),
					A5($elm$core$Dict$RBNode_elm_builtin, 0, rK, rV, rLeft, rRight));
			} else {
				return A5(
					$elm$core$Dict$RBNode_elm_builtin,
					1,
					k,
					v,
					A5($elm$core$Dict$RBNode_elm_builtin, 0, lK, lV, lLeft, lRight),
					A5($elm$core$Dict$RBNode_elm_builtin, 0, rK, rV, rLeft, rRight));
			}
		}
	} else {
		return dict;
	}
};
var $elm$core$Dict$removeHelpPrepEQGT = F7(
	function (targetKey, dict, color, key, value, left, right) {
		if ((left.$ === -1) && (!left.a)) {
			var _v1 = left.a;
			var lK = left.b;
			var lV = left.c;
			var lLeft = left.d;
			var lRight = left.e;
			return A5(
				$elm$core$Dict$RBNode_elm_builtin,
				color,
				lK,
				lV,
				lLeft,
				A5($elm$core$Dict$RBNode_elm_builtin, 0, key, value, lRight, right));
		} else {
			_v2$2:
			while (true) {
				if ((right.$ === -1) && (right.a === 1)) {
					if (right.d.$ === -1) {
						if (right.d.a === 1) {
							var _v3 = right.a;
							var _v4 = right.d;
							var _v5 = _v4.a;
							return $elm$core$Dict$moveRedRight(dict);
						} else {
							break _v2$2;
						}
					} else {
						var _v6 = right.a;
						var _v7 = right.d;
						return $elm$core$Dict$moveRedRight(dict);
					}
				} else {
					break _v2$2;
				}
			}
			return dict;
		}
	});
var $elm$core$Dict$removeMin = function (dict) {
	if ((dict.$ === -1) && (dict.d.$ === -1)) {
		var color = dict.a;
		var key = dict.b;
		var value = dict.c;
		var left = dict.d;
		var lColor = left.a;
		var lLeft = left.d;
		var right = dict.e;
		if (lColor === 1) {
			if ((lLeft.$ === -1) && (!lLeft.a)) {
				var _v3 = lLeft.a;
				return A5(
					$elm$core$Dict$RBNode_elm_builtin,
					color,
					key,
					value,
					$elm$core$Dict$removeMin(left),
					right);
			} else {
				var _v4 = $elm$core$Dict$moveRedLeft(dict);
				if (_v4.$ === -1) {
					var nColor = _v4.a;
					var nKey = _v4.b;
					var nValue = _v4.c;
					var nLeft = _v4.d;
					var nRight = _v4.e;
					return A5(
						$elm$core$Dict$balance,
						nColor,
						nKey,
						nValue,
						$elm$core$Dict$removeMin(nLeft),
						nRight);
				} else {
					return $elm$core$Dict$RBEmpty_elm_builtin;
				}
			}
		} else {
			return A5(
				$elm$core$Dict$RBNode_elm_builtin,
				color,
				key,
				value,
				$elm$core$Dict$removeMin(left),
				right);
		}
	} else {
		return $elm$core$Dict$RBEmpty_elm_builtin;
	}
};
var $elm$core$Dict$removeHelp = F2(
	function (targetKey, dict) {
		if (dict.$ === -2) {
			return $elm$core$Dict$RBEmpty_elm_builtin;
		} else {
			var color = dict.a;
			var key = dict.b;
			var value = dict.c;
			var left = dict.d;
			var right = dict.e;
			if (_Utils_cmp(targetKey, key) < 0) {
				if ((left.$ === -1) && (left.a === 1)) {
					var _v4 = left.a;
					var lLeft = left.d;
					if ((lLeft.$ === -1) && (!lLeft.a)) {
						var _v6 = lLeft.a;
						return A5(
							$elm$core$Dict$RBNode_elm_builtin,
							color,
							key,
							value,
							A2($elm$core$Dict$removeHelp, targetKey, left),
							right);
					} else {
						var _v7 = $elm$core$Dict$moveRedLeft(dict);
						if (_v7.$ === -1) {
							var nColor = _v7.a;
							var nKey = _v7.b;
							var nValue = _v7.c;
							var nLeft = _v7.d;
							var nRight = _v7.e;
							return A5(
								$elm$core$Dict$balance,
								nColor,
								nKey,
								nValue,
								A2($elm$core$Dict$removeHelp, targetKey, nLeft),
								nRight);
						} else {
							return $elm$core$Dict$RBEmpty_elm_builtin;
						}
					}
				} else {
					return A5(
						$elm$core$Dict$RBNode_elm_builtin,
						color,
						key,
						value,
						A2($elm$core$Dict$removeHelp, targetKey, left),
						right);
				}
			} else {
				return A2(
					$elm$core$Dict$removeHelpEQGT,
					targetKey,
					A7($elm$core$Dict$removeHelpPrepEQGT, targetKey, dict, color, key, value, left, right));
			}
		}
	});
var $elm$core$Dict$removeHelpEQGT = F2(
	function (targetKey, dict) {
		if (dict.$ === -1) {
			var color = dict.a;
			var key = dict.b;
			var value = dict.c;
			var left = dict.d;
			var right = dict.e;
			if (_Utils_eq(targetKey, key)) {
				var _v1 = $elm$core$Dict$getMin(right);
				if (_v1.$ === -1) {
					var minKey = _v1.b;
					var minValue = _v1.c;
					return A5(
						$elm$core$Dict$balance,
						color,
						minKey,
						minValue,
						left,
						$elm$core$Dict$removeMin(right));
				} else {
					return $elm$core$Dict$RBEmpty_elm_builtin;
				}
			} else {
				return A5(
					$elm$core$Dict$balance,
					color,
					key,
					value,
					left,
					A2($elm$core$Dict$removeHelp, targetKey, right));
			}
		} else {
			return $elm$core$Dict$RBEmpty_elm_builtin;
		}
	});
var $elm$core$Dict$remove = F2(
	function (key, dict) {
		var _v0 = A2($elm$core$Dict$removeHelp, key, dict);
		if ((_v0.$ === -1) && (!_v0.a)) {
			var _v1 = _v0.a;
			var k = _v0.b;
			var v = _v0.c;
			var l = _v0.d;
			var r = _v0.e;
			return A5($elm$core$Dict$RBNode_elm_builtin, 1, k, v, l, r);
		} else {
			var x = _v0;
			return x;
		}
	});
var $author$project$Main$VerifierCreation = {$: 7};
var $elm$core$String$lines = _String_lines;
var $author$project$Contrat$lignes = A2(
	$elm$core$Basics$composeR,
	$elm$core$String$lines,
	A2(
		$elm$core$Basics$composeR,
		$elm$core$List$map($elm$core$String$trim),
		$elm$core$List$filter(
			$elm$core$Basics$neq(''))));
var $elm$core$Basics$negate = function (n) {
	return -n;
};
var $author$project$Main$valeur = F2(
	function (cle, m) {
		return A2(
			$elm$core$Maybe$withDefault,
			'',
			A2($elm$core$Dict$get, cle, m.y));
	});
var $author$project$Main$corpsEdition = function (m) {
	var version = A2(
		$elm$core$Maybe$withDefault,
		_List_Nil,
		A2(
			$elm$core$Maybe$map,
			function (d) {
				return _List_fromArray(
					[
						_Utils_Tuple2(
						'id',
						$elm$json$Json$Encode$int(
							A2($author$project$Contrat$entier, 'id', d))),
						_Utils_Tuple2(
						'version',
						$elm$json$Json$Encode$int(
							A2($author$project$Contrat$entier, 'version', d)))
					]);
			},
			m.c));
	var textes = A2(
		$elm$core$List$map,
		function (cle) {
			return _Utils_Tuple2(
				cle,
				$elm$json$Json$Encode$string(
					A2($author$project$Main$valeur, cle, m)));
		},
		(!m.a) ? _List_fromArray(
			['titre', 'contenu', 'suivi']) : _List_fromArray(
			['contenu']));
	var tableaux = A2(
		$elm$core$List$map,
		function (cle) {
			return _Utils_Tuple2(
				cle,
				A2(
					$elm$json$Json$Encode$list,
					$elm$json$Json$Encode$string,
					$author$project$Contrat$lignes(
						A2($author$project$Main$valeur, cle, m))));
		},
		(!m.a) ? _List_fromArray(
			['alias', 'tags']) : _List_fromArray(
			['alias']));
	var specifiques = (!m.a) ? _List_fromArray(
		[
			_Utils_Tuple2(
			'priorite',
			$elm$json$Json$Encode$int(
				A2(
					$elm$core$Maybe$withDefault,
					0,
					$elm$core$String$toInt(
						A2($author$project$Main$valeur, 'priorite', m)))))
		]) : ((!_Utils_eq(m.c, $elm$core$Maybe$Nothing)) ? _List_Nil : _Utils_ap(
		_List_fromArray(
			[
				_Utils_Tuple2(
				'stabilite',
				$elm$json$Json$Encode$int(
					A2(
						$elm$core$Maybe$withDefault,
						-15,
						$elm$core$String$toInt(
							A2($author$project$Main$valeur, 'stabilite', m))))),
				_Utils_Tuple2(
				'preuve_creation',
				A2(
					$elm$core$Maybe$withDefault,
					$elm$json$Json$Encode$null,
					A2($elm$core$Maybe$map, $elm$json$Json$Encode$string, m.al))),
				_Utils_Tuple2(
				'candidats_examines',
				A2(
					$elm$json$Json$Encode$list,
					$elm$json$Json$Encode$int,
					A2(
						$elm$core$List$map,
						$author$project$Contrat$entier('id'),
						m.z))),
				_Utils_Tuple2(
				'distinction',
				$elm$json$Json$Encode$string(
					A2($author$project$Main$valeur, 'distinction', m))),
				_Utils_Tuple2(
				'justification',
				$elm$json$Json$Encode$string(
					A2($author$project$Main$valeur, 'justification', m)))
			]),
		$elm$core$String$isEmpty(
			A2($author$project$Main$valeur, 'reference_a', m)) ? _List_Nil : _List_fromArray(
			[
				_Utils_Tuple2(
				'reference_a',
				$elm$json$Json$Encode$string(
					A2($author$project$Main$valeur, 'reference_a', m)))
			])));
	return _Utils_ap(
		textes,
		_Utils_ap(
			tableaux,
			_Utils_ap(version, specifiques)));
};
var $author$project$Main$sauver = function (m) {
	return ($elm$core$String$isEmpty(
		$elm$core$String$trim(
			A2($author$project$Main$valeur, 'contenu', m))) || ((!m.a) && $elm$core$String$isEmpty(
		$elm$core$String$trim(
			A2($author$project$Main$valeur, 'titre', m))))) ? A3($author$project$Main$notifier, 3, 'Le contenu et, pour une fiche, le titre sont requis.', m) : (((!m.a) && (!A3(
		$author$project$Main$entierValide,
		-20,
		20,
		A2($author$project$Main$valeur, 'priorite', m)))) ? A3($author$project$Main$notifier, 3, 'La priorité doit être un entier de −20 à +20 dB.', m) : (((m.a === 1) && (_Utils_eq(m.c, $elm$core$Maybe$Nothing) && (!A3(
		$author$project$Main$entierValide,
		-128,
		127,
		A2($author$project$Main$valeur, 'stabilite', m))))) ? A3($author$project$Main$notifier, 3, 'La stabilité doit être un entier de −128 à +127 dB.', m) : (((m.a === 1) && (_Utils_eq(m.c, $elm$core$Maybe$Nothing) && (!m.S))) ? A4(
		$author$project$Main$api,
		$author$project$Main$VerifierCreation,
		'preparer_creation_item',
		_List_fromArray(
			[
				_Utils_Tuple2(
				'contenu',
				$elm$json$Json$Encode$string(
					A2($author$project$Main$valeur, 'contenu', m)))
			]),
		m) : A4(
		$author$project$Main$ecrire,
		$author$project$Main$Enregistrer(m.a),
		'enregistrer_' + $author$project$Contrat$nom(m.a),
		$author$project$Main$corpsEdition(m),
		m))));
};
var $elm$json$Json$Decode$succeed = _Json_succeed;
var $author$project$Main$actualiser = F2(
	function (msg, m) {
		actualiser:
		while (true) {
			switch (msg.$) {
				case 0:
					var donnees = msg.a;
					if (!_Utils_eq(
						A2($author$project$Contrat$objet, 'auth', donnees),
						$elm$json$Json$Encode$null)) {
						var auth = A2($author$project$Contrat$objet, 'auth', donnees);
						return _Utils_Tuple2(
							_Utils_update(
								m,
								{
									a6: A2($author$project$Contrat$chaine, 'mode', auth),
									aH: A2($author$project$Contrat$chaine, 'compte', auth),
									dB: A2($author$project$Contrat$objet, 'notice', auth)
								}),
							$elm$core$Platform$Cmd$none);
					} else {
						return _Utils_Tuple2(
							_Utils_update(
								m,
								{
									cy: A2($author$project$Contrat$chaine, 'gestion_acces', donnees),
									bQ: A2($author$project$Contrat$chaine, 'url_mcp', donnees)
								}),
							$elm$core$Platform$Cmd$none);
					}
				case 1:
					return (m.g || m.m) ? A3($author$project$Main$notifier, 0, 'Terminez votre saisie avant de changer de page.', m) : A2(
						$author$project$Main$avecAdresse,
						'#compte',
						A4(
							$author$project$Main$api,
							$author$project$Main$LireLimites,
							'lire_limites',
							_List_Nil,
							_Utils_update(
								m,
								{aG: true, aM: false, du: false})));
				case 2:
					return (m.g || m.m) ? A3($author$project$Main$notifier, 0, 'Terminez votre saisie avant de changer de page.', m) : A2(
						$author$project$Main$avecAdresse,
						'#administration',
						A4(
							$author$project$Main$envoyer,
							$author$project$Main$Gerer('lister_comptes'),
							'/api/gestion/lister_comptes',
							$elm$json$Json$Encode$object(_List_Nil),
							_Utils_update(
								m,
								{aG: false, aM: true, du: false})));
				case 3:
					var action = msg.a;
					var _v10 = A2($author$project$Gestion$actualiser, action, m.as);
					var gestion = _v10.a;
					var demande = _v10.b;
					var n = _Utils_update(
						m,
						{as: gestion});
					return A2(
						$elm$core$Maybe$withDefault,
						_Utils_Tuple2(n, $elm$core$Platform$Cmd$none),
						A2(
							$elm$core$Maybe$map,
							function (_v11) {
								var op = _v11.a;
								var p = _v11.b;
								return A4(
									$author$project$Main$envoyer,
									$author$project$Main$Gerer(op),
									'/api/gestion/' + op,
									p,
									n);
							},
							demande));
				case 4:
					var action = msg.a;
					var _export = A2($author$project$Compte$actualiser, action, m.ah);
					var n = _Utils_update(
						m,
						{ah: _export});
					switch (action.$) {
						case 4:
							return _Utils_Tuple2(
								_Utils_update(
									n,
									{bc: true}),
								A2(
									$author$project$Main$effet,
									'exporter',
									$elm$json$Json$Encode$object(
										_List_fromArray(
											[
												_Utils_Tuple2(
												'csrf',
												A2(
													$elm$core$Maybe$withDefault,
													$elm$json$Json$Encode$null,
													A2(
														$elm$core$Maybe$map,
														A2(
															$elm$core$Basics$composeR,
															function ($) {
																return $.b0;
															},
															$elm$json$Json$Encode$string),
														m.E))),
												_Utils_Tuple2(
												'format',
												$elm$json$Json$Encode$string(_export.bf)),
												_Utils_Tuple2(
												'toutes',
												$elm$json$Json$Encode$bool(_export.bm)),
												_Utils_Tuple2(
												'fiches',
												A2($elm$json$Json$Encode$list, $elm$json$Json$Encode$int, _export.ay))
											]))));
						case 3:
							var debut = action.a;
							return A4(
								$author$project$Main$envoyer,
								$author$project$Main$ApercuExport,
								'/api/web/exporter_compte',
								$elm$json$Json$Encode$object(
									_List_fromArray(
										[
											_Utils_Tuple2(
											'table',
											$elm$json$Json$Encode$string('vision_fiches')),
											_Utils_Tuple2(
											'debut',
											$elm$json$Json$Encode$int(
												A2($elm$core$Basics$max, 0, debut)))
										])),
								n);
						case 5:
							var $temp$msg = $author$project$Main$Naviguer($author$project$Main$EffacerVision),
								$temp$m = n;
							msg = $temp$msg;
							m = $temp$m;
							continue actualiser;
						default:
							return _Utils_Tuple2(n, $elm$core$Platform$Cmd$none);
					}
				case 5:
					var resultat = msg.a;
					return A3(
						$author$project$Main$notifier,
						A2($author$project$Contrat$vrai, 'reussi', resultat) ? 1 : 3,
						A2($author$project$Contrat$vrai, 'reussi', resultat) ? 'Export téléchargé.' : 'L’export a été interrompu. Réessayez en suspendant les modifications et les assistants.',
						_Utils_update(
							m,
							{bc: false}));
				case 6:
					var texte = msg.a;
					return _Utils_Tuple2(
						_Utils_update(
							m,
							{aK: texte}),
						$elm$core$Platform$Cmd$none);
				case 7:
					var valeurNotice = msg.a;
					return _Utils_Tuple2(
						_Utils_update(
							m,
							{bE: valeurNotice}),
						$elm$core$Platform$Cmd$none);
				case 9:
					var messageAdmission = msg.a;
					return _Utils_Tuple2(
						_Utils_update(
							m,
							{
								aA: A2($author$project$Admission$actualiser, messageAdmission, m.aA)
							}),
						$elm$core$Platform$Cmd$none);
				case 10:
					var oui = msg.a;
					return _Utils_Tuple2(
						_Utils_update(
							m,
							{a5: oui}),
						$elm$core$Platform$Cmd$none);
				case 11:
					return m.a5 ? A4(
						$author$project$Main$envoyer,
						$author$project$Main$ConfirmerAdmission,
						'/auth/admission/confirmer',
						$elm$json$Json$Encode$object(
							_List_fromArray(
								[
									_Utils_Tuple2(
									'token',
									$elm$json$Json$Encode$string(
										A2($elm$core$String$dropLeft, 1, m.f.cV))),
									_Utils_Tuple2(
									'acceptation',
									$elm$json$Json$Encode$bool(true))
								])),
						m) : A3($author$project$Main$notifier, 0, 'Cochez la confirmation avant de continuer.', m);
				case 8:
					return ((!m.bE) || (!A2($author$project$Contrat$vrai, 'inscriptions_ouvertes', m.dB))) ? A3($author$project$Main$notifier, 0, 'Lisez la notice. Les inscriptions doivent être ouvertes pour activer le lien.', m) : A4(
						$author$project$Main$envoyer,
						$author$project$Main$Inscrire,
						'/auth/admission',
						A3(
							$author$project$Admission$corps,
							A2($elm$core$String$dropLeft, 1, m.f.cV),
							A2($author$project$Contrat$chaine, 'version', m.dB),
							m.aA),
						m);
				case 12:
					return _Utils_Tuple2(
						_Utils_update(
							m,
							{c2: false}),
						A2(
							$author$project$Main$effet,
							'copier',
							$elm$json$Json$Encode$string(m.bQ)));
				case 13:
					var reussite = msg.a;
					return _Utils_Tuple2(
						_Utils_update(
							m,
							{c2: reussite}),
						$elm$core$Platform$Cmd$none);
				case 14:
					var identifiant = msg.a;
					return _Utils_Tuple2(
						_Utils_update(
							m,
							{
								c2: false,
								f: A2($author$project$Main$changerAdresse, '#' + identifiant, m.f)
							}),
						A2(
							$author$project$Main$effet,
							'adresse',
							$elm$json$Json$Encode$string('#' + identifiant)));
				case 18:
					return _Utils_Tuple2(
						_Utils_update(
							m,
							{be: !m.be}),
						$elm$core$Platform$Cmd$none);
				case 17:
					return _Utils_Tuple2(
						_Utils_update(
							m,
							{du: !m.du}),
						$elm$core$Platform$Cmd$none);
				case 16:
					var valeurAdresse = msg.a;
					if (_Utils_eq(m.E, $elm$core$Maybe$Nothing)) {
						var flags = m.f;
						return _Utils_Tuple2(
							_Utils_update(
								m,
								{
									f: _Utils_update(
										flags,
										{cV: valeurAdresse})
								}),
							$elm$core$Platform$Cmd$none);
					} else {
						if (m.g || (m.m || (!_Utils_eq(m.e, $elm$core$Maybe$Nothing)))) {
							return _Utils_Tuple2(
								_Utils_update(
									m,
									{
										H: $elm$core$Maybe$Just(
											_Utils_Tuple2(0, 'Enregistrez ou fermez la saisie avant de consulter un autre objet.'))
									}),
								A2(
									$author$project$Main$effet,
									'adresse',
									$elm$json$Json$Encode$string(
										A2(
											$elm$core$Maybe$withDefault,
											'',
											A2(
												$elm$core$Maybe$map,
												A2(
													$elm$core$Basics$composeR,
													$author$project$Contrat$entier('id'),
													$author$project$Contrat$destination(m.a)),
												m.c)))));
						} else {
							if (valeurAdresse === '#compte') {
								var $temp$msg = $author$project$Main$MonCompte,
									$temp$m = m;
								msg = $temp$msg;
								m = $temp$m;
								continue actualiser;
							} else {
								if (valeurAdresse === '#administration') {
									var $temp$msg = $author$project$Main$Administration,
										$temp$m = m;
									msg = $temp$msg;
									m = $temp$m;
									continue actualiser;
								} else {
									var _v13 = $author$project$Contrat$depuisAdresse(valeurAdresse);
									if (!_v13.$) {
										var _v14 = _v13.a;
										var nature = _v14.a;
										var id = _v14.b;
										var $temp$msg = A2($author$project$Main$Ouvrir, nature, id),
											$temp$m = m;
										msg = $temp$msg;
										m = $temp$m;
										continue actualiser;
									} else {
										var $temp$msg = $author$project$Main$Naviguer(
											$author$project$Main$Changer(
												(valeurAdresse === '#items') ? 1 : 0)),
											$temp$m = m;
										msg = $temp$msg;
										m = $temp$m;
										continue actualiser;
									}
								}
							}
						}
					}
				case 15:
					var r = msg.a;
					return A2($author$project$Main$recevoir, r, m);
				case 19:
					var s = msg.a;
					return _Utils_Tuple2(
						_Utils_update(
							m,
							{bg: s}),
						$elm$core$Platform$Cmd$none);
				case 20:
					var s = msg.a;
					return _Utils_Tuple2(
						_Utils_update(
							m,
							{aY: s}),
						$elm$core$Platform$Cmd$none);
				case 21:
					return A4(
						$author$project$Main$envoyer,
						$author$project$Main$Connecter,
						'/auth/login',
						$elm$json$Json$Encode$object(
							_List_fromArray(
								[
									_Utils_Tuple2(
									'username',
									$elm$json$Json$Encode$string(m.bg)),
									_Utils_Tuple2(
									'password',
									$elm$json$Json$Encode$string(m.aY))
								])),
						_Utils_update(
							m,
							{aY: ''}));
				case 22:
					var c = msg.a;
					return (!_Utils_eq(m.e, $elm$core$Maybe$Nothing)) ? A3($author$project$Main$notifier, 0, 'Une écriture attend son résultat.', m) : ((m.g || (m.m || function () {
						switch (c.$) {
							case 3:
								return true;
							case 4:
								return true;
							case 5:
								return true;
							default:
								return false;
						}
					}())) ? _Utils_Tuple2(
						_Utils_update(
							m,
							{
								aI: $elm$core$Maybe$Just(c)
							}),
						$elm$core$Platform$Cmd$none) : A2($author$project$Main$executer, c, m));
				case 23:
					return A2(
						$elm$core$Maybe$withDefault,
						_Utils_Tuple2(m, $elm$core$Platform$Cmd$none),
						A2(
							$elm$core$Maybe$map,
							function (c) {
								return A2(
									$author$project$Main$executer,
									c,
									_Utils_update(
										m,
										{l: $elm$core$Maybe$Nothing, g: false, m: false}));
							},
							m.aI));
				case 24:
					return _Utils_Tuple2(
						_Utils_update(
							m,
							{aI: $elm$core$Maybe$Nothing}),
						$elm$core$Platform$Cmd$none);
				case 25:
					var s = msg.a;
					return _Utils_Tuple2(
						_Utils_update(
							m,
							{bI: s}),
						$elm$core$Platform$Cmd$none);
				case 26:
					var s = msg.a;
					return _Utils_Tuple2(
						_Utils_update(
							m,
							{bK: s}),
						$elm$core$Platform$Cmd$none);
				case 27:
					return $author$project$Main$lister(
						_Utils_update(
							m,
							{a9: 0}));
				case 28:
					var s = msg.a;
					return $author$project$Main$lister(
						_Utils_update(
							m,
							{a9: 0, by: s}));
				case 29:
					var s = msg.a;
					return $author$project$Main$lister(
						_Utils_update(
							m,
							{a9: 0, bn: s}));
				case 30:
					var pas = msg.a;
					return $author$project$Main$lister(
						_Utils_update(
							m,
							{
								a9: A2($elm$core$Basics$max, 0, m.a9 + (20 * pas))
							}));
				case 31:
					var nature = msg.a;
					var id = msg.b;
					return (m.g || (m.m || (!_Utils_eq(m.e, $elm$core$Maybe$Nothing)))) ? A3($author$project$Main$notifier, 0, 'Enregistrez ou fermez la saisie avant de consulter un autre objet.', m) : A3(
						$author$project$Main$lire,
						nature,
						id,
						_Utils_update(
							m,
							{z: _List_Nil, T: 0, c: $elm$core$Maybe$Nothing, i: false, l: $elm$core$Maybe$Nothing, bd: 'tous', aj: false, a: nature, aT: $elm$core$Maybe$Nothing, bo: 'echeance'}));
				case 32:
					return (m.g || (m.m || (!_Utils_eq(m.e, $elm$core$Maybe$Nothing)))) ? A3($author$project$Main$notifier, 0, 'Terminez la saisie en cours.', m) : _Utils_Tuple2(
						_Utils_update(
							m,
							{y: $author$project$Contrat$nouveau, z: _List_Nil, S: false, c: $elm$core$Maybe$Nothing, i: true, g: false, al: $elm$core$Maybe$Nothing}),
						A2(
							$author$project$Main$effet,
							'focus',
							$elm$json$Json$Encode$string('edition')));
				case 33:
					return A2(
						$elm$core$Maybe$withDefault,
						_Utils_Tuple2(m, $elm$core$Platform$Cmd$none),
						A2(
							$elm$core$Maybe$map,
							function (d) {
								return _Utils_Tuple2(
									_Utils_update(
										m,
										{
											y: $author$project$Contrat$brouillon(d),
											i: true
										}),
									$elm$core$Platform$Cmd$none);
							},
							m.c));
				case 34:
					return _Utils_Tuple2(
						_Utils_update(
							m,
							{
								y: A2(
									$elm$core$Maybe$withDefault,
									$author$project$Contrat$nouveau,
									A2($elm$core$Maybe$map, $author$project$Contrat$brouillon, m.c)),
								i: false,
								g: false
							}),
						$elm$core$Platform$Cmd$none);
				case 35:
					var commande = msg.a;
					return _Utils_Tuple2(
						_Utils_update(
							m,
							{
								aT: _Utils_eq(
									m.aT,
									$elm$core$Maybe$Just(commande)) ? $elm$core$Maybe$Nothing : $elm$core$Maybe$Just(commande)
							}),
						$elm$core$Platform$Cmd$none);
				case 36:
					var tri = msg.a;
					return (m.m || m.g) ? A3($author$project$Main$notifier, 0, 'Enregistrez ou annulez la modification de la ligne.', m) : A2(
						$elm$core$Maybe$withDefault,
						_Utils_Tuple2(m, $elm$core$Platform$Cmd$none),
						A2(
							$elm$core$Maybe$map,
							function (d) {
								return A3(
									$author$project$Main$lire,
									m.a,
									A2($author$project$Contrat$entier, 'id', d),
									_Utils_update(
										m,
										{T: 0, bo: tri}));
							},
							m.c));
				case 37:
					var filtre = msg.a;
					return (m.m || m.g) ? A3($author$project$Main$notifier, 0, 'Enregistrez ou annulez la modification de la ligne.', m) : A2(
						$elm$core$Maybe$withDefault,
						_Utils_Tuple2(m, $elm$core$Platform$Cmd$none),
						A2(
							$elm$core$Maybe$map,
							function (d) {
								return A3(
									$author$project$Main$lire,
									m.a,
									A2($author$project$Contrat$entier, 'id', d),
									_Utils_update(
										m,
										{T: 0, bd: filtre}));
							},
							m.c));
				case 38:
					var id = msg.a;
					var ligne = $elm$core$List$head(
						A2(
							$elm$core$List$filter,
							function (v) {
								return _Utils_eq(
									A2($author$project$Contrat$entier, 'id', v),
									id);
							},
							A2(
								$elm$core$Maybe$withDefault,
								_List_Nil,
								A2(
									$elm$core$Maybe$map,
									$author$project$Contrat$listes('items'),
									m.c))));
					return _Utils_Tuple2(
						_Utils_update(
							m,
							{
								D: A2(
									$elm$core$Maybe$withDefault,
									'',
									A2(
										$elm$core$Maybe$map,
										$author$project$Contrat$chaine('contenu'),
										ligne)),
								l: $elm$core$Maybe$Just(id),
								m: false
							}),
						$elm$core$Platform$Cmd$none);
				case 39:
					var s = msg.a;
					return _Utils_Tuple2(
						_Utils_update(
							m,
							{D: s, m: true}),
						$elm$core$Platform$Cmd$none);
				case 41:
					return _Utils_Tuple2(
						_Utils_update(
							m,
							{D: '', l: $elm$core$Maybe$Nothing, m: false}),
						$elm$core$Platform$Cmd$none);
				case 40:
					var ligne = $elm$core$List$head(
						A2(
							$elm$core$List$filter,
							function (v) {
								return _Utils_eq(
									$elm$core$Maybe$Just(
										A2($author$project$Contrat$entier, 'id', v)),
									m.l);
							},
							A2(
								$elm$core$Maybe$withDefault,
								_List_Nil,
								A2(
									$elm$core$Maybe$map,
									$author$project$Contrat$listes('items'),
									m.c))));
					return $elm$core$String$isEmpty(
						$elm$core$String$trim(m.D)) ? A3($author$project$Main$notifier, 3, 'La connaissance ne peut pas être vide.', m) : A2(
						$elm$core$Maybe$withDefault,
						_Utils_Tuple2(m, $elm$core$Platform$Cmd$none),
						A2(
							$elm$core$Maybe$map,
							function (v) {
								return A4(
									$author$project$Main$ecrire,
									$author$project$Main$EnregistrerLigne(
										A2($author$project$Contrat$entier, 'id', v)),
									'enregistrer_item',
									_List_fromArray(
										[
											_Utils_Tuple2(
											'id',
											$elm$json$Json$Encode$int(
												A2($author$project$Contrat$entier, 'id', v))),
											_Utils_Tuple2(
											'version',
											$elm$json$Json$Encode$int(
												A2($author$project$Contrat$entier, 'version', v))),
											_Utils_Tuple2(
											'contenu',
											$elm$json$Json$Encode$string(m.D))
										]),
									m);
							},
							ligne));
				case 42:
					var cle = msg.a;
					var s = msg.b;
					return (!_Utils_eq(m.e, $elm$core$Maybe$Nothing)) ? _Utils_Tuple2(m, $elm$core$Platform$Cmd$none) : _Utils_Tuple2(
						_Utils_update(
							m,
							{
								y: A3($elm$core$Dict$insert, cle, s, m.y),
								z: ((cle === 'contenu') && (m.a === 1)) ? _List_Nil : m.z,
								S: ((cle === 'titre') || ((cle === 'contenu') && (m.a === 1))) ? false : m.S,
								g: true,
								al: ((cle === 'contenu') && (m.a === 1)) ? $elm$core$Maybe$Nothing : m.al
							}),
						$elm$core$Platform$Cmd$none);
				case 43:
					return $author$project$Main$sauver(m);
				case 44:
					return ($elm$core$String$length(
						A2($author$project$Main$valeur, 'distinction', m)) < 10) ? A3($author$project$Main$notifier, 3, 'Précisez ce qui distingue cette connaissance des items trouvés.', m) : $author$project$Main$sauver(
						_Utils_update(
							m,
							{S: true}));
				case 45:
					var id = msg.a;
					return A3(
						$author$project$Main$lire,
						1,
						id,
						_Utils_update(
							m,
							{z: _List_Nil, S: false, T: 0, i: false, g: false, a: 1, al: $elm$core$Maybe$Nothing}));
				case 46:
					return A2(
						$elm$core$Maybe$withDefault,
						_Utils_Tuple2(m, $elm$core$Platform$Cmd$none),
						A2(
							$elm$core$Maybe$map,
							function (e) {
								return A4($author$project$Main$envoyer, e.co, e.bV, e.b$, m);
							},
							m.e));
				case 47:
					return _Utils_Tuple2(
						_Utils_update(
							m,
							{aj: !m.aj, bi: _List_Nil}),
						$elm$core$Platform$Cmd$none);
				case 48:
					var s = msg.a;
					return _Utils_Tuple2(
						_Utils_update(
							m,
							{bJ: s}),
						$elm$core$Platform$Cmd$none);
				case 49:
					return A4(
						$author$project$Main$api,
						$author$project$Main$RechercherLiens,
						'rechercher',
						_List_fromArray(
							[
								_Utils_Tuple2(
								'type',
								$elm$json$Json$Encode$string(
									(!m.a) ? 'item' : 'fiche')),
								_Utils_Tuple2(
								'requete',
								$elm$json$Json$Encode$string(m.bJ)),
								_Utils_Tuple2(
								'limite',
								$elm$json$Json$Encode$int(20))
							]),
						m);
				case 50:
					var cible = msg.a;
					var _v16 = m.c;
					if (_v16.$ === 1) {
						return _Utils_Tuple2(m, $elm$core$Platform$Cmd$none);
					} else {
						var d = _v16.a;
						var i = (m.a === 1) ? d : cible;
						var f = (!m.a) ? d : cible;
						return A4(
							$author$project$Main$ecrire,
							$author$project$Main$Lier,
							'lier_item',
							_List_fromArray(
								[
									_Utils_Tuple2(
									'fiche_id',
									$elm$json$Json$Encode$int(
										A2($author$project$Contrat$entier, 'id', f))),
									_Utils_Tuple2(
									'item_id',
									$elm$json$Json$Encode$int(
										A2($author$project$Contrat$entier, 'id', i))),
									_Utils_Tuple2(
									'version_fiche',
									$elm$json$Json$Encode$int(
										A2($author$project$Contrat$entier, 'version', f))),
									_Utils_Tuple2(
									'action',
									$elm$json$Json$Encode$string('rattacher'))
								]),
							m);
					}
				case 51:
					var pas = msg.a;
					return (m.m || m.g) ? A3($author$project$Main$notifier, 0, 'Enregistrez ou annulez la modification de la ligne.', m) : A2(
						$elm$core$Maybe$withDefault,
						_Utils_Tuple2(m, $elm$core$Platform$Cmd$none),
						A2(
							$elm$core$Maybe$map,
							function (d) {
								return A3(
									$author$project$Main$lire,
									m.a,
									A2($author$project$Contrat$entier, 'id', d),
									_Utils_update(
										m,
										{
											T: A2($elm$core$Basics$max, 0, m.T + (20 * pas))
										}));
							},
							m.c));
				case 52:
					return A4(
						$author$project$Main$envoyer,
						$author$project$Main$LirePolitique,
						'/api/web/lire_politique',
						$elm$json$Json$Encode$object(_List_Nil),
						_Utils_update(
							m,
							{aX: !m.aX}));
				case 53:
					var s = msg.a;
					return _Utils_Tuple2(
						_Utils_update(
							m,
							{
								V: s,
								n: A2($elm$core$List$cons, 'intervalle_jours', m.n)
							}),
						$elm$core$Platform$Cmd$none);
				case 54:
					var s = msg.a;
					return _Utils_Tuple2(
						_Utils_update(
							m,
							{
								N: s,
								n: A2($elm$core$List$cons, 'budget', m.n)
							}),
						$elm$core$Platform$Cmd$none);
				case 55:
					var s = msg.a;
					return _Utils_Tuple2(
						_Utils_update(
							m,
							{
								U: s,
								n: A2($elm$core$List$cons, 'duree_seance_courte_minutes', m.n)
							}),
						$elm$core$Platform$Cmd$none);
				case 56:
					var s = msg.a;
					return _Utils_Tuple2(
						_Utils_update(
							m,
							{
								aa: s,
								n: A2($elm$core$List$cons, 'questions_typiques', m.n)
							}),
						$elm$core$Platform$Cmd$none);
				default:
					return $elm$core$List$isEmpty(m.n) ? A3($author$project$Main$notifier, 0, 'Aucun réglage n’a été modifié.', m) : ((A2($author$project$Contrat$entier, 'version', m._) < 1) ? A3($author$project$Main$notifier, 0, 'Chargement des réglages en cours.', m) : (((!A3($author$project$Main$entierValide, 1, 3650, m.V)) || (((m.N !== '') && (!A3($author$project$Main$entierValide, 1, 1000, m.N))) || ((!A3($author$project$Main$entierValide, 1, 20, m.aa)) || (!A3($author$project$Main$entierValide, 1, 10080, m.U))))) ? A3($author$project$Main$notifier, 3, 'L’intervalle doit être de 1 à 3650 jours, le budget vide ou de 1 à 1000, le nombre typique de questions de 1 à 20, et le seuil de séance courte de 1 à 10080 minutes.', m) : A4(
						$author$project$Main$ecrire,
						$author$project$Main$Regler,
						'regler_politique',
						A2(
							$elm$core$List$cons,
							_Utils_Tuple2(
								'version',
								$elm$json$Json$Encode$int(
									A2($author$project$Contrat$entier, 'version', m._))),
							A2(
								$elm$core$List$filter,
								function (_v17) {
									var cle = _v17.a;
									return A2($elm$core$List$member, cle, m.n);
								},
								_List_fromArray(
									[
										_Utils_Tuple2(
										'intervalle_jours',
										$elm$json$Json$Encode$int(
											A2(
												$elm$core$Maybe$withDefault,
												90,
												$elm$core$String$toInt(m.V)))),
										_Utils_Tuple2(
										'budget',
										A2(
											$elm$core$Maybe$withDefault,
											$elm$json$Json$Encode$null,
											A2(
												$elm$core$Maybe$map,
												$elm$json$Json$Encode$int,
												$elm$core$String$toInt(m.N)))),
										_Utils_Tuple2(
										'duree_seance_courte_minutes',
										$elm$json$Json$Encode$int(
											A2(
												$elm$core$Maybe$withDefault,
												60,
												$elm$core$String$toInt(m.U)))),
										_Utils_Tuple2(
										'questions_typiques',
										$elm$json$Json$Encode$int(
											A2(
												$elm$core$Maybe$withDefault,
												8,
												$elm$core$String$toInt(m.aa))))
									]))),
						m)));
			}
		}
	});
var $author$project$Main$appliquer = F3(
	function (but, corps, m) {
		var pr = A2($author$project$Contrat$objet, 'politique', corps);
		var rafraichirPolitique = (!_Utils_eq(pr, $elm$json$Json$Encode$null)) && ($elm$core$List$isEmpty(m.n) || _Utils_eq(but, $author$project$Main$Regler));
		var maintenant = A2($author$project$Contrat$chaine, 'maintenant', corps);
		var flags = m.f;
		var n = _Utils_update(
			m,
			{
				N: (_Utils_eq(pr, $elm$json$Json$Encode$null) || ((!_Utils_eq(but, $author$project$Main$Regler)) && A2($elm$core$List$member, 'budget', m.n))) ? m.N : A2(
					$elm$core$Maybe$withDefault,
					'',
					A2(
						$elm$core$Maybe$map,
						A2($elm$core$Basics$composeR, $elm$core$Basics$round, $elm$core$String$fromInt),
						A2($author$project$Contrat$nombre, 'budget', pr))),
				U: (_Utils_eq(pr, $elm$json$Json$Encode$null) || ((!_Utils_eq(but, $author$project$Main$Regler)) && A2($elm$core$List$member, 'duree_seance_courte_minutes', m.n))) ? m.U : $elm$core$String$fromInt(
					A2($author$project$Contrat$entier, 'duree_seance_courte_minutes', pr)),
				f: (maintenant === '') ? flags : _Utils_update(
					flags,
					{b8: maintenant}),
				V: (_Utils_eq(pr, $elm$json$Json$Encode$null) || ((!_Utils_eq(but, $author$project$Main$Regler)) && A2($elm$core$List$member, 'intervalle_jours', m.n))) ? m.V : $elm$core$String$fromInt(
					A2($author$project$Contrat$entier, 'intervalle_jours', pr)),
				_: (_Utils_eq(pr, $elm$json$Json$Encode$null) || ((!rafraichirPolitique) && (!_Utils_eq(m._, $elm$json$Json$Encode$null)))) ? m._ : pr,
				aa: (_Utils_eq(pr, $elm$json$Json$Encode$null) || ((!_Utils_eq(but, $author$project$Main$Regler)) && A2($elm$core$List$member, 'questions_typiques', m.n))) ? m.aa : $elm$core$String$fromInt(
					A2($author$project$Contrat$entier, 'questions_typiques', pr))
			});
		var connecter = function () {
			var _v5 = A2(
				$elm$json$Json$Decode$decodeValue,
				A5(
					$elm$json$Json$Decode$map4,
					$author$project$Main$Session,
					A2($elm$json$Json$Decode$field, 'username', $elm$json$Json$Decode$string),
					A2($elm$json$Json$Decode$field, 'csrf', $elm$json$Json$Decode$string),
					$elm$json$Json$Decode$oneOf(
						_List_fromArray(
							[
								A2($elm$json$Json$Decode$field, 'administrateur', $elm$json$Json$Decode$bool),
								$elm$json$Json$Decode$succeed(false)
							])),
					$elm$json$Json$Decode$oneOf(
						_List_fromArray(
							[
								A2($elm$json$Json$Decode$field, 'verificationRenforcee', $elm$json$Json$Decode$bool),
								$elm$json$Json$Decode$succeed(false)
							]))),
				corps);
			if (_v5.$ === 1) {
				return A3(
					$author$project$Main$notifier,
					3,
					'Réponse de session invalide.',
					_Utils_update(
						n,
						{an: false}));
			} else {
				var s = _v5.a;
				if ($elm$core$String$isEmpty(s.aF) || $elm$core$String$isEmpty(s.b0)) {
					return A3(
						$author$project$Main$notifier,
						3,
						'Réponse de session incomplète.',
						_Utils_update(
							n,
							{an: false}));
				} else {
					var base = _Utils_update(
						n,
						{
							N: '',
							U: '60',
							V: '90',
							H: $elm$core$Maybe$Nothing,
							_: $elm$json$Json$Encode$null,
							aa: '8',
							aX: false,
							n: _List_Nil,
							aY: '',
							E: $elm$core$Maybe$Just(s),
							a_: $elm$core$Maybe$Nothing,
							an: false
						});
					var restaure = function () {
						var _v8 = m.a_;
						if (!_v8.$) {
							var b = _v8.a;
							return _Utils_eq(b.aF, s.aF) ? _Utils_update(
								base,
								{
									y: b.y,
									D: b.D,
									c: b.c,
									e: b.e,
									i: _Utils_eq(b.l, $elm$core$Maybe$Nothing),
									l: b.l,
									g: _Utils_eq(b.l, $elm$core$Maybe$Nothing),
									m: !_Utils_eq(b.l, $elm$core$Maybe$Nothing),
									a: b.a
								}) : base;
						} else {
							return base;
						}
					}();
					if ($author$project$Informations$publique(m.f.bV)) {
						return _Utils_Tuple2(restaure, $elm$core$Platform$Cmd$none);
					} else {
						if (m.f.cV === '#compte') {
							return A2($author$project$Main$actualiser, $author$project$Main$MonCompte, restaure);
						} else {
							if (m.f.cV === '#administration') {
								return A2($author$project$Main$actualiser, $author$project$Main$Administration, restaure);
							} else {
								if (restaure.i || (!_Utils_eq(restaure.l, $elm$core$Maybe$Nothing))) {
									return $author$project$Main$lister(restaure);
								} else {
									var _v6 = $author$project$Contrat$depuisAdresse(m.f.cV);
									if (!_v6.$) {
										var _v7 = _v6.a;
										var nature = _v7.a;
										var id = _v7.b;
										return A2(
											$author$project$Main$actualiser,
											A2($author$project$Main$Ouvrir, nature, id),
											restaure);
									} else {
										return $author$project$Main$lister(
											_Utils_update(
												restaure,
												{
													a: (m.f.cV === '#items') ? 1 : restaure.a
												}));
									}
								}
							}
						}
					}
				}
			}
		}();
		switch (but.$) {
			case 12:
				return A4(
					$author$project$Main$envoyer,
					$author$project$Main$ApercuExport,
					'/api/web/exporter_compte',
					$elm$json$Json$Encode$object(
						_List_fromArray(
							[
								_Utils_Tuple2(
								'table',
								$elm$json$Json$Encode$string('vision_fiches')),
								_Utils_Tuple2(
								'debut',
								$elm$json$Json$Encode$int(n.ah.a9))
							])),
					_Utils_update(
						n,
						{bB: corps}));
			case 13:
				return _Utils_Tuple2(
					_Utils_update(
						n,
						{
							ah: A2($author$project$Compte$recevoir, corps, n.ah)
						}),
					$elm$core$Platform$Cmd$none);
			case 14:
				var op = but.a;
				return _Utils_Tuple2(
					_Utils_update(
						n,
						{
							as: A3($author$project$Gestion$recevoir, op, corps, n.as)
						}),
					$elm$core$Platform$Cmd$none);
			case 18:
				return _Utils_Tuple2(
					_Utils_update(
						n,
						{W: corps}),
					$elm$core$Platform$Cmd$none);
			case 16:
				return _Utils_Tuple2(
					_Utils_update(
						n,
						{aB: corps}),
					$elm$core$Platform$Cmd$none);
			case 17:
				return A3(
					$author$project$Main$notifier,
					0,
					A2($author$project$Contrat$chaine, 'information', corps),
					_Utils_update(
						n,
						{a5: false, aB: $elm$json$Json$Encode$null}));
			case 15:
				return A3(
					$author$project$Main$notifier,
					0,
					A2($author$project$Contrat$chaine, 'information', corps),
					_Utils_update(
						n,
						{aA: $author$project$Admission$initial}));
			case 19:
				return A2($author$project$Contrat$vrai, 'effacement_en_attente', corps) ? A3($author$project$Main$notifier, 0, 'Votre demande d’effacement est enregistrée. La copie chiffrée du registre est encore en attente d’envoi ; la procédure reprendra automatiquement. Vous pouvez encore exporter vos données.', n) : _Utils_Tuple2(
					$author$project$Main$initial(m.f),
					$elm$core$Platform$Cmd$batch(
						_List_fromArray(
							[
								A2($author$project$Main$effet, 'annulerRequetes', $elm$json$Json$Encode$null),
								A2(
								$author$project$Main$effet,
								'redirection',
								$elm$json$Json$Encode$string('/'))
							])));
			case 11:
				return _Utils_Tuple2(n, $elm$core$Platform$Cmd$none);
			case 0:
				return connecter;
			case 1:
				return connecter;
			case 2:
				return _Utils_Tuple2(
					_Utils_update(
						n,
						{af: $elm$core$Dict$empty, y: $author$project$Contrat$nouveau, N: '', z: _List_Nil, ah: $author$project$Compte$initial, aG: false, c: $elm$core$Maybe$Nothing, U: '60', e: $elm$core$Maybe$Nothing, i: false, aK: '', bc: false, as: $author$project$Gestion$initial, aM: false, V: '90', bi: _List_Nil, bB: $elm$json$Json$Encode$null, g: false, _: $elm$json$Json$Encode$null, aa: '8', aX: false, n: _List_Nil, bk: _List_Nil, E: $elm$core$Maybe$Nothing, a_: $elm$core$Maybe$Nothing}),
					A2($author$project$Main$effet, 'annulerRequetes', $elm$json$Json$Encode$null));
			case 3:
				var nature = but.a;
				return _Utils_eq(nature, m.a) ? _Utils_Tuple2(
					_Utils_update(
						n,
						{
							bk: A2($author$project$Contrat$listes, 'resultats', corps),
							a0: A2($author$project$Contrat$entier, 'total', corps)
						}),
					$elm$core$Platform$Cmd$none) : _Utils_Tuple2(n, $elm$core$Platform$Cmd$none);
			case 4:
				var nature = but.a;
				var _v3 = $elm$core$List$head(
					A2($author$project$Contrat$listes, 'objets', corps));
				if (_v3.$ === 1) {
					return A3($author$project$Main$notifier, 3, 'Objet introuvable.', n);
				} else {
					var d = _v3.a;
					return _Utils_Tuple2(
						_Utils_update(
							n,
							{
								y: $author$project$Contrat$brouillon(d),
								c: $elm$core$Maybe$Just(d),
								i: false,
								g: false,
								a: nature
							}),
						$elm$core$Platform$Cmd$batch(
							_List_fromArray(
								[
									A2(
									$author$project$Main$effet,
									'focus',
									$elm$json$Json$Encode$string('detail')),
									A2(
									$author$project$Main$effet,
									'adresse',
									$elm$json$Json$Encode$string(
										A2(
											$author$project$Contrat$destination,
											nature,
											A2($author$project$Contrat$entier, 'id', d))))
								])));
				}
			case 5:
				var nature = but.a;
				if (!A2($author$project$Contrat$vrai, 'enregistre', corps)) {
					return A3($author$project$Main$notifier, 3, 'L’enregistrement n’est pas confirmé.', n);
				} else {
					var d = A2(
						$author$project$Contrat$objet,
						$author$project$Contrat$nom(nature),
						corps);
					return A3(
						$author$project$Main$lire,
						nature,
						A2($author$project$Contrat$entier, 'id', d),
						_Utils_update(
							n,
							{
								z: _List_Nil,
								S: false,
								c: $elm$core$Maybe$Just(d),
								e: $elm$core$Maybe$Nothing,
								i: false,
								H: $elm$core$Maybe$Just(
									_Utils_Tuple2(1, 'Enregistré.')),
								g: false,
								al: $elm$core$Maybe$Nothing
							}));
				}
			case 6:
				return (!A2($author$project$Contrat$vrai, 'enregistre', corps)) ? A3($author$project$Main$notifier, 3, 'L’enregistrement n’est pas confirmé.', n) : A2(
					$elm$core$Maybe$withDefault,
					_Utils_Tuple2(
						_Utils_update(
							n,
							{e: $elm$core$Maybe$Nothing}),
						$elm$core$Platform$Cmd$none),
					A2(
						$elm$core$Maybe$map,
						function (d) {
							return A3(
								$author$project$Main$lire,
								n.a,
								A2($author$project$Contrat$entier, 'id', d),
								_Utils_update(
									n,
									{
										D: '',
										e: $elm$core$Maybe$Nothing,
										l: $elm$core$Maybe$Nothing,
										H: $elm$core$Maybe$Just(
											_Utils_Tuple2(1, 'Item enregistré.')),
										m: false
									}));
						},
						n.c));
			case 7:
				var preuve = A2($author$project$Contrat$chaine, 'preuve_creation', corps);
				var candidats = A2($author$project$Contrat$listes, 'candidats', corps);
				var suite = _Utils_update(
					n,
					{
						z: candidats,
						al: $elm$core$Maybe$Just(preuve)
					});
				return (preuve === '') ? A3($author$project$Main$notifier, 3, 'Préparation indisponible : réessayez après remise en état de la recherche sémantique.', n) : ($elm$core$List$isEmpty(candidats) ? $author$project$Main$sauver(
					_Utils_update(
						suite,
						{S: true})) : A3($author$project$Main$notifier, 0, 'Examinez tous les items proposés. Réutilisez la même connaissance ou expliquez la distinction avant de créer.', suite));
			case 8:
				return _Utils_Tuple2(
					_Utils_update(
						n,
						{
							bi: A2($author$project$Contrat$listes, 'resultats', corps)
						}),
					$elm$core$Platform$Cmd$none);
			case 9:
				if (!A2($author$project$Contrat$vrai, 'enregistre', corps)) {
					return A3($author$project$Main$notifier, 3, 'Le lien n’est pas confirmé.', n);
				} else {
					var _v4 = n.c;
					if (!_v4.$) {
						var d = _v4.a;
						return A3(
							$author$project$Main$lire,
							n.a,
							A2($author$project$Contrat$entier, 'id', d),
							_Utils_update(
								n,
								{e: $elm$core$Maybe$Nothing, aj: false}));
					} else {
						return _Utils_Tuple2(
							_Utils_update(
								n,
								{e: $elm$core$Maybe$Nothing}),
							$elm$core$Platform$Cmd$none);
					}
				}
			default:
				return (!A2($author$project$Contrat$vrai, 'enregistre', corps)) ? A3($author$project$Main$notifier, 3, 'Le réglage n’est pas confirmé.', n) : A3(
					$author$project$Main$notifier,
					1,
					'Politique enregistrée ; les stabilités sont conservées.',
					_Utils_update(
						n,
						{e: $elm$core$Maybe$Nothing, n: _List_Nil}));
		}
	});
var $author$project$Main$recevoir = F2(
	function (retour, m) {
		var statut = A2($author$project$Contrat$entier, 'statut', retour);
		var numero = A2($author$project$Contrat$entier, 'numero', retour);
		var corps = A2($author$project$Contrat$objet, 'corps', retour);
		var erreur = function () {
			var e = A2($author$project$Contrat$chaine, 'erreur', corps);
			return (e === '') ? A2($author$project$Contrat$chaine, 'error', corps) : e;
		}();
		var _v0 = A2($elm$core$Dict$get, numero, m.af);
		if (_v0.$ === 1) {
			return _Utils_Tuple2(m, $elm$core$Platform$Cmd$none);
		} else {
			var but = _v0.a;
			var obsolete = function () {
				switch (but.$) {
					case 3:
						return !_Utils_eq(numero, m.b2);
					case 4:
						return !_Utils_eq(numero, m.b1);
					default:
						return false;
				}
			}();
			var n = _Utils_update(
				m,
				{
					af: A2($elm$core$Dict$remove, numero, m.af)
				});
			if (obsolete) {
				return _Utils_Tuple2(n, $elm$core$Platform$Cmd$none);
			} else {
				if (((statut === 401) || (erreur === 'csrf_required')) && (!_Utils_eq(but, $author$project$Main$Connecter))) {
					var vide = $author$project$Main$initial(m.f);
					var suspension = A2(
						$elm$core$Maybe$map,
						function (s) {
							return {y: m.y, aF: s.aF, D: m.D, c: m.c, e: m.e, l: m.l, a: m.a};
						},
						m.E);
					return _Utils_Tuple2(
						_Utils_update(
							vide,
							{
								a6: m.a6,
								aH: m.aH,
								cy: m.cy,
								H: $elm$core$Maybe$Just(
									_Utils_Tuple2(0, 'Connectez-vous pour accéder à vos fiches et items.')),
								dB: m.dB,
								aQ: m.aQ,
								a_: (m.g || (m.m || (!_Utils_eq(m.e, $elm$core$Maybe$Nothing)))) ? suspension : $elm$core$Maybe$Nothing,
								bQ: m.bQ,
								an: false
							}),
						A2($author$project$Main$effet, 'annulerRequetes', $elm$json$Json$Encode$null));
				} else {
					if (!statut) {
						return A3($author$project$Main$notifier, 3, 'La réponse n’a pas été reçue. Une écriture a pu être enregistrée : utilisez Réessayer, qui conserve sa clé.', n);
					} else {
						if ((statut < 200) || ((statut >= 300) || (erreur !== ''))) {
							return A3(
								$author$project$Main$notifier,
								3,
								(statut === 409) ? 'L’objet a changé. Votre saisie est conservée ; fermez puis relisez la version actuelle avant de concilier les modifications.' : ((erreur === 'quota_depasse') ? 'Votre quota est atteint. Consultez Mon compte et mes limites. Vos données sont conservées ; l’archivage ne libère pas d’espace.' : (A2(
									$elm$core$List$member,
									erreur,
									_List_fromArray(
										['texte_trop_long', 'ligne_trop_longue'])) ? 'Le texte dépasse la longueur autorisée. Raccourcissez-le ; les plafonds sont indiqués dans Mon compte et mes limites.' : (A2(
									$elm$core$List$member,
									erreur,
									_List_fromArray(
										['limite_fiches', 'limite_items_fiche'])) ? 'La limite de fiches ou d’items par fiche est atteinte. Consultez Mon compte et mes limites.' : ((erreur === 'verification_renforcee_requise') ? 'L’administration nécessite une nouvelle connexion avec mot de passe et code de sécurité.' : ('Opération refusée : ' + ((erreur === '') ? 'réponse inattendue' : erreur)))))),
								_Utils_update(
									n,
									{e: $elm$core$Maybe$Nothing, an: false}));
						} else {
							return A3($author$project$Main$appliquer, but, corps, n);
						}
					}
				}
			}
		}
	});
var $author$project$Main$adresse = _Platform_incomingPort('adresse', $elm$json$Json$Decode$string);
var $elm$core$Basics$always = F2(
	function (a, _v0) {
		return a;
	});
var $elm$json$Json$Decode$andThen = _Json_andThen;
var $elm$core$Platform$Sub$batch = _Platform_batch;
var $author$project$Main$configuration = _Platform_incomingPort('configuration', $elm$json$Json$Decode$value);
var $author$project$Main$copie = _Platform_incomingPort('copie', $elm$json$Json$Decode$bool);
var $elm$json$Json$Decode$map = _Json_map1;
var $elm$json$Json$Decode$map2 = _Json_map2;
var $elm$virtual_dom$VirtualDom$toHandlerInt = function (handler) {
	switch (handler.$) {
		case 0:
			return 0;
		case 1:
			return 1;
		case 2:
			return 2;
		default:
			return 3;
	}
};
var $elm$browser$Browser$External = function (a) {
	return {$: 1, a: a};
};
var $elm$browser$Browser$Internal = function (a) {
	return {$: 0, a: a};
};
var $elm$browser$Browser$Dom$NotFound = $elm$core$Basics$identity;
var $elm$url$Url$Http = 0;
var $elm$url$Url$Https = 1;
var $elm$url$Url$Url = F6(
	function (protocol, host, port_, path, query, fragment) {
		return {dd: fragment, dl: host, dH: path, dJ: port_, dM: protocol, dN: query};
	});
var $elm$core$String$contains = _String_contains;
var $elm$core$String$indexes = _String_indexes;
var $elm$url$Url$chompBeforePath = F5(
	function (protocol, path, params, frag, str) {
		if ($elm$core$String$isEmpty(str) || A2($elm$core$String$contains, '@', str)) {
			return $elm$core$Maybe$Nothing;
		} else {
			var _v0 = A2($elm$core$String$indexes, ':', str);
			if (!_v0.b) {
				return $elm$core$Maybe$Just(
					A6($elm$url$Url$Url, protocol, str, $elm$core$Maybe$Nothing, path, params, frag));
			} else {
				if (!_v0.b.b) {
					var i = _v0.a;
					var _v1 = $elm$core$String$toInt(
						A2($elm$core$String$dropLeft, i + 1, str));
					if (_v1.$ === 1) {
						return $elm$core$Maybe$Nothing;
					} else {
						var port_ = _v1;
						return $elm$core$Maybe$Just(
							A6(
								$elm$url$Url$Url,
								protocol,
								A2($elm$core$String$left, i, str),
								port_,
								path,
								params,
								frag));
					}
				} else {
					return $elm$core$Maybe$Nothing;
				}
			}
		}
	});
var $elm$url$Url$chompBeforeQuery = F4(
	function (protocol, params, frag, str) {
		if ($elm$core$String$isEmpty(str)) {
			return $elm$core$Maybe$Nothing;
		} else {
			var _v0 = A2($elm$core$String$indexes, '/', str);
			if (!_v0.b) {
				return A5($elm$url$Url$chompBeforePath, protocol, '/', params, frag, str);
			} else {
				var i = _v0.a;
				return A5(
					$elm$url$Url$chompBeforePath,
					protocol,
					A2($elm$core$String$dropLeft, i, str),
					params,
					frag,
					A2($elm$core$String$left, i, str));
			}
		}
	});
var $elm$url$Url$chompBeforeFragment = F3(
	function (protocol, frag, str) {
		if ($elm$core$String$isEmpty(str)) {
			return $elm$core$Maybe$Nothing;
		} else {
			var _v0 = A2($elm$core$String$indexes, '?', str);
			if (!_v0.b) {
				return A4($elm$url$Url$chompBeforeQuery, protocol, $elm$core$Maybe$Nothing, frag, str);
			} else {
				var i = _v0.a;
				return A4(
					$elm$url$Url$chompBeforeQuery,
					protocol,
					$elm$core$Maybe$Just(
						A2($elm$core$String$dropLeft, i + 1, str)),
					frag,
					A2($elm$core$String$left, i, str));
			}
		}
	});
var $elm$url$Url$chompAfterProtocol = F2(
	function (protocol, str) {
		if ($elm$core$String$isEmpty(str)) {
			return $elm$core$Maybe$Nothing;
		} else {
			var _v0 = A2($elm$core$String$indexes, '#', str);
			if (!_v0.b) {
				return A3($elm$url$Url$chompBeforeFragment, protocol, $elm$core$Maybe$Nothing, str);
			} else {
				var i = _v0.a;
				return A3(
					$elm$url$Url$chompBeforeFragment,
					protocol,
					$elm$core$Maybe$Just(
						A2($elm$core$String$dropLeft, i + 1, str)),
					A2($elm$core$String$left, i, str));
			}
		}
	});
var $elm$url$Url$fromString = function (str) {
	return A2($elm$core$String$startsWith, 'http://', str) ? A2(
		$elm$url$Url$chompAfterProtocol,
		0,
		A2($elm$core$String$dropLeft, 7, str)) : (A2($elm$core$String$startsWith, 'https://', str) ? A2(
		$elm$url$Url$chompAfterProtocol,
		1,
		A2($elm$core$String$dropLeft, 8, str)) : $elm$core$Maybe$Nothing);
};
var $elm$core$Basics$never = function (_v0) {
	never:
	while (true) {
		var nvr = _v0;
		var $temp$_v0 = nvr;
		_v0 = $temp$_v0;
		continue never;
	}
};
var $elm$core$Task$Perform = $elm$core$Basics$identity;
var $elm$core$Task$succeed = _Scheduler_succeed;
var $elm$core$Task$init = $elm$core$Task$succeed(0);
var $elm$core$Task$andThen = _Scheduler_andThen;
var $elm$core$Task$map = F2(
	function (func, taskA) {
		return A2(
			$elm$core$Task$andThen,
			function (a) {
				return $elm$core$Task$succeed(
					func(a));
			},
			taskA);
	});
var $elm$core$Task$map2 = F3(
	function (func, taskA, taskB) {
		return A2(
			$elm$core$Task$andThen,
			function (a) {
				return A2(
					$elm$core$Task$andThen,
					function (b) {
						return $elm$core$Task$succeed(
							A2(func, a, b));
					},
					taskB);
			},
			taskA);
	});
var $elm$core$Task$sequence = function (tasks) {
	return A3(
		$elm$core$List$foldr,
		$elm$core$Task$map2($elm$core$List$cons),
		$elm$core$Task$succeed(_List_Nil),
		tasks);
};
var $elm$core$Platform$sendToApp = _Platform_sendToApp;
var $elm$core$Task$spawnCmd = F2(
	function (router, _v0) {
		var task = _v0;
		return _Scheduler_spawn(
			A2(
				$elm$core$Task$andThen,
				$elm$core$Platform$sendToApp(router),
				task));
	});
var $elm$core$Task$onEffects = F3(
	function (router, commands, state) {
		return A2(
			$elm$core$Task$map,
			function (_v0) {
				return 0;
			},
			$elm$core$Task$sequence(
				A2(
					$elm$core$List$map,
					$elm$core$Task$spawnCmd(router),
					commands)));
	});
var $elm$core$Task$onSelfMsg = F3(
	function (_v0, _v1, _v2) {
		return $elm$core$Task$succeed(0);
	});
var $elm$core$Task$cmdMap = F2(
	function (tagger, _v0) {
		var task = _v0;
		return A2($elm$core$Task$map, tagger, task);
	});
_Platform_effectManagers['Task'] = _Platform_createManager($elm$core$Task$init, $elm$core$Task$onEffects, $elm$core$Task$onSelfMsg, $elm$core$Task$cmdMap);
var $elm$core$Task$command = _Platform_leaf('Task');
var $elm$core$Task$perform = F2(
	function (toMessage, task) {
		return $elm$core$Task$command(
			A2($elm$core$Task$map, toMessage, task));
	});
var $elm$browser$Browser$element = _Browser_element;
var $author$project$Main$exportation = _Platform_incomingPort('exportation', $elm$json$Json$Decode$value);
var $author$project$Main$reponse = _Platform_incomingPort('reponse', $elm$json$Json$Decode$value);
var $author$project$Main$AccepterNotice = function (a) {
	return {$: 7, a: a};
};
var $author$project$Main$AccordAdmission = function (a) {
	return {$: 10, a: a};
};
var $author$project$Main$AdmissionMessage = function (a) {
	return {$: 9, a: a};
};
var $author$project$Main$ChoisirChapitre = function (a) {
	return {$: 14, a: a};
};
var $author$project$Main$CompteMessage = function (a) {
	return {$: 4, a: a};
};
var $author$project$Main$ConfirmerLienAdmission = {$: 11};
var $author$project$Main$Connexion = {$: 21};
var $author$project$Main$CopierAdresse = {$: 12};
var $author$project$Main$GestionMessage = function (a) {
	return {$: 3, a: a};
};
var $author$project$Main$Identifiant = function (a) {
	return {$: 19, a: a};
};
var $author$project$Main$Inscription = {$: 8};
var $author$project$Main$Menu = {$: 17};
var $author$project$Main$Quitter = {$: 2};
var $author$project$Main$Reglages = {$: 52};
var $author$project$MrJam$Pictogrammes$Reglages = 7;
var $author$project$Main$Secret = function (a) {
	return {$: 20, a: a};
};
var $author$project$MrJam$Pictogrammes$Sortir = 12;
var $author$project$MrJam$Controles$Discrete = {$: 3};
var $elm$virtual_dom$VirtualDom$attribute = F2(
	function (key, value) {
		return A2(
			_VirtualDom_attribute,
			_VirtualDom_noOnOrFormAction(key),
			_VirtualDom_noJavaScriptOrHtmlUri(value));
	});
var $elm$html$Html$Attributes$attribute = $elm$virtual_dom$VirtualDom$attribute;
var $mdgriffith$elm_ui$Internal$Model$Attr = function (a) {
	return {$: 1, a: a};
};
var $mdgriffith$elm_ui$Element$htmlAttribute = $mdgriffith$elm_ui$Internal$Model$Attr;
var $elm$virtual_dom$VirtualDom$style = _VirtualDom_style;
var $elm$html$Html$Attributes$style = $elm$virtual_dom$VirtualDom$style;
var $author$project$MrJam$Theme$palette = function (h) {
	return _List_fromArray(
		[
			_Utils_Tuple2(
			'encre',
			{bT: 0.035, b5: h, bA: 0.25}),
			_Utils_Tuple2(
			'discret',
			{bT: 0.025, b5: h, bA: 0.45}),
			_Utils_Tuple2(
			'accent',
			{bT: 0.08, b5: h, bA: 0.46}),
			_Utils_Tuple2(
			'accentSurvol',
			{bT: 0.07, b5: h, bA: 0.39}),
			_Utils_Tuple2(
			'ligne',
			{bT: 0.016, b5: h, bA: 0.88}),
			_Utils_Tuple2(
			'controle',
			{bT: 0.022, b5: h, bA: 0.65}),
			_Utils_Tuple2(
			'papier',
			{bT: 0.004, b5: h, bA: 0.98}),
			_Utils_Tuple2(
			'surface',
			{bT: 0, b5: h, bA: 1}),
			_Utils_Tuple2(
			'doux',
			{bT: 0.012, b5: h, bA: 0.95}),
			_Utils_Tuple2(
			'danger',
			{bT: 0.12, b5: 28, bA: 0.46}),
			_Utils_Tuple2(
			'dangerSurvol',
			{bT: 0.1, b5: 28, bA: 0.39})
		]);
};
var $mdgriffith$elm_ui$Internal$Model$Rgba = F4(
	function (a, b, c, d) {
		return {$: 0, a: a, b: b, c: c, d: d};
	});
var $mdgriffith$elm_ui$Element$rgb = F3(
	function (r, g, b) {
		return A4($mdgriffith$elm_ui$Internal$Model$Rgba, r, g, b, 1);
	});
var $elm$core$Tuple$second = function (_v0) {
	var y = _v0.b;
	return y;
};
var $elm$core$Basics$abs = function (n) {
	return (n < 0) ? (-n) : n;
};
var $elm$core$Basics$cos = _Basics_cos;
var $elm$core$Basics$pi = _Basics_pi;
var $elm$core$Basics$degrees = function (angleInDegrees) {
	return (angleInDegrees * $elm$core$Basics$pi) / 180;
};
var $elm$core$Basics$pow = _Basics_pow;
var $elm$core$Basics$sin = _Basics_sin;
var $author$project$MrJam$OKLab$lineaire = function (col) {
	var b = col.bT * $elm$core$Basics$sin(
		$elm$core$Basics$degrees(col.b5));
	var a = col.bT * $elm$core$Basics$cos(
		$elm$core$Basics$degrees(col.b5));
	var l = A2($elm$core$Basics$pow, (col.bA + (0.3963377774 * a)) + (0.2158037573 * b), 3);
	var m = A2($elm$core$Basics$pow, (col.bA - (0.1055613458 * a)) - (0.0638541728 * b), 3);
	var s = A2($elm$core$Basics$pow, (col.bA - (0.0894841775 * a)) - (1.291485548 * b), 3);
	return {bR: (((-0.0041960863) * l) - (0.7034186147 * m)) + (1.707614701 * s), b4: (((-1.2684380046) * l) + (2.6097574011 * m)) - (0.3413193965 * s), ca: ((4.0767416621 * l) - (3.3077115913 * m)) + (0.2309699292 * s)};
};
var $author$project$MrJam$OKLab$srgb = function (col) {
	var transfert = function (v) {
		return ($elm$core$Basics$abs(v) <= 0.0031308) ? (12.92 * v) : (((v < 0) ? (-1) : 1) * ((1.055 * A2(
			$elm$core$Basics$pow,
			$elm$core$Basics$abs(v),
			1 / 2.4)) - 0.055));
	};
	var rgb = $author$project$MrJam$OKLab$lineaire(col);
	return {
		bR: transfert(rgb.bR),
		b4: transfert(rgb.b4),
		ca: transfert(rgb.ca)
	};
};
var $author$project$MrJam$Theme$rendu = function (nom) {
	return A2(
		$elm$core$Maybe$withDefault,
		A3($mdgriffith$elm_ui$Element$rgb, 0, 0, 0),
		A2(
			$elm$core$Maybe$map,
			A2(
				$elm$core$Basics$composeR,
				$elm$core$Tuple$second,
				A2(
					$elm$core$Basics$composeR,
					$author$project$MrJam$OKLab$srgb,
					function (rgb) {
						return A3($mdgriffith$elm_ui$Element$rgb, rgb.ca, rgb.b4, rgb.bR);
					})),
			$elm$core$List$head(
				A2(
					$elm$core$List$filter,
					A2(
						$elm$core$Basics$composeR,
						$elm$core$Tuple$first,
						$elm$core$Basics$eq(nom)),
					$author$project$MrJam$Theme$palette(137.50776405003785)))));
};
var $author$project$MrJam$Theme$nomCouleur = function (col) {
	return A2(
		$elm$core$Maybe$withDefault,
		'encre',
		A2(
			$elm$core$Maybe$map,
			$elm$core$Tuple$first,
			$elm$core$List$head(
				A2(
					$elm$core$List$filter,
					function (_v0) {
						var nom = _v0.a;
						return _Utils_eq(
							$author$project$MrJam$Theme$rendu(nom),
							col);
					},
					$author$project$MrJam$Theme$palette(137.50776405003785)))));
};
var $author$project$MrJam$Theme$variable = function (col) {
	return 'var(--mrjam-' + ($author$project$MrJam$Theme$nomCouleur(col) + ')');
};
var $author$project$MrJam$Theme$bordure = function (col) {
	return $mdgriffith$elm_ui$Element$htmlAttribute(
		A2(
			$elm$html$Html$Attributes$style,
			'border-color',
			$author$project$MrJam$Theme$variable(col)));
};
var $mdgriffith$elm_ui$Internal$Model$Button = {$: 8};
var $mdgriffith$elm_ui$Internal$Model$Describe = function (a) {
	return {$: 2, a: a};
};
var $mdgriffith$elm_ui$Internal$Model$Unkeyed = function (a) {
	return {$: 0, a: a};
};
var $mdgriffith$elm_ui$Internal$Model$AsEl = 2;
var $mdgriffith$elm_ui$Internal$Model$asEl = 2;
var $mdgriffith$elm_ui$Internal$Style$classes = {ed: 'a', cj: 'atv', ei: 'ab', ej: 'cx', ek: 'cy', el: 'acb', em: 'accx', en: 'accy', eo: 'acr', cX: 'al', cY: 'ar', ep: 'at', ck: 'ah', cl: 'av', er: 's', ex: 'bh', ey: 'b', eA: 'w7', eC: 'bd', eD: 'bdt', bS: 'bn', eE: 'bs', bU: 'cpe', eO: 'cp', eP: 'cpx', eQ: 'cpy', aq: 'c', bX: 'ctr', bY: 'cb', bZ: 'ccx', ar: 'ccy', bv: 'cl', b_: 'cr', eS: 'ct', eT: 'cptr', eU: 'ctxt', e8: 'fcs', dc: 'focus-within', e9: 'fs', fa: 'g', cA: 'hbh', cB: 'hc', dj: 'he', cC: 'hf', dk: 'hfp', fc: 'hv', ff: 'ic', fh: 'fr', b7: 'lbl', fk: 'iml', fl: 'imlf', fm: 'imlp', fn: 'implw', fo: 'it', fp: 'i', ds: 'lnk', bj: 'nb', dz: 'notxt', fK: 'ol', fM: 'or', aS: 'oq', fQ: 'oh', dF: 'pg', dG: 'p', fS: 'ppe', f0: 'ui', ab: 'r', f2: 'sb', f3: 'sbx', f4: 'sby', f5: 'sbt', f8: 'e', f9: 'cap', ga: 'sev', gg: 'sk', bL: 't', gm: 'tc', gn: 'w8', go: 'w2', gp: 'w9', gq: 'tj', ch: 'tja', gr: 'tl', gs: 'w3', gt: 'w5', gu: 'w4', gv: 'tr', gw: 'w6', gx: 'w1', gy: 'tun', d1: 'ts', a1: 'clr', gF: 'u', cP: 'wc', d8: 'we', cQ: 'wf', d9: 'wfp', cR: 'wrp'};
var $elm$html$Html$Attributes$boolProperty = F2(
	function (key, bool) {
		return A2(
			_VirtualDom_property,
			key,
			$elm$json$Json$Encode$bool(bool));
	});
var $elm$html$Html$Attributes$disabled = $elm$html$Html$Attributes$boolProperty('disabled');
var $mdgriffith$elm_ui$Internal$Model$Generic = {$: 0};
var $mdgriffith$elm_ui$Internal$Model$div = $mdgriffith$elm_ui$Internal$Model$Generic;
var $mdgriffith$elm_ui$Internal$Model$NoNearbyChildren = {$: 0};
var $mdgriffith$elm_ui$Internal$Model$columnClass = $mdgriffith$elm_ui$Internal$Style$classes.er + (' ' + $mdgriffith$elm_ui$Internal$Style$classes.aq);
var $mdgriffith$elm_ui$Internal$Model$gridClass = $mdgriffith$elm_ui$Internal$Style$classes.er + (' ' + $mdgriffith$elm_ui$Internal$Style$classes.fa);
var $mdgriffith$elm_ui$Internal$Model$pageClass = $mdgriffith$elm_ui$Internal$Style$classes.er + (' ' + $mdgriffith$elm_ui$Internal$Style$classes.dF);
var $mdgriffith$elm_ui$Internal$Model$paragraphClass = $mdgriffith$elm_ui$Internal$Style$classes.er + (' ' + $mdgriffith$elm_ui$Internal$Style$classes.dG);
var $mdgriffith$elm_ui$Internal$Model$rowClass = $mdgriffith$elm_ui$Internal$Style$classes.er + (' ' + $mdgriffith$elm_ui$Internal$Style$classes.ab);
var $mdgriffith$elm_ui$Internal$Model$singleClass = $mdgriffith$elm_ui$Internal$Style$classes.er + (' ' + $mdgriffith$elm_ui$Internal$Style$classes.f8);
var $mdgriffith$elm_ui$Internal$Model$contextClasses = function (context) {
	switch (context) {
		case 0:
			return $mdgriffith$elm_ui$Internal$Model$rowClass;
		case 1:
			return $mdgriffith$elm_ui$Internal$Model$columnClass;
		case 2:
			return $mdgriffith$elm_ui$Internal$Model$singleClass;
		case 3:
			return $mdgriffith$elm_ui$Internal$Model$gridClass;
		case 4:
			return $mdgriffith$elm_ui$Internal$Model$paragraphClass;
		default:
			return $mdgriffith$elm_ui$Internal$Model$pageClass;
	}
};
var $mdgriffith$elm_ui$Internal$Model$Keyed = function (a) {
	return {$: 1, a: a};
};
var $mdgriffith$elm_ui$Internal$Model$NoStyleSheet = {$: 0};
var $mdgriffith$elm_ui$Internal$Model$Styled = function (a) {
	return {$: 1, a: a};
};
var $mdgriffith$elm_ui$Internal$Model$Unstyled = function (a) {
	return {$: 0, a: a};
};
var $mdgriffith$elm_ui$Internal$Model$addChildren = F2(
	function (existing, nearbyChildren) {
		switch (nearbyChildren.$) {
			case 0:
				return existing;
			case 1:
				var behind = nearbyChildren.a;
				return _Utils_ap(behind, existing);
			case 2:
				var inFront = nearbyChildren.a;
				return _Utils_ap(existing, inFront);
			default:
				var behind = nearbyChildren.a;
				var inFront = nearbyChildren.b;
				return _Utils_ap(
					behind,
					_Utils_ap(existing, inFront));
		}
	});
var $mdgriffith$elm_ui$Internal$Model$addKeyedChildren = F3(
	function (key, existing, nearbyChildren) {
		switch (nearbyChildren.$) {
			case 0:
				return existing;
			case 1:
				var behind = nearbyChildren.a;
				return _Utils_ap(
					A2(
						$elm$core$List$map,
						function (x) {
							return _Utils_Tuple2(key, x);
						},
						behind),
					existing);
			case 2:
				var inFront = nearbyChildren.a;
				return _Utils_ap(
					existing,
					A2(
						$elm$core$List$map,
						function (x) {
							return _Utils_Tuple2(key, x);
						},
						inFront));
			default:
				var behind = nearbyChildren.a;
				var inFront = nearbyChildren.b;
				return _Utils_ap(
					A2(
						$elm$core$List$map,
						function (x) {
							return _Utils_Tuple2(key, x);
						},
						behind),
					_Utils_ap(
						existing,
						A2(
							$elm$core$List$map,
							function (x) {
								return _Utils_Tuple2(key, x);
							},
							inFront)));
		}
	});
var $mdgriffith$elm_ui$Internal$Model$AsParagraph = 4;
var $mdgriffith$elm_ui$Internal$Model$asParagraph = 4;
var $mdgriffith$elm_ui$Internal$Flag$Flag = function (a) {
	return {$: 0, a: a};
};
var $mdgriffith$elm_ui$Internal$Flag$Second = function (a) {
	return {$: 1, a: a};
};
var $elm$core$Bitwise$shiftLeftBy = _Bitwise_shiftLeftBy;
var $mdgriffith$elm_ui$Internal$Flag$flag = function (i) {
	return (i > 31) ? $mdgriffith$elm_ui$Internal$Flag$Second(1 << (i - 32)) : $mdgriffith$elm_ui$Internal$Flag$Flag(1 << i);
};
var $mdgriffith$elm_ui$Internal$Flag$alignBottom = $mdgriffith$elm_ui$Internal$Flag$flag(41);
var $mdgriffith$elm_ui$Internal$Flag$alignRight = $mdgriffith$elm_ui$Internal$Flag$flag(40);
var $mdgriffith$elm_ui$Internal$Flag$centerX = $mdgriffith$elm_ui$Internal$Flag$flag(42);
var $mdgriffith$elm_ui$Internal$Flag$centerY = $mdgriffith$elm_ui$Internal$Flag$flag(43);
var $elm$html$Html$Attributes$stringProperty = F2(
	function (key, string) {
		return A2(
			_VirtualDom_property,
			key,
			$elm$json$Json$Encode$string(string));
	});
var $elm$html$Html$Attributes$class = $elm$html$Html$Attributes$stringProperty('className');
var $elm$html$Html$div = _VirtualDom_node('div');
var $elm$core$Set$Set_elm_builtin = $elm$core$Basics$identity;
var $elm$core$Set$empty = $elm$core$Dict$empty;
var $mdgriffith$elm_ui$Internal$Model$lengthClassName = function (x) {
	switch (x.$) {
		case 0:
			var px = x.a;
			return $elm$core$String$fromInt(px) + 'px';
		case 1:
			return 'auto';
		case 2:
			var i = x.a;
			return $elm$core$String$fromInt(i) + 'fr';
		case 3:
			var min = x.a;
			var len = x.b;
			return 'min' + ($elm$core$String$fromInt(min) + $mdgriffith$elm_ui$Internal$Model$lengthClassName(len));
		default:
			var max = x.a;
			var len = x.b;
			return 'max' + ($elm$core$String$fromInt(max) + $mdgriffith$elm_ui$Internal$Model$lengthClassName(len));
	}
};
var $mdgriffith$elm_ui$Internal$Model$floatClass = function (x) {
	return $elm$core$String$fromInt(
		$elm$core$Basics$round(x * 255));
};
var $mdgriffith$elm_ui$Internal$Model$transformClass = function (transform) {
	switch (transform.$) {
		case 0:
			return $elm$core$Maybe$Nothing;
		case 1:
			var _v1 = transform.a;
			var x = _v1.a;
			var y = _v1.b;
			var z = _v1.c;
			return $elm$core$Maybe$Just(
				'mv-' + ($mdgriffith$elm_ui$Internal$Model$floatClass(x) + ('-' + ($mdgriffith$elm_ui$Internal$Model$floatClass(y) + ('-' + $mdgriffith$elm_ui$Internal$Model$floatClass(z))))));
		default:
			var _v2 = transform.a;
			var tx = _v2.a;
			var ty = _v2.b;
			var tz = _v2.c;
			var _v3 = transform.b;
			var sx = _v3.a;
			var sy = _v3.b;
			var sz = _v3.c;
			var _v4 = transform.c;
			var ox = _v4.a;
			var oy = _v4.b;
			var oz = _v4.c;
			var angle = transform.d;
			return $elm$core$Maybe$Just(
				'tfrm-' + ($mdgriffith$elm_ui$Internal$Model$floatClass(tx) + ('-' + ($mdgriffith$elm_ui$Internal$Model$floatClass(ty) + ('-' + ($mdgriffith$elm_ui$Internal$Model$floatClass(tz) + ('-' + ($mdgriffith$elm_ui$Internal$Model$floatClass(sx) + ('-' + ($mdgriffith$elm_ui$Internal$Model$floatClass(sy) + ('-' + ($mdgriffith$elm_ui$Internal$Model$floatClass(sz) + ('-' + ($mdgriffith$elm_ui$Internal$Model$floatClass(ox) + ('-' + ($mdgriffith$elm_ui$Internal$Model$floatClass(oy) + ('-' + ($mdgriffith$elm_ui$Internal$Model$floatClass(oz) + ('-' + $mdgriffith$elm_ui$Internal$Model$floatClass(angle))))))))))))))))))));
	}
};
var $mdgriffith$elm_ui$Internal$Model$getStyleName = function (style) {
	switch (style.$) {
		case 13:
			var name = style.a;
			return name;
		case 12:
			var name = style.a;
			var o = style.b;
			return name;
		case 0:
			var _class = style.a;
			return _class;
		case 1:
			var name = style.a;
			return name;
		case 2:
			var i = style.a;
			return 'font-size-' + $elm$core$String$fromInt(i);
		case 3:
			var _class = style.a;
			return _class;
		case 4:
			var _class = style.a;
			return _class;
		case 5:
			var cls = style.a;
			var x = style.b;
			var y = style.c;
			return cls;
		case 7:
			var cls = style.a;
			var top = style.b;
			var right = style.c;
			var bottom = style.d;
			var left = style.e;
			return cls;
		case 6:
			var cls = style.a;
			var top = style.b;
			var right = style.c;
			var bottom = style.d;
			var left = style.e;
			return cls;
		case 8:
			var template = style.a;
			return 'grid-rows-' + (A2(
				$elm$core$String$join,
				'-',
				A2($elm$core$List$map, $mdgriffith$elm_ui$Internal$Model$lengthClassName, template.f1)) + ('-cols-' + (A2(
				$elm$core$String$join,
				'-',
				A2($elm$core$List$map, $mdgriffith$elm_ui$Internal$Model$lengthClassName, template.ag)) + ('-space-x-' + ($mdgriffith$elm_ui$Internal$Model$lengthClassName(template.gb.a) + ('-space-y-' + $mdgriffith$elm_ui$Internal$Model$lengthClassName(template.gb.b)))))));
		case 9:
			var pos = style.a;
			return 'gp grid-pos-' + ($elm$core$String$fromInt(pos.ab) + ('-' + ($elm$core$String$fromInt(pos.eR) + ('-' + ($elm$core$String$fromInt(pos.d7) + ('-' + $elm$core$String$fromInt(pos.di)))))));
		case 11:
			var selector = style.a;
			var subStyle = style.b;
			var name = function () {
				switch (selector) {
					case 0:
						return 'fs';
					case 1:
						return 'hv';
					default:
						return 'act';
				}
			}();
			return A2(
				$elm$core$String$join,
				' ',
				A2(
					$elm$core$List$map,
					function (sty) {
						var _v1 = $mdgriffith$elm_ui$Internal$Model$getStyleName(sty);
						if (_v1 === '') {
							return '';
						} else {
							var styleName = _v1;
							return styleName + ('-' + name);
						}
					},
					subStyle));
		default:
			var x = style.a;
			return A2(
				$elm$core$Maybe$withDefault,
				'',
				$mdgriffith$elm_ui$Internal$Model$transformClass(x));
	}
};
var $elm$core$Set$insert = F2(
	function (key, _v0) {
		var dict = _v0;
		return A3($elm$core$Dict$insert, key, 0, dict);
	});
var $elm$core$Dict$member = F2(
	function (key, dict) {
		var _v0 = A2($elm$core$Dict$get, key, dict);
		if (!_v0.$) {
			return true;
		} else {
			return false;
		}
	});
var $elm$core$Set$member = F2(
	function (key, _v0) {
		var dict = _v0;
		return A2($elm$core$Dict$member, key, dict);
	});
var $mdgriffith$elm_ui$Internal$Model$reduceStyles = F2(
	function (style, nevermind) {
		var cache = nevermind.a;
		var existing = nevermind.b;
		var styleName = $mdgriffith$elm_ui$Internal$Model$getStyleName(style);
		return A2($elm$core$Set$member, styleName, cache) ? nevermind : _Utils_Tuple2(
			A2($elm$core$Set$insert, styleName, cache),
			A2($elm$core$List$cons, style, existing));
	});
var $mdgriffith$elm_ui$Internal$Model$Property = F2(
	function (a, b) {
		return {$: 0, a: a, b: b};
	});
var $mdgriffith$elm_ui$Internal$Model$Style = F2(
	function (a, b) {
		return {$: 0, a: a, b: b};
	});
var $mdgriffith$elm_ui$Internal$Style$dot = function (c) {
	return '.' + c;
};
var $elm$core$List$maybeCons = F3(
	function (f, mx, xs) {
		var _v0 = f(mx);
		if (!_v0.$) {
			var x = _v0.a;
			return A2($elm$core$List$cons, x, xs);
		} else {
			return xs;
		}
	});
var $elm$core$List$filterMap = F2(
	function (f, xs) {
		return A3(
			$elm$core$List$foldr,
			$elm$core$List$maybeCons(f),
			_List_Nil,
			xs);
	});
var $mdgriffith$elm_ui$Internal$Model$formatColor = function (_v0) {
	var red = _v0.a;
	var green = _v0.b;
	var blue = _v0.c;
	var alpha = _v0.d;
	return 'rgba(' + ($elm$core$String$fromInt(
		$elm$core$Basics$round(red * 255)) + ((',' + $elm$core$String$fromInt(
		$elm$core$Basics$round(green * 255))) + ((',' + $elm$core$String$fromInt(
		$elm$core$Basics$round(blue * 255))) + (',' + ($elm$core$String$fromFloat(alpha) + ')')))));
};
var $mdgriffith$elm_ui$Internal$Model$formatBoxShadow = function (shadow) {
	return A2(
		$elm$core$String$join,
		' ',
		A2(
			$elm$core$List$filterMap,
			$elm$core$Basics$identity,
			_List_fromArray(
				[
					shadow.dn ? $elm$core$Maybe$Just('inset') : $elm$core$Maybe$Nothing,
					$elm$core$Maybe$Just(
					$elm$core$String$fromFloat(shadow.dC.a) + 'px'),
					$elm$core$Maybe$Just(
					$elm$core$String$fromFloat(shadow.dC.b) + 'px'),
					$elm$core$Maybe$Just(
					$elm$core$String$fromFloat(shadow.a7) + 'px'),
					$elm$core$Maybe$Just(
					$elm$core$String$fromFloat(shadow.aZ) + 'px'),
					$elm$core$Maybe$Just(
					$mdgriffith$elm_ui$Internal$Model$formatColor(shadow.a8))
				])));
};
var $elm$core$Tuple$mapFirst = F2(
	function (func, _v0) {
		var x = _v0.a;
		var y = _v0.b;
		return _Utils_Tuple2(
			func(x),
			y);
	});
var $elm$core$Tuple$mapSecond = F2(
	function (func, _v0) {
		var x = _v0.a;
		var y = _v0.b;
		return _Utils_Tuple2(
			x,
			func(y));
	});
var $mdgriffith$elm_ui$Internal$Model$renderFocusStyle = function (focus) {
	return _List_fromArray(
		[
			A2(
			$mdgriffith$elm_ui$Internal$Model$Style,
			$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.dc) + ':focus-within',
			A2(
				$elm$core$List$filterMap,
				$elm$core$Basics$identity,
				_List_fromArray(
					[
						A2(
						$elm$core$Maybe$map,
						function (color) {
							return A2(
								$mdgriffith$elm_ui$Internal$Model$Property,
								'border-color',
								$mdgriffith$elm_ui$Internal$Model$formatColor(color));
						},
						focus.eB),
						A2(
						$elm$core$Maybe$map,
						function (color) {
							return A2(
								$mdgriffith$elm_ui$Internal$Model$Property,
								'background-color',
								$mdgriffith$elm_ui$Internal$Model$formatColor(color));
						},
						focus.et),
						A2(
						$elm$core$Maybe$map,
						function (shadow) {
							return A2(
								$mdgriffith$elm_ui$Internal$Model$Property,
								'box-shadow',
								$mdgriffith$elm_ui$Internal$Model$formatBoxShadow(
									{
										a7: shadow.a7,
										a8: shadow.a8,
										dn: false,
										dC: A2(
											$elm$core$Tuple$mapSecond,
											$elm$core$Basics$toFloat,
											A2($elm$core$Tuple$mapFirst, $elm$core$Basics$toFloat, shadow.dC)),
										aZ: shadow.aZ
									}));
						},
						focus.f7),
						$elm$core$Maybe$Just(
						A2($mdgriffith$elm_ui$Internal$Model$Property, 'outline', 'none'))
					]))),
			A2(
			$mdgriffith$elm_ui$Internal$Model$Style,
			($mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.er) + ':focus .focusable, ') + (($mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.er) + '.focusable:focus, ') + ('.ui-slide-bar:focus + ' + ($mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.er) + ' .focusable-thumb'))),
			A2(
				$elm$core$List$filterMap,
				$elm$core$Basics$identity,
				_List_fromArray(
					[
						A2(
						$elm$core$Maybe$map,
						function (color) {
							return A2(
								$mdgriffith$elm_ui$Internal$Model$Property,
								'border-color',
								$mdgriffith$elm_ui$Internal$Model$formatColor(color));
						},
						focus.eB),
						A2(
						$elm$core$Maybe$map,
						function (color) {
							return A2(
								$mdgriffith$elm_ui$Internal$Model$Property,
								'background-color',
								$mdgriffith$elm_ui$Internal$Model$formatColor(color));
						},
						focus.et),
						A2(
						$elm$core$Maybe$map,
						function (shadow) {
							return A2(
								$mdgriffith$elm_ui$Internal$Model$Property,
								'box-shadow',
								$mdgriffith$elm_ui$Internal$Model$formatBoxShadow(
									{
										a7: shadow.a7,
										a8: shadow.a8,
										dn: false,
										dC: A2(
											$elm$core$Tuple$mapSecond,
											$elm$core$Basics$toFloat,
											A2($elm$core$Tuple$mapFirst, $elm$core$Basics$toFloat, shadow.dC)),
										aZ: shadow.aZ
									}));
						},
						focus.f7),
						$elm$core$Maybe$Just(
						A2($mdgriffith$elm_ui$Internal$Model$Property, 'outline', 'none'))
					])))
		]);
};
var $elm$virtual_dom$VirtualDom$node = function (tag) {
	return _VirtualDom_node(
		_VirtualDom_noScript(tag));
};
var $elm$virtual_dom$VirtualDom$property = F2(
	function (key, value) {
		return A2(
			_VirtualDom_property,
			_VirtualDom_noInnerHtmlOrFormAction(key),
			_VirtualDom_noJavaScriptOrHtmlJson(value));
	});
var $mdgriffith$elm_ui$Internal$Style$AllChildren = F2(
	function (a, b) {
		return {$: 2, a: a, b: b};
	});
var $mdgriffith$elm_ui$Internal$Style$Batch = function (a) {
	return {$: 6, a: a};
};
var $mdgriffith$elm_ui$Internal$Style$Child = F2(
	function (a, b) {
		return {$: 1, a: a, b: b};
	});
var $mdgriffith$elm_ui$Internal$Style$Class = F2(
	function (a, b) {
		return {$: 0, a: a, b: b};
	});
var $mdgriffith$elm_ui$Internal$Style$Descriptor = F2(
	function (a, b) {
		return {$: 4, a: a, b: b};
	});
var $mdgriffith$elm_ui$Internal$Style$Left = 3;
var $mdgriffith$elm_ui$Internal$Style$Prop = F2(
	function (a, b) {
		return {$: 0, a: a, b: b};
	});
var $mdgriffith$elm_ui$Internal$Style$Right = 2;
var $mdgriffith$elm_ui$Internal$Style$Self = $elm$core$Basics$identity;
var $mdgriffith$elm_ui$Internal$Style$Supports = F2(
	function (a, b) {
		return {$: 3, a: a, b: b};
	});
var $mdgriffith$elm_ui$Internal$Style$Content = $elm$core$Basics$identity;
var $mdgriffith$elm_ui$Internal$Style$Bottom = 1;
var $mdgriffith$elm_ui$Internal$Style$CenterX = 4;
var $mdgriffith$elm_ui$Internal$Style$CenterY = 5;
var $mdgriffith$elm_ui$Internal$Style$Top = 0;
var $mdgriffith$elm_ui$Internal$Style$alignments = _List_fromArray(
	[0, 1, 2, 3, 4, 5]);
var $elm$core$List$append = F2(
	function (xs, ys) {
		if (!ys.b) {
			return xs;
		} else {
			return A3($elm$core$List$foldr, $elm$core$List$cons, ys, xs);
		}
	});
var $elm$core$List$concat = function (lists) {
	return A3($elm$core$List$foldr, $elm$core$List$append, _List_Nil, lists);
};
var $elm$core$List$concatMap = F2(
	function (f, list) {
		return $elm$core$List$concat(
			A2($elm$core$List$map, f, list));
	});
var $mdgriffith$elm_ui$Internal$Style$contentName = function (desc) {
	switch (desc) {
		case 0:
			var _v1 = desc;
			return $mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.eS);
		case 1:
			var _v2 = desc;
			return $mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.bY);
		case 2:
			var _v3 = desc;
			return $mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.b_);
		case 3:
			var _v4 = desc;
			return $mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.bv);
		case 4:
			var _v5 = desc;
			return $mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.bZ);
		default:
			var _v6 = desc;
			return $mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.ar);
	}
};
var $mdgriffith$elm_ui$Internal$Style$selfName = function (desc) {
	switch (desc) {
		case 0:
			var _v1 = desc;
			return $mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.ep);
		case 1:
			var _v2 = desc;
			return $mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.ei);
		case 2:
			var _v3 = desc;
			return $mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.cY);
		case 3:
			var _v4 = desc;
			return $mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.cX);
		case 4:
			var _v5 = desc;
			return $mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.ej);
		default:
			var _v6 = desc;
			return $mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.ek);
	}
};
var $mdgriffith$elm_ui$Internal$Style$describeAlignment = function (values) {
	var createDescription = function (alignment) {
		var _v0 = values(alignment);
		var content = _v0.a;
		var indiv = _v0.b;
		return _List_fromArray(
			[
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$contentName(alignment),
				content),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Child,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.er),
				_List_fromArray(
					[
						A2(
						$mdgriffith$elm_ui$Internal$Style$Descriptor,
						$mdgriffith$elm_ui$Internal$Style$selfName(alignment),
						indiv)
					]))
			]);
	};
	return $mdgriffith$elm_ui$Internal$Style$Batch(
		A2($elm$core$List$concatMap, createDescription, $mdgriffith$elm_ui$Internal$Style$alignments));
};
var $mdgriffith$elm_ui$Internal$Style$elDescription = _List_fromArray(
	[
		A2($mdgriffith$elm_ui$Internal$Style$Prop, 'display', 'flex'),
		A2($mdgriffith$elm_ui$Internal$Style$Prop, 'flex-direction', 'column'),
		A2($mdgriffith$elm_ui$Internal$Style$Prop, 'white-space', 'pre'),
		A2(
		$mdgriffith$elm_ui$Internal$Style$Descriptor,
		$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.cA),
		_List_fromArray(
			[
				A2($mdgriffith$elm_ui$Internal$Style$Prop, 'z-index', '0'),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Child,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.ex),
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'z-index', '-1')
					]))
			])),
		A2(
		$mdgriffith$elm_ui$Internal$Style$Descriptor,
		$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.f5),
		_List_fromArray(
			[
				A2(
				$mdgriffith$elm_ui$Internal$Style$Child,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.bL),
				_List_fromArray(
					[
						A2(
						$mdgriffith$elm_ui$Internal$Style$Descriptor,
						$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.cC),
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'flex-grow', '0')
							])),
						A2(
						$mdgriffith$elm_ui$Internal$Style$Descriptor,
						$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.cQ),
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'align-self', 'auto !important')
							]))
					]))
			])),
		A2(
		$mdgriffith$elm_ui$Internal$Style$Child,
		$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.cB),
		_List_fromArray(
			[
				A2($mdgriffith$elm_ui$Internal$Style$Prop, 'height', 'auto')
			])),
		A2(
		$mdgriffith$elm_ui$Internal$Style$Child,
		$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.cC),
		_List_fromArray(
			[
				A2($mdgriffith$elm_ui$Internal$Style$Prop, 'flex-grow', '100000')
			])),
		A2(
		$mdgriffith$elm_ui$Internal$Style$Child,
		$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.cQ),
		_List_fromArray(
			[
				A2($mdgriffith$elm_ui$Internal$Style$Prop, 'width', '100%')
			])),
		A2(
		$mdgriffith$elm_ui$Internal$Style$Child,
		$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.d9),
		_List_fromArray(
			[
				A2($mdgriffith$elm_ui$Internal$Style$Prop, 'width', '100%')
			])),
		A2(
		$mdgriffith$elm_ui$Internal$Style$Child,
		$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.cP),
		_List_fromArray(
			[
				A2($mdgriffith$elm_ui$Internal$Style$Prop, 'align-self', 'flex-start')
			])),
		$mdgriffith$elm_ui$Internal$Style$describeAlignment(
		function (alignment) {
			switch (alignment) {
				case 0:
					return _Utils_Tuple2(
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'justify-content', 'flex-start')
							]),
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'margin-bottom', 'auto !important'),
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'margin-top', '0 !important')
							]));
				case 1:
					return _Utils_Tuple2(
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'justify-content', 'flex-end')
							]),
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'margin-top', 'auto !important'),
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'margin-bottom', '0 !important')
							]));
				case 2:
					return _Utils_Tuple2(
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'align-items', 'flex-end')
							]),
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'align-self', 'flex-end')
							]));
				case 3:
					return _Utils_Tuple2(
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'align-items', 'flex-start')
							]),
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'align-self', 'flex-start')
							]));
				case 4:
					return _Utils_Tuple2(
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'align-items', 'center')
							]),
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'align-self', 'center')
							]));
				default:
					return _Utils_Tuple2(
						_List_fromArray(
							[
								A2(
								$mdgriffith$elm_ui$Internal$Style$Child,
								$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.er),
								_List_fromArray(
									[
										A2($mdgriffith$elm_ui$Internal$Style$Prop, 'margin-top', 'auto'),
										A2($mdgriffith$elm_ui$Internal$Style$Prop, 'margin-bottom', 'auto')
									]))
							]),
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'margin-top', 'auto !important'),
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'margin-bottom', 'auto !important')
							]));
			}
		})
	]);
var $mdgriffith$elm_ui$Internal$Style$gridAlignments = function (values) {
	var createDescription = function (alignment) {
		return _List_fromArray(
			[
				A2(
				$mdgriffith$elm_ui$Internal$Style$Child,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.er),
				_List_fromArray(
					[
						A2(
						$mdgriffith$elm_ui$Internal$Style$Descriptor,
						$mdgriffith$elm_ui$Internal$Style$selfName(alignment),
						values(alignment))
					]))
			]);
	};
	return $mdgriffith$elm_ui$Internal$Style$Batch(
		A2($elm$core$List$concatMap, createDescription, $mdgriffith$elm_ui$Internal$Style$alignments));
};
var $mdgriffith$elm_ui$Internal$Style$Above = 0;
var $mdgriffith$elm_ui$Internal$Style$Behind = 5;
var $mdgriffith$elm_ui$Internal$Style$Below = 1;
var $mdgriffith$elm_ui$Internal$Style$OnLeft = 3;
var $mdgriffith$elm_ui$Internal$Style$OnRight = 2;
var $mdgriffith$elm_ui$Internal$Style$Within = 4;
var $mdgriffith$elm_ui$Internal$Style$locations = function () {
	var loc = 0;
	var _v0 = function () {
		switch (loc) {
			case 0:
				return 0;
			case 1:
				return 0;
			case 2:
				return 0;
			case 3:
				return 0;
			case 4:
				return 0;
			default:
				return 0;
		}
	}();
	return _List_fromArray(
		[0, 1, 2, 3, 4, 5]);
}();
var $mdgriffith$elm_ui$Internal$Style$baseSheet = _List_fromArray(
	[
		A2(
		$mdgriffith$elm_ui$Internal$Style$Class,
		'html,body',
		_List_fromArray(
			[
				A2($mdgriffith$elm_ui$Internal$Style$Prop, 'height', '100%'),
				A2($mdgriffith$elm_ui$Internal$Style$Prop, 'padding', '0'),
				A2($mdgriffith$elm_ui$Internal$Style$Prop, 'margin', '0')
			])),
		A2(
		$mdgriffith$elm_ui$Internal$Style$Class,
		_Utils_ap(
			$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.er),
			_Utils_ap(
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.f8),
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.ff))),
		_List_fromArray(
			[
				A2($mdgriffith$elm_ui$Internal$Style$Prop, 'display', 'block'),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.cC),
				_List_fromArray(
					[
						A2(
						$mdgriffith$elm_ui$Internal$Style$Child,
						'img',
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'max-height', '100%'),
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'object-fit', 'cover')
							]))
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.cQ),
				_List_fromArray(
					[
						A2(
						$mdgriffith$elm_ui$Internal$Style$Child,
						'img',
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'max-width', '100%'),
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'object-fit', 'cover')
							]))
					]))
			])),
		A2(
		$mdgriffith$elm_ui$Internal$Style$Class,
		$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.er) + ':focus',
		_List_fromArray(
			[
				A2($mdgriffith$elm_ui$Internal$Style$Prop, 'outline', 'none')
			])),
		A2(
		$mdgriffith$elm_ui$Internal$Style$Class,
		$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.f0),
		_List_fromArray(
			[
				A2($mdgriffith$elm_ui$Internal$Style$Prop, 'width', '100%'),
				A2($mdgriffith$elm_ui$Internal$Style$Prop, 'height', 'auto'),
				A2($mdgriffith$elm_ui$Internal$Style$Prop, 'min-height', '100%'),
				A2($mdgriffith$elm_ui$Internal$Style$Prop, 'z-index', '0'),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				_Utils_ap(
					$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.er),
					$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.cC)),
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'height', '100%'),
						A2(
						$mdgriffith$elm_ui$Internal$Style$Child,
						$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.cC),
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'height', '100%')
							]))
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Child,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.fh),
				_List_fromArray(
					[
						A2(
						$mdgriffith$elm_ui$Internal$Style$Descriptor,
						$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.bj),
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'position', 'fixed'),
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'z-index', '20')
							]))
					]))
			])),
		A2(
		$mdgriffith$elm_ui$Internal$Style$Class,
		$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.bj),
		_List_fromArray(
			[
				A2($mdgriffith$elm_ui$Internal$Style$Prop, 'position', 'relative'),
				A2($mdgriffith$elm_ui$Internal$Style$Prop, 'border', 'none'),
				A2($mdgriffith$elm_ui$Internal$Style$Prop, 'display', 'flex'),
				A2($mdgriffith$elm_ui$Internal$Style$Prop, 'flex-direction', 'row'),
				A2($mdgriffith$elm_ui$Internal$Style$Prop, 'flex-basis', 'auto'),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.f8),
				$mdgriffith$elm_ui$Internal$Style$elDescription),
				$mdgriffith$elm_ui$Internal$Style$Batch(
				function (fn) {
					return A2($elm$core$List$map, fn, $mdgriffith$elm_ui$Internal$Style$locations);
				}(
					function (loc) {
						switch (loc) {
							case 0:
								return A2(
									$mdgriffith$elm_ui$Internal$Style$Descriptor,
									$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.ed),
									_List_fromArray(
										[
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'position', 'absolute'),
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'bottom', '100%'),
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'left', '0'),
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'width', '100%'),
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'z-index', '20'),
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'margin', '0 !important'),
											A2(
											$mdgriffith$elm_ui$Internal$Style$Child,
											$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.cC),
											_List_fromArray(
												[
													A2($mdgriffith$elm_ui$Internal$Style$Prop, 'height', 'auto')
												])),
											A2(
											$mdgriffith$elm_ui$Internal$Style$Child,
											$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.cQ),
											_List_fromArray(
												[
													A2($mdgriffith$elm_ui$Internal$Style$Prop, 'width', '100%')
												])),
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'pointer-events', 'none'),
											A2(
											$mdgriffith$elm_ui$Internal$Style$Child,
											'*',
											_List_fromArray(
												[
													A2($mdgriffith$elm_ui$Internal$Style$Prop, 'pointer-events', 'auto')
												]))
										]));
							case 1:
								return A2(
									$mdgriffith$elm_ui$Internal$Style$Descriptor,
									$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.ey),
									_List_fromArray(
										[
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'position', 'absolute'),
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'bottom', '0'),
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'left', '0'),
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'height', '0'),
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'width', '100%'),
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'z-index', '20'),
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'margin', '0 !important'),
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'pointer-events', 'none'),
											A2(
											$mdgriffith$elm_ui$Internal$Style$Child,
											'*',
											_List_fromArray(
												[
													A2($mdgriffith$elm_ui$Internal$Style$Prop, 'pointer-events', 'auto')
												])),
											A2(
											$mdgriffith$elm_ui$Internal$Style$Child,
											$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.cC),
											_List_fromArray(
												[
													A2($mdgriffith$elm_ui$Internal$Style$Prop, 'height', 'auto')
												]))
										]));
							case 2:
								return A2(
									$mdgriffith$elm_ui$Internal$Style$Descriptor,
									$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.fM),
									_List_fromArray(
										[
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'position', 'absolute'),
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'left', '100%'),
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'top', '0'),
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'height', '100%'),
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'margin', '0 !important'),
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'z-index', '20'),
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'pointer-events', 'none'),
											A2(
											$mdgriffith$elm_ui$Internal$Style$Child,
											'*',
											_List_fromArray(
												[
													A2($mdgriffith$elm_ui$Internal$Style$Prop, 'pointer-events', 'auto')
												]))
										]));
							case 3:
								return A2(
									$mdgriffith$elm_ui$Internal$Style$Descriptor,
									$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.fK),
									_List_fromArray(
										[
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'position', 'absolute'),
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'right', '100%'),
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'top', '0'),
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'height', '100%'),
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'margin', '0 !important'),
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'z-index', '20'),
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'pointer-events', 'none'),
											A2(
											$mdgriffith$elm_ui$Internal$Style$Child,
											'*',
											_List_fromArray(
												[
													A2($mdgriffith$elm_ui$Internal$Style$Prop, 'pointer-events', 'auto')
												]))
										]));
							case 4:
								return A2(
									$mdgriffith$elm_ui$Internal$Style$Descriptor,
									$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.fh),
									_List_fromArray(
										[
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'position', 'absolute'),
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'width', '100%'),
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'height', '100%'),
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'left', '0'),
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'top', '0'),
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'margin', '0 !important'),
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'pointer-events', 'none'),
											A2(
											$mdgriffith$elm_ui$Internal$Style$Child,
											'*',
											_List_fromArray(
												[
													A2($mdgriffith$elm_ui$Internal$Style$Prop, 'pointer-events', 'auto')
												]))
										]));
							default:
								return A2(
									$mdgriffith$elm_ui$Internal$Style$Descriptor,
									$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.ex),
									_List_fromArray(
										[
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'position', 'absolute'),
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'width', '100%'),
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'height', '100%'),
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'left', '0'),
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'top', '0'),
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'margin', '0 !important'),
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'z-index', '0'),
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'pointer-events', 'none'),
											A2(
											$mdgriffith$elm_ui$Internal$Style$Child,
											'*',
											_List_fromArray(
												[
													A2($mdgriffith$elm_ui$Internal$Style$Prop, 'pointer-events', 'auto')
												]))
										]));
						}
					}))
			])),
		A2(
		$mdgriffith$elm_ui$Internal$Style$Class,
		$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.er),
		_List_fromArray(
			[
				A2($mdgriffith$elm_ui$Internal$Style$Prop, 'position', 'relative'),
				A2($mdgriffith$elm_ui$Internal$Style$Prop, 'border', 'none'),
				A2($mdgriffith$elm_ui$Internal$Style$Prop, 'flex-shrink', '0'),
				A2($mdgriffith$elm_ui$Internal$Style$Prop, 'display', 'flex'),
				A2($mdgriffith$elm_ui$Internal$Style$Prop, 'flex-direction', 'row'),
				A2($mdgriffith$elm_ui$Internal$Style$Prop, 'flex-basis', 'auto'),
				A2($mdgriffith$elm_ui$Internal$Style$Prop, 'resize', 'none'),
				A2($mdgriffith$elm_ui$Internal$Style$Prop, 'font-feature-settings', 'inherit'),
				A2($mdgriffith$elm_ui$Internal$Style$Prop, 'box-sizing', 'border-box'),
				A2($mdgriffith$elm_ui$Internal$Style$Prop, 'margin', '0'),
				A2($mdgriffith$elm_ui$Internal$Style$Prop, 'padding', '0'),
				A2($mdgriffith$elm_ui$Internal$Style$Prop, 'border-width', '0'),
				A2($mdgriffith$elm_ui$Internal$Style$Prop, 'border-style', 'solid'),
				A2($mdgriffith$elm_ui$Internal$Style$Prop, 'font-size', 'inherit'),
				A2($mdgriffith$elm_ui$Internal$Style$Prop, 'color', 'inherit'),
				A2($mdgriffith$elm_ui$Internal$Style$Prop, 'font-family', 'inherit'),
				A2($mdgriffith$elm_ui$Internal$Style$Prop, 'line-height', '1'),
				A2($mdgriffith$elm_ui$Internal$Style$Prop, 'font-weight', 'inherit'),
				A2($mdgriffith$elm_ui$Internal$Style$Prop, 'text-decoration', 'none'),
				A2($mdgriffith$elm_ui$Internal$Style$Prop, 'font-style', 'inherit'),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.cR),
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'flex-wrap', 'wrap')
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.dz),
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, '-moz-user-select', 'none'),
						A2($mdgriffith$elm_ui$Internal$Style$Prop, '-webkit-user-select', 'none'),
						A2($mdgriffith$elm_ui$Internal$Style$Prop, '-ms-user-select', 'none'),
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'user-select', 'none')
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.eT),
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'cursor', 'pointer')
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.eU),
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'cursor', 'text')
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.fS),
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'pointer-events', 'none !important')
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.bU),
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'pointer-events', 'auto !important')
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.a1),
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'opacity', '0')
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.aS),
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'opacity', '1')
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot(
					_Utils_ap($mdgriffith$elm_ui$Internal$Style$classes.fc, $mdgriffith$elm_ui$Internal$Style$classes.a1)) + ':hover',
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'opacity', '0')
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot(
					_Utils_ap($mdgriffith$elm_ui$Internal$Style$classes.fc, $mdgriffith$elm_ui$Internal$Style$classes.aS)) + ':hover',
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'opacity', '1')
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot(
					_Utils_ap($mdgriffith$elm_ui$Internal$Style$classes.e8, $mdgriffith$elm_ui$Internal$Style$classes.a1)) + ':focus',
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'opacity', '0')
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot(
					_Utils_ap($mdgriffith$elm_ui$Internal$Style$classes.e8, $mdgriffith$elm_ui$Internal$Style$classes.aS)) + ':focus',
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'opacity', '1')
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot(
					_Utils_ap($mdgriffith$elm_ui$Internal$Style$classes.cj, $mdgriffith$elm_ui$Internal$Style$classes.a1)) + ':active',
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'opacity', '0')
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot(
					_Utils_ap($mdgriffith$elm_ui$Internal$Style$classes.cj, $mdgriffith$elm_ui$Internal$Style$classes.aS)) + ':active',
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'opacity', '1')
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.d1),
				_List_fromArray(
					[
						A2(
						$mdgriffith$elm_ui$Internal$Style$Prop,
						'transition',
						A2(
							$elm$core$String$join,
							', ',
							A2(
								$elm$core$List$map,
								function (x) {
									return x + ' 160ms';
								},
								_List_fromArray(
									['transform', 'opacity', 'filter', 'background-color', 'color', 'font-size']))))
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.f2),
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'overflow', 'auto'),
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'flex-shrink', '1')
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.f3),
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'overflow-x', 'auto'),
						A2(
						$mdgriffith$elm_ui$Internal$Style$Descriptor,
						$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.ab),
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'flex-shrink', '1')
							]))
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.f4),
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'overflow-y', 'auto'),
						A2(
						$mdgriffith$elm_ui$Internal$Style$Descriptor,
						$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.aq),
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'flex-shrink', '1')
							])),
						A2(
						$mdgriffith$elm_ui$Internal$Style$Descriptor,
						$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.f8),
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'flex-shrink', '1')
							]))
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.eO),
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'overflow', 'hidden')
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.eP),
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'overflow-x', 'hidden')
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.eQ),
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'overflow-y', 'hidden')
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.cP),
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'width', 'auto')
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.bS),
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'border-width', '0')
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.eC),
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'border-style', 'dashed')
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.eD),
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'border-style', 'dotted')
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.eE),
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'border-style', 'solid')
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.bL),
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'white-space', 'pre'),
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'display', 'inline-block')
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.fo),
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'line-height', '1.05'),
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'background', 'transparent'),
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'text-align', 'inherit')
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.f8),
				$mdgriffith$elm_ui$Internal$Style$elDescription),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.ab),
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'display', 'flex'),
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'flex-direction', 'row'),
						A2(
						$mdgriffith$elm_ui$Internal$Style$Child,
						$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.er),
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'flex-basis', '0%'),
								A2(
								$mdgriffith$elm_ui$Internal$Style$Descriptor,
								$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.d8),
								_List_fromArray(
									[
										A2($mdgriffith$elm_ui$Internal$Style$Prop, 'flex-basis', 'auto')
									])),
								A2(
								$mdgriffith$elm_ui$Internal$Style$Descriptor,
								$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.ds),
								_List_fromArray(
									[
										A2($mdgriffith$elm_ui$Internal$Style$Prop, 'flex-basis', 'auto')
									]))
							])),
						A2(
						$mdgriffith$elm_ui$Internal$Style$Child,
						$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.cC),
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'align-self', 'stretch !important')
							])),
						A2(
						$mdgriffith$elm_ui$Internal$Style$Child,
						$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.dk),
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'align-self', 'stretch !important')
							])),
						A2(
						$mdgriffith$elm_ui$Internal$Style$Child,
						$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.cQ),
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'flex-grow', '100000')
							])),
						A2(
						$mdgriffith$elm_ui$Internal$Style$Child,
						$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.bX),
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'flex-grow', '0'),
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'flex-basis', 'auto'),
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'align-self', 'stretch')
							])),
						A2(
						$mdgriffith$elm_ui$Internal$Style$Child,
						'u:first-of-type.' + $mdgriffith$elm_ui$Internal$Style$classes.eo,
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'flex-grow', '1')
							])),
						A2(
						$mdgriffith$elm_ui$Internal$Style$Child,
						's:first-of-type.' + $mdgriffith$elm_ui$Internal$Style$classes.em,
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'flex-grow', '1'),
								A2(
								$mdgriffith$elm_ui$Internal$Style$Child,
								$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.ej),
								_List_fromArray(
									[
										A2($mdgriffith$elm_ui$Internal$Style$Prop, 'margin-left', 'auto !important')
									]))
							])),
						A2(
						$mdgriffith$elm_ui$Internal$Style$Child,
						's:last-of-type.' + $mdgriffith$elm_ui$Internal$Style$classes.em,
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'flex-grow', '1'),
								A2(
								$mdgriffith$elm_ui$Internal$Style$Child,
								$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.ej),
								_List_fromArray(
									[
										A2($mdgriffith$elm_ui$Internal$Style$Prop, 'margin-right', 'auto !important')
									]))
							])),
						A2(
						$mdgriffith$elm_ui$Internal$Style$Child,
						's:only-of-type.' + $mdgriffith$elm_ui$Internal$Style$classes.em,
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'flex-grow', '1'),
								A2(
								$mdgriffith$elm_ui$Internal$Style$Child,
								$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.ek),
								_List_fromArray(
									[
										A2($mdgriffith$elm_ui$Internal$Style$Prop, 'margin-top', 'auto !important'),
										A2($mdgriffith$elm_ui$Internal$Style$Prop, 'margin-bottom', 'auto !important')
									]))
							])),
						A2(
						$mdgriffith$elm_ui$Internal$Style$Child,
						's:last-of-type.' + ($mdgriffith$elm_ui$Internal$Style$classes.em + ' ~ u'),
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'flex-grow', '0')
							])),
						A2(
						$mdgriffith$elm_ui$Internal$Style$Child,
						'u:first-of-type.' + ($mdgriffith$elm_ui$Internal$Style$classes.eo + (' ~ s.' + $mdgriffith$elm_ui$Internal$Style$classes.em)),
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'flex-grow', '0')
							])),
						$mdgriffith$elm_ui$Internal$Style$describeAlignment(
						function (alignment) {
							switch (alignment) {
								case 0:
									return _Utils_Tuple2(
										_List_fromArray(
											[
												A2($mdgriffith$elm_ui$Internal$Style$Prop, 'align-items', 'flex-start')
											]),
										_List_fromArray(
											[
												A2($mdgriffith$elm_ui$Internal$Style$Prop, 'align-self', 'flex-start')
											]));
								case 1:
									return _Utils_Tuple2(
										_List_fromArray(
											[
												A2($mdgriffith$elm_ui$Internal$Style$Prop, 'align-items', 'flex-end')
											]),
										_List_fromArray(
											[
												A2($mdgriffith$elm_ui$Internal$Style$Prop, 'align-self', 'flex-end')
											]));
								case 2:
									return _Utils_Tuple2(
										_List_fromArray(
											[
												A2($mdgriffith$elm_ui$Internal$Style$Prop, 'justify-content', 'flex-end')
											]),
										_List_Nil);
								case 3:
									return _Utils_Tuple2(
										_List_fromArray(
											[
												A2($mdgriffith$elm_ui$Internal$Style$Prop, 'justify-content', 'flex-start')
											]),
										_List_Nil);
								case 4:
									return _Utils_Tuple2(
										_List_fromArray(
											[
												A2($mdgriffith$elm_ui$Internal$Style$Prop, 'justify-content', 'center')
											]),
										_List_Nil);
								default:
									return _Utils_Tuple2(
										_List_fromArray(
											[
												A2($mdgriffith$elm_ui$Internal$Style$Prop, 'align-items', 'center')
											]),
										_List_fromArray(
											[
												A2($mdgriffith$elm_ui$Internal$Style$Prop, 'align-self', 'center')
											]));
							}
						}),
						A2(
						$mdgriffith$elm_ui$Internal$Style$Descriptor,
						$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.ga),
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'justify-content', 'space-between')
							])),
						A2(
						$mdgriffith$elm_ui$Internal$Style$Descriptor,
						$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.b7),
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'align-items', 'baseline')
							]))
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.aq),
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'display', 'flex'),
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'flex-direction', 'column'),
						A2(
						$mdgriffith$elm_ui$Internal$Style$Child,
						$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.er),
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'flex-basis', '0px'),
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'min-height', 'min-content'),
								A2(
								$mdgriffith$elm_ui$Internal$Style$Descriptor,
								$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.dj),
								_List_fromArray(
									[
										A2($mdgriffith$elm_ui$Internal$Style$Prop, 'flex-basis', 'auto')
									]))
							])),
						A2(
						$mdgriffith$elm_ui$Internal$Style$Child,
						$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.cC),
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'flex-grow', '100000')
							])),
						A2(
						$mdgriffith$elm_ui$Internal$Style$Child,
						$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.cQ),
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'width', '100%')
							])),
						A2(
						$mdgriffith$elm_ui$Internal$Style$Child,
						$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.d9),
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'width', '100%')
							])),
						A2(
						$mdgriffith$elm_ui$Internal$Style$Child,
						$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.cP),
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'align-self', 'flex-start')
							])),
						A2(
						$mdgriffith$elm_ui$Internal$Style$Child,
						'u:first-of-type.' + $mdgriffith$elm_ui$Internal$Style$classes.el,
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'flex-grow', '1')
							])),
						A2(
						$mdgriffith$elm_ui$Internal$Style$Child,
						's:first-of-type.' + $mdgriffith$elm_ui$Internal$Style$classes.en,
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'flex-grow', '1'),
								A2(
								$mdgriffith$elm_ui$Internal$Style$Child,
								$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.ek),
								_List_fromArray(
									[
										A2($mdgriffith$elm_ui$Internal$Style$Prop, 'margin-top', 'auto !important'),
										A2($mdgriffith$elm_ui$Internal$Style$Prop, 'margin-bottom', '0 !important')
									]))
							])),
						A2(
						$mdgriffith$elm_ui$Internal$Style$Child,
						's:last-of-type.' + $mdgriffith$elm_ui$Internal$Style$classes.en,
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'flex-grow', '1'),
								A2(
								$mdgriffith$elm_ui$Internal$Style$Child,
								$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.ek),
								_List_fromArray(
									[
										A2($mdgriffith$elm_ui$Internal$Style$Prop, 'margin-bottom', 'auto !important'),
										A2($mdgriffith$elm_ui$Internal$Style$Prop, 'margin-top', '0 !important')
									]))
							])),
						A2(
						$mdgriffith$elm_ui$Internal$Style$Child,
						's:only-of-type.' + $mdgriffith$elm_ui$Internal$Style$classes.en,
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'flex-grow', '1'),
								A2(
								$mdgriffith$elm_ui$Internal$Style$Child,
								$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.ek),
								_List_fromArray(
									[
										A2($mdgriffith$elm_ui$Internal$Style$Prop, 'margin-top', 'auto !important'),
										A2($mdgriffith$elm_ui$Internal$Style$Prop, 'margin-bottom', 'auto !important')
									]))
							])),
						A2(
						$mdgriffith$elm_ui$Internal$Style$Child,
						's:last-of-type.' + ($mdgriffith$elm_ui$Internal$Style$classes.en + ' ~ u'),
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'flex-grow', '0')
							])),
						A2(
						$mdgriffith$elm_ui$Internal$Style$Child,
						'u:first-of-type.' + ($mdgriffith$elm_ui$Internal$Style$classes.el + (' ~ s.' + $mdgriffith$elm_ui$Internal$Style$classes.en)),
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'flex-grow', '0')
							])),
						$mdgriffith$elm_ui$Internal$Style$describeAlignment(
						function (alignment) {
							switch (alignment) {
								case 0:
									return _Utils_Tuple2(
										_List_fromArray(
											[
												A2($mdgriffith$elm_ui$Internal$Style$Prop, 'justify-content', 'flex-start')
											]),
										_List_fromArray(
											[
												A2($mdgriffith$elm_ui$Internal$Style$Prop, 'margin-bottom', 'auto')
											]));
								case 1:
									return _Utils_Tuple2(
										_List_fromArray(
											[
												A2($mdgriffith$elm_ui$Internal$Style$Prop, 'justify-content', 'flex-end')
											]),
										_List_fromArray(
											[
												A2($mdgriffith$elm_ui$Internal$Style$Prop, 'margin-top', 'auto')
											]));
								case 2:
									return _Utils_Tuple2(
										_List_fromArray(
											[
												A2($mdgriffith$elm_ui$Internal$Style$Prop, 'align-items', 'flex-end')
											]),
										_List_fromArray(
											[
												A2($mdgriffith$elm_ui$Internal$Style$Prop, 'align-self', 'flex-end')
											]));
								case 3:
									return _Utils_Tuple2(
										_List_fromArray(
											[
												A2($mdgriffith$elm_ui$Internal$Style$Prop, 'align-items', 'flex-start')
											]),
										_List_fromArray(
											[
												A2($mdgriffith$elm_ui$Internal$Style$Prop, 'align-self', 'flex-start')
											]));
								case 4:
									return _Utils_Tuple2(
										_List_fromArray(
											[
												A2($mdgriffith$elm_ui$Internal$Style$Prop, 'align-items', 'center')
											]),
										_List_fromArray(
											[
												A2($mdgriffith$elm_ui$Internal$Style$Prop, 'align-self', 'center')
											]));
								default:
									return _Utils_Tuple2(
										_List_fromArray(
											[
												A2($mdgriffith$elm_ui$Internal$Style$Prop, 'justify-content', 'center')
											]),
										_List_Nil);
							}
						}),
						A2(
						$mdgriffith$elm_ui$Internal$Style$Child,
						$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.bX),
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'flex-grow', '0'),
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'flex-basis', 'auto'),
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'width', '100%'),
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'align-self', 'stretch !important')
							])),
						A2(
						$mdgriffith$elm_ui$Internal$Style$Descriptor,
						$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.ga),
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'justify-content', 'space-between')
							]))
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.fa),
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'display', '-ms-grid'),
						A2(
						$mdgriffith$elm_ui$Internal$Style$Child,
						'.gp',
						_List_fromArray(
							[
								A2(
								$mdgriffith$elm_ui$Internal$Style$Child,
								$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.er),
								_List_fromArray(
									[
										A2($mdgriffith$elm_ui$Internal$Style$Prop, 'width', '100%')
									]))
							])),
						A2(
						$mdgriffith$elm_ui$Internal$Style$Supports,
						_Utils_Tuple2('display', 'grid'),
						_List_fromArray(
							[
								_Utils_Tuple2('display', 'grid')
							])),
						$mdgriffith$elm_ui$Internal$Style$gridAlignments(
						function (alignment) {
							switch (alignment) {
								case 0:
									return _List_fromArray(
										[
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'justify-content', 'flex-start')
										]);
								case 1:
									return _List_fromArray(
										[
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'justify-content', 'flex-end')
										]);
								case 2:
									return _List_fromArray(
										[
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'align-items', 'flex-end')
										]);
								case 3:
									return _List_fromArray(
										[
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'align-items', 'flex-start')
										]);
								case 4:
									return _List_fromArray(
										[
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'align-items', 'center')
										]);
								default:
									return _List_fromArray(
										[
											A2($mdgriffith$elm_ui$Internal$Style$Prop, 'justify-content', 'center')
										]);
							}
						})
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.dF),
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'display', 'block'),
						A2(
						$mdgriffith$elm_ui$Internal$Style$Child,
						$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.er + ':first-child'),
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'margin', '0 !important')
							])),
						A2(
						$mdgriffith$elm_ui$Internal$Style$Child,
						$mdgriffith$elm_ui$Internal$Style$dot(
							$mdgriffith$elm_ui$Internal$Style$classes.er + ($mdgriffith$elm_ui$Internal$Style$selfName(3) + (':first-child + .' + $mdgriffith$elm_ui$Internal$Style$classes.er))),
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'margin', '0 !important')
							])),
						A2(
						$mdgriffith$elm_ui$Internal$Style$Child,
						$mdgriffith$elm_ui$Internal$Style$dot(
							$mdgriffith$elm_ui$Internal$Style$classes.er + ($mdgriffith$elm_ui$Internal$Style$selfName(2) + (':first-child + .' + $mdgriffith$elm_ui$Internal$Style$classes.er))),
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'margin', '0 !important')
							])),
						$mdgriffith$elm_ui$Internal$Style$describeAlignment(
						function (alignment) {
							switch (alignment) {
								case 0:
									return _Utils_Tuple2(_List_Nil, _List_Nil);
								case 1:
									return _Utils_Tuple2(_List_Nil, _List_Nil);
								case 2:
									return _Utils_Tuple2(
										_List_Nil,
										_List_fromArray(
											[
												A2($mdgriffith$elm_ui$Internal$Style$Prop, 'float', 'right'),
												A2(
												$mdgriffith$elm_ui$Internal$Style$Descriptor,
												'::after',
												_List_fromArray(
													[
														A2($mdgriffith$elm_ui$Internal$Style$Prop, 'content', '\"\"'),
														A2($mdgriffith$elm_ui$Internal$Style$Prop, 'display', 'table'),
														A2($mdgriffith$elm_ui$Internal$Style$Prop, 'clear', 'both')
													]))
											]));
								case 3:
									return _Utils_Tuple2(
										_List_Nil,
										_List_fromArray(
											[
												A2($mdgriffith$elm_ui$Internal$Style$Prop, 'float', 'left'),
												A2(
												$mdgriffith$elm_ui$Internal$Style$Descriptor,
												'::after',
												_List_fromArray(
													[
														A2($mdgriffith$elm_ui$Internal$Style$Prop, 'content', '\"\"'),
														A2($mdgriffith$elm_ui$Internal$Style$Prop, 'display', 'table'),
														A2($mdgriffith$elm_ui$Internal$Style$Prop, 'clear', 'both')
													]))
											]));
								case 4:
									return _Utils_Tuple2(_List_Nil, _List_Nil);
								default:
									return _Utils_Tuple2(_List_Nil, _List_Nil);
							}
						})
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.fk),
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'white-space', 'pre-wrap !important'),
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'height', '100%'),
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'width', '100%'),
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'background-color', 'transparent')
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.fn),
				_List_fromArray(
					[
						A2(
						$mdgriffith$elm_ui$Internal$Style$Descriptor,
						$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.f8),
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'flex-basis', 'auto')
							]))
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.fm),
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'white-space', 'pre-wrap !important'),
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'cursor', 'text'),
						A2(
						$mdgriffith$elm_ui$Internal$Style$Child,
						$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.fl),
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'white-space', 'pre-wrap !important'),
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'color', 'transparent')
							]))
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.dG),
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'display', 'block'),
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'white-space', 'normal'),
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'overflow-wrap', 'break-word'),
						A2(
						$mdgriffith$elm_ui$Internal$Style$Descriptor,
						$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.cA),
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'z-index', '0'),
								A2(
								$mdgriffith$elm_ui$Internal$Style$Child,
								$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.ex),
								_List_fromArray(
									[
										A2($mdgriffith$elm_ui$Internal$Style$Prop, 'z-index', '-1')
									]))
							])),
						A2(
						$mdgriffith$elm_ui$Internal$Style$AllChildren,
						$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.bL),
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'display', 'inline'),
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'white-space', 'normal')
							])),
						A2(
						$mdgriffith$elm_ui$Internal$Style$AllChildren,
						$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.dG),
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'display', 'inline'),
								A2(
								$mdgriffith$elm_ui$Internal$Style$Descriptor,
								'::after',
								_List_fromArray(
									[
										A2($mdgriffith$elm_ui$Internal$Style$Prop, 'content', 'none')
									])),
								A2(
								$mdgriffith$elm_ui$Internal$Style$Descriptor,
								'::before',
								_List_fromArray(
									[
										A2($mdgriffith$elm_ui$Internal$Style$Prop, 'content', 'none')
									]))
							])),
						A2(
						$mdgriffith$elm_ui$Internal$Style$AllChildren,
						$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.f8),
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'display', 'inline'),
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'white-space', 'normal'),
								A2(
								$mdgriffith$elm_ui$Internal$Style$Descriptor,
								$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.d8),
								_List_fromArray(
									[
										A2($mdgriffith$elm_ui$Internal$Style$Prop, 'display', 'inline-block')
									])),
								A2(
								$mdgriffith$elm_ui$Internal$Style$Descriptor,
								$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.fh),
								_List_fromArray(
									[
										A2($mdgriffith$elm_ui$Internal$Style$Prop, 'display', 'flex')
									])),
								A2(
								$mdgriffith$elm_ui$Internal$Style$Descriptor,
								$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.ex),
								_List_fromArray(
									[
										A2($mdgriffith$elm_ui$Internal$Style$Prop, 'display', 'flex')
									])),
								A2(
								$mdgriffith$elm_ui$Internal$Style$Descriptor,
								$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.ed),
								_List_fromArray(
									[
										A2($mdgriffith$elm_ui$Internal$Style$Prop, 'display', 'flex')
									])),
								A2(
								$mdgriffith$elm_ui$Internal$Style$Descriptor,
								$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.ey),
								_List_fromArray(
									[
										A2($mdgriffith$elm_ui$Internal$Style$Prop, 'display', 'flex')
									])),
								A2(
								$mdgriffith$elm_ui$Internal$Style$Descriptor,
								$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.fM),
								_List_fromArray(
									[
										A2($mdgriffith$elm_ui$Internal$Style$Prop, 'display', 'flex')
									])),
								A2(
								$mdgriffith$elm_ui$Internal$Style$Descriptor,
								$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.fK),
								_List_fromArray(
									[
										A2($mdgriffith$elm_ui$Internal$Style$Prop, 'display', 'flex')
									])),
								A2(
								$mdgriffith$elm_ui$Internal$Style$Child,
								$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.bL),
								_List_fromArray(
									[
										A2($mdgriffith$elm_ui$Internal$Style$Prop, 'display', 'inline'),
										A2($mdgriffith$elm_ui$Internal$Style$Prop, 'white-space', 'normal')
									]))
							])),
						A2(
						$mdgriffith$elm_ui$Internal$Style$Child,
						$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.ab),
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'display', 'inline')
							])),
						A2(
						$mdgriffith$elm_ui$Internal$Style$Child,
						$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.aq),
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'display', 'inline-flex')
							])),
						A2(
						$mdgriffith$elm_ui$Internal$Style$Child,
						$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.fa),
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Style$Prop, 'display', 'inline-grid')
							])),
						$mdgriffith$elm_ui$Internal$Style$describeAlignment(
						function (alignment) {
							switch (alignment) {
								case 0:
									return _Utils_Tuple2(_List_Nil, _List_Nil);
								case 1:
									return _Utils_Tuple2(_List_Nil, _List_Nil);
								case 2:
									return _Utils_Tuple2(
										_List_Nil,
										_List_fromArray(
											[
												A2($mdgriffith$elm_ui$Internal$Style$Prop, 'float', 'right')
											]));
								case 3:
									return _Utils_Tuple2(
										_List_Nil,
										_List_fromArray(
											[
												A2($mdgriffith$elm_ui$Internal$Style$Prop, 'float', 'left')
											]));
								case 4:
									return _Utils_Tuple2(_List_Nil, _List_Nil);
								default:
									return _Utils_Tuple2(_List_Nil, _List_Nil);
							}
						})
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				'.hidden',
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'display', 'none')
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.gx),
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'font-weight', '100')
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.go),
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'font-weight', '200')
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.gs),
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'font-weight', '300')
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.gu),
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'font-weight', '400')
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.gt),
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'font-weight', '500')
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.gw),
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'font-weight', '600')
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.eA),
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'font-weight', '700')
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.gn),
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'font-weight', '800')
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.gp),
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'font-weight', '900')
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.fp),
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'font-style', 'italic')
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.gg),
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'text-decoration', 'line-through')
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.gF),
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'text-decoration', 'underline'),
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'text-decoration-skip-ink', 'auto'),
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'text-decoration-skip', 'ink')
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				_Utils_ap(
					$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.gF),
					$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.gg)),
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'text-decoration', 'line-through underline'),
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'text-decoration-skip-ink', 'auto'),
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'text-decoration-skip', 'ink')
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.gy),
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'font-style', 'normal')
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.gq),
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'text-align', 'justify')
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.ch),
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'text-align', 'justify-all')
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.gm),
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'text-align', 'center')
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.gv),
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'text-align', 'right')
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				$mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.gr),
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'text-align', 'left')
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Descriptor,
				'.modal',
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'position', 'fixed'),
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'left', '0'),
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'top', '0'),
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'width', '100%'),
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'height', '100%'),
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'pointer-events', 'none')
					]))
			]))
	]);
var $mdgriffith$elm_ui$Internal$Style$fontVariant = function (_var) {
	return _List_fromArray(
		[
			A2(
			$mdgriffith$elm_ui$Internal$Style$Class,
			'.v-' + _var,
			_List_fromArray(
				[
					A2($mdgriffith$elm_ui$Internal$Style$Prop, 'font-feature-settings', '\"' + (_var + '\"'))
				])),
			A2(
			$mdgriffith$elm_ui$Internal$Style$Class,
			'.v-' + (_var + '-off'),
			_List_fromArray(
				[
					A2($mdgriffith$elm_ui$Internal$Style$Prop, 'font-feature-settings', '\"' + (_var + '\" 0'))
				]))
		]);
};
var $mdgriffith$elm_ui$Internal$Style$commonValues = $elm$core$List$concat(
	_List_fromArray(
		[
			A2(
			$elm$core$List$map,
			function (x) {
				return A2(
					$mdgriffith$elm_ui$Internal$Style$Class,
					'.border-' + $elm$core$String$fromInt(x),
					_List_fromArray(
						[
							A2(
							$mdgriffith$elm_ui$Internal$Style$Prop,
							'border-width',
							$elm$core$String$fromInt(x) + 'px')
						]));
			},
			A2($elm$core$List$range, 0, 6)),
			A2(
			$elm$core$List$map,
			function (i) {
				return A2(
					$mdgriffith$elm_ui$Internal$Style$Class,
					'.font-size-' + $elm$core$String$fromInt(i),
					_List_fromArray(
						[
							A2(
							$mdgriffith$elm_ui$Internal$Style$Prop,
							'font-size',
							$elm$core$String$fromInt(i) + 'px')
						]));
			},
			A2($elm$core$List$range, 8, 32)),
			A2(
			$elm$core$List$map,
			function (i) {
				return A2(
					$mdgriffith$elm_ui$Internal$Style$Class,
					'.p-' + $elm$core$String$fromInt(i),
					_List_fromArray(
						[
							A2(
							$mdgriffith$elm_ui$Internal$Style$Prop,
							'padding',
							$elm$core$String$fromInt(i) + 'px')
						]));
			},
			A2($elm$core$List$range, 0, 24)),
			_List_fromArray(
			[
				A2(
				$mdgriffith$elm_ui$Internal$Style$Class,
				'.v-smcp',
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'font-variant', 'small-caps')
					])),
				A2(
				$mdgriffith$elm_ui$Internal$Style$Class,
				'.v-smcp-off',
				_List_fromArray(
					[
						A2($mdgriffith$elm_ui$Internal$Style$Prop, 'font-variant', 'normal')
					]))
			]),
			$mdgriffith$elm_ui$Internal$Style$fontVariant('zero'),
			$mdgriffith$elm_ui$Internal$Style$fontVariant('onum'),
			$mdgriffith$elm_ui$Internal$Style$fontVariant('liga'),
			$mdgriffith$elm_ui$Internal$Style$fontVariant('dlig'),
			$mdgriffith$elm_ui$Internal$Style$fontVariant('ordn'),
			$mdgriffith$elm_ui$Internal$Style$fontVariant('tnum'),
			$mdgriffith$elm_ui$Internal$Style$fontVariant('afrc'),
			$mdgriffith$elm_ui$Internal$Style$fontVariant('frac')
		]));
var $mdgriffith$elm_ui$Internal$Style$explainer = '\n.explain {\n    border: 6px solid rgb(174, 121, 15) !important;\n}\n.explain > .' + ($mdgriffith$elm_ui$Internal$Style$classes.er + (' {\n    border: 4px dashed rgb(0, 151, 167) !important;\n}\n\n.ctr {\n    border: none !important;\n}\n.explain > .ctr > .' + ($mdgriffith$elm_ui$Internal$Style$classes.er + ' {\n    border: 4px dashed rgb(0, 151, 167) !important;\n}\n\n')));
var $mdgriffith$elm_ui$Internal$Style$inputTextReset = '\ninput[type="search"],\ninput[type="search"]::-webkit-search-decoration,\ninput[type="search"]::-webkit-search-cancel-button,\ninput[type="search"]::-webkit-search-results-button,\ninput[type="search"]::-webkit-search-results-decoration {\n  -webkit-appearance:none;\n}\n';
var $mdgriffith$elm_ui$Internal$Style$sliderReset = '\ninput[type=range] {\n  -webkit-appearance: none; \n  background: transparent;\n  position:absolute;\n  left:0;\n  top:0;\n  z-index:10;\n  width: 100%;\n  outline: dashed 1px;\n  height: 100%;\n  opacity: 0;\n}\n';
var $mdgriffith$elm_ui$Internal$Style$thumbReset = '\ninput[type=range]::-webkit-slider-thumb {\n    -webkit-appearance: none;\n    opacity: 0.5;\n    width: 80px;\n    height: 80px;\n    background-color: black;\n    border:none;\n    border-radius: 5px;\n}\ninput[type=range]::-moz-range-thumb {\n    opacity: 0.5;\n    width: 80px;\n    height: 80px;\n    background-color: black;\n    border:none;\n    border-radius: 5px;\n}\ninput[type=range]::-ms-thumb {\n    opacity: 0.5;\n    width: 80px;\n    height: 80px;\n    background-color: black;\n    border:none;\n    border-radius: 5px;\n}\ninput[type=range][orient=vertical]{\n    writing-mode: bt-lr; /* IE */\n    -webkit-appearance: slider-vertical;  /* WebKit */\n}\n';
var $mdgriffith$elm_ui$Internal$Style$trackReset = '\ninput[type=range]::-moz-range-track {\n    background: transparent;\n    cursor: pointer;\n}\ninput[type=range]::-ms-track {\n    background: transparent;\n    cursor: pointer;\n}\ninput[type=range]::-webkit-slider-runnable-track {\n    background: transparent;\n    cursor: pointer;\n}\n';
var $mdgriffith$elm_ui$Internal$Style$overrides = '@media screen and (-ms-high-contrast: active), (-ms-high-contrast: none) {' + ($mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.er) + ($mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.ab) + (' > ' + ($mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.er) + (' { flex-basis: auto !important; } ' + ($mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.er) + ($mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.ab) + (' > ' + ($mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.er) + ($mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.bX) + (' { flex-basis: auto !important; }}' + ($mdgriffith$elm_ui$Internal$Style$inputTextReset + ($mdgriffith$elm_ui$Internal$Style$sliderReset + ($mdgriffith$elm_ui$Internal$Style$trackReset + ($mdgriffith$elm_ui$Internal$Style$thumbReset + $mdgriffith$elm_ui$Internal$Style$explainer)))))))))))))));
var $elm$core$String$concat = function (strings) {
	return A2($elm$core$String$join, '', strings);
};
var $mdgriffith$elm_ui$Internal$Style$Intermediate = $elm$core$Basics$identity;
var $mdgriffith$elm_ui$Internal$Style$emptyIntermediate = F2(
	function (selector, closing) {
		return {bW: closing, w: _List_Nil, ax: _List_Nil, ac: selector};
	});
var $mdgriffith$elm_ui$Internal$Style$renderRules = F2(
	function (_v0, rulesToRender) {
		var parent = _v0;
		var generateIntermediates = F2(
			function (rule, rendered) {
				switch (rule.$) {
					case 0:
						var name = rule.a;
						var val = rule.b;
						return _Utils_update(
							rendered,
							{
								ax: A2(
									$elm$core$List$cons,
									_Utils_Tuple2(name, val),
									rendered.ax)
							});
					case 3:
						var _v2 = rule.a;
						var prop = _v2.a;
						var value = _v2.b;
						var props = rule.b;
						return _Utils_update(
							rendered,
							{
								w: A2(
									$elm$core$List$cons,
									{bW: '\n}', w: _List_Nil, ax: props, ac: '@supports (' + (prop + (':' + (value + (') {' + parent.ac))))},
									rendered.w)
							});
					case 5:
						var selector = rule.a;
						var adjRules = rule.b;
						return _Utils_update(
							rendered,
							{
								w: A2(
									$elm$core$List$cons,
									A2(
										$mdgriffith$elm_ui$Internal$Style$renderRules,
										A2($mdgriffith$elm_ui$Internal$Style$emptyIntermediate, parent.ac + (' + ' + selector), ''),
										adjRules),
									rendered.w)
							});
					case 1:
						var child = rule.a;
						var childRules = rule.b;
						return _Utils_update(
							rendered,
							{
								w: A2(
									$elm$core$List$cons,
									A2(
										$mdgriffith$elm_ui$Internal$Style$renderRules,
										A2($mdgriffith$elm_ui$Internal$Style$emptyIntermediate, parent.ac + (' > ' + child), ''),
										childRules),
									rendered.w)
							});
					case 2:
						var child = rule.a;
						var childRules = rule.b;
						return _Utils_update(
							rendered,
							{
								w: A2(
									$elm$core$List$cons,
									A2(
										$mdgriffith$elm_ui$Internal$Style$renderRules,
										A2($mdgriffith$elm_ui$Internal$Style$emptyIntermediate, parent.ac + (' ' + child), ''),
										childRules),
									rendered.w)
							});
					case 4:
						var descriptor = rule.a;
						var descriptorRules = rule.b;
						return _Utils_update(
							rendered,
							{
								w: A2(
									$elm$core$List$cons,
									A2(
										$mdgriffith$elm_ui$Internal$Style$renderRules,
										A2(
											$mdgriffith$elm_ui$Internal$Style$emptyIntermediate,
											_Utils_ap(parent.ac, descriptor),
											''),
										descriptorRules),
									rendered.w)
							});
					default:
						var batched = rule.a;
						return _Utils_update(
							rendered,
							{
								w: A2(
									$elm$core$List$cons,
									A2(
										$mdgriffith$elm_ui$Internal$Style$renderRules,
										A2($mdgriffith$elm_ui$Internal$Style$emptyIntermediate, parent.ac, ''),
										batched),
									rendered.w)
							});
				}
			});
		return A3($elm$core$List$foldr, generateIntermediates, parent, rulesToRender);
	});
var $mdgriffith$elm_ui$Internal$Style$renderCompact = function (styleClasses) {
	var renderValues = function (values) {
		return $elm$core$String$concat(
			A2(
				$elm$core$List$map,
				function (_v3) {
					var x = _v3.a;
					var y = _v3.b;
					return x + (':' + (y + ';'));
				},
				values));
	};
	var renderClass = function (rule) {
		var _v2 = rule.ax;
		if (!_v2.b) {
			return '';
		} else {
			return rule.ac + ('{' + (renderValues(rule.ax) + (rule.bW + '}')));
		}
	};
	var renderIntermediate = function (_v0) {
		var rule = _v0;
		return _Utils_ap(
			renderClass(rule),
			$elm$core$String$concat(
				A2($elm$core$List$map, renderIntermediate, rule.w)));
	};
	return $elm$core$String$concat(
		A2(
			$elm$core$List$map,
			renderIntermediate,
			A3(
				$elm$core$List$foldr,
				F2(
					function (_v1, existing) {
						var name = _v1.a;
						var styleRules = _v1.b;
						return A2(
							$elm$core$List$cons,
							A2(
								$mdgriffith$elm_ui$Internal$Style$renderRules,
								A2($mdgriffith$elm_ui$Internal$Style$emptyIntermediate, name, ''),
								styleRules),
							existing);
					}),
				_List_Nil,
				styleClasses)));
};
var $mdgriffith$elm_ui$Internal$Style$rules = _Utils_ap(
	$mdgriffith$elm_ui$Internal$Style$overrides,
	$mdgriffith$elm_ui$Internal$Style$renderCompact(
		_Utils_ap($mdgriffith$elm_ui$Internal$Style$baseSheet, $mdgriffith$elm_ui$Internal$Style$commonValues)));
var $elm$virtual_dom$VirtualDom$text = _VirtualDom_text;
var $mdgriffith$elm_ui$Internal$Model$staticRoot = function (opts) {
	var _v0 = opts.fA;
	switch (_v0) {
		case 0:
			return A3(
				$elm$virtual_dom$VirtualDom$node,
				'div',
				_List_Nil,
				_List_fromArray(
					[
						A3(
						$elm$virtual_dom$VirtualDom$node,
						'style',
						_List_Nil,
						_List_fromArray(
							[
								$elm$virtual_dom$VirtualDom$text($mdgriffith$elm_ui$Internal$Style$rules)
							]))
					]));
		case 1:
			return $elm$virtual_dom$VirtualDom$text('');
		default:
			return A3(
				$elm$virtual_dom$VirtualDom$node,
				'elm-ui-static-rules',
				_List_fromArray(
					[
						A2(
						$elm$virtual_dom$VirtualDom$property,
						'rules',
						$elm$json$Json$Encode$string($mdgriffith$elm_ui$Internal$Style$rules))
					]),
				_List_Nil);
	}
};
var $mdgriffith$elm_ui$Internal$Model$fontName = function (font) {
	switch (font.$) {
		case 0:
			return 'serif';
		case 1:
			return 'sans-serif';
		case 2:
			return 'monospace';
		case 3:
			var name = font.a;
			return '\"' + (name + '\"');
		case 4:
			var name = font.a;
			var url = font.b;
			return '\"' + (name + '\"');
		default:
			var name = font.a.fB;
			return '\"' + (name + '\"');
	}
};
var $mdgriffith$elm_ui$Internal$Model$isSmallCaps = function (_var) {
	switch (_var.$) {
		case 0:
			var name = _var.a;
			return name === 'smcp';
		case 1:
			var name = _var.a;
			return false;
		default:
			var name = _var.a;
			var index = _var.b;
			return (name === 'smcp') && (index === 1);
	}
};
var $mdgriffith$elm_ui$Internal$Model$hasSmallCaps = function (typeface) {
	if (typeface.$ === 5) {
		var font = typeface.a;
		return A2($elm$core$List$any, $mdgriffith$elm_ui$Internal$Model$isSmallCaps, font.d2);
	} else {
		return false;
	}
};
var $elm$core$Basics$min = F2(
	function (x, y) {
		return (_Utils_cmp(x, y) < 0) ? x : y;
	});
var $mdgriffith$elm_ui$Internal$Model$renderProps = F3(
	function (force, _v0, existing) {
		var key = _v0.a;
		var val = _v0.b;
		return force ? (existing + ('\n  ' + (key + (': ' + (val + ' !important;'))))) : (existing + ('\n  ' + (key + (': ' + (val + ';')))));
	});
var $mdgriffith$elm_ui$Internal$Model$renderStyle = F4(
	function (options, maybePseudo, selector, props) {
		if (maybePseudo.$ === 1) {
			return _List_fromArray(
				[
					selector + ('{' + (A3(
					$elm$core$List$foldl,
					$mdgriffith$elm_ui$Internal$Model$renderProps(false),
					'',
					props) + '\n}'))
				]);
		} else {
			var pseudo = maybePseudo.a;
			switch (pseudo) {
				case 1:
					var _v2 = options.fc;
					switch (_v2) {
						case 0:
							return _List_Nil;
						case 2:
							return _List_fromArray(
								[
									selector + ('-hv {' + (A3(
									$elm$core$List$foldl,
									$mdgriffith$elm_ui$Internal$Model$renderProps(true),
									'',
									props) + '\n}'))
								]);
						default:
							return _List_fromArray(
								[
									selector + ('-hv:hover {' + (A3(
									$elm$core$List$foldl,
									$mdgriffith$elm_ui$Internal$Model$renderProps(false),
									'',
									props) + '\n}'))
								]);
					}
				case 0:
					var renderedProps = A3(
						$elm$core$List$foldl,
						$mdgriffith$elm_ui$Internal$Model$renderProps(false),
						'',
						props);
					return _List_fromArray(
						[
							selector + ('-fs:focus {' + (renderedProps + '\n}')),
							('.' + ($mdgriffith$elm_ui$Internal$Style$classes.er + (':focus ' + (selector + '-fs  {')))) + (renderedProps + '\n}'),
							(selector + '-fs:focus-within {') + (renderedProps + '\n}'),
							('.ui-slide-bar:focus + ' + ($mdgriffith$elm_ui$Internal$Style$dot($mdgriffith$elm_ui$Internal$Style$classes.er) + (' .focusable-thumb' + (selector + '-fs {')))) + (renderedProps + '\n}')
						]);
				default:
					return _List_fromArray(
						[
							selector + ('-act:active {' + (A3(
							$elm$core$List$foldl,
							$mdgriffith$elm_ui$Internal$Model$renderProps(false),
							'',
							props) + '\n}'))
						]);
			}
		}
	});
var $mdgriffith$elm_ui$Internal$Model$renderVariant = function (_var) {
	switch (_var.$) {
		case 0:
			var name = _var.a;
			return '\"' + (name + '\"');
		case 1:
			var name = _var.a;
			return '\"' + (name + '\" 0');
		default:
			var name = _var.a;
			var index = _var.b;
			return '\"' + (name + ('\" ' + $elm$core$String$fromInt(index)));
	}
};
var $mdgriffith$elm_ui$Internal$Model$renderVariants = function (typeface) {
	if (typeface.$ === 5) {
		var font = typeface.a;
		return $elm$core$Maybe$Just(
			A2(
				$elm$core$String$join,
				', ',
				A2($elm$core$List$map, $mdgriffith$elm_ui$Internal$Model$renderVariant, font.d2)));
	} else {
		return $elm$core$Maybe$Nothing;
	}
};
var $mdgriffith$elm_ui$Internal$Model$transformValue = function (transform) {
	switch (transform.$) {
		case 0:
			return $elm$core$Maybe$Nothing;
		case 1:
			var _v1 = transform.a;
			var x = _v1.a;
			var y = _v1.b;
			var z = _v1.c;
			return $elm$core$Maybe$Just(
				'translate3d(' + ($elm$core$String$fromFloat(x) + ('px, ' + ($elm$core$String$fromFloat(y) + ('px, ' + ($elm$core$String$fromFloat(z) + 'px)'))))));
		default:
			var _v2 = transform.a;
			var tx = _v2.a;
			var ty = _v2.b;
			var tz = _v2.c;
			var _v3 = transform.b;
			var sx = _v3.a;
			var sy = _v3.b;
			var sz = _v3.c;
			var _v4 = transform.c;
			var ox = _v4.a;
			var oy = _v4.b;
			var oz = _v4.c;
			var angle = transform.d;
			var translate = 'translate3d(' + ($elm$core$String$fromFloat(tx) + ('px, ' + ($elm$core$String$fromFloat(ty) + ('px, ' + ($elm$core$String$fromFloat(tz) + 'px)')))));
			var scale = 'scale3d(' + ($elm$core$String$fromFloat(sx) + (', ' + ($elm$core$String$fromFloat(sy) + (', ' + ($elm$core$String$fromFloat(sz) + ')')))));
			var rotate = 'rotate3d(' + ($elm$core$String$fromFloat(ox) + (', ' + ($elm$core$String$fromFloat(oy) + (', ' + ($elm$core$String$fromFloat(oz) + (', ' + ($elm$core$String$fromFloat(angle) + 'rad)')))))));
			return $elm$core$Maybe$Just(translate + (' ' + (scale + (' ' + rotate))));
	}
};
var $mdgriffith$elm_ui$Internal$Model$renderStyleRule = F3(
	function (options, rule, maybePseudo) {
		switch (rule.$) {
			case 0:
				var selector = rule.a;
				var props = rule.b;
				return A4($mdgriffith$elm_ui$Internal$Model$renderStyle, options, maybePseudo, selector, props);
			case 13:
				var name = rule.a;
				var prop = rule.b;
				return A4(
					$mdgriffith$elm_ui$Internal$Model$renderStyle,
					options,
					maybePseudo,
					'.' + name,
					_List_fromArray(
						[
							A2($mdgriffith$elm_ui$Internal$Model$Property, 'box-shadow', prop)
						]));
			case 12:
				var name = rule.a;
				var transparency = rule.b;
				var opacity = A2(
					$elm$core$Basics$max,
					0,
					A2($elm$core$Basics$min, 1, 1 - transparency));
				return A4(
					$mdgriffith$elm_ui$Internal$Model$renderStyle,
					options,
					maybePseudo,
					'.' + name,
					_List_fromArray(
						[
							A2(
							$mdgriffith$elm_ui$Internal$Model$Property,
							'opacity',
							$elm$core$String$fromFloat(opacity))
						]));
			case 2:
				var i = rule.a;
				return A4(
					$mdgriffith$elm_ui$Internal$Model$renderStyle,
					options,
					maybePseudo,
					'.font-size-' + $elm$core$String$fromInt(i),
					_List_fromArray(
						[
							A2(
							$mdgriffith$elm_ui$Internal$Model$Property,
							'font-size',
							$elm$core$String$fromInt(i) + 'px')
						]));
			case 1:
				var name = rule.a;
				var typefaces = rule.b;
				var features = A2(
					$elm$core$String$join,
					', ',
					A2($elm$core$List$filterMap, $mdgriffith$elm_ui$Internal$Model$renderVariants, typefaces));
				var families = _List_fromArray(
					[
						A2(
						$mdgriffith$elm_ui$Internal$Model$Property,
						'font-family',
						A2(
							$elm$core$String$join,
							', ',
							A2($elm$core$List$map, $mdgriffith$elm_ui$Internal$Model$fontName, typefaces))),
						A2($mdgriffith$elm_ui$Internal$Model$Property, 'font-feature-settings', features),
						A2(
						$mdgriffith$elm_ui$Internal$Model$Property,
						'font-variant',
						A2($elm$core$List$any, $mdgriffith$elm_ui$Internal$Model$hasSmallCaps, typefaces) ? 'small-caps' : 'normal')
					]);
				return A4($mdgriffith$elm_ui$Internal$Model$renderStyle, options, maybePseudo, '.' + name, families);
			case 3:
				var _class = rule.a;
				var prop = rule.b;
				var val = rule.c;
				return A4(
					$mdgriffith$elm_ui$Internal$Model$renderStyle,
					options,
					maybePseudo,
					'.' + _class,
					_List_fromArray(
						[
							A2($mdgriffith$elm_ui$Internal$Model$Property, prop, val)
						]));
			case 4:
				var _class = rule.a;
				var prop = rule.b;
				var color = rule.c;
				return A4(
					$mdgriffith$elm_ui$Internal$Model$renderStyle,
					options,
					maybePseudo,
					'.' + _class,
					_List_fromArray(
						[
							A2(
							$mdgriffith$elm_ui$Internal$Model$Property,
							prop,
							$mdgriffith$elm_ui$Internal$Model$formatColor(color))
						]));
			case 5:
				var cls = rule.a;
				var x = rule.b;
				var y = rule.c;
				var yPx = $elm$core$String$fromInt(y) + 'px';
				var xPx = $elm$core$String$fromInt(x) + 'px';
				var single = '.' + $mdgriffith$elm_ui$Internal$Style$classes.f8;
				var row = '.' + $mdgriffith$elm_ui$Internal$Style$classes.ab;
				var wrappedRow = '.' + ($mdgriffith$elm_ui$Internal$Style$classes.cR + row);
				var right = '.' + $mdgriffith$elm_ui$Internal$Style$classes.cY;
				var paragraph = '.' + $mdgriffith$elm_ui$Internal$Style$classes.dG;
				var page = '.' + $mdgriffith$elm_ui$Internal$Style$classes.dF;
				var left = '.' + $mdgriffith$elm_ui$Internal$Style$classes.cX;
				var halfY = $elm$core$String$fromFloat(y / 2) + 'px';
				var halfX = $elm$core$String$fromFloat(x / 2) + 'px';
				var column = '.' + $mdgriffith$elm_ui$Internal$Style$classes.aq;
				var _class = '.' + cls;
				var any = '.' + $mdgriffith$elm_ui$Internal$Style$classes.er;
				return $elm$core$List$concat(
					_List_fromArray(
						[
							A4(
							$mdgriffith$elm_ui$Internal$Model$renderStyle,
							options,
							maybePseudo,
							_class + (row + (' > ' + (any + (' + ' + any)))),
							_List_fromArray(
								[
									A2($mdgriffith$elm_ui$Internal$Model$Property, 'margin-left', xPx)
								])),
							A4(
							$mdgriffith$elm_ui$Internal$Model$renderStyle,
							options,
							maybePseudo,
							_class + (wrappedRow + (' > ' + any)),
							_List_fromArray(
								[
									A2($mdgriffith$elm_ui$Internal$Model$Property, 'margin', halfY + (' ' + halfX))
								])),
							A4(
							$mdgriffith$elm_ui$Internal$Model$renderStyle,
							options,
							maybePseudo,
							_class + (column + (' > ' + (any + (' + ' + any)))),
							_List_fromArray(
								[
									A2($mdgriffith$elm_ui$Internal$Model$Property, 'margin-top', yPx)
								])),
							A4(
							$mdgriffith$elm_ui$Internal$Model$renderStyle,
							options,
							maybePseudo,
							_class + (page + (' > ' + (any + (' + ' + any)))),
							_List_fromArray(
								[
									A2($mdgriffith$elm_ui$Internal$Model$Property, 'margin-top', yPx)
								])),
							A4(
							$mdgriffith$elm_ui$Internal$Model$renderStyle,
							options,
							maybePseudo,
							_class + (page + (' > ' + left)),
							_List_fromArray(
								[
									A2($mdgriffith$elm_ui$Internal$Model$Property, 'margin-right', xPx)
								])),
							A4(
							$mdgriffith$elm_ui$Internal$Model$renderStyle,
							options,
							maybePseudo,
							_class + (page + (' > ' + right)),
							_List_fromArray(
								[
									A2($mdgriffith$elm_ui$Internal$Model$Property, 'margin-left', xPx)
								])),
							A4(
							$mdgriffith$elm_ui$Internal$Model$renderStyle,
							options,
							maybePseudo,
							_Utils_ap(_class, paragraph),
							_List_fromArray(
								[
									A2(
									$mdgriffith$elm_ui$Internal$Model$Property,
									'line-height',
									'calc(1em + ' + ($elm$core$String$fromInt(y) + 'px)'))
								])),
							A4(
							$mdgriffith$elm_ui$Internal$Model$renderStyle,
							options,
							maybePseudo,
							'textarea' + (any + _class),
							_List_fromArray(
								[
									A2(
									$mdgriffith$elm_ui$Internal$Model$Property,
									'line-height',
									'calc(1em + ' + ($elm$core$String$fromInt(y) + 'px)')),
									A2(
									$mdgriffith$elm_ui$Internal$Model$Property,
									'height',
									'calc(100% + ' + ($elm$core$String$fromInt(y) + 'px)'))
								])),
							A4(
							$mdgriffith$elm_ui$Internal$Model$renderStyle,
							options,
							maybePseudo,
							_class + (paragraph + (' > ' + left)),
							_List_fromArray(
								[
									A2($mdgriffith$elm_ui$Internal$Model$Property, 'margin-right', xPx)
								])),
							A4(
							$mdgriffith$elm_ui$Internal$Model$renderStyle,
							options,
							maybePseudo,
							_class + (paragraph + (' > ' + right)),
							_List_fromArray(
								[
									A2($mdgriffith$elm_ui$Internal$Model$Property, 'margin-left', xPx)
								])),
							A4(
							$mdgriffith$elm_ui$Internal$Model$renderStyle,
							options,
							maybePseudo,
							_class + (paragraph + '::after'),
							_List_fromArray(
								[
									A2($mdgriffith$elm_ui$Internal$Model$Property, 'content', '\'\''),
									A2($mdgriffith$elm_ui$Internal$Model$Property, 'display', 'block'),
									A2($mdgriffith$elm_ui$Internal$Model$Property, 'height', '0'),
									A2($mdgriffith$elm_ui$Internal$Model$Property, 'width', '0'),
									A2(
									$mdgriffith$elm_ui$Internal$Model$Property,
									'margin-top',
									$elm$core$String$fromInt((-1) * ((y / 2) | 0)) + 'px')
								])),
							A4(
							$mdgriffith$elm_ui$Internal$Model$renderStyle,
							options,
							maybePseudo,
							_class + (paragraph + '::before'),
							_List_fromArray(
								[
									A2($mdgriffith$elm_ui$Internal$Model$Property, 'content', '\'\''),
									A2($mdgriffith$elm_ui$Internal$Model$Property, 'display', 'block'),
									A2($mdgriffith$elm_ui$Internal$Model$Property, 'height', '0'),
									A2($mdgriffith$elm_ui$Internal$Model$Property, 'width', '0'),
									A2(
									$mdgriffith$elm_ui$Internal$Model$Property,
									'margin-bottom',
									$elm$core$String$fromInt((-1) * ((y / 2) | 0)) + 'px')
								]))
						]));
			case 7:
				var cls = rule.a;
				var top = rule.b;
				var right = rule.c;
				var bottom = rule.d;
				var left = rule.e;
				var _class = '.' + cls;
				return A4(
					$mdgriffith$elm_ui$Internal$Model$renderStyle,
					options,
					maybePseudo,
					_class,
					_List_fromArray(
						[
							A2(
							$mdgriffith$elm_ui$Internal$Model$Property,
							'padding',
							$elm$core$String$fromFloat(top) + ('px ' + ($elm$core$String$fromFloat(right) + ('px ' + ($elm$core$String$fromFloat(bottom) + ('px ' + ($elm$core$String$fromFloat(left) + 'px')))))))
						]));
			case 6:
				var cls = rule.a;
				var top = rule.b;
				var right = rule.c;
				var bottom = rule.d;
				var left = rule.e;
				var _class = '.' + cls;
				return A4(
					$mdgriffith$elm_ui$Internal$Model$renderStyle,
					options,
					maybePseudo,
					_class,
					_List_fromArray(
						[
							A2(
							$mdgriffith$elm_ui$Internal$Model$Property,
							'border-width',
							$elm$core$String$fromInt(top) + ('px ' + ($elm$core$String$fromInt(right) + ('px ' + ($elm$core$String$fromInt(bottom) + ('px ' + ($elm$core$String$fromInt(left) + 'px')))))))
						]));
			case 8:
				var template = rule.a;
				var toGridLengthHelper = F3(
					function (minimum, maximum, x) {
						toGridLengthHelper:
						while (true) {
							switch (x.$) {
								case 0:
									var px = x.a;
									return $elm$core$String$fromInt(px) + 'px';
								case 1:
									var _v2 = _Utils_Tuple2(minimum, maximum);
									if (_v2.a.$ === 1) {
										if (_v2.b.$ === 1) {
											var _v3 = _v2.a;
											var _v4 = _v2.b;
											return 'max-content';
										} else {
											var _v6 = _v2.a;
											var maxSize = _v2.b.a;
											return 'minmax(max-content, ' + ($elm$core$String$fromInt(maxSize) + 'px)');
										}
									} else {
										if (_v2.b.$ === 1) {
											var minSize = _v2.a.a;
											var _v5 = _v2.b;
											return 'minmax(' + ($elm$core$String$fromInt(minSize) + ('px, ' + 'max-content)'));
										} else {
											var minSize = _v2.a.a;
											var maxSize = _v2.b.a;
											return 'minmax(' + ($elm$core$String$fromInt(minSize) + ('px, ' + ($elm$core$String$fromInt(maxSize) + 'px)')));
										}
									}
								case 2:
									var i = x.a;
									var _v7 = _Utils_Tuple2(minimum, maximum);
									if (_v7.a.$ === 1) {
										if (_v7.b.$ === 1) {
											var _v8 = _v7.a;
											var _v9 = _v7.b;
											return $elm$core$String$fromInt(i) + 'fr';
										} else {
											var _v11 = _v7.a;
											var maxSize = _v7.b.a;
											return 'minmax(max-content, ' + ($elm$core$String$fromInt(maxSize) + 'px)');
										}
									} else {
										if (_v7.b.$ === 1) {
											var minSize = _v7.a.a;
											var _v10 = _v7.b;
											return 'minmax(' + ($elm$core$String$fromInt(minSize) + ('px, ' + ($elm$core$String$fromInt(i) + ('fr' + 'fr)'))));
										} else {
											var minSize = _v7.a.a;
											var maxSize = _v7.b.a;
											return 'minmax(' + ($elm$core$String$fromInt(minSize) + ('px, ' + ($elm$core$String$fromInt(maxSize) + 'px)')));
										}
									}
								case 3:
									var m = x.a;
									var len = x.b;
									var $temp$minimum = $elm$core$Maybe$Just(m),
										$temp$maximum = maximum,
										$temp$x = len;
									minimum = $temp$minimum;
									maximum = $temp$maximum;
									x = $temp$x;
									continue toGridLengthHelper;
								default:
									var m = x.a;
									var len = x.b;
									var $temp$minimum = minimum,
										$temp$maximum = $elm$core$Maybe$Just(m),
										$temp$x = len;
									minimum = $temp$minimum;
									maximum = $temp$maximum;
									x = $temp$x;
									continue toGridLengthHelper;
							}
						}
					});
				var toGridLength = function (x) {
					return A3(toGridLengthHelper, $elm$core$Maybe$Nothing, $elm$core$Maybe$Nothing, x);
				};
				var xSpacing = toGridLength(template.gb.a);
				var ySpacing = toGridLength(template.gb.b);
				var rows = function (x) {
					return 'grid-template-rows: ' + (x + ';');
				}(
					A2(
						$elm$core$String$join,
						' ',
						A2($elm$core$List$map, toGridLength, template.f1)));
				var msRows = function (x) {
					return '-ms-grid-rows: ' + (x + ';');
				}(
					A2(
						$elm$core$String$join,
						ySpacing,
						A2($elm$core$List$map, toGridLength, template.ag)));
				var msColumns = function (x) {
					return '-ms-grid-columns: ' + (x + ';');
				}(
					A2(
						$elm$core$String$join,
						ySpacing,
						A2($elm$core$List$map, toGridLength, template.ag)));
				var gapY = 'grid-row-gap:' + (toGridLength(template.gb.b) + ';');
				var gapX = 'grid-column-gap:' + (toGridLength(template.gb.a) + ';');
				var columns = function (x) {
					return 'grid-template-columns: ' + (x + ';');
				}(
					A2(
						$elm$core$String$join,
						' ',
						A2($elm$core$List$map, toGridLength, template.ag)));
				var _class = '.grid-rows-' + (A2(
					$elm$core$String$join,
					'-',
					A2($elm$core$List$map, $mdgriffith$elm_ui$Internal$Model$lengthClassName, template.f1)) + ('-cols-' + (A2(
					$elm$core$String$join,
					'-',
					A2($elm$core$List$map, $mdgriffith$elm_ui$Internal$Model$lengthClassName, template.ag)) + ('-space-x-' + ($mdgriffith$elm_ui$Internal$Model$lengthClassName(template.gb.a) + ('-space-y-' + $mdgriffith$elm_ui$Internal$Model$lengthClassName(template.gb.b)))))));
				var modernGrid = _class + ('{' + (columns + (rows + (gapX + (gapY + '}')))));
				var supports = '@supports (display:grid) {' + (modernGrid + '}');
				var base = _class + ('{' + (msColumns + (msRows + '}')));
				return _List_fromArray(
					[base, supports]);
			case 9:
				var position = rule.a;
				var msPosition = A2(
					$elm$core$String$join,
					' ',
					_List_fromArray(
						[
							'-ms-grid-row: ' + ($elm$core$String$fromInt(position.ab) + ';'),
							'-ms-grid-row-span: ' + ($elm$core$String$fromInt(position.di) + ';'),
							'-ms-grid-column: ' + ($elm$core$String$fromInt(position.eR) + ';'),
							'-ms-grid-column-span: ' + ($elm$core$String$fromInt(position.d7) + ';')
						]));
				var modernPosition = A2(
					$elm$core$String$join,
					' ',
					_List_fromArray(
						[
							'grid-row: ' + ($elm$core$String$fromInt(position.ab) + (' / ' + ($elm$core$String$fromInt(position.ab + position.di) + ';'))),
							'grid-column: ' + ($elm$core$String$fromInt(position.eR) + (' / ' + ($elm$core$String$fromInt(position.eR + position.d7) + ';')))
						]));
				var _class = '.grid-pos-' + ($elm$core$String$fromInt(position.ab) + ('-' + ($elm$core$String$fromInt(position.eR) + ('-' + ($elm$core$String$fromInt(position.d7) + ('-' + $elm$core$String$fromInt(position.di)))))));
				var modernGrid = _class + ('{' + (modernPosition + '}'));
				var supports = '@supports (display:grid) {' + (modernGrid + '}');
				var base = _class + ('{' + (msPosition + '}'));
				return _List_fromArray(
					[base, supports]);
			case 11:
				var _class = rule.a;
				var styles = rule.b;
				var renderPseudoRule = function (style) {
					return A3(
						$mdgriffith$elm_ui$Internal$Model$renderStyleRule,
						options,
						style,
						$elm$core$Maybe$Just(_class));
				};
				return A2($elm$core$List$concatMap, renderPseudoRule, styles);
			default:
				var transform = rule.a;
				var val = $mdgriffith$elm_ui$Internal$Model$transformValue(transform);
				var _class = $mdgriffith$elm_ui$Internal$Model$transformClass(transform);
				var _v12 = _Utils_Tuple2(_class, val);
				if ((!_v12.a.$) && (!_v12.b.$)) {
					var cls = _v12.a.a;
					var v = _v12.b.a;
					return A4(
						$mdgriffith$elm_ui$Internal$Model$renderStyle,
						options,
						maybePseudo,
						'.' + cls,
						_List_fromArray(
							[
								A2($mdgriffith$elm_ui$Internal$Model$Property, 'transform', v)
							]));
				} else {
					return _List_Nil;
				}
		}
	});
var $mdgriffith$elm_ui$Internal$Model$encodeStyles = F2(
	function (options, stylesheet) {
		return $elm$json$Json$Encode$object(
			A2(
				$elm$core$List$map,
				function (style) {
					var styled = A3($mdgriffith$elm_ui$Internal$Model$renderStyleRule, options, style, $elm$core$Maybe$Nothing);
					return _Utils_Tuple2(
						$mdgriffith$elm_ui$Internal$Model$getStyleName(style),
						A2($elm$json$Json$Encode$list, $elm$json$Json$Encode$string, styled));
				},
				stylesheet));
	});
var $mdgriffith$elm_ui$Internal$Model$bracket = F2(
	function (selector, rules) {
		var renderPair = function (_v0) {
			var name = _v0.a;
			var val = _v0.b;
			return name + (': ' + (val + ';'));
		};
		return selector + (' {' + (A2(
			$elm$core$String$join,
			'',
			A2($elm$core$List$map, renderPair, rules)) + '}'));
	});
var $mdgriffith$elm_ui$Internal$Model$fontRule = F3(
	function (name, modifier, _v0) {
		var parentAdj = _v0.a;
		var textAdjustment = _v0.b;
		return _List_fromArray(
			[
				A2($mdgriffith$elm_ui$Internal$Model$bracket, '.' + (name + ('.' + (modifier + (', ' + ('.' + (name + (' .' + modifier))))))), parentAdj),
				A2($mdgriffith$elm_ui$Internal$Model$bracket, '.' + (name + ('.' + (modifier + ('> .' + ($mdgriffith$elm_ui$Internal$Style$classes.bL + (', .' + (name + (' .' + (modifier + (' > .' + $mdgriffith$elm_ui$Internal$Style$classes.bL)))))))))), textAdjustment)
			]);
	});
var $mdgriffith$elm_ui$Internal$Model$renderFontAdjustmentRule = F3(
	function (fontToAdjust, _v0, otherFontName) {
		var full = _v0.a;
		var capital = _v0.b;
		var name = _Utils_eq(fontToAdjust, otherFontName) ? fontToAdjust : (otherFontName + (' .' + fontToAdjust));
		return A2(
			$elm$core$String$join,
			' ',
			_Utils_ap(
				A3($mdgriffith$elm_ui$Internal$Model$fontRule, name, $mdgriffith$elm_ui$Internal$Style$classes.f9, capital),
				A3($mdgriffith$elm_ui$Internal$Model$fontRule, name, $mdgriffith$elm_ui$Internal$Style$classes.e9, full)));
	});
var $mdgriffith$elm_ui$Internal$Model$renderNullAdjustmentRule = F2(
	function (fontToAdjust, otherFontName) {
		var name = _Utils_eq(fontToAdjust, otherFontName) ? fontToAdjust : (otherFontName + (' .' + fontToAdjust));
		return A2(
			$elm$core$String$join,
			' ',
			_List_fromArray(
				[
					A2(
					$mdgriffith$elm_ui$Internal$Model$bracket,
					'.' + (name + ('.' + ($mdgriffith$elm_ui$Internal$Style$classes.f9 + (', ' + ('.' + (name + (' .' + $mdgriffith$elm_ui$Internal$Style$classes.f9))))))),
					_List_fromArray(
						[
							_Utils_Tuple2('line-height', '1')
						])),
					A2(
					$mdgriffith$elm_ui$Internal$Model$bracket,
					'.' + (name + ('.' + ($mdgriffith$elm_ui$Internal$Style$classes.f9 + ('> .' + ($mdgriffith$elm_ui$Internal$Style$classes.bL + (', .' + (name + (' .' + ($mdgriffith$elm_ui$Internal$Style$classes.f9 + (' > .' + $mdgriffith$elm_ui$Internal$Style$classes.bL)))))))))),
					_List_fromArray(
						[
							_Utils_Tuple2('vertical-align', '0'),
							_Utils_Tuple2('line-height', '1')
						]))
				]));
	});
var $mdgriffith$elm_ui$Internal$Model$adjust = F3(
	function (size, height, vertical) {
		return {di: height / size, aZ: size, d4: vertical};
	});
var $elm$core$List$maximum = function (list) {
	if (list.b) {
		var x = list.a;
		var xs = list.b;
		return $elm$core$Maybe$Just(
			A3($elm$core$List$foldl, $elm$core$Basics$max, x, xs));
	} else {
		return $elm$core$Maybe$Nothing;
	}
};
var $elm$core$List$minimum = function (list) {
	if (list.b) {
		var x = list.a;
		var xs = list.b;
		return $elm$core$Maybe$Just(
			A3($elm$core$List$foldl, $elm$core$Basics$min, x, xs));
	} else {
		return $elm$core$Maybe$Nothing;
	}
};
var $mdgriffith$elm_ui$Internal$Model$convertAdjustment = function (adjustment) {
	var lines = _List_fromArray(
		[adjustment.eK, adjustment.ew, adjustment.eY, adjustment.fx]);
	var lineHeight = 1.5;
	var normalDescender = (lineHeight - 1) / 2;
	var oldMiddle = lineHeight / 2;
	var descender = A2(
		$elm$core$Maybe$withDefault,
		adjustment.eY,
		$elm$core$List$minimum(lines));
	var newBaseline = A2(
		$elm$core$Maybe$withDefault,
		adjustment.ew,
		$elm$core$List$minimum(
			A2(
				$elm$core$List$filter,
				function (x) {
					return !_Utils_eq(x, descender);
				},
				lines)));
	var base = lineHeight;
	var ascender = A2(
		$elm$core$Maybe$withDefault,
		adjustment.eK,
		$elm$core$List$maximum(lines));
	var capitalSize = 1 / (ascender - newBaseline);
	var capitalVertical = 1 - ascender;
	var fullSize = 1 / (ascender - descender);
	var fullVertical = 1 - ascender;
	var newCapitalMiddle = ((ascender - newBaseline) / 2) + newBaseline;
	var newFullMiddle = ((ascender - descender) / 2) + descender;
	return {
		eK: A3($mdgriffith$elm_ui$Internal$Model$adjust, capitalSize, ascender - newBaseline, capitalVertical),
		de: A3($mdgriffith$elm_ui$Internal$Model$adjust, fullSize, ascender - descender, fullVertical)
	};
};
var $mdgriffith$elm_ui$Internal$Model$fontAdjustmentRules = function (converted) {
	return _Utils_Tuple2(
		_List_fromArray(
			[
				_Utils_Tuple2('display', 'block')
			]),
		_List_fromArray(
			[
				_Utils_Tuple2('display', 'inline-block'),
				_Utils_Tuple2(
				'line-height',
				$elm$core$String$fromFloat(converted.di)),
				_Utils_Tuple2(
				'vertical-align',
				$elm$core$String$fromFloat(converted.d4) + 'em'),
				_Utils_Tuple2(
				'font-size',
				$elm$core$String$fromFloat(converted.aZ) + 'em')
			]));
};
var $mdgriffith$elm_ui$Internal$Model$typefaceAdjustment = function (typefaces) {
	return A3(
		$elm$core$List$foldl,
		F2(
			function (face, found) {
				if (found.$ === 1) {
					if (face.$ === 5) {
						var _with = face.a;
						var _v2 = _with.eg;
						if (_v2.$ === 1) {
							return found;
						} else {
							var adjustment = _v2.a;
							return $elm$core$Maybe$Just(
								_Utils_Tuple2(
									$mdgriffith$elm_ui$Internal$Model$fontAdjustmentRules(
										function ($) {
											return $.de;
										}(
											$mdgriffith$elm_ui$Internal$Model$convertAdjustment(adjustment))),
									$mdgriffith$elm_ui$Internal$Model$fontAdjustmentRules(
										function ($) {
											return $.eK;
										}(
											$mdgriffith$elm_ui$Internal$Model$convertAdjustment(adjustment)))));
						}
					} else {
						return found;
					}
				} else {
					return found;
				}
			}),
		$elm$core$Maybe$Nothing,
		typefaces);
};
var $mdgriffith$elm_ui$Internal$Model$renderTopLevelValues = function (rules) {
	var withImport = function (font) {
		if (font.$ === 4) {
			var url = font.b;
			return $elm$core$Maybe$Just('@import url(\'' + (url + '\');'));
		} else {
			return $elm$core$Maybe$Nothing;
		}
	};
	var fontImports = function (_v2) {
		var name = _v2.a;
		var typefaces = _v2.b;
		var imports = A2(
			$elm$core$String$join,
			'\n',
			A2($elm$core$List$filterMap, withImport, typefaces));
		return imports;
	};
	var allNames = A2($elm$core$List$map, $elm$core$Tuple$first, rules);
	var fontAdjustments = function (_v1) {
		var name = _v1.a;
		var typefaces = _v1.b;
		var _v0 = $mdgriffith$elm_ui$Internal$Model$typefaceAdjustment(typefaces);
		if (_v0.$ === 1) {
			return A2(
				$elm$core$String$join,
				'',
				A2(
					$elm$core$List$map,
					$mdgriffith$elm_ui$Internal$Model$renderNullAdjustmentRule(name),
					allNames));
		} else {
			var adjustment = _v0.a;
			return A2(
				$elm$core$String$join,
				'',
				A2(
					$elm$core$List$map,
					A2($mdgriffith$elm_ui$Internal$Model$renderFontAdjustmentRule, name, adjustment),
					allNames));
		}
	};
	return _Utils_ap(
		A2(
			$elm$core$String$join,
			'\n',
			A2($elm$core$List$map, fontImports, rules)),
		A2(
			$elm$core$String$join,
			'\n',
			A2($elm$core$List$map, fontAdjustments, rules)));
};
var $mdgriffith$elm_ui$Internal$Model$topLevelValue = function (rule) {
	if (rule.$ === 1) {
		var name = rule.a;
		var typefaces = rule.b;
		return $elm$core$Maybe$Just(
			_Utils_Tuple2(name, typefaces));
	} else {
		return $elm$core$Maybe$Nothing;
	}
};
var $mdgriffith$elm_ui$Internal$Model$toStyleSheetString = F2(
	function (options, stylesheet) {
		var combine = F2(
			function (style, rendered) {
				return {
					cb: _Utils_ap(
						rendered.cb,
						A3($mdgriffith$elm_ui$Internal$Model$renderStyleRule, options, style, $elm$core$Maybe$Nothing)),
					bN: function () {
						var _v1 = $mdgriffith$elm_ui$Internal$Model$topLevelValue(style);
						if (_v1.$ === 1) {
							return rendered.bN;
						} else {
							var topLevel = _v1.a;
							return A2($elm$core$List$cons, topLevel, rendered.bN);
						}
					}()
				};
			});
		var _v0 = A3(
			$elm$core$List$foldl,
			combine,
			{cb: _List_Nil, bN: _List_Nil},
			stylesheet);
		var topLevel = _v0.bN;
		var rules = _v0.cb;
		return _Utils_ap(
			$mdgriffith$elm_ui$Internal$Model$renderTopLevelValues(topLevel),
			$elm$core$String$concat(rules));
	});
var $mdgriffith$elm_ui$Internal$Model$toStyleSheet = F2(
	function (options, styleSheet) {
		var _v0 = options.fA;
		switch (_v0) {
			case 0:
				return A3(
					$elm$virtual_dom$VirtualDom$node,
					'div',
					_List_Nil,
					_List_fromArray(
						[
							A3(
							$elm$virtual_dom$VirtualDom$node,
							'style',
							_List_Nil,
							_List_fromArray(
								[
									$elm$virtual_dom$VirtualDom$text(
									A2($mdgriffith$elm_ui$Internal$Model$toStyleSheetString, options, styleSheet))
								]))
						]));
			case 1:
				return A3(
					$elm$virtual_dom$VirtualDom$node,
					'div',
					_List_Nil,
					_List_fromArray(
						[
							A3(
							$elm$virtual_dom$VirtualDom$node,
							'style',
							_List_Nil,
							_List_fromArray(
								[
									$elm$virtual_dom$VirtualDom$text(
									A2($mdgriffith$elm_ui$Internal$Model$toStyleSheetString, options, styleSheet))
								]))
						]));
			default:
				return A3(
					$elm$virtual_dom$VirtualDom$node,
					'elm-ui-rules',
					_List_fromArray(
						[
							A2(
							$elm$virtual_dom$VirtualDom$property,
							'rules',
							A2($mdgriffith$elm_ui$Internal$Model$encodeStyles, options, styleSheet))
						]),
					_List_Nil);
		}
	});
var $mdgriffith$elm_ui$Internal$Model$embedKeyed = F4(
	function (_static, opts, styles, children) {
		var dynamicStyleSheet = A2(
			$mdgriffith$elm_ui$Internal$Model$toStyleSheet,
			opts,
			A3(
				$elm$core$List$foldl,
				$mdgriffith$elm_ui$Internal$Model$reduceStyles,
				_Utils_Tuple2(
					$elm$core$Set$empty,
					$mdgriffith$elm_ui$Internal$Model$renderFocusStyle(opts.e8)),
				styles).b);
		return _static ? A2(
			$elm$core$List$cons,
			_Utils_Tuple2(
				'static-stylesheet',
				$mdgriffith$elm_ui$Internal$Model$staticRoot(opts)),
			A2(
				$elm$core$List$cons,
				_Utils_Tuple2('dynamic-stylesheet', dynamicStyleSheet),
				children)) : A2(
			$elm$core$List$cons,
			_Utils_Tuple2('dynamic-stylesheet', dynamicStyleSheet),
			children);
	});
var $mdgriffith$elm_ui$Internal$Model$embedWith = F4(
	function (_static, opts, styles, children) {
		var dynamicStyleSheet = A2(
			$mdgriffith$elm_ui$Internal$Model$toStyleSheet,
			opts,
			A3(
				$elm$core$List$foldl,
				$mdgriffith$elm_ui$Internal$Model$reduceStyles,
				_Utils_Tuple2(
					$elm$core$Set$empty,
					$mdgriffith$elm_ui$Internal$Model$renderFocusStyle(opts.e8)),
				styles).b);
		return _static ? A2(
			$elm$core$List$cons,
			$mdgriffith$elm_ui$Internal$Model$staticRoot(opts),
			A2($elm$core$List$cons, dynamicStyleSheet, children)) : A2($elm$core$List$cons, dynamicStyleSheet, children);
	});
var $mdgriffith$elm_ui$Internal$Flag$heightBetween = $mdgriffith$elm_ui$Internal$Flag$flag(45);
var $mdgriffith$elm_ui$Internal$Flag$heightFill = $mdgriffith$elm_ui$Internal$Flag$flag(37);
var $elm$virtual_dom$VirtualDom$keyedNode = function (tag) {
	return _VirtualDom_keyedNode(
		_VirtualDom_noScript(tag));
};
var $elm$html$Html$p = _VirtualDom_node('p');
var $elm$core$Bitwise$and = _Bitwise_and;
var $mdgriffith$elm_ui$Internal$Flag$present = F2(
	function (myFlag, _v0) {
		var fieldOne = _v0.a;
		var fieldTwo = _v0.b;
		if (!myFlag.$) {
			var first = myFlag.a;
			return _Utils_eq(first & fieldOne, first);
		} else {
			var second = myFlag.a;
			return _Utils_eq(second & fieldTwo, second);
		}
	});
var $elm$html$Html$s = _VirtualDom_node('s');
var $elm$html$Html$u = _VirtualDom_node('u');
var $mdgriffith$elm_ui$Internal$Flag$widthBetween = $mdgriffith$elm_ui$Internal$Flag$flag(44);
var $mdgriffith$elm_ui$Internal$Flag$widthFill = $mdgriffith$elm_ui$Internal$Flag$flag(39);
var $mdgriffith$elm_ui$Internal$Model$finalizeNode = F6(
	function (has, node, attributes, children, embedMode, parentContext) {
		var createNode = F2(
			function (nodeName, attrs) {
				if (children.$ === 1) {
					var keyed = children.a;
					return A3(
						$elm$virtual_dom$VirtualDom$keyedNode,
						nodeName,
						attrs,
						function () {
							switch (embedMode.$) {
								case 0:
									return keyed;
								case 2:
									var opts = embedMode.a;
									var styles = embedMode.b;
									return A4($mdgriffith$elm_ui$Internal$Model$embedKeyed, false, opts, styles, keyed);
								default:
									var opts = embedMode.a;
									var styles = embedMode.b;
									return A4($mdgriffith$elm_ui$Internal$Model$embedKeyed, true, opts, styles, keyed);
							}
						}());
				} else {
					var unkeyed = children.a;
					return A2(
						function () {
							switch (nodeName) {
								case 'div':
									return $elm$html$Html$div;
								case 'p':
									return $elm$html$Html$p;
								default:
									return $elm$virtual_dom$VirtualDom$node(nodeName);
							}
						}(),
						attrs,
						function () {
							switch (embedMode.$) {
								case 0:
									return unkeyed;
								case 2:
									var opts = embedMode.a;
									var styles = embedMode.b;
									return A4($mdgriffith$elm_ui$Internal$Model$embedWith, false, opts, styles, unkeyed);
								default:
									var opts = embedMode.a;
									var styles = embedMode.b;
									return A4($mdgriffith$elm_ui$Internal$Model$embedWith, true, opts, styles, unkeyed);
							}
						}());
				}
			});
		var html = function () {
			switch (node.$) {
				case 0:
					return A2(createNode, 'div', attributes);
				case 1:
					var nodeName = node.a;
					return A2(createNode, nodeName, attributes);
				default:
					var nodeName = node.a;
					var internal = node.b;
					return A3(
						$elm$virtual_dom$VirtualDom$node,
						nodeName,
						attributes,
						_List_fromArray(
							[
								A2(
								createNode,
								internal,
								_List_fromArray(
									[
										$elm$html$Html$Attributes$class($mdgriffith$elm_ui$Internal$Style$classes.er + (' ' + $mdgriffith$elm_ui$Internal$Style$classes.f8))
									]))
							]));
			}
		}();
		switch (parentContext) {
			case 0:
				return (A2($mdgriffith$elm_ui$Internal$Flag$present, $mdgriffith$elm_ui$Internal$Flag$widthFill, has) && (!A2($mdgriffith$elm_ui$Internal$Flag$present, $mdgriffith$elm_ui$Internal$Flag$widthBetween, has))) ? html : (A2($mdgriffith$elm_ui$Internal$Flag$present, $mdgriffith$elm_ui$Internal$Flag$alignRight, has) ? A2(
					$elm$html$Html$u,
					_List_fromArray(
						[
							$elm$html$Html$Attributes$class(
							A2(
								$elm$core$String$join,
								' ',
								_List_fromArray(
									[$mdgriffith$elm_ui$Internal$Style$classes.er, $mdgriffith$elm_ui$Internal$Style$classes.f8, $mdgriffith$elm_ui$Internal$Style$classes.bX, $mdgriffith$elm_ui$Internal$Style$classes.ar, $mdgriffith$elm_ui$Internal$Style$classes.eo])))
						]),
					_List_fromArray(
						[html])) : (A2($mdgriffith$elm_ui$Internal$Flag$present, $mdgriffith$elm_ui$Internal$Flag$centerX, has) ? A2(
					$elm$html$Html$s,
					_List_fromArray(
						[
							$elm$html$Html$Attributes$class(
							A2(
								$elm$core$String$join,
								' ',
								_List_fromArray(
									[$mdgriffith$elm_ui$Internal$Style$classes.er, $mdgriffith$elm_ui$Internal$Style$classes.f8, $mdgriffith$elm_ui$Internal$Style$classes.bX, $mdgriffith$elm_ui$Internal$Style$classes.ar, $mdgriffith$elm_ui$Internal$Style$classes.em])))
						]),
					_List_fromArray(
						[html])) : html));
			case 1:
				return (A2($mdgriffith$elm_ui$Internal$Flag$present, $mdgriffith$elm_ui$Internal$Flag$heightFill, has) && (!A2($mdgriffith$elm_ui$Internal$Flag$present, $mdgriffith$elm_ui$Internal$Flag$heightBetween, has))) ? html : (A2($mdgriffith$elm_ui$Internal$Flag$present, $mdgriffith$elm_ui$Internal$Flag$centerY, has) ? A2(
					$elm$html$Html$s,
					_List_fromArray(
						[
							$elm$html$Html$Attributes$class(
							A2(
								$elm$core$String$join,
								' ',
								_List_fromArray(
									[$mdgriffith$elm_ui$Internal$Style$classes.er, $mdgriffith$elm_ui$Internal$Style$classes.f8, $mdgriffith$elm_ui$Internal$Style$classes.bX, $mdgriffith$elm_ui$Internal$Style$classes.en])))
						]),
					_List_fromArray(
						[html])) : (A2($mdgriffith$elm_ui$Internal$Flag$present, $mdgriffith$elm_ui$Internal$Flag$alignBottom, has) ? A2(
					$elm$html$Html$u,
					_List_fromArray(
						[
							$elm$html$Html$Attributes$class(
							A2(
								$elm$core$String$join,
								' ',
								_List_fromArray(
									[$mdgriffith$elm_ui$Internal$Style$classes.er, $mdgriffith$elm_ui$Internal$Style$classes.f8, $mdgriffith$elm_ui$Internal$Style$classes.bX, $mdgriffith$elm_ui$Internal$Style$classes.el])))
						]),
					_List_fromArray(
						[html])) : html));
			default:
				return html;
		}
	});
var $elm$html$Html$text = $elm$virtual_dom$VirtualDom$text;
var $mdgriffith$elm_ui$Internal$Model$textElementClasses = $mdgriffith$elm_ui$Internal$Style$classes.er + (' ' + ($mdgriffith$elm_ui$Internal$Style$classes.bL + (' ' + ($mdgriffith$elm_ui$Internal$Style$classes.cP + (' ' + $mdgriffith$elm_ui$Internal$Style$classes.cB)))));
var $mdgriffith$elm_ui$Internal$Model$textElement = function (str) {
	return A2(
		$elm$html$Html$div,
		_List_fromArray(
			[
				$elm$html$Html$Attributes$class($mdgriffith$elm_ui$Internal$Model$textElementClasses)
			]),
		_List_fromArray(
			[
				$elm$html$Html$text(str)
			]));
};
var $mdgriffith$elm_ui$Internal$Model$textElementFillClasses = $mdgriffith$elm_ui$Internal$Style$classes.er + (' ' + ($mdgriffith$elm_ui$Internal$Style$classes.bL + (' ' + ($mdgriffith$elm_ui$Internal$Style$classes.cQ + (' ' + $mdgriffith$elm_ui$Internal$Style$classes.cC)))));
var $mdgriffith$elm_ui$Internal$Model$textElementFill = function (str) {
	return A2(
		$elm$html$Html$div,
		_List_fromArray(
			[
				$elm$html$Html$Attributes$class($mdgriffith$elm_ui$Internal$Model$textElementFillClasses)
			]),
		_List_fromArray(
			[
				$elm$html$Html$text(str)
			]));
};
var $mdgriffith$elm_ui$Internal$Model$createElement = F3(
	function (context, children, rendered) {
		var gatherKeyed = F2(
			function (_v8, _v9) {
				var key = _v8.a;
				var child = _v8.b;
				var htmls = _v9.a;
				var existingStyles = _v9.b;
				switch (child.$) {
					case 0:
						var html = child.a;
						return _Utils_eq(context, $mdgriffith$elm_ui$Internal$Model$asParagraph) ? _Utils_Tuple2(
							A2(
								$elm$core$List$cons,
								_Utils_Tuple2(
									key,
									html(context)),
								htmls),
							existingStyles) : _Utils_Tuple2(
							A2(
								$elm$core$List$cons,
								_Utils_Tuple2(
									key,
									html(context)),
								htmls),
							existingStyles);
					case 1:
						var styled = child.a;
						return _Utils_eq(context, $mdgriffith$elm_ui$Internal$Model$asParagraph) ? _Utils_Tuple2(
							A2(
								$elm$core$List$cons,
								_Utils_Tuple2(
									key,
									A2(styled.fd, $mdgriffith$elm_ui$Internal$Model$NoStyleSheet, context)),
								htmls),
							$elm$core$List$isEmpty(existingStyles) ? styled.dY : _Utils_ap(styled.dY, existingStyles)) : _Utils_Tuple2(
							A2(
								$elm$core$List$cons,
								_Utils_Tuple2(
									key,
									A2(styled.fd, $mdgriffith$elm_ui$Internal$Model$NoStyleSheet, context)),
								htmls),
							$elm$core$List$isEmpty(existingStyles) ? styled.dY : _Utils_ap(styled.dY, existingStyles));
					case 2:
						var str = child.a;
						return _Utils_Tuple2(
							A2(
								$elm$core$List$cons,
								_Utils_Tuple2(
									key,
									_Utils_eq(context, $mdgriffith$elm_ui$Internal$Model$asEl) ? $mdgriffith$elm_ui$Internal$Model$textElementFill(str) : $mdgriffith$elm_ui$Internal$Model$textElement(str)),
								htmls),
							existingStyles);
					default:
						return _Utils_Tuple2(htmls, existingStyles);
				}
			});
		var gather = F2(
			function (child, _v6) {
				var htmls = _v6.a;
				var existingStyles = _v6.b;
				switch (child.$) {
					case 0:
						var html = child.a;
						return _Utils_eq(context, $mdgriffith$elm_ui$Internal$Model$asParagraph) ? _Utils_Tuple2(
							A2(
								$elm$core$List$cons,
								html(context),
								htmls),
							existingStyles) : _Utils_Tuple2(
							A2(
								$elm$core$List$cons,
								html(context),
								htmls),
							existingStyles);
					case 1:
						var styled = child.a;
						return _Utils_eq(context, $mdgriffith$elm_ui$Internal$Model$asParagraph) ? _Utils_Tuple2(
							A2(
								$elm$core$List$cons,
								A2(styled.fd, $mdgriffith$elm_ui$Internal$Model$NoStyleSheet, context),
								htmls),
							$elm$core$List$isEmpty(existingStyles) ? styled.dY : _Utils_ap(styled.dY, existingStyles)) : _Utils_Tuple2(
							A2(
								$elm$core$List$cons,
								A2(styled.fd, $mdgriffith$elm_ui$Internal$Model$NoStyleSheet, context),
								htmls),
							$elm$core$List$isEmpty(existingStyles) ? styled.dY : _Utils_ap(styled.dY, existingStyles));
					case 2:
						var str = child.a;
						return _Utils_Tuple2(
							A2(
								$elm$core$List$cons,
								_Utils_eq(context, $mdgriffith$elm_ui$Internal$Model$asEl) ? $mdgriffith$elm_ui$Internal$Model$textElementFill(str) : $mdgriffith$elm_ui$Internal$Model$textElement(str),
								htmls),
							existingStyles);
					default:
						return _Utils_Tuple2(htmls, existingStyles);
				}
			});
		if (children.$ === 1) {
			var keyedChildren = children.a;
			var _v1 = A3(
				$elm$core$List$foldr,
				gatherKeyed,
				_Utils_Tuple2(_List_Nil, _List_Nil),
				keyedChildren);
			var keyed = _v1.a;
			var styles = _v1.b;
			var newStyles = $elm$core$List$isEmpty(styles) ? rendered.dY : _Utils_ap(rendered.dY, styles);
			if (!newStyles.b) {
				return $mdgriffith$elm_ui$Internal$Model$Unstyled(
					A5(
						$mdgriffith$elm_ui$Internal$Model$finalizeNode,
						rendered.aN,
						rendered.dA,
						rendered.aD,
						$mdgriffith$elm_ui$Internal$Model$Keyed(
							A3($mdgriffith$elm_ui$Internal$Model$addKeyedChildren, 'nearby-element-pls', keyed, rendered.eN)),
						$mdgriffith$elm_ui$Internal$Model$NoStyleSheet));
			} else {
				var allStyles = newStyles;
				return $mdgriffith$elm_ui$Internal$Model$Styled(
					{
						fd: A4(
							$mdgriffith$elm_ui$Internal$Model$finalizeNode,
							rendered.aN,
							rendered.dA,
							rendered.aD,
							$mdgriffith$elm_ui$Internal$Model$Keyed(
								A3($mdgriffith$elm_ui$Internal$Model$addKeyedChildren, 'nearby-element-pls', keyed, rendered.eN))),
						dY: allStyles
					});
			}
		} else {
			var unkeyedChildren = children.a;
			var _v3 = A3(
				$elm$core$List$foldr,
				gather,
				_Utils_Tuple2(_List_Nil, _List_Nil),
				unkeyedChildren);
			var unkeyed = _v3.a;
			var styles = _v3.b;
			var newStyles = $elm$core$List$isEmpty(styles) ? rendered.dY : _Utils_ap(rendered.dY, styles);
			if (!newStyles.b) {
				return $mdgriffith$elm_ui$Internal$Model$Unstyled(
					A5(
						$mdgriffith$elm_ui$Internal$Model$finalizeNode,
						rendered.aN,
						rendered.dA,
						rendered.aD,
						$mdgriffith$elm_ui$Internal$Model$Unkeyed(
							A2($mdgriffith$elm_ui$Internal$Model$addChildren, unkeyed, rendered.eN)),
						$mdgriffith$elm_ui$Internal$Model$NoStyleSheet));
			} else {
				var allStyles = newStyles;
				return $mdgriffith$elm_ui$Internal$Model$Styled(
					{
						fd: A4(
							$mdgriffith$elm_ui$Internal$Model$finalizeNode,
							rendered.aN,
							rendered.dA,
							rendered.aD,
							$mdgriffith$elm_ui$Internal$Model$Unkeyed(
								A2($mdgriffith$elm_ui$Internal$Model$addChildren, unkeyed, rendered.eN))),
						dY: allStyles
					});
			}
		}
	});
var $mdgriffith$elm_ui$Internal$Model$Single = F3(
	function (a, b, c) {
		return {$: 3, a: a, b: b, c: c};
	});
var $mdgriffith$elm_ui$Internal$Model$Transform = function (a) {
	return {$: 10, a: a};
};
var $mdgriffith$elm_ui$Internal$Flag$Field = F2(
	function (a, b) {
		return {$: 0, a: a, b: b};
	});
var $elm$core$Bitwise$or = _Bitwise_or;
var $mdgriffith$elm_ui$Internal$Flag$add = F2(
	function (myFlag, _v0) {
		var one = _v0.a;
		var two = _v0.b;
		if (!myFlag.$) {
			var first = myFlag.a;
			return A2($mdgriffith$elm_ui$Internal$Flag$Field, first | one, two);
		} else {
			var second = myFlag.a;
			return A2($mdgriffith$elm_ui$Internal$Flag$Field, one, second | two);
		}
	});
var $mdgriffith$elm_ui$Internal$Model$ChildrenBehind = function (a) {
	return {$: 1, a: a};
};
var $mdgriffith$elm_ui$Internal$Model$ChildrenBehindAndInFront = F2(
	function (a, b) {
		return {$: 3, a: a, b: b};
	});
var $mdgriffith$elm_ui$Internal$Model$ChildrenInFront = function (a) {
	return {$: 2, a: a};
};
var $mdgriffith$elm_ui$Internal$Model$nearbyElement = F2(
	function (location, elem) {
		return A2(
			$elm$html$Html$div,
			_List_fromArray(
				[
					$elm$html$Html$Attributes$class(
					function () {
						switch (location) {
							case 0:
								return A2(
									$elm$core$String$join,
									' ',
									_List_fromArray(
										[$mdgriffith$elm_ui$Internal$Style$classes.bj, $mdgriffith$elm_ui$Internal$Style$classes.f8, $mdgriffith$elm_ui$Internal$Style$classes.ed]));
							case 1:
								return A2(
									$elm$core$String$join,
									' ',
									_List_fromArray(
										[$mdgriffith$elm_ui$Internal$Style$classes.bj, $mdgriffith$elm_ui$Internal$Style$classes.f8, $mdgriffith$elm_ui$Internal$Style$classes.ey]));
							case 2:
								return A2(
									$elm$core$String$join,
									' ',
									_List_fromArray(
										[$mdgriffith$elm_ui$Internal$Style$classes.bj, $mdgriffith$elm_ui$Internal$Style$classes.f8, $mdgriffith$elm_ui$Internal$Style$classes.fM]));
							case 3:
								return A2(
									$elm$core$String$join,
									' ',
									_List_fromArray(
										[$mdgriffith$elm_ui$Internal$Style$classes.bj, $mdgriffith$elm_ui$Internal$Style$classes.f8, $mdgriffith$elm_ui$Internal$Style$classes.fK]));
							case 4:
								return A2(
									$elm$core$String$join,
									' ',
									_List_fromArray(
										[$mdgriffith$elm_ui$Internal$Style$classes.bj, $mdgriffith$elm_ui$Internal$Style$classes.f8, $mdgriffith$elm_ui$Internal$Style$classes.fh]));
							default:
								return A2(
									$elm$core$String$join,
									' ',
									_List_fromArray(
										[$mdgriffith$elm_ui$Internal$Style$classes.bj, $mdgriffith$elm_ui$Internal$Style$classes.f8, $mdgriffith$elm_ui$Internal$Style$classes.ex]));
						}
					}())
				]),
			_List_fromArray(
				[
					function () {
					switch (elem.$) {
						case 3:
							return $elm$virtual_dom$VirtualDom$text('');
						case 2:
							var str = elem.a;
							return $mdgriffith$elm_ui$Internal$Model$textElement(str);
						case 0:
							var html = elem.a;
							return html($mdgriffith$elm_ui$Internal$Model$asEl);
						default:
							var styled = elem.a;
							return A2(styled.fd, $mdgriffith$elm_ui$Internal$Model$NoStyleSheet, $mdgriffith$elm_ui$Internal$Model$asEl);
					}
				}()
				]));
	});
var $mdgriffith$elm_ui$Internal$Model$addNearbyElement = F3(
	function (location, elem, existing) {
		var nearby = A2($mdgriffith$elm_ui$Internal$Model$nearbyElement, location, elem);
		switch (existing.$) {
			case 0:
				if (location === 5) {
					return $mdgriffith$elm_ui$Internal$Model$ChildrenBehind(
						_List_fromArray(
							[nearby]));
				} else {
					return $mdgriffith$elm_ui$Internal$Model$ChildrenInFront(
						_List_fromArray(
							[nearby]));
				}
			case 1:
				var existingBehind = existing.a;
				if (location === 5) {
					return $mdgriffith$elm_ui$Internal$Model$ChildrenBehind(
						A2($elm$core$List$cons, nearby, existingBehind));
				} else {
					return A2(
						$mdgriffith$elm_ui$Internal$Model$ChildrenBehindAndInFront,
						existingBehind,
						_List_fromArray(
							[nearby]));
				}
			case 2:
				var existingInFront = existing.a;
				if (location === 5) {
					return A2(
						$mdgriffith$elm_ui$Internal$Model$ChildrenBehindAndInFront,
						_List_fromArray(
							[nearby]),
						existingInFront);
				} else {
					return $mdgriffith$elm_ui$Internal$Model$ChildrenInFront(
						A2($elm$core$List$cons, nearby, existingInFront));
				}
			default:
				var existingBehind = existing.a;
				var existingInFront = existing.b;
				if (location === 5) {
					return A2(
						$mdgriffith$elm_ui$Internal$Model$ChildrenBehindAndInFront,
						A2($elm$core$List$cons, nearby, existingBehind),
						existingInFront);
				} else {
					return A2(
						$mdgriffith$elm_ui$Internal$Model$ChildrenBehindAndInFront,
						existingBehind,
						A2($elm$core$List$cons, nearby, existingInFront));
				}
		}
	});
var $mdgriffith$elm_ui$Internal$Model$Embedded = F2(
	function (a, b) {
		return {$: 2, a: a, b: b};
	});
var $mdgriffith$elm_ui$Internal$Model$NodeName = function (a) {
	return {$: 1, a: a};
};
var $mdgriffith$elm_ui$Internal$Model$addNodeName = F2(
	function (newNode, old) {
		switch (old.$) {
			case 0:
				return $mdgriffith$elm_ui$Internal$Model$NodeName(newNode);
			case 1:
				var name = old.a;
				return A2($mdgriffith$elm_ui$Internal$Model$Embedded, name, newNode);
			default:
				var x = old.a;
				var y = old.b;
				return A2($mdgriffith$elm_ui$Internal$Model$Embedded, x, y);
		}
	});
var $mdgriffith$elm_ui$Internal$Model$alignXName = function (align) {
	switch (align) {
		case 0:
			return $mdgriffith$elm_ui$Internal$Style$classes.ck + (' ' + $mdgriffith$elm_ui$Internal$Style$classes.cX);
		case 2:
			return $mdgriffith$elm_ui$Internal$Style$classes.ck + (' ' + $mdgriffith$elm_ui$Internal$Style$classes.cY);
		default:
			return $mdgriffith$elm_ui$Internal$Style$classes.ck + (' ' + $mdgriffith$elm_ui$Internal$Style$classes.ej);
	}
};
var $mdgriffith$elm_ui$Internal$Model$alignYName = function (align) {
	switch (align) {
		case 0:
			return $mdgriffith$elm_ui$Internal$Style$classes.cl + (' ' + $mdgriffith$elm_ui$Internal$Style$classes.ep);
		case 2:
			return $mdgriffith$elm_ui$Internal$Style$classes.cl + (' ' + $mdgriffith$elm_ui$Internal$Style$classes.ei);
		default:
			return $mdgriffith$elm_ui$Internal$Style$classes.cl + (' ' + $mdgriffith$elm_ui$Internal$Style$classes.ek);
	}
};
var $mdgriffith$elm_ui$Internal$Model$FullTransform = F4(
	function (a, b, c, d) {
		return {$: 2, a: a, b: b, c: c, d: d};
	});
var $mdgriffith$elm_ui$Internal$Model$Moved = function (a) {
	return {$: 1, a: a};
};
var $mdgriffith$elm_ui$Internal$Model$composeTransformation = F2(
	function (transform, component) {
		switch (transform.$) {
			case 0:
				switch (component.$) {
					case 0:
						var x = component.a;
						return $mdgriffith$elm_ui$Internal$Model$Moved(
							_Utils_Tuple3(x, 0, 0));
					case 1:
						var y = component.a;
						return $mdgriffith$elm_ui$Internal$Model$Moved(
							_Utils_Tuple3(0, y, 0));
					case 2:
						var z = component.a;
						return $mdgriffith$elm_ui$Internal$Model$Moved(
							_Utils_Tuple3(0, 0, z));
					case 3:
						var xyz = component.a;
						return $mdgriffith$elm_ui$Internal$Model$Moved(xyz);
					case 4:
						var xyz = component.a;
						var angle = component.b;
						return A4(
							$mdgriffith$elm_ui$Internal$Model$FullTransform,
							_Utils_Tuple3(0, 0, 0),
							_Utils_Tuple3(1, 1, 1),
							xyz,
							angle);
					default:
						var xyz = component.a;
						return A4(
							$mdgriffith$elm_ui$Internal$Model$FullTransform,
							_Utils_Tuple3(0, 0, 0),
							xyz,
							_Utils_Tuple3(0, 0, 1),
							0);
				}
			case 1:
				var moved = transform.a;
				var x = moved.a;
				var y = moved.b;
				var z = moved.c;
				switch (component.$) {
					case 0:
						var newX = component.a;
						return $mdgriffith$elm_ui$Internal$Model$Moved(
							_Utils_Tuple3(newX, y, z));
					case 1:
						var newY = component.a;
						return $mdgriffith$elm_ui$Internal$Model$Moved(
							_Utils_Tuple3(x, newY, z));
					case 2:
						var newZ = component.a;
						return $mdgriffith$elm_ui$Internal$Model$Moved(
							_Utils_Tuple3(x, y, newZ));
					case 3:
						var xyz = component.a;
						return $mdgriffith$elm_ui$Internal$Model$Moved(xyz);
					case 4:
						var xyz = component.a;
						var angle = component.b;
						return A4(
							$mdgriffith$elm_ui$Internal$Model$FullTransform,
							moved,
							_Utils_Tuple3(1, 1, 1),
							xyz,
							angle);
					default:
						var scale = component.a;
						return A4(
							$mdgriffith$elm_ui$Internal$Model$FullTransform,
							moved,
							scale,
							_Utils_Tuple3(0, 0, 1),
							0);
				}
			default:
				var moved = transform.a;
				var x = moved.a;
				var y = moved.b;
				var z = moved.c;
				var scaled = transform.b;
				var origin = transform.c;
				var angle = transform.d;
				switch (component.$) {
					case 0:
						var newX = component.a;
						return A4(
							$mdgriffith$elm_ui$Internal$Model$FullTransform,
							_Utils_Tuple3(newX, y, z),
							scaled,
							origin,
							angle);
					case 1:
						var newY = component.a;
						return A4(
							$mdgriffith$elm_ui$Internal$Model$FullTransform,
							_Utils_Tuple3(x, newY, z),
							scaled,
							origin,
							angle);
					case 2:
						var newZ = component.a;
						return A4(
							$mdgriffith$elm_ui$Internal$Model$FullTransform,
							_Utils_Tuple3(x, y, newZ),
							scaled,
							origin,
							angle);
					case 3:
						var newMove = component.a;
						return A4($mdgriffith$elm_ui$Internal$Model$FullTransform, newMove, scaled, origin, angle);
					case 4:
						var newOrigin = component.a;
						var newAngle = component.b;
						return A4($mdgriffith$elm_ui$Internal$Model$FullTransform, moved, scaled, newOrigin, newAngle);
					default:
						var newScale = component.a;
						return A4($mdgriffith$elm_ui$Internal$Model$FullTransform, moved, newScale, origin, angle);
				}
		}
	});
var $mdgriffith$elm_ui$Internal$Flag$height = $mdgriffith$elm_ui$Internal$Flag$flag(7);
var $mdgriffith$elm_ui$Internal$Flag$heightContent = $mdgriffith$elm_ui$Internal$Flag$flag(36);
var $mdgriffith$elm_ui$Internal$Flag$merge = F2(
	function (_v0, _v1) {
		var one = _v0.a;
		var two = _v0.b;
		var three = _v1.a;
		var four = _v1.b;
		return A2($mdgriffith$elm_ui$Internal$Flag$Field, one | three, two | four);
	});
var $mdgriffith$elm_ui$Internal$Flag$none = A2($mdgriffith$elm_ui$Internal$Flag$Field, 0, 0);
var $mdgriffith$elm_ui$Internal$Model$renderHeight = function (h) {
	switch (h.$) {
		case 0:
			var px = h.a;
			var val = $elm$core$String$fromInt(px);
			var name = 'height-px-' + val;
			return _Utils_Tuple3(
				$mdgriffith$elm_ui$Internal$Flag$none,
				$mdgriffith$elm_ui$Internal$Style$classes.dj + (' ' + name),
				_List_fromArray(
					[
						A3($mdgriffith$elm_ui$Internal$Model$Single, name, 'height', val + 'px')
					]));
		case 1:
			return _Utils_Tuple3(
				A2($mdgriffith$elm_ui$Internal$Flag$add, $mdgriffith$elm_ui$Internal$Flag$heightContent, $mdgriffith$elm_ui$Internal$Flag$none),
				$mdgriffith$elm_ui$Internal$Style$classes.cB,
				_List_Nil);
		case 2:
			var portion = h.a;
			return (portion === 1) ? _Utils_Tuple3(
				A2($mdgriffith$elm_ui$Internal$Flag$add, $mdgriffith$elm_ui$Internal$Flag$heightFill, $mdgriffith$elm_ui$Internal$Flag$none),
				$mdgriffith$elm_ui$Internal$Style$classes.cC,
				_List_Nil) : _Utils_Tuple3(
				A2($mdgriffith$elm_ui$Internal$Flag$add, $mdgriffith$elm_ui$Internal$Flag$heightFill, $mdgriffith$elm_ui$Internal$Flag$none),
				$mdgriffith$elm_ui$Internal$Style$classes.dk + (' height-fill-' + $elm$core$String$fromInt(portion)),
				_List_fromArray(
					[
						A3(
						$mdgriffith$elm_ui$Internal$Model$Single,
						$mdgriffith$elm_ui$Internal$Style$classes.er + ('.' + ($mdgriffith$elm_ui$Internal$Style$classes.aq + (' > ' + $mdgriffith$elm_ui$Internal$Style$dot(
							'height-fill-' + $elm$core$String$fromInt(portion))))),
						'flex-grow',
						$elm$core$String$fromInt(portion * 100000))
					]));
		case 3:
			var minSize = h.a;
			var len = h.b;
			var cls = 'min-height-' + $elm$core$String$fromInt(minSize);
			var style = A3(
				$mdgriffith$elm_ui$Internal$Model$Single,
				cls,
				'min-height',
				$elm$core$String$fromInt(minSize) + 'px !important');
			var _v1 = $mdgriffith$elm_ui$Internal$Model$renderHeight(len);
			var newFlag = _v1.a;
			var newAttrs = _v1.b;
			var newStyle = _v1.c;
			return _Utils_Tuple3(
				A2($mdgriffith$elm_ui$Internal$Flag$add, $mdgriffith$elm_ui$Internal$Flag$heightBetween, newFlag),
				cls + (' ' + newAttrs),
				A2($elm$core$List$cons, style, newStyle));
		default:
			var maxSize = h.a;
			var len = h.b;
			var cls = 'max-height-' + $elm$core$String$fromInt(maxSize);
			var style = A3(
				$mdgriffith$elm_ui$Internal$Model$Single,
				cls,
				'max-height',
				$elm$core$String$fromInt(maxSize) + 'px');
			var _v2 = $mdgriffith$elm_ui$Internal$Model$renderHeight(len);
			var newFlag = _v2.a;
			var newAttrs = _v2.b;
			var newStyle = _v2.c;
			return _Utils_Tuple3(
				A2($mdgriffith$elm_ui$Internal$Flag$add, $mdgriffith$elm_ui$Internal$Flag$heightBetween, newFlag),
				cls + (' ' + newAttrs),
				A2($elm$core$List$cons, style, newStyle));
	}
};
var $mdgriffith$elm_ui$Internal$Flag$widthContent = $mdgriffith$elm_ui$Internal$Flag$flag(38);
var $mdgriffith$elm_ui$Internal$Model$renderWidth = function (w) {
	switch (w.$) {
		case 0:
			var px = w.a;
			return _Utils_Tuple3(
				$mdgriffith$elm_ui$Internal$Flag$none,
				$mdgriffith$elm_ui$Internal$Style$classes.d8 + (' width-px-' + $elm$core$String$fromInt(px)),
				_List_fromArray(
					[
						A3(
						$mdgriffith$elm_ui$Internal$Model$Single,
						'width-px-' + $elm$core$String$fromInt(px),
						'width',
						$elm$core$String$fromInt(px) + 'px')
					]));
		case 1:
			return _Utils_Tuple3(
				A2($mdgriffith$elm_ui$Internal$Flag$add, $mdgriffith$elm_ui$Internal$Flag$widthContent, $mdgriffith$elm_ui$Internal$Flag$none),
				$mdgriffith$elm_ui$Internal$Style$classes.cP,
				_List_Nil);
		case 2:
			var portion = w.a;
			return (portion === 1) ? _Utils_Tuple3(
				A2($mdgriffith$elm_ui$Internal$Flag$add, $mdgriffith$elm_ui$Internal$Flag$widthFill, $mdgriffith$elm_ui$Internal$Flag$none),
				$mdgriffith$elm_ui$Internal$Style$classes.cQ,
				_List_Nil) : _Utils_Tuple3(
				A2($mdgriffith$elm_ui$Internal$Flag$add, $mdgriffith$elm_ui$Internal$Flag$widthFill, $mdgriffith$elm_ui$Internal$Flag$none),
				$mdgriffith$elm_ui$Internal$Style$classes.d9 + (' width-fill-' + $elm$core$String$fromInt(portion)),
				_List_fromArray(
					[
						A3(
						$mdgriffith$elm_ui$Internal$Model$Single,
						$mdgriffith$elm_ui$Internal$Style$classes.er + ('.' + ($mdgriffith$elm_ui$Internal$Style$classes.ab + (' > ' + $mdgriffith$elm_ui$Internal$Style$dot(
							'width-fill-' + $elm$core$String$fromInt(portion))))),
						'flex-grow',
						$elm$core$String$fromInt(portion * 100000))
					]));
		case 3:
			var minSize = w.a;
			var len = w.b;
			var cls = 'min-width-' + $elm$core$String$fromInt(minSize);
			var style = A3(
				$mdgriffith$elm_ui$Internal$Model$Single,
				cls,
				'min-width',
				$elm$core$String$fromInt(minSize) + 'px');
			var _v1 = $mdgriffith$elm_ui$Internal$Model$renderWidth(len);
			var newFlag = _v1.a;
			var newAttrs = _v1.b;
			var newStyle = _v1.c;
			return _Utils_Tuple3(
				A2($mdgriffith$elm_ui$Internal$Flag$add, $mdgriffith$elm_ui$Internal$Flag$widthBetween, newFlag),
				cls + (' ' + newAttrs),
				A2($elm$core$List$cons, style, newStyle));
		default:
			var maxSize = w.a;
			var len = w.b;
			var cls = 'max-width-' + $elm$core$String$fromInt(maxSize);
			var style = A3(
				$mdgriffith$elm_ui$Internal$Model$Single,
				cls,
				'max-width',
				$elm$core$String$fromInt(maxSize) + 'px');
			var _v2 = $mdgriffith$elm_ui$Internal$Model$renderWidth(len);
			var newFlag = _v2.a;
			var newAttrs = _v2.b;
			var newStyle = _v2.c;
			return _Utils_Tuple3(
				A2($mdgriffith$elm_ui$Internal$Flag$add, $mdgriffith$elm_ui$Internal$Flag$widthBetween, newFlag),
				cls + (' ' + newAttrs),
				A2($elm$core$List$cons, style, newStyle));
	}
};
var $mdgriffith$elm_ui$Internal$Flag$borderWidth = $mdgriffith$elm_ui$Internal$Flag$flag(27);
var $mdgriffith$elm_ui$Internal$Model$skippable = F2(
	function (flag, style) {
		if (_Utils_eq(flag, $mdgriffith$elm_ui$Internal$Flag$borderWidth)) {
			if (style.$ === 3) {
				var val = style.c;
				switch (val) {
					case '0px':
						return true;
					case '1px':
						return true;
					case '2px':
						return true;
					case '3px':
						return true;
					case '4px':
						return true;
					case '5px':
						return true;
					case '6px':
						return true;
					default:
						return false;
				}
			} else {
				return false;
			}
		} else {
			switch (style.$) {
				case 2:
					var i = style.a;
					return (i >= 8) && (i <= 32);
				case 7:
					var name = style.a;
					var t = style.b;
					var r = style.c;
					var b = style.d;
					var l = style.e;
					return _Utils_eq(t, b) && (_Utils_eq(t, r) && (_Utils_eq(t, l) && ((t >= 0) && (t <= 24))));
				default:
					return false;
			}
		}
	});
var $mdgriffith$elm_ui$Internal$Flag$width = $mdgriffith$elm_ui$Internal$Flag$flag(6);
var $mdgriffith$elm_ui$Internal$Flag$xAlign = $mdgriffith$elm_ui$Internal$Flag$flag(30);
var $mdgriffith$elm_ui$Internal$Flag$yAlign = $mdgriffith$elm_ui$Internal$Flag$flag(29);
var $mdgriffith$elm_ui$Internal$Model$gatherAttrRecursive = F8(
	function (classes, node, has, transform, styles, attrs, children, elementAttrs) {
		gatherAttrRecursive:
		while (true) {
			if (!elementAttrs.b) {
				var _v1 = $mdgriffith$elm_ui$Internal$Model$transformClass(transform);
				if (_v1.$ === 1) {
					return {
						aD: A2(
							$elm$core$List$cons,
							$elm$html$Html$Attributes$class(classes),
							attrs),
						eN: children,
						aN: has,
						dA: node,
						dY: styles
					};
				} else {
					var _class = _v1.a;
					return {
						aD: A2(
							$elm$core$List$cons,
							$elm$html$Html$Attributes$class(classes + (' ' + _class)),
							attrs),
						eN: children,
						aN: has,
						dA: node,
						dY: A2(
							$elm$core$List$cons,
							$mdgriffith$elm_ui$Internal$Model$Transform(transform),
							styles)
					};
				}
			} else {
				var attribute = elementAttrs.a;
				var remaining = elementAttrs.b;
				switch (attribute.$) {
					case 0:
						var $temp$classes = classes,
							$temp$node = node,
							$temp$has = has,
							$temp$transform = transform,
							$temp$styles = styles,
							$temp$attrs = attrs,
							$temp$children = children,
							$temp$elementAttrs = remaining;
						classes = $temp$classes;
						node = $temp$node;
						has = $temp$has;
						transform = $temp$transform;
						styles = $temp$styles;
						attrs = $temp$attrs;
						children = $temp$children;
						elementAttrs = $temp$elementAttrs;
						continue gatherAttrRecursive;
					case 3:
						var flag = attribute.a;
						var exactClassName = attribute.b;
						if (A2($mdgriffith$elm_ui$Internal$Flag$present, flag, has)) {
							var $temp$classes = classes,
								$temp$node = node,
								$temp$has = has,
								$temp$transform = transform,
								$temp$styles = styles,
								$temp$attrs = attrs,
								$temp$children = children,
								$temp$elementAttrs = remaining;
							classes = $temp$classes;
							node = $temp$node;
							has = $temp$has;
							transform = $temp$transform;
							styles = $temp$styles;
							attrs = $temp$attrs;
							children = $temp$children;
							elementAttrs = $temp$elementAttrs;
							continue gatherAttrRecursive;
						} else {
							var $temp$classes = exactClassName + (' ' + classes),
								$temp$node = node,
								$temp$has = A2($mdgriffith$elm_ui$Internal$Flag$add, flag, has),
								$temp$transform = transform,
								$temp$styles = styles,
								$temp$attrs = attrs,
								$temp$children = children,
								$temp$elementAttrs = remaining;
							classes = $temp$classes;
							node = $temp$node;
							has = $temp$has;
							transform = $temp$transform;
							styles = $temp$styles;
							attrs = $temp$attrs;
							children = $temp$children;
							elementAttrs = $temp$elementAttrs;
							continue gatherAttrRecursive;
						}
					case 1:
						var actualAttribute = attribute.a;
						var $temp$classes = classes,
							$temp$node = node,
							$temp$has = has,
							$temp$transform = transform,
							$temp$styles = styles,
							$temp$attrs = A2($elm$core$List$cons, actualAttribute, attrs),
							$temp$children = children,
							$temp$elementAttrs = remaining;
						classes = $temp$classes;
						node = $temp$node;
						has = $temp$has;
						transform = $temp$transform;
						styles = $temp$styles;
						attrs = $temp$attrs;
						children = $temp$children;
						elementAttrs = $temp$elementAttrs;
						continue gatherAttrRecursive;
					case 4:
						var flag = attribute.a;
						var style = attribute.b;
						if (A2($mdgriffith$elm_ui$Internal$Flag$present, flag, has)) {
							var $temp$classes = classes,
								$temp$node = node,
								$temp$has = has,
								$temp$transform = transform,
								$temp$styles = styles,
								$temp$attrs = attrs,
								$temp$children = children,
								$temp$elementAttrs = remaining;
							classes = $temp$classes;
							node = $temp$node;
							has = $temp$has;
							transform = $temp$transform;
							styles = $temp$styles;
							attrs = $temp$attrs;
							children = $temp$children;
							elementAttrs = $temp$elementAttrs;
							continue gatherAttrRecursive;
						} else {
							if (A2($mdgriffith$elm_ui$Internal$Model$skippable, flag, style)) {
								var $temp$classes = $mdgriffith$elm_ui$Internal$Model$getStyleName(style) + (' ' + classes),
									$temp$node = node,
									$temp$has = A2($mdgriffith$elm_ui$Internal$Flag$add, flag, has),
									$temp$transform = transform,
									$temp$styles = styles,
									$temp$attrs = attrs,
									$temp$children = children,
									$temp$elementAttrs = remaining;
								classes = $temp$classes;
								node = $temp$node;
								has = $temp$has;
								transform = $temp$transform;
								styles = $temp$styles;
								attrs = $temp$attrs;
								children = $temp$children;
								elementAttrs = $temp$elementAttrs;
								continue gatherAttrRecursive;
							} else {
								var $temp$classes = $mdgriffith$elm_ui$Internal$Model$getStyleName(style) + (' ' + classes),
									$temp$node = node,
									$temp$has = A2($mdgriffith$elm_ui$Internal$Flag$add, flag, has),
									$temp$transform = transform,
									$temp$styles = A2($elm$core$List$cons, style, styles),
									$temp$attrs = attrs,
									$temp$children = children,
									$temp$elementAttrs = remaining;
								classes = $temp$classes;
								node = $temp$node;
								has = $temp$has;
								transform = $temp$transform;
								styles = $temp$styles;
								attrs = $temp$attrs;
								children = $temp$children;
								elementAttrs = $temp$elementAttrs;
								continue gatherAttrRecursive;
							}
						}
					case 10:
						var flag = attribute.a;
						var component = attribute.b;
						var $temp$classes = classes,
							$temp$node = node,
							$temp$has = A2($mdgriffith$elm_ui$Internal$Flag$add, flag, has),
							$temp$transform = A2($mdgriffith$elm_ui$Internal$Model$composeTransformation, transform, component),
							$temp$styles = styles,
							$temp$attrs = attrs,
							$temp$children = children,
							$temp$elementAttrs = remaining;
						classes = $temp$classes;
						node = $temp$node;
						has = $temp$has;
						transform = $temp$transform;
						styles = $temp$styles;
						attrs = $temp$attrs;
						children = $temp$children;
						elementAttrs = $temp$elementAttrs;
						continue gatherAttrRecursive;
					case 7:
						var width = attribute.a;
						if (A2($mdgriffith$elm_ui$Internal$Flag$present, $mdgriffith$elm_ui$Internal$Flag$width, has)) {
							var $temp$classes = classes,
								$temp$node = node,
								$temp$has = has,
								$temp$transform = transform,
								$temp$styles = styles,
								$temp$attrs = attrs,
								$temp$children = children,
								$temp$elementAttrs = remaining;
							classes = $temp$classes;
							node = $temp$node;
							has = $temp$has;
							transform = $temp$transform;
							styles = $temp$styles;
							attrs = $temp$attrs;
							children = $temp$children;
							elementAttrs = $temp$elementAttrs;
							continue gatherAttrRecursive;
						} else {
							switch (width.$) {
								case 0:
									var px = width.a;
									var $temp$classes = ($mdgriffith$elm_ui$Internal$Style$classes.d8 + (' width-px-' + $elm$core$String$fromInt(px))) + (' ' + classes),
										$temp$node = node,
										$temp$has = A2($mdgriffith$elm_ui$Internal$Flag$add, $mdgriffith$elm_ui$Internal$Flag$width, has),
										$temp$transform = transform,
										$temp$styles = A2(
										$elm$core$List$cons,
										A3(
											$mdgriffith$elm_ui$Internal$Model$Single,
											'width-px-' + $elm$core$String$fromInt(px),
											'width',
											$elm$core$String$fromInt(px) + 'px'),
										styles),
										$temp$attrs = attrs,
										$temp$children = children,
										$temp$elementAttrs = remaining;
									classes = $temp$classes;
									node = $temp$node;
									has = $temp$has;
									transform = $temp$transform;
									styles = $temp$styles;
									attrs = $temp$attrs;
									children = $temp$children;
									elementAttrs = $temp$elementAttrs;
									continue gatherAttrRecursive;
								case 1:
									var $temp$classes = classes + (' ' + $mdgriffith$elm_ui$Internal$Style$classes.cP),
										$temp$node = node,
										$temp$has = A2(
										$mdgriffith$elm_ui$Internal$Flag$add,
										$mdgriffith$elm_ui$Internal$Flag$widthContent,
										A2($mdgriffith$elm_ui$Internal$Flag$add, $mdgriffith$elm_ui$Internal$Flag$width, has)),
										$temp$transform = transform,
										$temp$styles = styles,
										$temp$attrs = attrs,
										$temp$children = children,
										$temp$elementAttrs = remaining;
									classes = $temp$classes;
									node = $temp$node;
									has = $temp$has;
									transform = $temp$transform;
									styles = $temp$styles;
									attrs = $temp$attrs;
									children = $temp$children;
									elementAttrs = $temp$elementAttrs;
									continue gatherAttrRecursive;
								case 2:
									var portion = width.a;
									if (portion === 1) {
										var $temp$classes = classes + (' ' + $mdgriffith$elm_ui$Internal$Style$classes.cQ),
											$temp$node = node,
											$temp$has = A2(
											$mdgriffith$elm_ui$Internal$Flag$add,
											$mdgriffith$elm_ui$Internal$Flag$widthFill,
											A2($mdgriffith$elm_ui$Internal$Flag$add, $mdgriffith$elm_ui$Internal$Flag$width, has)),
											$temp$transform = transform,
											$temp$styles = styles,
											$temp$attrs = attrs,
											$temp$children = children,
											$temp$elementAttrs = remaining;
										classes = $temp$classes;
										node = $temp$node;
										has = $temp$has;
										transform = $temp$transform;
										styles = $temp$styles;
										attrs = $temp$attrs;
										children = $temp$children;
										elementAttrs = $temp$elementAttrs;
										continue gatherAttrRecursive;
									} else {
										var $temp$classes = classes + (' ' + ($mdgriffith$elm_ui$Internal$Style$classes.d9 + (' width-fill-' + $elm$core$String$fromInt(portion)))),
											$temp$node = node,
											$temp$has = A2(
											$mdgriffith$elm_ui$Internal$Flag$add,
											$mdgriffith$elm_ui$Internal$Flag$widthFill,
											A2($mdgriffith$elm_ui$Internal$Flag$add, $mdgriffith$elm_ui$Internal$Flag$width, has)),
											$temp$transform = transform,
											$temp$styles = A2(
											$elm$core$List$cons,
											A3(
												$mdgriffith$elm_ui$Internal$Model$Single,
												$mdgriffith$elm_ui$Internal$Style$classes.er + ('.' + ($mdgriffith$elm_ui$Internal$Style$classes.ab + (' > ' + $mdgriffith$elm_ui$Internal$Style$dot(
													'width-fill-' + $elm$core$String$fromInt(portion))))),
												'flex-grow',
												$elm$core$String$fromInt(portion * 100000)),
											styles),
											$temp$attrs = attrs,
											$temp$children = children,
											$temp$elementAttrs = remaining;
										classes = $temp$classes;
										node = $temp$node;
										has = $temp$has;
										transform = $temp$transform;
										styles = $temp$styles;
										attrs = $temp$attrs;
										children = $temp$children;
										elementAttrs = $temp$elementAttrs;
										continue gatherAttrRecursive;
									}
								default:
									var _v4 = $mdgriffith$elm_ui$Internal$Model$renderWidth(width);
									var addToFlags = _v4.a;
									var newClass = _v4.b;
									var newStyles = _v4.c;
									var $temp$classes = classes + (' ' + newClass),
										$temp$node = node,
										$temp$has = A2(
										$mdgriffith$elm_ui$Internal$Flag$merge,
										addToFlags,
										A2($mdgriffith$elm_ui$Internal$Flag$add, $mdgriffith$elm_ui$Internal$Flag$width, has)),
										$temp$transform = transform,
										$temp$styles = _Utils_ap(newStyles, styles),
										$temp$attrs = attrs,
										$temp$children = children,
										$temp$elementAttrs = remaining;
									classes = $temp$classes;
									node = $temp$node;
									has = $temp$has;
									transform = $temp$transform;
									styles = $temp$styles;
									attrs = $temp$attrs;
									children = $temp$children;
									elementAttrs = $temp$elementAttrs;
									continue gatherAttrRecursive;
							}
						}
					case 8:
						var height = attribute.a;
						if (A2($mdgriffith$elm_ui$Internal$Flag$present, $mdgriffith$elm_ui$Internal$Flag$height, has)) {
							var $temp$classes = classes,
								$temp$node = node,
								$temp$has = has,
								$temp$transform = transform,
								$temp$styles = styles,
								$temp$attrs = attrs,
								$temp$children = children,
								$temp$elementAttrs = remaining;
							classes = $temp$classes;
							node = $temp$node;
							has = $temp$has;
							transform = $temp$transform;
							styles = $temp$styles;
							attrs = $temp$attrs;
							children = $temp$children;
							elementAttrs = $temp$elementAttrs;
							continue gatherAttrRecursive;
						} else {
							switch (height.$) {
								case 0:
									var px = height.a;
									var val = $elm$core$String$fromInt(px) + 'px';
									var name = 'height-px-' + val;
									var $temp$classes = $mdgriffith$elm_ui$Internal$Style$classes.dj + (' ' + (name + (' ' + classes))),
										$temp$node = node,
										$temp$has = A2($mdgriffith$elm_ui$Internal$Flag$add, $mdgriffith$elm_ui$Internal$Flag$height, has),
										$temp$transform = transform,
										$temp$styles = A2(
										$elm$core$List$cons,
										A3($mdgriffith$elm_ui$Internal$Model$Single, name, 'height ', val),
										styles),
										$temp$attrs = attrs,
										$temp$children = children,
										$temp$elementAttrs = remaining;
									classes = $temp$classes;
									node = $temp$node;
									has = $temp$has;
									transform = $temp$transform;
									styles = $temp$styles;
									attrs = $temp$attrs;
									children = $temp$children;
									elementAttrs = $temp$elementAttrs;
									continue gatherAttrRecursive;
								case 1:
									var $temp$classes = $mdgriffith$elm_ui$Internal$Style$classes.cB + (' ' + classes),
										$temp$node = node,
										$temp$has = A2(
										$mdgriffith$elm_ui$Internal$Flag$add,
										$mdgriffith$elm_ui$Internal$Flag$heightContent,
										A2($mdgriffith$elm_ui$Internal$Flag$add, $mdgriffith$elm_ui$Internal$Flag$height, has)),
										$temp$transform = transform,
										$temp$styles = styles,
										$temp$attrs = attrs,
										$temp$children = children,
										$temp$elementAttrs = remaining;
									classes = $temp$classes;
									node = $temp$node;
									has = $temp$has;
									transform = $temp$transform;
									styles = $temp$styles;
									attrs = $temp$attrs;
									children = $temp$children;
									elementAttrs = $temp$elementAttrs;
									continue gatherAttrRecursive;
								case 2:
									var portion = height.a;
									if (portion === 1) {
										var $temp$classes = $mdgriffith$elm_ui$Internal$Style$classes.cC + (' ' + classes),
											$temp$node = node,
											$temp$has = A2(
											$mdgriffith$elm_ui$Internal$Flag$add,
											$mdgriffith$elm_ui$Internal$Flag$heightFill,
											A2($mdgriffith$elm_ui$Internal$Flag$add, $mdgriffith$elm_ui$Internal$Flag$height, has)),
											$temp$transform = transform,
											$temp$styles = styles,
											$temp$attrs = attrs,
											$temp$children = children,
											$temp$elementAttrs = remaining;
										classes = $temp$classes;
										node = $temp$node;
										has = $temp$has;
										transform = $temp$transform;
										styles = $temp$styles;
										attrs = $temp$attrs;
										children = $temp$children;
										elementAttrs = $temp$elementAttrs;
										continue gatherAttrRecursive;
									} else {
										var $temp$classes = classes + (' ' + ($mdgriffith$elm_ui$Internal$Style$classes.dk + (' height-fill-' + $elm$core$String$fromInt(portion)))),
											$temp$node = node,
											$temp$has = A2(
											$mdgriffith$elm_ui$Internal$Flag$add,
											$mdgriffith$elm_ui$Internal$Flag$heightFill,
											A2($mdgriffith$elm_ui$Internal$Flag$add, $mdgriffith$elm_ui$Internal$Flag$height, has)),
											$temp$transform = transform,
											$temp$styles = A2(
											$elm$core$List$cons,
											A3(
												$mdgriffith$elm_ui$Internal$Model$Single,
												$mdgriffith$elm_ui$Internal$Style$classes.er + ('.' + ($mdgriffith$elm_ui$Internal$Style$classes.aq + (' > ' + $mdgriffith$elm_ui$Internal$Style$dot(
													'height-fill-' + $elm$core$String$fromInt(portion))))),
												'flex-grow',
												$elm$core$String$fromInt(portion * 100000)),
											styles),
											$temp$attrs = attrs,
											$temp$children = children,
											$temp$elementAttrs = remaining;
										classes = $temp$classes;
										node = $temp$node;
										has = $temp$has;
										transform = $temp$transform;
										styles = $temp$styles;
										attrs = $temp$attrs;
										children = $temp$children;
										elementAttrs = $temp$elementAttrs;
										continue gatherAttrRecursive;
									}
								default:
									var _v6 = $mdgriffith$elm_ui$Internal$Model$renderHeight(height);
									var addToFlags = _v6.a;
									var newClass = _v6.b;
									var newStyles = _v6.c;
									var $temp$classes = classes + (' ' + newClass),
										$temp$node = node,
										$temp$has = A2(
										$mdgriffith$elm_ui$Internal$Flag$merge,
										addToFlags,
										A2($mdgriffith$elm_ui$Internal$Flag$add, $mdgriffith$elm_ui$Internal$Flag$height, has)),
										$temp$transform = transform,
										$temp$styles = _Utils_ap(newStyles, styles),
										$temp$attrs = attrs,
										$temp$children = children,
										$temp$elementAttrs = remaining;
									classes = $temp$classes;
									node = $temp$node;
									has = $temp$has;
									transform = $temp$transform;
									styles = $temp$styles;
									attrs = $temp$attrs;
									children = $temp$children;
									elementAttrs = $temp$elementAttrs;
									continue gatherAttrRecursive;
							}
						}
					case 2:
						var description = attribute.a;
						switch (description.$) {
							case 0:
								var $temp$classes = classes,
									$temp$node = A2($mdgriffith$elm_ui$Internal$Model$addNodeName, 'main', node),
									$temp$has = has,
									$temp$transform = transform,
									$temp$styles = styles,
									$temp$attrs = attrs,
									$temp$children = children,
									$temp$elementAttrs = remaining;
								classes = $temp$classes;
								node = $temp$node;
								has = $temp$has;
								transform = $temp$transform;
								styles = $temp$styles;
								attrs = $temp$attrs;
								children = $temp$children;
								elementAttrs = $temp$elementAttrs;
								continue gatherAttrRecursive;
							case 1:
								var $temp$classes = classes,
									$temp$node = A2($mdgriffith$elm_ui$Internal$Model$addNodeName, 'nav', node),
									$temp$has = has,
									$temp$transform = transform,
									$temp$styles = styles,
									$temp$attrs = attrs,
									$temp$children = children,
									$temp$elementAttrs = remaining;
								classes = $temp$classes;
								node = $temp$node;
								has = $temp$has;
								transform = $temp$transform;
								styles = $temp$styles;
								attrs = $temp$attrs;
								children = $temp$children;
								elementAttrs = $temp$elementAttrs;
								continue gatherAttrRecursive;
							case 2:
								var $temp$classes = classes,
									$temp$node = A2($mdgriffith$elm_ui$Internal$Model$addNodeName, 'footer', node),
									$temp$has = has,
									$temp$transform = transform,
									$temp$styles = styles,
									$temp$attrs = attrs,
									$temp$children = children,
									$temp$elementAttrs = remaining;
								classes = $temp$classes;
								node = $temp$node;
								has = $temp$has;
								transform = $temp$transform;
								styles = $temp$styles;
								attrs = $temp$attrs;
								children = $temp$children;
								elementAttrs = $temp$elementAttrs;
								continue gatherAttrRecursive;
							case 3:
								var $temp$classes = classes,
									$temp$node = A2($mdgriffith$elm_ui$Internal$Model$addNodeName, 'aside', node),
									$temp$has = has,
									$temp$transform = transform,
									$temp$styles = styles,
									$temp$attrs = attrs,
									$temp$children = children,
									$temp$elementAttrs = remaining;
								classes = $temp$classes;
								node = $temp$node;
								has = $temp$has;
								transform = $temp$transform;
								styles = $temp$styles;
								attrs = $temp$attrs;
								children = $temp$children;
								elementAttrs = $temp$elementAttrs;
								continue gatherAttrRecursive;
							case 4:
								var i = description.a;
								if (i <= 1) {
									var $temp$classes = classes,
										$temp$node = A2($mdgriffith$elm_ui$Internal$Model$addNodeName, 'h1', node),
										$temp$has = has,
										$temp$transform = transform,
										$temp$styles = styles,
										$temp$attrs = attrs,
										$temp$children = children,
										$temp$elementAttrs = remaining;
									classes = $temp$classes;
									node = $temp$node;
									has = $temp$has;
									transform = $temp$transform;
									styles = $temp$styles;
									attrs = $temp$attrs;
									children = $temp$children;
									elementAttrs = $temp$elementAttrs;
									continue gatherAttrRecursive;
								} else {
									if (i < 7) {
										var $temp$classes = classes,
											$temp$node = A2(
											$mdgriffith$elm_ui$Internal$Model$addNodeName,
											'h' + $elm$core$String$fromInt(i),
											node),
											$temp$has = has,
											$temp$transform = transform,
											$temp$styles = styles,
											$temp$attrs = attrs,
											$temp$children = children,
											$temp$elementAttrs = remaining;
										classes = $temp$classes;
										node = $temp$node;
										has = $temp$has;
										transform = $temp$transform;
										styles = $temp$styles;
										attrs = $temp$attrs;
										children = $temp$children;
										elementAttrs = $temp$elementAttrs;
										continue gatherAttrRecursive;
									} else {
										var $temp$classes = classes,
											$temp$node = A2($mdgriffith$elm_ui$Internal$Model$addNodeName, 'h6', node),
											$temp$has = has,
											$temp$transform = transform,
											$temp$styles = styles,
											$temp$attrs = attrs,
											$temp$children = children,
											$temp$elementAttrs = remaining;
										classes = $temp$classes;
										node = $temp$node;
										has = $temp$has;
										transform = $temp$transform;
										styles = $temp$styles;
										attrs = $temp$attrs;
										children = $temp$children;
										elementAttrs = $temp$elementAttrs;
										continue gatherAttrRecursive;
									}
								}
							case 9:
								var $temp$classes = classes,
									$temp$node = node,
									$temp$has = has,
									$temp$transform = transform,
									$temp$styles = styles,
									$temp$attrs = attrs,
									$temp$children = children,
									$temp$elementAttrs = remaining;
								classes = $temp$classes;
								node = $temp$node;
								has = $temp$has;
								transform = $temp$transform;
								styles = $temp$styles;
								attrs = $temp$attrs;
								children = $temp$children;
								elementAttrs = $temp$elementAttrs;
								continue gatherAttrRecursive;
							case 8:
								var $temp$classes = classes,
									$temp$node = node,
									$temp$has = has,
									$temp$transform = transform,
									$temp$styles = styles,
									$temp$attrs = A2(
									$elm$core$List$cons,
									A2($elm$virtual_dom$VirtualDom$attribute, 'role', 'button'),
									attrs),
									$temp$children = children,
									$temp$elementAttrs = remaining;
								classes = $temp$classes;
								node = $temp$node;
								has = $temp$has;
								transform = $temp$transform;
								styles = $temp$styles;
								attrs = $temp$attrs;
								children = $temp$children;
								elementAttrs = $temp$elementAttrs;
								continue gatherAttrRecursive;
							case 5:
								var label = description.a;
								var $temp$classes = classes,
									$temp$node = node,
									$temp$has = has,
									$temp$transform = transform,
									$temp$styles = styles,
									$temp$attrs = A2(
									$elm$core$List$cons,
									A2($elm$virtual_dom$VirtualDom$attribute, 'aria-label', label),
									attrs),
									$temp$children = children,
									$temp$elementAttrs = remaining;
								classes = $temp$classes;
								node = $temp$node;
								has = $temp$has;
								transform = $temp$transform;
								styles = $temp$styles;
								attrs = $temp$attrs;
								children = $temp$children;
								elementAttrs = $temp$elementAttrs;
								continue gatherAttrRecursive;
							case 6:
								var $temp$classes = classes,
									$temp$node = node,
									$temp$has = has,
									$temp$transform = transform,
									$temp$styles = styles,
									$temp$attrs = A2(
									$elm$core$List$cons,
									A2($elm$virtual_dom$VirtualDom$attribute, 'aria-live', 'polite'),
									attrs),
									$temp$children = children,
									$temp$elementAttrs = remaining;
								classes = $temp$classes;
								node = $temp$node;
								has = $temp$has;
								transform = $temp$transform;
								styles = $temp$styles;
								attrs = $temp$attrs;
								children = $temp$children;
								elementAttrs = $temp$elementAttrs;
								continue gatherAttrRecursive;
							default:
								var $temp$classes = classes,
									$temp$node = node,
									$temp$has = has,
									$temp$transform = transform,
									$temp$styles = styles,
									$temp$attrs = A2(
									$elm$core$List$cons,
									A2($elm$virtual_dom$VirtualDom$attribute, 'aria-live', 'assertive'),
									attrs),
									$temp$children = children,
									$temp$elementAttrs = remaining;
								classes = $temp$classes;
								node = $temp$node;
								has = $temp$has;
								transform = $temp$transform;
								styles = $temp$styles;
								attrs = $temp$attrs;
								children = $temp$children;
								elementAttrs = $temp$elementAttrs;
								continue gatherAttrRecursive;
						}
					case 9:
						var location = attribute.a;
						var elem = attribute.b;
						var newStyles = function () {
							switch (elem.$) {
								case 3:
									return styles;
								case 2:
									var str = elem.a;
									return styles;
								case 0:
									var html = elem.a;
									return styles;
								default:
									var styled = elem.a;
									return _Utils_ap(styles, styled.dY);
							}
						}();
						var $temp$classes = classes,
							$temp$node = node,
							$temp$has = has,
							$temp$transform = transform,
							$temp$styles = newStyles,
							$temp$attrs = attrs,
							$temp$children = A3($mdgriffith$elm_ui$Internal$Model$addNearbyElement, location, elem, children),
							$temp$elementAttrs = remaining;
						classes = $temp$classes;
						node = $temp$node;
						has = $temp$has;
						transform = $temp$transform;
						styles = $temp$styles;
						attrs = $temp$attrs;
						children = $temp$children;
						elementAttrs = $temp$elementAttrs;
						continue gatherAttrRecursive;
					case 6:
						var x = attribute.a;
						if (A2($mdgriffith$elm_ui$Internal$Flag$present, $mdgriffith$elm_ui$Internal$Flag$xAlign, has)) {
							var $temp$classes = classes,
								$temp$node = node,
								$temp$has = has,
								$temp$transform = transform,
								$temp$styles = styles,
								$temp$attrs = attrs,
								$temp$children = children,
								$temp$elementAttrs = remaining;
							classes = $temp$classes;
							node = $temp$node;
							has = $temp$has;
							transform = $temp$transform;
							styles = $temp$styles;
							attrs = $temp$attrs;
							children = $temp$children;
							elementAttrs = $temp$elementAttrs;
							continue gatherAttrRecursive;
						} else {
							var $temp$classes = $mdgriffith$elm_ui$Internal$Model$alignXName(x) + (' ' + classes),
								$temp$node = node,
								$temp$has = function (flags) {
								switch (x) {
									case 1:
										return A2($mdgriffith$elm_ui$Internal$Flag$add, $mdgriffith$elm_ui$Internal$Flag$centerX, flags);
									case 2:
										return A2($mdgriffith$elm_ui$Internal$Flag$add, $mdgriffith$elm_ui$Internal$Flag$alignRight, flags);
									default:
										return flags;
								}
							}(
								A2($mdgriffith$elm_ui$Internal$Flag$add, $mdgriffith$elm_ui$Internal$Flag$xAlign, has)),
								$temp$transform = transform,
								$temp$styles = styles,
								$temp$attrs = attrs,
								$temp$children = children,
								$temp$elementAttrs = remaining;
							classes = $temp$classes;
							node = $temp$node;
							has = $temp$has;
							transform = $temp$transform;
							styles = $temp$styles;
							attrs = $temp$attrs;
							children = $temp$children;
							elementAttrs = $temp$elementAttrs;
							continue gatherAttrRecursive;
						}
					default:
						var y = attribute.a;
						if (A2($mdgriffith$elm_ui$Internal$Flag$present, $mdgriffith$elm_ui$Internal$Flag$yAlign, has)) {
							var $temp$classes = classes,
								$temp$node = node,
								$temp$has = has,
								$temp$transform = transform,
								$temp$styles = styles,
								$temp$attrs = attrs,
								$temp$children = children,
								$temp$elementAttrs = remaining;
							classes = $temp$classes;
							node = $temp$node;
							has = $temp$has;
							transform = $temp$transform;
							styles = $temp$styles;
							attrs = $temp$attrs;
							children = $temp$children;
							elementAttrs = $temp$elementAttrs;
							continue gatherAttrRecursive;
						} else {
							var $temp$classes = $mdgriffith$elm_ui$Internal$Model$alignYName(y) + (' ' + classes),
								$temp$node = node,
								$temp$has = function (flags) {
								switch (y) {
									case 1:
										return A2($mdgriffith$elm_ui$Internal$Flag$add, $mdgriffith$elm_ui$Internal$Flag$centerY, flags);
									case 2:
										return A2($mdgriffith$elm_ui$Internal$Flag$add, $mdgriffith$elm_ui$Internal$Flag$alignBottom, flags);
									default:
										return flags;
								}
							}(
								A2($mdgriffith$elm_ui$Internal$Flag$add, $mdgriffith$elm_ui$Internal$Flag$yAlign, has)),
								$temp$transform = transform,
								$temp$styles = styles,
								$temp$attrs = attrs,
								$temp$children = children,
								$temp$elementAttrs = remaining;
							classes = $temp$classes;
							node = $temp$node;
							has = $temp$has;
							transform = $temp$transform;
							styles = $temp$styles;
							attrs = $temp$attrs;
							children = $temp$children;
							elementAttrs = $temp$elementAttrs;
							continue gatherAttrRecursive;
						}
				}
			}
		}
	});
var $mdgriffith$elm_ui$Internal$Model$Untransformed = {$: 0};
var $mdgriffith$elm_ui$Internal$Model$untransformed = $mdgriffith$elm_ui$Internal$Model$Untransformed;
var $mdgriffith$elm_ui$Internal$Model$element = F4(
	function (context, node, attributes, children) {
		return A3(
			$mdgriffith$elm_ui$Internal$Model$createElement,
			context,
			children,
			A8(
				$mdgriffith$elm_ui$Internal$Model$gatherAttrRecursive,
				$mdgriffith$elm_ui$Internal$Model$contextClasses(context),
				node,
				$mdgriffith$elm_ui$Internal$Flag$none,
				$mdgriffith$elm_ui$Internal$Model$untransformed,
				_List_Nil,
				_List_Nil,
				$mdgriffith$elm_ui$Internal$Model$NoNearbyChildren,
				$elm$core$List$reverse(attributes)));
	});
var $mdgriffith$elm_ui$Element$Input$enter = 'Enter';
var $mdgriffith$elm_ui$Internal$Model$NoAttribute = {$: 0};
var $mdgriffith$elm_ui$Element$Input$hasFocusStyle = function (attr) {
	if (((attr.$ === 4) && (attr.b.$ === 11)) && (!attr.b.a)) {
		var _v1 = attr.b;
		var _v2 = _v1.a;
		return true;
	} else {
		return false;
	}
};
var $mdgriffith$elm_ui$Internal$Model$htmlClass = function (cls) {
	return $mdgriffith$elm_ui$Internal$Model$Attr(
		$elm$html$Html$Attributes$class(cls));
};
var $mdgriffith$elm_ui$Element$Input$focusDefault = function (attrs) {
	return A2($elm$core$List$any, $mdgriffith$elm_ui$Element$Input$hasFocusStyle, attrs) ? $mdgriffith$elm_ui$Internal$Model$NoAttribute : $mdgriffith$elm_ui$Internal$Model$htmlClass('focusable');
};
var $mdgriffith$elm_ui$Internal$Model$Height = function (a) {
	return {$: 8, a: a};
};
var $mdgriffith$elm_ui$Element$height = $mdgriffith$elm_ui$Internal$Model$Height;
var $elm$core$Basics$composeL = F3(
	function (g, f, x) {
		return g(
			f(x));
	});
var $elm$virtual_dom$VirtualDom$Normal = function (a) {
	return {$: 0, a: a};
};
var $elm$virtual_dom$VirtualDom$on = _VirtualDom_on;
var $elm$html$Html$Events$on = F2(
	function (event, decoder) {
		return A2(
			$elm$virtual_dom$VirtualDom$on,
			event,
			$elm$virtual_dom$VirtualDom$Normal(decoder));
	});
var $elm$html$Html$Events$onClick = function (msg) {
	return A2(
		$elm$html$Html$Events$on,
		'click',
		$elm$json$Json$Decode$succeed(msg));
};
var $mdgriffith$elm_ui$Element$Events$onClick = A2($elm$core$Basics$composeL, $mdgriffith$elm_ui$Internal$Model$Attr, $elm$html$Html$Events$onClick);
var $elm$json$Json$Decode$fail = _Json_fail;
var $elm$virtual_dom$VirtualDom$MayPreventDefault = function (a) {
	return {$: 2, a: a};
};
var $elm$html$Html$Events$preventDefaultOn = F2(
	function (event, decoder) {
		return A2(
			$elm$virtual_dom$VirtualDom$on,
			event,
			$elm$virtual_dom$VirtualDom$MayPreventDefault(decoder));
	});
var $mdgriffith$elm_ui$Element$Input$onKeyLookup = function (lookup) {
	var decode = function (code) {
		var _v0 = lookup(code);
		if (_v0.$ === 1) {
			return $elm$json$Json$Decode$fail('No key matched');
		} else {
			var msg = _v0.a;
			return $elm$json$Json$Decode$succeed(msg);
		}
	};
	var isKey = A2(
		$elm$json$Json$Decode$andThen,
		decode,
		A2($elm$json$Json$Decode$field, 'key', $elm$json$Json$Decode$string));
	return $mdgriffith$elm_ui$Internal$Model$Attr(
		A2(
			$elm$html$Html$Events$preventDefaultOn,
			'keydown',
			A2(
				$elm$json$Json$Decode$map,
				function (fired) {
					return _Utils_Tuple2(fired, true);
				},
				isKey)));
};
var $mdgriffith$elm_ui$Internal$Model$Class = F2(
	function (a, b) {
		return {$: 3, a: a, b: b};
	});
var $mdgriffith$elm_ui$Internal$Flag$cursor = $mdgriffith$elm_ui$Internal$Flag$flag(21);
var $mdgriffith$elm_ui$Element$pointer = A2($mdgriffith$elm_ui$Internal$Model$Class, $mdgriffith$elm_ui$Internal$Flag$cursor, $mdgriffith$elm_ui$Internal$Style$classes.eT);
var $mdgriffith$elm_ui$Internal$Model$Content = {$: 1};
var $mdgriffith$elm_ui$Element$shrink = $mdgriffith$elm_ui$Internal$Model$Content;
var $mdgriffith$elm_ui$Element$Input$space = ' ';
var $elm$html$Html$Attributes$tabindex = function (n) {
	return A2(
		_VirtualDom_attribute,
		'tabIndex',
		$elm$core$String$fromInt(n));
};
var $mdgriffith$elm_ui$Internal$Model$Width = function (a) {
	return {$: 7, a: a};
};
var $mdgriffith$elm_ui$Element$width = $mdgriffith$elm_ui$Internal$Model$Width;
var $mdgriffith$elm_ui$Element$Input$button = F2(
	function (attrs, _v0) {
		var onPress = _v0.fL;
		var label = _v0.au;
		return A4(
			$mdgriffith$elm_ui$Internal$Model$element,
			$mdgriffith$elm_ui$Internal$Model$asEl,
			$mdgriffith$elm_ui$Internal$Model$div,
			A2(
				$elm$core$List$cons,
				$mdgriffith$elm_ui$Element$width($mdgriffith$elm_ui$Element$shrink),
				A2(
					$elm$core$List$cons,
					$mdgriffith$elm_ui$Element$height($mdgriffith$elm_ui$Element$shrink),
					A2(
						$elm$core$List$cons,
						$mdgriffith$elm_ui$Internal$Model$htmlClass($mdgriffith$elm_ui$Internal$Style$classes.bZ + (' ' + ($mdgriffith$elm_ui$Internal$Style$classes.ar + (' ' + ($mdgriffith$elm_ui$Internal$Style$classes.f5 + (' ' + $mdgriffith$elm_ui$Internal$Style$classes.dz)))))),
						A2(
							$elm$core$List$cons,
							$mdgriffith$elm_ui$Element$pointer,
							A2(
								$elm$core$List$cons,
								$mdgriffith$elm_ui$Element$Input$focusDefault(attrs),
								A2(
									$elm$core$List$cons,
									$mdgriffith$elm_ui$Internal$Model$Describe($mdgriffith$elm_ui$Internal$Model$Button),
									A2(
										$elm$core$List$cons,
										$mdgriffith$elm_ui$Internal$Model$Attr(
											$elm$html$Html$Attributes$tabindex(0)),
										function () {
											if (onPress.$ === 1) {
												return A2(
													$elm$core$List$cons,
													$mdgriffith$elm_ui$Internal$Model$Attr(
														$elm$html$Html$Attributes$disabled(true)),
													attrs);
											} else {
												var msg = onPress.a;
												return A2(
													$elm$core$List$cons,
													$mdgriffith$elm_ui$Element$Events$onClick(msg),
													A2(
														$elm$core$List$cons,
														$mdgriffith$elm_ui$Element$Input$onKeyLookup(
															function (code) {
																return _Utils_eq(code, $mdgriffith$elm_ui$Element$Input$enter) ? $elm$core$Maybe$Just(msg) : (_Utils_eq(code, $mdgriffith$elm_ui$Element$Input$space) ? $elm$core$Maybe$Just(msg) : $elm$core$Maybe$Nothing);
															}),
														attrs));
											}
										}()))))))),
			$mdgriffith$elm_ui$Internal$Model$Unkeyed(
				_List_fromArray(
					[label])));
	});
var $author$project$MrJam$Theme$couleurs = {
	a4: $author$project$MrJam$Theme$rendu('accent'),
	ee: $author$project$MrJam$Theme$rendu('accentSurvol'),
	c1: $author$project$MrJam$Theme$rendu('controle'),
	c4: $author$project$MrJam$Theme$rendu('danger'),
	eV: $author$project$MrJam$Theme$rendu('dangerSurvol'),
	eZ: $author$project$MrJam$Theme$rendu('discret'),
	e$: $author$project$MrJam$Theme$rendu('doux'),
	c8: $author$project$MrJam$Theme$rendu('encre'),
	fv: $author$project$MrJam$Theme$rendu('ligne'),
	fR: $author$project$MrJam$Theme$rendu('papier'),
	d_: $author$project$MrJam$Theme$rendu('surface')
};
var $author$project$MrJam$Theme$fond = function (col) {
	return $mdgriffith$elm_ui$Element$htmlAttribute(
		A2(
			$elm$html$Html$Attributes$style,
			'background-color',
			$author$project$MrJam$Theme$variable(col)));
};
var $mdgriffith$elm_ui$Internal$Model$Min = F2(
	function (a, b) {
		return {$: 3, a: a, b: b};
	});
var $mdgriffith$elm_ui$Element$minimum = F2(
	function (i, l) {
		return A2($mdgriffith$elm_ui$Internal$Model$Min, i, l);
	});
var $mdgriffith$elm_ui$Internal$Model$PaddingStyle = F5(
	function (a, b, c, d, e) {
		return {$: 7, a: a, b: b, c: c, d: d, e: e};
	});
var $mdgriffith$elm_ui$Internal$Model$StyleClass = F2(
	function (a, b) {
		return {$: 4, a: a, b: b};
	});
var $mdgriffith$elm_ui$Internal$Flag$padding = $mdgriffith$elm_ui$Internal$Flag$flag(2);
var $mdgriffith$elm_ui$Element$padding = function (x) {
	var f = x;
	return A2(
		$mdgriffith$elm_ui$Internal$Model$StyleClass,
		$mdgriffith$elm_ui$Internal$Flag$padding,
		A5(
			$mdgriffith$elm_ui$Internal$Model$PaddingStyle,
			'p-' + $elm$core$String$fromInt(x),
			f,
			f,
			f,
			f));
};
var $mdgriffith$elm_ui$Element$paddingXY = F2(
	function (x, y) {
		if (_Utils_eq(x, y)) {
			var f = x;
			return A2(
				$mdgriffith$elm_ui$Internal$Model$StyleClass,
				$mdgriffith$elm_ui$Internal$Flag$padding,
				A5(
					$mdgriffith$elm_ui$Internal$Model$PaddingStyle,
					'p-' + $elm$core$String$fromInt(x),
					f,
					f,
					f,
					f));
		} else {
			var yFloat = y;
			var xFloat = x;
			return A2(
				$mdgriffith$elm_ui$Internal$Model$StyleClass,
				$mdgriffith$elm_ui$Internal$Flag$padding,
				A5(
					$mdgriffith$elm_ui$Internal$Model$PaddingStyle,
					'p-' + ($elm$core$String$fromInt(x) + ('-' + $elm$core$String$fromInt(y))),
					yFloat,
					xFloat,
					yFloat,
					xFloat));
		}
	});
var $author$project$MrJam$Theme$police = function (col) {
	return $mdgriffith$elm_ui$Element$htmlAttribute(
		A2(
			$elm$html$Html$Attributes$style,
			'color',
			$author$project$MrJam$Theme$variable(col)));
};
var $mdgriffith$elm_ui$Internal$Model$Px = function (a) {
	return {$: 0, a: a};
};
var $mdgriffith$elm_ui$Element$px = $mdgriffith$elm_ui$Internal$Model$Px;
var $mdgriffith$elm_ui$Internal$Flag$borderRound = $mdgriffith$elm_ui$Internal$Flag$flag(17);
var $mdgriffith$elm_ui$Element$Border$rounded = function (radius) {
	return A2(
		$mdgriffith$elm_ui$Internal$Model$StyleClass,
		$mdgriffith$elm_ui$Internal$Flag$borderRound,
		A3(
			$mdgriffith$elm_ui$Internal$Model$Single,
			'br-' + $elm$core$String$fromInt(radius),
			'border-radius',
			$elm$core$String$fromInt(radius) + 'px'));
};
var $mdgriffith$elm_ui$Internal$Flag$fontWeight = $mdgriffith$elm_ui$Internal$Flag$flag(13);
var $mdgriffith$elm_ui$Element$Font$semiBold = A2($mdgriffith$elm_ui$Internal$Model$Class, $mdgriffith$elm_ui$Internal$Flag$fontWeight, $mdgriffith$elm_ui$Internal$Style$classes.gw);
var $mdgriffith$elm_ui$Internal$Model$FontSize = function (a) {
	return {$: 2, a: a};
};
var $mdgriffith$elm_ui$Internal$Flag$fontSize = $mdgriffith$elm_ui$Internal$Flag$flag(4);
var $mdgriffith$elm_ui$Element$Font$size = function (i) {
	return A2(
		$mdgriffith$elm_ui$Internal$Model$StyleClass,
		$mdgriffith$elm_ui$Internal$Flag$fontSize,
		$mdgriffith$elm_ui$Internal$Model$FontSize(i));
};
var $author$project$MrJam$Theme$survol = function (col) {
	return $mdgriffith$elm_ui$Element$htmlAttribute(
		$elm$html$Html$Attributes$class(
			'mrjam-survol-' + $author$project$MrJam$Theme$nomCouleur(col)));
};
var $mdgriffith$elm_ui$Internal$Model$BorderWidth = F5(
	function (a, b, c, d, e) {
		return {$: 6, a: a, b: b, c: c, d: d, e: e};
	});
var $mdgriffith$elm_ui$Element$Border$width = function (v) {
	return A2(
		$mdgriffith$elm_ui$Internal$Model$StyleClass,
		$mdgriffith$elm_ui$Internal$Flag$borderWidth,
		A5(
			$mdgriffith$elm_ui$Internal$Model$BorderWidth,
			'b-' + $elm$core$String$fromInt(v),
			v,
			v,
			v,
			v));
};
var $author$project$MrJam$Controles$actionAvecContenu = F4(
	function (intention, attributs, contenu, message) {
		var selection = function () {
			if (intention.$ === 4) {
				var actif = intention.a;
				return _List_fromArray(
					[
						$mdgriffith$elm_ui$Element$htmlAttribute(
						A2(
							$elm$html$Html$Attributes$attribute,
							'aria-pressed',
							actif ? 'true' : 'false'))
					]);
			} else {
				return _List_Nil;
			}
		}();
		var _v0 = function () {
			if (_Utils_eq(message, $elm$core$Maybe$Nothing)) {
				return _Utils_Tuple3(
					_Utils_eq(intention, $author$project$MrJam$Controles$Discrete) ? $author$project$MrJam$Theme$couleurs.d_ : $author$project$MrJam$Theme$couleurs.e$,
					$author$project$MrJam$Theme$couleurs.eZ,
					$author$project$MrJam$Theme$couleurs.e$);
			} else {
				switch (intention.$) {
					case 0:
						return _Utils_Tuple3($author$project$MrJam$Theme$couleurs.a4, $author$project$MrJam$Theme$couleurs.d_, $author$project$MrJam$Theme$couleurs.ee);
					case 2:
						return _Utils_Tuple3($author$project$MrJam$Theme$couleurs.c4, $author$project$MrJam$Theme$couleurs.d_, $author$project$MrJam$Theme$couleurs.eV);
					case 3:
						return _Utils_Tuple3($author$project$MrJam$Theme$couleurs.d_, $author$project$MrJam$Theme$couleurs.eZ, $author$project$MrJam$Theme$couleurs.e$);
					default:
						return _Utils_Tuple3($author$project$MrJam$Theme$couleurs.d_, $author$project$MrJam$Theme$couleurs.c8, $author$project$MrJam$Theme$couleurs.e$);
				}
			}
		}();
		var fond = _v0.a;
		var encre = _v0.b;
		var survol = _v0.c;
		var bord = function () {
			switch (intention.$) {
				case 1:
					return $author$project$MrJam$Theme$couleurs.c1;
				case 4:
					if (intention.a) {
						return $author$project$MrJam$Theme$couleurs.a4;
					} else {
						return $author$project$MrJam$Theme$couleurs.c1;
					}
				default:
					return fond;
			}
		}();
		return A2(
			$mdgriffith$elm_ui$Element$Input$button,
			_Utils_ap(
				_List_fromArray(
					[
						$mdgriffith$elm_ui$Element$height(
						A2($mdgriffith$elm_ui$Element$minimum, 34, $mdgriffith$elm_ui$Element$shrink)),
						$mdgriffith$elm_ui$Element$width(
						A2($mdgriffith$elm_ui$Element$minimum, 34, $mdgriffith$elm_ui$Element$shrink)),
						A2($mdgriffith$elm_ui$Element$paddingXY, 10, 6),
						$mdgriffith$elm_ui$Element$htmlAttribute(
						A2($elm$html$Html$Attributes$style, 'width', 'max-content')),
						$mdgriffith$elm_ui$Element$htmlAttribute(
						A2($elm$html$Html$Attributes$style, 'max-width', '100%')),
						$mdgriffith$elm_ui$Element$htmlAttribute(
						A2($elm$html$Html$Attributes$style, 'flex-basis', 'auto')),
						$mdgriffith$elm_ui$Element$Font$size(14),
						$author$project$MrJam$Theme$police(encre),
						$author$project$MrJam$Theme$fond(fond),
						$mdgriffith$elm_ui$Element$Border$rounded(5),
						$mdgriffith$elm_ui$Element$Border$width(1),
						$author$project$MrJam$Theme$bordure(bord),
						$author$project$MrJam$Theme$survol(survol),
						$mdgriffith$elm_ui$Element$htmlAttribute(
						A2(
							$elm$html$Html$Attributes$attribute,
							'aria-disabled',
							_Utils_eq(message, $elm$core$Maybe$Nothing) ? 'true' : 'false'))
					]),
				_Utils_ap(
					_Utils_eq(message, $elm$core$Maybe$Nothing) ? _List_fromArray(
						[
							$mdgriffith$elm_ui$Element$htmlAttribute(
							$elm$html$Html$Attributes$tabindex(-1))
						]) : _List_Nil,
					_Utils_ap(
						function () {
							switch (intention.$) {
								case 5:
									return _List_fromArray(
										[
											$mdgriffith$elm_ui$Element$width(
											$mdgriffith$elm_ui$Element$px(34)),
											$mdgriffith$elm_ui$Element$height(
											$mdgriffith$elm_ui$Element$px(34)),
											$mdgriffith$elm_ui$Element$htmlAttribute(
											A2($elm$html$Html$Attributes$style, 'width', '34px')),
											$mdgriffith$elm_ui$Element$padding(0),
											$mdgriffith$elm_ui$Element$Font$size(20)
										]);
								case 3:
									return _List_fromArray(
										[
											$mdgriffith$elm_ui$Element$Border$width(0),
											A2($mdgriffith$elm_ui$Element$paddingXY, 6, 4)
										]);
								default:
									return _List_fromArray(
										[$mdgriffith$elm_ui$Element$Font$semiBold]);
							}
						}(),
						_Utils_ap(selection, attributs)))),
			{au: contenu, fL: message});
	});
var $mdgriffith$elm_ui$Internal$Flag$fontAlignment = $mdgriffith$elm_ui$Internal$Flag$flag(12);
var $mdgriffith$elm_ui$Element$Font$center = A2($mdgriffith$elm_ui$Internal$Model$Class, $mdgriffith$elm_ui$Internal$Flag$fontAlignment, $mdgriffith$elm_ui$Internal$Style$classes.gm);
var $mdgriffith$elm_ui$Internal$Model$Paragraph = {$: 9};
var $mdgriffith$elm_ui$Internal$Model$Fill = function (a) {
	return {$: 2, a: a};
};
var $mdgriffith$elm_ui$Element$fill = $mdgriffith$elm_ui$Internal$Model$Fill(1);
var $mdgriffith$elm_ui$Internal$Model$SpacingStyle = F3(
	function (a, b, c) {
		return {$: 5, a: a, b: b, c: c};
	});
var $mdgriffith$elm_ui$Internal$Flag$spacing = $mdgriffith$elm_ui$Internal$Flag$flag(3);
var $mdgriffith$elm_ui$Internal$Model$spacingName = F2(
	function (x, y) {
		return 'spacing-' + ($elm$core$String$fromInt(x) + ('-' + $elm$core$String$fromInt(y)));
	});
var $mdgriffith$elm_ui$Element$spacing = function (x) {
	return A2(
		$mdgriffith$elm_ui$Internal$Model$StyleClass,
		$mdgriffith$elm_ui$Internal$Flag$spacing,
		A3(
			$mdgriffith$elm_ui$Internal$Model$SpacingStyle,
			A2($mdgriffith$elm_ui$Internal$Model$spacingName, x, x),
			x,
			x));
};
var $mdgriffith$elm_ui$Element$paragraph = F2(
	function (attrs, children) {
		return A4(
			$mdgriffith$elm_ui$Internal$Model$element,
			$mdgriffith$elm_ui$Internal$Model$asParagraph,
			$mdgriffith$elm_ui$Internal$Model$div,
			A2(
				$elm$core$List$cons,
				$mdgriffith$elm_ui$Internal$Model$Describe($mdgriffith$elm_ui$Internal$Model$Paragraph),
				A2(
					$elm$core$List$cons,
					$mdgriffith$elm_ui$Element$width($mdgriffith$elm_ui$Element$fill),
					A2(
						$elm$core$List$cons,
						$mdgriffith$elm_ui$Element$spacing(5),
						attrs))),
			$mdgriffith$elm_ui$Internal$Model$Unkeyed(children));
	});
var $mdgriffith$elm_ui$Internal$Model$Text = function (a) {
	return {$: 2, a: a};
};
var $mdgriffith$elm_ui$Element$text = function (content) {
	return $mdgriffith$elm_ui$Internal$Model$Text(content);
};
var $author$project$MrJam$Controles$action = F4(
	function (intention, attributs, libelle, message) {
		return A4(
			$author$project$MrJam$Controles$actionAvecContenu,
			intention,
			attributs,
			A2(
				$mdgriffith$elm_ui$Element$paragraph,
				_List_fromArray(
					[
						$mdgriffith$elm_ui$Element$htmlAttribute(
						A2($elm$html$Html$Attributes$style, 'width', 'max-content')),
						$mdgriffith$elm_ui$Element$htmlAttribute(
						A2($elm$html$Html$Attributes$style, 'max-width', '100%')),
						$mdgriffith$elm_ui$Element$Font$center
					]),
				_List_fromArray(
					[
						$mdgriffith$elm_ui$Element$text(libelle)
					])),
			message);
	});
var $author$project$MrJam$Documents$action = F2(
	function (libelle, message) {
		return A4(
			$author$project$MrJam$Controles$action,
			$author$project$MrJam$Controles$Discrete,
			_List_Nil,
			libelle,
			$elm$core$Maybe$Just(message));
	});
var $author$project$MrJam$Controles$Icone = {$: 5};
var $elm$html$Html$Attributes$title = $elm$html$Html$Attributes$stringProperty('title');
var $elm$svg$Svg$Attributes$d = _VirtualDom_attribute('d');
var $mdgriffith$elm_ui$Element$el = F2(
	function (attrs, child) {
		return A4(
			$mdgriffith$elm_ui$Internal$Model$element,
			$mdgriffith$elm_ui$Internal$Model$asEl,
			$mdgriffith$elm_ui$Internal$Model$div,
			A2(
				$elm$core$List$cons,
				$mdgriffith$elm_ui$Element$width($mdgriffith$elm_ui$Element$shrink),
				A2(
					$elm$core$List$cons,
					$mdgriffith$elm_ui$Element$height($mdgriffith$elm_ui$Element$shrink),
					attrs)),
			$mdgriffith$elm_ui$Internal$Model$Unkeyed(
				_List_fromArray(
					[child])));
	});
var $elm$svg$Svg$Attributes$fill = _VirtualDom_attribute('fill');
var $elm$svg$Svg$Attributes$height = _VirtualDom_attribute('height');
var $mdgriffith$elm_ui$Internal$Model$unstyled = A2($elm$core$Basics$composeL, $mdgriffith$elm_ui$Internal$Model$Unstyled, $elm$core$Basics$always);
var $mdgriffith$elm_ui$Element$html = $mdgriffith$elm_ui$Internal$Model$unstyled;
var $elm$svg$Svg$trustedNode = _VirtualDom_nodeNS('http://www.w3.org/2000/svg');
var $elm$svg$Svg$path = $elm$svg$Svg$trustedNode('path');
var $elm$svg$Svg$Attributes$stroke = _VirtualDom_attribute('stroke');
var $elm$svg$Svg$Attributes$strokeLinecap = _VirtualDom_attribute('stroke-linecap');
var $elm$svg$Svg$Attributes$strokeLinejoin = _VirtualDom_attribute('stroke-linejoin');
var $elm$svg$Svg$Attributes$strokeWidth = _VirtualDom_attribute('stroke-width');
var $elm$svg$Svg$svg = $elm$svg$Svg$trustedNode('svg');
var $author$project$MrJam$Pictogrammes$traces = function (icone) {
	switch (icone) {
		case 0:
			return _List_fromArray(
				['M12 5v14M5 12h14']);
		case 1:
			return _List_fromArray(
				['m15 5 4 4M4 20l4-1L20 7a2.8 2.8 0 0 0-4-4L4 15z']);
		case 2:
			return _List_fromArray(
				['m5 12 4 4L19 6']);
		case 3:
			return _List_fromArray(
				['m6 6 12 12M6 18 18 6']);
		case 4:
			return _List_fromArray(
				['m10 5-7 7 7 7M3 12h18']);
		case 5:
			return _List_fromArray(
				['M4 7h16M7 12h10M10 17h4']);
		case 6:
			return _List_fromArray(
				['M8 4v16m-4-4 4 4 4-4M16 20V4m-4 4 4-4 4 4']);
		case 7:
			return _List_fromArray(
				['M4 7h16M4 17h16M8 4v6M16 14v6']);
		case 8:
			return _List_fromArray(
				['M12 6C9 4 5 4 3 5v14c3-1 6-1 9 1 3-2 6-2 9-1V5c-2-1-6-1-9 1v14']);
		case 9:
			return _List_fromArray(
				['M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0M12 7v5l3 2']);
		case 10:
			return _List_fromArray(
				['m10 13 4-4M8 15l-1 1a3.5 3.5 0 0 1-5-5l4-4a3.5 3.5 0 0 1 5 0m2 2 1-1a3.5 3.5 0 0 1 5 5l-4 4a3.5 3.5 0 0 1-5 0']);
		case 11:
			return _List_fromArray(
				['M4 8h16v12H4zM3 4h18v4H3zM9 12h6']);
		case 12:
			return _List_fromArray(
				['M9 4H4v16h5M10 12h11m-4-4 4 4-4 4']);
		case 13:
			return _List_fromArray(
				['M9 9h11v11H9zM15 9V4H4v11h5']);
		case 14:
			return _List_fromArray(
				['M4 12h16m-6-6 6 6-6 6']);
		case 15:
			return _List_fromArray(
				['M21 11a8 8 0 0 1-8 8H8l-5 3 1-6a8 8 0 1 1 17-5M8 10h8M8 14h5']);
		case 17:
			return _List_fromArray(
				['M12 3 21 7v5c0 5-4 8-9 10-5-2-9-5-9-10V7z', 'm8 12 3 3 5-6']);
		case 18:
			return _List_fromArray(
				['M16 10a6 6 0 1 1-12 0 6 6 0 0 1 12 0m-1.5 4.5L21 21']);
		default:
			return _List_fromArray(
				['m12 3 2.5 5 5.5.8-4 4 1 5.5-5-2.6L7 18.3l1-5.5-4-4L9.5 8z']);
	}
};
var $elm$svg$Svg$Attributes$viewBox = _VirtualDom_attribute('viewBox');
var $elm$svg$Svg$Attributes$width = _VirtualDom_attribute('width');
var $author$project$MrJam$Pictogrammes$vue = function (icone) {
	return A2(
		$mdgriffith$elm_ui$Element$el,
		_List_fromArray(
			[
				$mdgriffith$elm_ui$Element$width(
				$mdgriffith$elm_ui$Element$px(22)),
				$mdgriffith$elm_ui$Element$height(
				$mdgriffith$elm_ui$Element$px(22))
			]),
		$mdgriffith$elm_ui$Element$html(
			A2(
				$elm$svg$Svg$svg,
				_List_fromArray(
					[
						$elm$svg$Svg$Attributes$viewBox('0 0 24 24'),
						$elm$svg$Svg$Attributes$width('22'),
						$elm$svg$Svg$Attributes$height('22'),
						$elm$svg$Svg$Attributes$fill('none'),
						$elm$svg$Svg$Attributes$stroke('currentColor'),
						$elm$svg$Svg$Attributes$strokeWidth('1.7'),
						$elm$svg$Svg$Attributes$strokeLinecap('round'),
						$elm$svg$Svg$Attributes$strokeLinejoin('round'),
						A2($elm$html$Html$Attributes$attribute, 'aria-hidden', 'true'),
						A2($elm$html$Html$Attributes$attribute, 'focusable', 'false')
					]),
				A2(
					$elm$core$List$map,
					function (trace) {
						return A2(
							$elm$svg$Svg$path,
							_List_fromArray(
								[
									$elm$svg$Svg$Attributes$d(trace)
								]),
							_List_Nil);
					},
					$author$project$MrJam$Pictogrammes$traces(icone)))));
};
var $author$project$MrJam$Pictogrammes$action = F3(
	function (icone, libelle, message) {
		return A4(
			$author$project$MrJam$Controles$actionAvecContenu,
			$author$project$MrJam$Controles$Icone,
			_List_fromArray(
				[
					$mdgriffith$elm_ui$Element$htmlAttribute(
					A2($elm$html$Html$Attributes$attribute, 'aria-label', libelle)),
					$mdgriffith$elm_ui$Element$htmlAttribute(
					$elm$html$Html$Attributes$title(libelle)),
					$mdgriffith$elm_ui$Element$htmlAttribute(
					$elm$html$Html$Attributes$class('mrjam-picto-action'))
				]),
			$author$project$MrJam$Pictogrammes$vue(icone),
			$elm$core$Maybe$Just(message));
	});
var $mdgriffith$elm_ui$Internal$Model$LivePolite = {$: 6};
var $mdgriffith$elm_ui$Element$Region$announce = $mdgriffith$elm_ui$Internal$Model$Describe($mdgriffith$elm_ui$Internal$Model$LivePolite);
var $mdgriffith$elm_ui$Element$Font$bold = A2($mdgriffith$elm_ui$Internal$Model$Class, $mdgriffith$elm_ui$Internal$Flag$fontWeight, $mdgriffith$elm_ui$Internal$Style$classes.eA);
var $author$project$MrJam$avis = F2(
	function (niveau, contenu) {
		var _v0 = function () {
			switch (niveau) {
				case 0:
					return _Utils_Tuple2('Information', $author$project$MrJam$Theme$couleurs.c8);
				case 1:
					return _Utils_Tuple2('Confirmation', $author$project$MrJam$Theme$couleurs.a4);
				case 2:
					return _Utils_Tuple2('Attention', $author$project$MrJam$Theme$couleurs.c4);
				default:
					return _Utils_Tuple2('Erreur', $author$project$MrJam$Theme$couleurs.c4);
			}
		}();
		var prefixe = _v0.a;
		var couleur = _v0.b;
		return A2(
			$mdgriffith$elm_ui$Element$paragraph,
			_List_fromArray(
				[
					$mdgriffith$elm_ui$Element$width($mdgriffith$elm_ui$Element$fill),
					$mdgriffith$elm_ui$Element$padding(14),
					$mdgriffith$elm_ui$Element$spacing(6),
					$author$project$MrJam$Theme$fond($author$project$MrJam$Theme$couleurs.e$),
					$author$project$MrJam$Theme$police(couleur),
					$mdgriffith$elm_ui$Element$Border$rounded(12),
					$mdgriffith$elm_ui$Element$Region$announce
				]),
			_List_fromArray(
				[
					A2(
					$mdgriffith$elm_ui$Element$el,
					_List_fromArray(
						[$mdgriffith$elm_ui$Element$Font$bold]),
					$mdgriffith$elm_ui$Element$text(prefixe + ' : ')),
					$mdgriffith$elm_ui$Element$text(contenu)
				]));
	});
var $author$project$MrJam$Controles$Principale = {$: 0};
var $author$project$MrJam$bouton = F2(
	function (libelle, message) {
		return A4(
			$author$project$MrJam$Controles$action,
			$author$project$MrJam$Controles$Principale,
			_List_Nil,
			libelle,
			$elm$core$Maybe$Just(message));
	});
var $mdgriffith$elm_ui$Internal$Model$AlignX = function (a) {
	return {$: 6, a: a};
};
var $mdgriffith$elm_ui$Internal$Model$Left = 0;
var $mdgriffith$elm_ui$Element$alignLeft = $mdgriffith$elm_ui$Internal$Model$AlignX(0);
var $mdgriffith$elm_ui$Internal$Model$AsColumn = 1;
var $mdgriffith$elm_ui$Internal$Model$asColumn = 1;
var $mdgriffith$elm_ui$Internal$Model$AsRow = 0;
var $mdgriffith$elm_ui$Internal$Model$asRow = 0;
var $mdgriffith$elm_ui$Element$Input$applyLabel = F3(
	function (attrs, label, input) {
		if (label.$ === 1) {
			var labelText = label.a;
			return A4(
				$mdgriffith$elm_ui$Internal$Model$element,
				$mdgriffith$elm_ui$Internal$Model$asColumn,
				$mdgriffith$elm_ui$Internal$Model$NodeName('label'),
				attrs,
				$mdgriffith$elm_ui$Internal$Model$Unkeyed(
					_List_fromArray(
						[input])));
		} else {
			var position = label.a;
			var labelAttrs = label.b;
			var labelChild = label.c;
			var labelElement = A4(
				$mdgriffith$elm_ui$Internal$Model$element,
				$mdgriffith$elm_ui$Internal$Model$asEl,
				$mdgriffith$elm_ui$Internal$Model$div,
				labelAttrs,
				$mdgriffith$elm_ui$Internal$Model$Unkeyed(
					_List_fromArray(
						[labelChild])));
			switch (position) {
				case 2:
					return A4(
						$mdgriffith$elm_ui$Internal$Model$element,
						$mdgriffith$elm_ui$Internal$Model$asColumn,
						$mdgriffith$elm_ui$Internal$Model$NodeName('label'),
						A2(
							$elm$core$List$cons,
							$mdgriffith$elm_ui$Internal$Model$htmlClass($mdgriffith$elm_ui$Internal$Style$classes.b7),
							attrs),
						$mdgriffith$elm_ui$Internal$Model$Unkeyed(
							_List_fromArray(
								[labelElement, input])));
				case 3:
					return A4(
						$mdgriffith$elm_ui$Internal$Model$element,
						$mdgriffith$elm_ui$Internal$Model$asColumn,
						$mdgriffith$elm_ui$Internal$Model$NodeName('label'),
						A2(
							$elm$core$List$cons,
							$mdgriffith$elm_ui$Internal$Model$htmlClass($mdgriffith$elm_ui$Internal$Style$classes.b7),
							attrs),
						$mdgriffith$elm_ui$Internal$Model$Unkeyed(
							_List_fromArray(
								[input, labelElement])));
				case 0:
					return A4(
						$mdgriffith$elm_ui$Internal$Model$element,
						$mdgriffith$elm_ui$Internal$Model$asRow,
						$mdgriffith$elm_ui$Internal$Model$NodeName('label'),
						A2(
							$elm$core$List$cons,
							$mdgriffith$elm_ui$Internal$Model$htmlClass($mdgriffith$elm_ui$Internal$Style$classes.b7),
							attrs),
						$mdgriffith$elm_ui$Internal$Model$Unkeyed(
							_List_fromArray(
								[input, labelElement])));
				default:
					return A4(
						$mdgriffith$elm_ui$Internal$Model$element,
						$mdgriffith$elm_ui$Internal$Model$asRow,
						$mdgriffith$elm_ui$Internal$Model$NodeName('label'),
						A2(
							$elm$core$List$cons,
							$mdgriffith$elm_ui$Internal$Model$htmlClass($mdgriffith$elm_ui$Internal$Style$classes.b7),
							attrs),
						$mdgriffith$elm_ui$Internal$Model$Unkeyed(
							_List_fromArray(
								[labelElement, input])));
			}
		}
	});
var $mdgriffith$elm_ui$Internal$Model$AlignY = function (a) {
	return {$: 5, a: a};
};
var $mdgriffith$elm_ui$Internal$Model$CenterY = 1;
var $mdgriffith$elm_ui$Element$centerY = $mdgriffith$elm_ui$Internal$Model$AlignY(1);
var $mdgriffith$elm_ui$Internal$Model$Label = function (a) {
	return {$: 5, a: a};
};
var $mdgriffith$elm_ui$Element$Input$hiddenLabelAttribute = function (label) {
	if (label.$ === 1) {
		var textLabel = label.a;
		return $mdgriffith$elm_ui$Internal$Model$Describe(
			$mdgriffith$elm_ui$Internal$Model$Label(textLabel));
	} else {
		return $mdgriffith$elm_ui$Internal$Model$NoAttribute;
	}
};
var $mdgriffith$elm_ui$Element$Input$isHiddenLabel = function (label) {
	if (label.$ === 1) {
		return true;
	} else {
		return false;
	}
};
var $mdgriffith$elm_ui$Element$Input$tabindex = A2($elm$core$Basics$composeL, $mdgriffith$elm_ui$Internal$Model$Attr, $elm$html$Html$Attributes$tabindex);
var $mdgriffith$elm_ui$Element$Input$checkbox = F2(
	function (attrs, _v0) {
		var label = _v0.au;
		var icon = _v0.fe;
		var checked = _v0.eM;
		var onChange = _v0.aR;
		var attributes = _Utils_ap(
			_List_fromArray(
				[
					$mdgriffith$elm_ui$Element$Input$isHiddenLabel(label) ? $mdgriffith$elm_ui$Internal$Model$NoAttribute : $mdgriffith$elm_ui$Element$spacing(6),
					$mdgriffith$elm_ui$Internal$Model$Attr(
					$elm$html$Html$Events$onClick(
						onChange(!checked))),
					$mdgriffith$elm_ui$Element$Region$announce,
					$mdgriffith$elm_ui$Element$Input$onKeyLookup(
					function (code) {
						return _Utils_eq(code, $mdgriffith$elm_ui$Element$Input$enter) ? $elm$core$Maybe$Just(
							onChange(!checked)) : (_Utils_eq(code, $mdgriffith$elm_ui$Element$Input$space) ? $elm$core$Maybe$Just(
							onChange(!checked)) : $elm$core$Maybe$Nothing);
					}),
					$mdgriffith$elm_ui$Element$Input$tabindex(0),
					$mdgriffith$elm_ui$Element$pointer,
					$mdgriffith$elm_ui$Element$alignLeft,
					$mdgriffith$elm_ui$Element$width($mdgriffith$elm_ui$Element$fill)
				]),
			attrs);
		return A3(
			$mdgriffith$elm_ui$Element$Input$applyLabel,
			A2(
				$elm$core$List$cons,
				$mdgriffith$elm_ui$Internal$Model$Attr(
					A2($elm$html$Html$Attributes$attribute, 'role', 'checkbox')),
				A2(
					$elm$core$List$cons,
					$mdgriffith$elm_ui$Internal$Model$Attr(
						A2(
							$elm$html$Html$Attributes$attribute,
							'aria-checked',
							checked ? 'true' : 'false')),
					A2(
						$elm$core$List$cons,
						$mdgriffith$elm_ui$Element$Input$hiddenLabelAttribute(label),
						attributes))),
			label,
			A4(
				$mdgriffith$elm_ui$Internal$Model$element,
				$mdgriffith$elm_ui$Internal$Model$asEl,
				$mdgriffith$elm_ui$Internal$Model$div,
				_List_fromArray(
					[
						$mdgriffith$elm_ui$Element$centerY,
						$mdgriffith$elm_ui$Element$height($mdgriffith$elm_ui$Element$fill),
						$mdgriffith$elm_ui$Element$width($mdgriffith$elm_ui$Element$shrink)
					]),
				$mdgriffith$elm_ui$Internal$Model$Unkeyed(
					_List_fromArray(
						[
							icon(checked)
						]))));
	});
var $mdgriffith$elm_ui$Internal$Model$CenterX = 1;
var $mdgriffith$elm_ui$Element$centerX = $mdgriffith$elm_ui$Internal$Model$AlignX(1);
var $author$project$MrJam$coche = function (valeur) {
	return A2(
		$mdgriffith$elm_ui$Element$el,
		_List_fromArray(
			[
				$mdgriffith$elm_ui$Element$width(
				$mdgriffith$elm_ui$Element$px(20)),
				$mdgriffith$elm_ui$Element$height(
				$mdgriffith$elm_ui$Element$px(20)),
				$mdgriffith$elm_ui$Element$Border$rounded(4),
				$mdgriffith$elm_ui$Element$Border$width(1),
				$author$project$MrJam$Theme$bordure($author$project$MrJam$Theme$couleurs.a4),
				$author$project$MrJam$Theme$fond(
				valeur ? $author$project$MrJam$Theme$couleurs.a4 : $author$project$MrJam$Theme$couleurs.d_),
				$author$project$MrJam$Theme$police($author$project$MrJam$Theme$couleurs.d_),
				$mdgriffith$elm_ui$Element$Font$size(16),
				$mdgriffith$elm_ui$Element$htmlAttribute(
				A2($elm$html$Html$Attributes$attribute, 'aria-hidden', 'true'))
			]),
		A2(
			$mdgriffith$elm_ui$Element$el,
			_List_fromArray(
				[$mdgriffith$elm_ui$Element$centerX, $mdgriffith$elm_ui$Element$centerY]),
			$mdgriffith$elm_ui$Element$text(
				valeur ? '✓' : '')));
};
var $mdgriffith$elm_ui$Element$Input$Label = F3(
	function (a, b, c) {
		return {$: 0, a: a, b: b, c: c};
	});
var $mdgriffith$elm_ui$Element$Input$OnRight = 0;
var $mdgriffith$elm_ui$Element$Input$labelRight = $mdgriffith$elm_ui$Element$Input$Label(0);
var $author$project$MrJam$paragraphe = function (contenu) {
	return A2(
		$mdgriffith$elm_ui$Element$paragraph,
		_List_fromArray(
			[
				$mdgriffith$elm_ui$Element$width($mdgriffith$elm_ui$Element$fill),
				$mdgriffith$elm_ui$Element$spacing(6)
			]),
		_List_fromArray(
			[
				$mdgriffith$elm_ui$Element$text(contenu)
			]));
};
var $author$project$MrJam$caseACocher = F3(
	function (libelle, valeur, modifier) {
		return A2(
			$mdgriffith$elm_ui$Element$Input$checkbox,
			_List_fromArray(
				[
					$mdgriffith$elm_ui$Element$width($mdgriffith$elm_ui$Element$fill),
					$mdgriffith$elm_ui$Element$height(
					A2($mdgriffith$elm_ui$Element$minimum, 44, $mdgriffith$elm_ui$Element$shrink)),
					$mdgriffith$elm_ui$Element$spacing(10)
				]),
			{
				eM: valeur,
				fe: $author$project$MrJam$coche,
				au: A2(
					$mdgriffith$elm_ui$Element$Input$labelRight,
					_List_fromArray(
						[
							$mdgriffith$elm_ui$Element$width($mdgriffith$elm_ui$Element$fill)
						]),
					$author$project$MrJam$paragraphe(libelle)),
				aR: modifier
			});
	});
var $author$project$MrJam$Theme$champ = _List_fromArray(
	[
		$mdgriffith$elm_ui$Element$width($mdgriffith$elm_ui$Element$fill),
		$mdgriffith$elm_ui$Element$height(
		A2($mdgriffith$elm_ui$Element$minimum, 36, $mdgriffith$elm_ui$Element$shrink)),
		A2($mdgriffith$elm_ui$Element$paddingXY, 10, 7),
		$author$project$MrJam$Theme$fond($author$project$MrJam$Theme$couleurs.d_),
		$author$project$MrJam$Theme$police($author$project$MrJam$Theme$couleurs.c8),
		$author$project$MrJam$Theme$bordure($author$project$MrJam$Theme$couleurs.c1),
		$mdgriffith$elm_ui$Element$Border$width(1),
		$mdgriffith$elm_ui$Element$Border$rounded(5)
	]);
var $mdgriffith$elm_ui$Element$Input$Above = 2;
var $mdgriffith$elm_ui$Element$Input$labelAbove = $mdgriffith$elm_ui$Element$Input$Label(2);
var $mdgriffith$elm_ui$Internal$Model$paddingName = F4(
	function (top, right, bottom, left) {
		return 'pad-' + ($elm$core$String$fromInt(top) + ('-' + ($elm$core$String$fromInt(right) + ('-' + ($elm$core$String$fromInt(bottom) + ('-' + $elm$core$String$fromInt(left)))))));
	});
var $mdgriffith$elm_ui$Element$paddingEach = function (_v0) {
	var top = _v0.gB;
	var right = _v0.fZ;
	var bottom = _v0.eF;
	var left = _v0.fr;
	if (_Utils_eq(top, right) && (_Utils_eq(top, bottom) && _Utils_eq(top, left))) {
		var topFloat = top;
		return A2(
			$mdgriffith$elm_ui$Internal$Model$StyleClass,
			$mdgriffith$elm_ui$Internal$Flag$padding,
			A5(
				$mdgriffith$elm_ui$Internal$Model$PaddingStyle,
				'p-' + $elm$core$String$fromInt(top),
				topFloat,
				topFloat,
				topFloat,
				topFloat));
	} else {
		return A2(
			$mdgriffith$elm_ui$Internal$Model$StyleClass,
			$mdgriffith$elm_ui$Internal$Flag$padding,
			A5(
				$mdgriffith$elm_ui$Internal$Model$PaddingStyle,
				A4($mdgriffith$elm_ui$Internal$Model$paddingName, top, right, bottom, left),
				top,
				right,
				bottom,
				left));
	}
};
var $author$project$MrJam$etiquette = function (libelle) {
	return A2(
		$mdgriffith$elm_ui$Element$Input$labelAbove,
		_List_fromArray(
			[
				$mdgriffith$elm_ui$Element$Font$size(14),
				$mdgriffith$elm_ui$Element$Font$semiBold,
				$mdgriffith$elm_ui$Element$paddingEach(
				{eF: 6, fr: 0, fZ: 0, gB: 0})
			]),
		$mdgriffith$elm_ui$Element$text(libelle));
};
var $author$project$MrJam$saisie = F4(
	function (construire, libelle, valeur, modifier) {
		return A2(
			construire,
			$author$project$MrJam$Theme$champ,
			{
				au: $author$project$MrJam$etiquette(libelle),
				aR: modifier,
				bG: $elm$core$Maybe$Nothing,
				bL: valeur
			});
	});
var $mdgriffith$elm_ui$Element$Input$TextInputNode = function (a) {
	return {$: 0, a: a};
};
var $mdgriffith$elm_ui$Element$Input$TextArea = {$: 1};
var $mdgriffith$elm_ui$Element$Input$autofill = A2(
	$elm$core$Basics$composeL,
	$mdgriffith$elm_ui$Internal$Model$Attr,
	$elm$html$Html$Attributes$attribute('autocomplete'));
var $mdgriffith$elm_ui$Internal$Model$Behind = 5;
var $mdgriffith$elm_ui$Internal$Model$Nearby = F2(
	function (a, b) {
		return {$: 9, a: a, b: b};
	});
var $mdgriffith$elm_ui$Element$createNearby = F2(
	function (loc, element) {
		if (element.$ === 3) {
			return $mdgriffith$elm_ui$Internal$Model$NoAttribute;
		} else {
			return A2($mdgriffith$elm_ui$Internal$Model$Nearby, loc, element);
		}
	});
var $mdgriffith$elm_ui$Element$behindContent = function (element) {
	return A2($mdgriffith$elm_ui$Element$createNearby, 5, element);
};
var $mdgriffith$elm_ui$Internal$Model$MoveY = function (a) {
	return {$: 1, a: a};
};
var $mdgriffith$elm_ui$Internal$Model$TransformComponent = F2(
	function (a, b) {
		return {$: 10, a: a, b: b};
	});
var $mdgriffith$elm_ui$Internal$Flag$moveY = $mdgriffith$elm_ui$Internal$Flag$flag(26);
var $mdgriffith$elm_ui$Element$moveUp = function (y) {
	return A2(
		$mdgriffith$elm_ui$Internal$Model$TransformComponent,
		$mdgriffith$elm_ui$Internal$Flag$moveY,
		$mdgriffith$elm_ui$Internal$Model$MoveY(-y));
};
var $mdgriffith$elm_ui$Element$Input$calcMoveToCompensateForPadding = function (attrs) {
	var gatherSpacing = F2(
		function (attr, found) {
			if ((attr.$ === 4) && (attr.b.$ === 5)) {
				var _v2 = attr.b;
				var x = _v2.b;
				var y = _v2.c;
				if (found.$ === 1) {
					return $elm$core$Maybe$Just(y);
				} else {
					return found;
				}
			} else {
				return found;
			}
		});
	var _v0 = A3($elm$core$List$foldr, gatherSpacing, $elm$core$Maybe$Nothing, attrs);
	if (_v0.$ === 1) {
		return $mdgriffith$elm_ui$Internal$Model$NoAttribute;
	} else {
		var vSpace = _v0.a;
		return $mdgriffith$elm_ui$Element$moveUp(
			$elm$core$Basics$floor(vSpace / 2));
	}
};
var $mdgriffith$elm_ui$Internal$Flag$overflow = $mdgriffith$elm_ui$Internal$Flag$flag(20);
var $mdgriffith$elm_ui$Element$clip = A2($mdgriffith$elm_ui$Internal$Model$Class, $mdgriffith$elm_ui$Internal$Flag$overflow, $mdgriffith$elm_ui$Internal$Style$classes.eO);
var $mdgriffith$elm_ui$Internal$Model$Colored = F3(
	function (a, b, c) {
		return {$: 4, a: a, b: b, c: c};
	});
var $mdgriffith$elm_ui$Internal$Flag$bgColor = $mdgriffith$elm_ui$Internal$Flag$flag(8);
var $mdgriffith$elm_ui$Internal$Model$formatColorClass = function (_v0) {
	var red = _v0.a;
	var green = _v0.b;
	var blue = _v0.c;
	var alpha = _v0.d;
	return $mdgriffith$elm_ui$Internal$Model$floatClass(red) + ('-' + ($mdgriffith$elm_ui$Internal$Model$floatClass(green) + ('-' + ($mdgriffith$elm_ui$Internal$Model$floatClass(blue) + ('-' + $mdgriffith$elm_ui$Internal$Model$floatClass(alpha))))));
};
var $mdgriffith$elm_ui$Element$Background$color = function (clr) {
	return A2(
		$mdgriffith$elm_ui$Internal$Model$StyleClass,
		$mdgriffith$elm_ui$Internal$Flag$bgColor,
		A3(
			$mdgriffith$elm_ui$Internal$Model$Colored,
			'bg-' + $mdgriffith$elm_ui$Internal$Model$formatColorClass(clr),
			'background-color',
			clr));
};
var $mdgriffith$elm_ui$Internal$Flag$borderColor = $mdgriffith$elm_ui$Internal$Flag$flag(28);
var $mdgriffith$elm_ui$Element$Border$color = function (clr) {
	return A2(
		$mdgriffith$elm_ui$Internal$Model$StyleClass,
		$mdgriffith$elm_ui$Internal$Flag$borderColor,
		A3(
			$mdgriffith$elm_ui$Internal$Model$Colored,
			'bc-' + $mdgriffith$elm_ui$Internal$Model$formatColorClass(clr),
			'border-color',
			clr));
};
var $mdgriffith$elm_ui$Element$Input$darkGrey = A3($mdgriffith$elm_ui$Element$rgb, 186 / 255, 189 / 255, 182 / 255);
var $mdgriffith$elm_ui$Element$Input$defaultTextPadding = A2($mdgriffith$elm_ui$Element$paddingXY, 12, 12);
var $mdgriffith$elm_ui$Element$Input$white = A3($mdgriffith$elm_ui$Element$rgb, 1, 1, 1);
var $mdgriffith$elm_ui$Element$Input$defaultTextBoxStyle = _List_fromArray(
	[
		$mdgriffith$elm_ui$Element$Input$defaultTextPadding,
		$mdgriffith$elm_ui$Element$Border$rounded(3),
		$mdgriffith$elm_ui$Element$Border$color($mdgriffith$elm_ui$Element$Input$darkGrey),
		$mdgriffith$elm_ui$Element$Background$color($mdgriffith$elm_ui$Element$Input$white),
		$mdgriffith$elm_ui$Element$Border$width(1),
		$mdgriffith$elm_ui$Element$spacing(5),
		$mdgriffith$elm_ui$Element$width($mdgriffith$elm_ui$Element$fill),
		$mdgriffith$elm_ui$Element$height($mdgriffith$elm_ui$Element$shrink)
	]);
var $mdgriffith$elm_ui$Element$Input$getHeight = function (attr) {
	if (attr.$ === 8) {
		var h = attr.a;
		return $elm$core$Maybe$Just(h);
	} else {
		return $elm$core$Maybe$Nothing;
	}
};
var $mdgriffith$elm_ui$Internal$Model$InFront = 4;
var $mdgriffith$elm_ui$Element$inFront = function (element) {
	return A2($mdgriffith$elm_ui$Element$createNearby, 4, element);
};
var $mdgriffith$elm_ui$Element$Input$isConstrained = function (len) {
	isConstrained:
	while (true) {
		switch (len.$) {
			case 1:
				return false;
			case 0:
				return true;
			case 2:
				return true;
			case 3:
				var l = len.b;
				var $temp$len = l;
				len = $temp$len;
				continue isConstrained;
			default:
				var l = len.b;
				return true;
		}
	}
};
var $mdgriffith$elm_ui$Element$Input$isStacked = function (label) {
	if (!label.$) {
		var loc = label.a;
		switch (loc) {
			case 0:
				return false;
			case 1:
				return false;
			case 2:
				return true;
			default:
				return true;
		}
	} else {
		return true;
	}
};
var $mdgriffith$elm_ui$Element$Input$negateBox = function (box) {
	return {eF: -box.eF, fr: -box.fr, fZ: -box.fZ, gB: -box.gB};
};
var $elm$html$Html$Events$alwaysStop = function (x) {
	return _Utils_Tuple2(x, true);
};
var $elm$virtual_dom$VirtualDom$MayStopPropagation = function (a) {
	return {$: 1, a: a};
};
var $elm$html$Html$Events$stopPropagationOn = F2(
	function (event, decoder) {
		return A2(
			$elm$virtual_dom$VirtualDom$on,
			event,
			$elm$virtual_dom$VirtualDom$MayStopPropagation(decoder));
	});
var $elm$json$Json$Decode$at = F2(
	function (fields, decoder) {
		return A3($elm$core$List$foldr, $elm$json$Json$Decode$field, decoder, fields);
	});
var $elm$html$Html$Events$targetValue = A2(
	$elm$json$Json$Decode$at,
	_List_fromArray(
		['target', 'value']),
	$elm$json$Json$Decode$string);
var $elm$html$Html$Events$onInput = function (tagger) {
	return A2(
		$elm$html$Html$Events$stopPropagationOn,
		'input',
		A2(
			$elm$json$Json$Decode$map,
			$elm$html$Html$Events$alwaysStop,
			A2($elm$json$Json$Decode$map, tagger, $elm$html$Html$Events$targetValue)));
};
var $mdgriffith$elm_ui$Element$Input$isFill = function (len) {
	isFill:
	while (true) {
		switch (len.$) {
			case 2:
				return true;
			case 1:
				return false;
			case 0:
				return false;
			case 3:
				var l = len.b;
				var $temp$len = l;
				len = $temp$len;
				continue isFill;
			default:
				var l = len.b;
				var $temp$len = l;
				len = $temp$len;
				continue isFill;
		}
	}
};
var $mdgriffith$elm_ui$Element$Input$isPixel = function (len) {
	isPixel:
	while (true) {
		switch (len.$) {
			case 1:
				return false;
			case 0:
				return true;
			case 2:
				return false;
			case 3:
				var l = len.b;
				var $temp$len = l;
				len = $temp$len;
				continue isPixel;
			default:
				var l = len.b;
				var $temp$len = l;
				len = $temp$len;
				continue isPixel;
		}
	}
};
var $mdgriffith$elm_ui$Internal$Model$paddingNameFloat = F4(
	function (top, right, bottom, left) {
		return 'pad-' + ($mdgriffith$elm_ui$Internal$Model$floatClass(top) + ('-' + ($mdgriffith$elm_ui$Internal$Model$floatClass(right) + ('-' + ($mdgriffith$elm_ui$Internal$Model$floatClass(bottom) + ('-' + $mdgriffith$elm_ui$Internal$Model$floatClass(left)))))));
	});
var $mdgriffith$elm_ui$Element$Input$redistributeOver = F4(
	function (isMultiline, stacked, attr, els) {
		switch (attr.$) {
			case 9:
				return _Utils_update(
					els,
					{
						aV: A2($elm$core$List$cons, attr, els.aV)
					});
			case 7:
				var width = attr.a;
				return $mdgriffith$elm_ui$Element$Input$isFill(width) ? _Utils_update(
					els,
					{
						k: A2($elm$core$List$cons, attr, els.k),
						v: A2($elm$core$List$cons, attr, els.v),
						aV: A2($elm$core$List$cons, attr, els.aV)
					}) : (stacked ? _Utils_update(
					els,
					{
						k: A2($elm$core$List$cons, attr, els.k)
					}) : _Utils_update(
					els,
					{
						aV: A2($elm$core$List$cons, attr, els.aV)
					}));
			case 8:
				var height = attr.a;
				return (!stacked) ? _Utils_update(
					els,
					{
						k: A2($elm$core$List$cons, attr, els.k),
						aV: A2($elm$core$List$cons, attr, els.aV)
					}) : ($mdgriffith$elm_ui$Element$Input$isFill(height) ? _Utils_update(
					els,
					{
						k: A2($elm$core$List$cons, attr, els.k),
						aV: A2($elm$core$List$cons, attr, els.aV)
					}) : ($mdgriffith$elm_ui$Element$Input$isPixel(height) ? _Utils_update(
					els,
					{
						aV: A2($elm$core$List$cons, attr, els.aV)
					}) : _Utils_update(
					els,
					{
						aV: A2($elm$core$List$cons, attr, els.aV)
					})));
			case 6:
				return _Utils_update(
					els,
					{
						k: A2($elm$core$List$cons, attr, els.k)
					});
			case 5:
				return _Utils_update(
					els,
					{
						k: A2($elm$core$List$cons, attr, els.k)
					});
			case 4:
				switch (attr.b.$) {
					case 5:
						var _v1 = attr.b;
						return _Utils_update(
							els,
							{
								k: A2($elm$core$List$cons, attr, els.k),
								v: A2($elm$core$List$cons, attr, els.v),
								aV: A2($elm$core$List$cons, attr, els.aV),
								br: A2($elm$core$List$cons, attr, els.br)
							});
					case 7:
						var cls = attr.a;
						var _v2 = attr.b;
						var pad = _v2.a;
						var t = _v2.b;
						var r = _v2.c;
						var b = _v2.d;
						var l = _v2.e;
						if (isMultiline) {
							return _Utils_update(
								els,
								{
									K: A2($elm$core$List$cons, attr, els.K),
									aV: A2($elm$core$List$cons, attr, els.aV)
								});
						} else {
							var newTop = t - A2($elm$core$Basics$min, t, b);
							var newLineHeight = $mdgriffith$elm_ui$Element$htmlAttribute(
								A2(
									$elm$html$Html$Attributes$style,
									'line-height',
									'calc(1.0em + ' + ($elm$core$String$fromFloat(
										2 * A2($elm$core$Basics$min, t, b)) + 'px)')));
							var newHeight = $mdgriffith$elm_ui$Element$htmlAttribute(
								A2(
									$elm$html$Html$Attributes$style,
									'height',
									'calc(1.0em + ' + ($elm$core$String$fromFloat(
										2 * A2($elm$core$Basics$min, t, b)) + 'px)')));
							var newBottom = b - A2($elm$core$Basics$min, t, b);
							var reducedVerticalPadding = A2(
								$mdgriffith$elm_ui$Internal$Model$StyleClass,
								$mdgriffith$elm_ui$Internal$Flag$padding,
								A5(
									$mdgriffith$elm_ui$Internal$Model$PaddingStyle,
									A4($mdgriffith$elm_ui$Internal$Model$paddingNameFloat, newTop, r, newBottom, l),
									newTop,
									r,
									newBottom,
									l));
							return _Utils_update(
								els,
								{
									K: A2($elm$core$List$cons, attr, els.K),
									v: A2(
										$elm$core$List$cons,
										newHeight,
										A2($elm$core$List$cons, newLineHeight, els.v)),
									aV: A2($elm$core$List$cons, reducedVerticalPadding, els.aV)
								});
						}
					case 6:
						var _v3 = attr.b;
						return _Utils_update(
							els,
							{
								K: A2($elm$core$List$cons, attr, els.K),
								aV: A2($elm$core$List$cons, attr, els.aV)
							});
					case 10:
						return _Utils_update(
							els,
							{
								K: A2($elm$core$List$cons, attr, els.K),
								aV: A2($elm$core$List$cons, attr, els.aV)
							});
					case 2:
						return _Utils_update(
							els,
							{
								k: A2($elm$core$List$cons, attr, els.k)
							});
					case 1:
						var _v4 = attr.b;
						return _Utils_update(
							els,
							{
								k: A2($elm$core$List$cons, attr, els.k)
							});
					default:
						var flag = attr.a;
						var cls = attr.b;
						return _Utils_update(
							els,
							{
								aV: A2($elm$core$List$cons, attr, els.aV)
							});
				}
			case 0:
				return els;
			case 1:
				var a = attr.a;
				return _Utils_update(
					els,
					{
						v: A2($elm$core$List$cons, attr, els.v)
					});
			case 2:
				return _Utils_update(
					els,
					{
						v: A2($elm$core$List$cons, attr, els.v)
					});
			case 3:
				return _Utils_update(
					els,
					{
						aV: A2($elm$core$List$cons, attr, els.aV)
					});
			default:
				return _Utils_update(
					els,
					{
						v: A2($elm$core$List$cons, attr, els.v)
					});
		}
	});
var $mdgriffith$elm_ui$Element$Input$redistribute = F3(
	function (isMultiline, stacked, attrs) {
		return function (redist) {
			return {
				K: $elm$core$List$reverse(redist.K),
				k: $elm$core$List$reverse(redist.k),
				v: $elm$core$List$reverse(redist.v),
				aV: $elm$core$List$reverse(redist.aV),
				br: $elm$core$List$reverse(redist.br)
			};
		}(
			A3(
				$elm$core$List$foldl,
				A2($mdgriffith$elm_ui$Element$Input$redistributeOver, isMultiline, stacked),
				{K: _List_Nil, k: _List_Nil, v: _List_Nil, aV: _List_Nil, br: _List_Nil},
				attrs));
	});
var $mdgriffith$elm_ui$Element$Input$renderBox = function (_v0) {
	var top = _v0.gB;
	var right = _v0.fZ;
	var bottom = _v0.eF;
	var left = _v0.fr;
	return $elm$core$String$fromInt(top) + ('px ' + ($elm$core$String$fromInt(right) + ('px ' + ($elm$core$String$fromInt(bottom) + ('px ' + ($elm$core$String$fromInt(left) + 'px'))))));
};
var $mdgriffith$elm_ui$Internal$Model$Transparency = F2(
	function (a, b) {
		return {$: 12, a: a, b: b};
	});
var $mdgriffith$elm_ui$Internal$Flag$transparency = $mdgriffith$elm_ui$Internal$Flag$flag(0);
var $mdgriffith$elm_ui$Element$alpha = function (o) {
	var transparency = function (x) {
		return 1 - x;
	}(
		A2(
			$elm$core$Basics$min,
			1.0,
			A2($elm$core$Basics$max, 0.0, o)));
	return A2(
		$mdgriffith$elm_ui$Internal$Model$StyleClass,
		$mdgriffith$elm_ui$Internal$Flag$transparency,
		A2(
			$mdgriffith$elm_ui$Internal$Model$Transparency,
			'transparency-' + $mdgriffith$elm_ui$Internal$Model$floatClass(transparency),
			transparency));
};
var $mdgriffith$elm_ui$Element$Input$charcoal = A3($mdgriffith$elm_ui$Element$rgb, 136 / 255, 138 / 255, 133 / 255);
var $mdgriffith$elm_ui$Internal$Flag$fontColor = $mdgriffith$elm_ui$Internal$Flag$flag(14);
var $mdgriffith$elm_ui$Element$Font$color = function (fontColor) {
	return A2(
		$mdgriffith$elm_ui$Internal$Model$StyleClass,
		$mdgriffith$elm_ui$Internal$Flag$fontColor,
		A3(
			$mdgriffith$elm_ui$Internal$Model$Colored,
			'fc-' + $mdgriffith$elm_ui$Internal$Model$formatColorClass(fontColor),
			'color',
			fontColor));
};
var $mdgriffith$elm_ui$Element$rgba = $mdgriffith$elm_ui$Internal$Model$Rgba;
var $mdgriffith$elm_ui$Element$Input$renderPlaceholder = F3(
	function (_v0, forPlaceholder, on) {
		var placeholderAttrs = _v0.a;
		var placeholderEl = _v0.b;
		return A2(
			$mdgriffith$elm_ui$Element$el,
			_Utils_ap(
				forPlaceholder,
				_Utils_ap(
					_List_fromArray(
						[
							$mdgriffith$elm_ui$Element$Font$color($mdgriffith$elm_ui$Element$Input$charcoal),
							$mdgriffith$elm_ui$Internal$Model$htmlClass($mdgriffith$elm_ui$Internal$Style$classes.dz + (' ' + $mdgriffith$elm_ui$Internal$Style$classes.fS)),
							$mdgriffith$elm_ui$Element$clip,
							$mdgriffith$elm_ui$Element$Border$color(
							A4($mdgriffith$elm_ui$Element$rgba, 0, 0, 0, 0)),
							$mdgriffith$elm_ui$Element$Background$color(
							A4($mdgriffith$elm_ui$Element$rgba, 0, 0, 0, 0)),
							$mdgriffith$elm_ui$Element$height($mdgriffith$elm_ui$Element$fill),
							$mdgriffith$elm_ui$Element$width($mdgriffith$elm_ui$Element$fill),
							$mdgriffith$elm_ui$Element$alpha(
							on ? 1 : 0)
						]),
					placeholderAttrs)),
			placeholderEl);
	});
var $mdgriffith$elm_ui$Element$scrollbarY = A2($mdgriffith$elm_ui$Internal$Model$Class, $mdgriffith$elm_ui$Internal$Flag$overflow, $mdgriffith$elm_ui$Internal$Style$classes.f4);
var $elm$html$Html$span = _VirtualDom_node('span');
var $elm$html$Html$Attributes$spellcheck = $elm$html$Html$Attributes$boolProperty('spellcheck');
var $mdgriffith$elm_ui$Element$Input$spellcheck = A2($elm$core$Basics$composeL, $mdgriffith$elm_ui$Internal$Model$Attr, $elm$html$Html$Attributes$spellcheck);
var $elm$html$Html$Attributes$type_ = $elm$html$Html$Attributes$stringProperty('type');
var $elm$html$Html$Attributes$value = $elm$html$Html$Attributes$stringProperty('value');
var $mdgriffith$elm_ui$Element$Input$value = A2($elm$core$Basics$composeL, $mdgriffith$elm_ui$Internal$Model$Attr, $elm$html$Html$Attributes$value);
var $mdgriffith$elm_ui$Element$Input$textHelper = F3(
	function (textInput, attrs, textOptions) {
		var withDefaults = _Utils_ap($mdgriffith$elm_ui$Element$Input$defaultTextBoxStyle, attrs);
		var redistributed = A3(
			$mdgriffith$elm_ui$Element$Input$redistribute,
			_Utils_eq(textInput.gE, $mdgriffith$elm_ui$Element$Input$TextArea),
			$mdgriffith$elm_ui$Element$Input$isStacked(textOptions.au),
			withDefaults);
		var onlySpacing = function (attr) {
			if ((attr.$ === 4) && (attr.b.$ === 5)) {
				var _v9 = attr.b;
				return true;
			} else {
				return false;
			}
		};
		var heightConstrained = function () {
			var _v7 = textInput.gE;
			if (!_v7.$) {
				var inputType = _v7.a;
				return false;
			} else {
				return A2(
					$elm$core$Maybe$withDefault,
					false,
					A2(
						$elm$core$Maybe$map,
						$mdgriffith$elm_ui$Element$Input$isConstrained,
						$elm$core$List$head(
							$elm$core$List$reverse(
								A2($elm$core$List$filterMap, $mdgriffith$elm_ui$Element$Input$getHeight, withDefaults)))));
			}
		}();
		var getPadding = function (attr) {
			if ((attr.$ === 4) && (attr.b.$ === 7)) {
				var cls = attr.a;
				var _v6 = attr.b;
				var pad = _v6.a;
				var t = _v6.b;
				var r = _v6.c;
				var b = _v6.d;
				var l = _v6.e;
				return $elm$core$Maybe$Just(
					{
						eF: A2(
							$elm$core$Basics$max,
							0,
							$elm$core$Basics$floor(b - 3)),
						fr: A2(
							$elm$core$Basics$max,
							0,
							$elm$core$Basics$floor(l - 3)),
						fZ: A2(
							$elm$core$Basics$max,
							0,
							$elm$core$Basics$floor(r - 3)),
						gB: A2(
							$elm$core$Basics$max,
							0,
							$elm$core$Basics$floor(t - 3))
					});
			} else {
				return $elm$core$Maybe$Nothing;
			}
		};
		var parentPadding = A2(
			$elm$core$Maybe$withDefault,
			{eF: 0, fr: 0, fZ: 0, gB: 0},
			$elm$core$List$head(
				$elm$core$List$reverse(
					A2($elm$core$List$filterMap, getPadding, withDefaults))));
		var inputElement = A4(
			$mdgriffith$elm_ui$Internal$Model$element,
			$mdgriffith$elm_ui$Internal$Model$asEl,
			function () {
				var _v3 = textInput.gE;
				if (!_v3.$) {
					var inputType = _v3.a;
					return $mdgriffith$elm_ui$Internal$Model$NodeName('input');
				} else {
					return $mdgriffith$elm_ui$Internal$Model$NodeName('textarea');
				}
			}(),
			_Utils_ap(
				function () {
					var _v4 = textInput.gE;
					if (!_v4.$) {
						var inputType = _v4.a;
						return _List_fromArray(
							[
								$mdgriffith$elm_ui$Internal$Model$Attr(
								$elm$html$Html$Attributes$type_(inputType)),
								$mdgriffith$elm_ui$Internal$Model$htmlClass($mdgriffith$elm_ui$Internal$Style$classes.fo)
							]);
					} else {
						return _List_fromArray(
							[
								$mdgriffith$elm_ui$Element$clip,
								$mdgriffith$elm_ui$Element$height($mdgriffith$elm_ui$Element$fill),
								$mdgriffith$elm_ui$Internal$Model$htmlClass($mdgriffith$elm_ui$Internal$Style$classes.fk),
								$mdgriffith$elm_ui$Element$Input$calcMoveToCompensateForPadding(withDefaults),
								$mdgriffith$elm_ui$Element$paddingEach(parentPadding),
								$mdgriffith$elm_ui$Internal$Model$Attr(
								A2(
									$elm$html$Html$Attributes$style,
									'margin',
									$mdgriffith$elm_ui$Element$Input$renderBox(
										$mdgriffith$elm_ui$Element$Input$negateBox(parentPadding)))),
								$mdgriffith$elm_ui$Internal$Model$Attr(
								A2($elm$html$Html$Attributes$style, 'box-sizing', 'content-box'))
							]);
					}
				}(),
				_Utils_ap(
					_List_fromArray(
						[
							$mdgriffith$elm_ui$Element$Input$value(textOptions.bL),
							$mdgriffith$elm_ui$Internal$Model$Attr(
							$elm$html$Html$Events$onInput(textOptions.aR)),
							$mdgriffith$elm_ui$Element$Input$hiddenLabelAttribute(textOptions.au),
							$mdgriffith$elm_ui$Element$Input$spellcheck(textInput.ad),
							A2(
							$elm$core$Maybe$withDefault,
							$mdgriffith$elm_ui$Internal$Model$NoAttribute,
							A2($elm$core$Maybe$map, $mdgriffith$elm_ui$Element$Input$autofill, textInput.R))
						]),
					redistributed.v)),
			$mdgriffith$elm_ui$Internal$Model$Unkeyed(_List_Nil));
		var wrappedInput = function () {
			var _v0 = textInput.gE;
			if (_v0.$ === 1) {
				return A4(
					$mdgriffith$elm_ui$Internal$Model$element,
					$mdgriffith$elm_ui$Internal$Model$asEl,
					$mdgriffith$elm_ui$Internal$Model$div,
					_Utils_ap(
						(heightConstrained ? $elm$core$List$cons($mdgriffith$elm_ui$Element$scrollbarY) : $elm$core$Basics$identity)(
							_List_fromArray(
								[
									$mdgriffith$elm_ui$Element$width($mdgriffith$elm_ui$Element$fill),
									A2($elm$core$List$any, $mdgriffith$elm_ui$Element$Input$hasFocusStyle, withDefaults) ? $mdgriffith$elm_ui$Internal$Model$NoAttribute : $mdgriffith$elm_ui$Internal$Model$htmlClass($mdgriffith$elm_ui$Internal$Style$classes.dc),
									$mdgriffith$elm_ui$Internal$Model$htmlClass($mdgriffith$elm_ui$Internal$Style$classes.fn)
								])),
						redistributed.aV),
					$mdgriffith$elm_ui$Internal$Model$Unkeyed(
						_List_fromArray(
							[
								A4(
								$mdgriffith$elm_ui$Internal$Model$element,
								$mdgriffith$elm_ui$Internal$Model$asParagraph,
								$mdgriffith$elm_ui$Internal$Model$div,
								A2(
									$elm$core$List$cons,
									$mdgriffith$elm_ui$Element$width($mdgriffith$elm_ui$Element$fill),
									A2(
										$elm$core$List$cons,
										$mdgriffith$elm_ui$Element$height($mdgriffith$elm_ui$Element$fill),
										A2(
											$elm$core$List$cons,
											$mdgriffith$elm_ui$Element$inFront(inputElement),
											A2(
												$elm$core$List$cons,
												$mdgriffith$elm_ui$Internal$Model$htmlClass($mdgriffith$elm_ui$Internal$Style$classes.fm),
												redistributed.br)))),
								$mdgriffith$elm_ui$Internal$Model$Unkeyed(
									function () {
										if (textOptions.bL === '') {
											var _v1 = textOptions.bG;
											if (_v1.$ === 1) {
												return _List_fromArray(
													[
														$mdgriffith$elm_ui$Element$text('\u00A0')
													]);
											} else {
												var place = _v1.a;
												return _List_fromArray(
													[
														A3($mdgriffith$elm_ui$Element$Input$renderPlaceholder, place, _List_Nil, textOptions.bL === '')
													]);
											}
										} else {
											return _List_fromArray(
												[
													$mdgriffith$elm_ui$Internal$Model$unstyled(
													A2(
														$elm$html$Html$span,
														_List_fromArray(
															[
																$elm$html$Html$Attributes$class($mdgriffith$elm_ui$Internal$Style$classes.fl)
															]),
														_List_fromArray(
															[
																$elm$html$Html$text(textOptions.bL + '\u00A0')
															])))
												]);
										}
									}()))
							])));
			} else {
				var inputType = _v0.a;
				return A4(
					$mdgriffith$elm_ui$Internal$Model$element,
					$mdgriffith$elm_ui$Internal$Model$asEl,
					$mdgriffith$elm_ui$Internal$Model$div,
					A2(
						$elm$core$List$cons,
						$mdgriffith$elm_ui$Element$width($mdgriffith$elm_ui$Element$fill),
						A2(
							$elm$core$List$cons,
							A2($elm$core$List$any, $mdgriffith$elm_ui$Element$Input$hasFocusStyle, withDefaults) ? $mdgriffith$elm_ui$Internal$Model$NoAttribute : $mdgriffith$elm_ui$Internal$Model$htmlClass($mdgriffith$elm_ui$Internal$Style$classes.dc),
							$elm$core$List$concat(
								_List_fromArray(
									[
										redistributed.aV,
										function () {
										var _v2 = textOptions.bG;
										if (_v2.$ === 1) {
											return _List_Nil;
										} else {
											var place = _v2.a;
											return _List_fromArray(
												[
													$mdgriffith$elm_ui$Element$behindContent(
													A3($mdgriffith$elm_ui$Element$Input$renderPlaceholder, place, redistributed.K, textOptions.bL === ''))
												]);
										}
									}()
									])))),
					$mdgriffith$elm_ui$Internal$Model$Unkeyed(
						_List_fromArray(
							[inputElement])));
			}
		}();
		return A3(
			$mdgriffith$elm_ui$Element$Input$applyLabel,
			A2(
				$elm$core$List$cons,
				A2($mdgriffith$elm_ui$Internal$Model$Class, $mdgriffith$elm_ui$Internal$Flag$cursor, $mdgriffith$elm_ui$Internal$Style$classes.eU),
				A2(
					$elm$core$List$cons,
					$mdgriffith$elm_ui$Element$Input$isHiddenLabel(textOptions.au) ? $mdgriffith$elm_ui$Internal$Model$NoAttribute : $mdgriffith$elm_ui$Element$spacing(5),
					A2($elm$core$List$cons, $mdgriffith$elm_ui$Element$Region$announce, redistributed.k))),
			textOptions.au,
			wrappedInput);
	});
var $mdgriffith$elm_ui$Element$Input$text = $mdgriffith$elm_ui$Element$Input$textHelper(
	{
		R: $elm$core$Maybe$Nothing,
		ad: false,
		gE: $mdgriffith$elm_ui$Element$Input$TextInputNode('text')
	});
var $author$project$MrJam$champ = $author$project$MrJam$saisie($mdgriffith$elm_ui$Element$Input$text);
var $mdgriffith$elm_ui$Element$column = F2(
	function (attrs, children) {
		return A4(
			$mdgriffith$elm_ui$Internal$Model$element,
			$mdgriffith$elm_ui$Internal$Model$asColumn,
			$mdgriffith$elm_ui$Internal$Model$div,
			A2(
				$elm$core$List$cons,
				$mdgriffith$elm_ui$Internal$Model$htmlClass($mdgriffith$elm_ui$Internal$Style$classes.eS + (' ' + $mdgriffith$elm_ui$Internal$Style$classes.bv)),
				A2(
					$elm$core$List$cons,
					$mdgriffith$elm_ui$Element$height($mdgriffith$elm_ui$Element$shrink),
					A2(
						$elm$core$List$cons,
						$mdgriffith$elm_ui$Element$width($mdgriffith$elm_ui$Element$shrink),
						attrs))),
			$mdgriffith$elm_ui$Internal$Model$Unkeyed(children));
	});
var $mdgriffith$elm_ui$Internal$Model$Heading = function (a) {
	return {$: 4, a: a};
};
var $mdgriffith$elm_ui$Element$Region$heading = A2($elm$core$Basics$composeL, $mdgriffith$elm_ui$Internal$Model$Describe, $mdgriffith$elm_ui$Internal$Model$Heading);
var $author$project$MrJam$Documents$document = F2(
	function (titre, contenu) {
		return A2(
			$mdgriffith$elm_ui$Element$column,
			_List_fromArray(
				[
					$mdgriffith$elm_ui$Element$width($mdgriffith$elm_ui$Element$fill),
					$mdgriffith$elm_ui$Element$spacing(18)
				]),
			A2(
				$elm$core$List$cons,
				A2(
					$mdgriffith$elm_ui$Element$paragraph,
					_List_fromArray(
						[
							$mdgriffith$elm_ui$Element$width($mdgriffith$elm_ui$Element$fill),
							$mdgriffith$elm_ui$Element$Region$heading(2),
							$mdgriffith$elm_ui$Element$htmlAttribute(
							$elm$html$Html$Attributes$tabindex(-1)),
							$mdgriffith$elm_ui$Element$Font$size(26),
							$mdgriffith$elm_ui$Element$Font$bold
						]),
					_List_fromArray(
						[
							$mdgriffith$elm_ui$Element$text(titre)
						])),
				contenu));
	});
var $author$project$Main$Budget = function (a) {
	return {$: 54, a: a};
};
var $author$project$Main$DureeSeanceCourte = function (a) {
	return {$: 55, a: a};
};
var $author$project$Main$Intervalle = function (a) {
	return {$: 53, a: a};
};
var $author$project$Main$QuestionsTypiques = function (a) {
	return {$: 56, a: a};
};
var $author$project$Main$Reessayer = {$: 46};
var $author$project$Main$SauverPolitique = {$: 57};
var $mdgriffith$elm_ui$Internal$Model$Padding = F5(
	function (a, b, c, d, e) {
		return {$: 0, a: a, b: b, c: c, d: d, e: e};
	});
var $mdgriffith$elm_ui$Internal$Model$Spaced = F3(
	function (a, b, c) {
		return {$: 0, a: a, b: b, c: c};
	});
var $mdgriffith$elm_ui$Internal$Model$extractSpacingAndPadding = function (attrs) {
	return A3(
		$elm$core$List$foldr,
		F2(
			function (attr, _v0) {
				var pad = _v0.a;
				var spacing = _v0.b;
				return _Utils_Tuple2(
					function () {
						if (!pad.$) {
							var x = pad.a;
							return pad;
						} else {
							if ((attr.$ === 4) && (attr.b.$ === 7)) {
								var _v3 = attr.b;
								var name = _v3.a;
								var t = _v3.b;
								var r = _v3.c;
								var b = _v3.d;
								var l = _v3.e;
								return $elm$core$Maybe$Just(
									A5($mdgriffith$elm_ui$Internal$Model$Padding, name, t, r, b, l));
							} else {
								return $elm$core$Maybe$Nothing;
							}
						}
					}(),
					function () {
						if (!spacing.$) {
							var x = spacing.a;
							return spacing;
						} else {
							if ((attr.$ === 4) && (attr.b.$ === 5)) {
								var _v6 = attr.b;
								var name = _v6.a;
								var x = _v6.b;
								var y = _v6.c;
								return $elm$core$Maybe$Just(
									A3($mdgriffith$elm_ui$Internal$Model$Spaced, name, x, y));
							} else {
								return $elm$core$Maybe$Nothing;
							}
						}
					}());
			}),
		_Utils_Tuple2($elm$core$Maybe$Nothing, $elm$core$Maybe$Nothing),
		attrs);
};
var $mdgriffith$elm_ui$Element$wrappedRow = F2(
	function (attrs, children) {
		var _v0 = $mdgriffith$elm_ui$Internal$Model$extractSpacingAndPadding(attrs);
		var padded = _v0.a;
		var spaced = _v0.b;
		if (spaced.$ === 1) {
			return A4(
				$mdgriffith$elm_ui$Internal$Model$element,
				$mdgriffith$elm_ui$Internal$Model$asRow,
				$mdgriffith$elm_ui$Internal$Model$div,
				A2(
					$elm$core$List$cons,
					$mdgriffith$elm_ui$Internal$Model$htmlClass($mdgriffith$elm_ui$Internal$Style$classes.bv + (' ' + ($mdgriffith$elm_ui$Internal$Style$classes.ar + (' ' + $mdgriffith$elm_ui$Internal$Style$classes.cR)))),
					A2(
						$elm$core$List$cons,
						$mdgriffith$elm_ui$Element$width($mdgriffith$elm_ui$Element$shrink),
						A2(
							$elm$core$List$cons,
							$mdgriffith$elm_ui$Element$height($mdgriffith$elm_ui$Element$shrink),
							attrs))),
				$mdgriffith$elm_ui$Internal$Model$Unkeyed(children));
		} else {
			var _v2 = spaced.a;
			var spaceName = _v2.a;
			var x = _v2.b;
			var y = _v2.c;
			var newPadding = function () {
				if (!padded.$) {
					var _v5 = padded.a;
					var name = _v5.a;
					var t = _v5.b;
					var r = _v5.c;
					var b = _v5.d;
					var l = _v5.e;
					if ((_Utils_cmp(r, x / 2) > -1) && (_Utils_cmp(b, y / 2) > -1)) {
						var newTop = t - (y / 2);
						var newRight = r - (x / 2);
						var newLeft = l - (x / 2);
						var newBottom = b - (y / 2);
						return $elm$core$Maybe$Just(
							A2(
								$mdgriffith$elm_ui$Internal$Model$StyleClass,
								$mdgriffith$elm_ui$Internal$Flag$padding,
								A5(
									$mdgriffith$elm_ui$Internal$Model$PaddingStyle,
									A4($mdgriffith$elm_ui$Internal$Model$paddingNameFloat, newTop, newRight, newBottom, newLeft),
									newTop,
									newRight,
									newBottom,
									newLeft)));
					} else {
						return $elm$core$Maybe$Nothing;
					}
				} else {
					return $elm$core$Maybe$Nothing;
				}
			}();
			if (!newPadding.$) {
				var pad = newPadding.a;
				return A4(
					$mdgriffith$elm_ui$Internal$Model$element,
					$mdgriffith$elm_ui$Internal$Model$asRow,
					$mdgriffith$elm_ui$Internal$Model$div,
					A2(
						$elm$core$List$cons,
						$mdgriffith$elm_ui$Internal$Model$htmlClass($mdgriffith$elm_ui$Internal$Style$classes.bv + (' ' + ($mdgriffith$elm_ui$Internal$Style$classes.ar + (' ' + $mdgriffith$elm_ui$Internal$Style$classes.cR)))),
						A2(
							$elm$core$List$cons,
							$mdgriffith$elm_ui$Element$width($mdgriffith$elm_ui$Element$shrink),
							A2(
								$elm$core$List$cons,
								$mdgriffith$elm_ui$Element$height($mdgriffith$elm_ui$Element$shrink),
								_Utils_ap(
									attrs,
									_List_fromArray(
										[pad]))))),
					$mdgriffith$elm_ui$Internal$Model$Unkeyed(children));
			} else {
				var halfY = -(y / 2);
				var halfX = -(x / 2);
				return A4(
					$mdgriffith$elm_ui$Internal$Model$element,
					$mdgriffith$elm_ui$Internal$Model$asEl,
					$mdgriffith$elm_ui$Internal$Model$div,
					attrs,
					$mdgriffith$elm_ui$Internal$Model$Unkeyed(
						_List_fromArray(
							[
								A4(
								$mdgriffith$elm_ui$Internal$Model$element,
								$mdgriffith$elm_ui$Internal$Model$asRow,
								$mdgriffith$elm_ui$Internal$Model$div,
								A2(
									$elm$core$List$cons,
									$mdgriffith$elm_ui$Internal$Model$htmlClass($mdgriffith$elm_ui$Internal$Style$classes.bv + (' ' + ($mdgriffith$elm_ui$Internal$Style$classes.ar + (' ' + $mdgriffith$elm_ui$Internal$Style$classes.cR)))),
									A2(
										$elm$core$List$cons,
										$mdgriffith$elm_ui$Internal$Model$Attr(
											A2(
												$elm$html$Html$Attributes$style,
												'margin',
												$elm$core$String$fromFloat(halfY) + ('px' + (' ' + ($elm$core$String$fromFloat(halfX) + 'px'))))),
										A2(
											$elm$core$List$cons,
											$mdgriffith$elm_ui$Internal$Model$Attr(
												A2(
													$elm$html$Html$Attributes$style,
													'width',
													'calc(100% + ' + ($elm$core$String$fromInt(x) + 'px)'))),
											A2(
												$elm$core$List$cons,
												$mdgriffith$elm_ui$Internal$Model$Attr(
													A2(
														$elm$html$Html$Attributes$style,
														'height',
														'calc(100% + ' + ($elm$core$String$fromInt(y) + 'px)'))),
												A2(
													$elm$core$List$cons,
													A2(
														$mdgriffith$elm_ui$Internal$Model$StyleClass,
														$mdgriffith$elm_ui$Internal$Flag$spacing,
														A3($mdgriffith$elm_ui$Internal$Model$SpacingStyle, spaceName, x, y)),
													_List_Nil))))),
								$mdgriffith$elm_ui$Internal$Model$Unkeyed(children))
							])));
			}
		}
	});
var $author$project$MrJam$actions = $mdgriffith$elm_ui$Element$wrappedRow(
	_List_fromArray(
		[
			$mdgriffith$elm_ui$Element$width($mdgriffith$elm_ui$Element$fill),
			$mdgriffith$elm_ui$Element$spacing(8)
		]));
var $author$project$MrJam$Controles$Secondaire = {$: 1};
var $author$project$MrJam$boutonSecondaire = F2(
	function (libelle, message) {
		return A4(
			$author$project$MrJam$Controles$action,
			$author$project$MrJam$Controles$Secondaire,
			_List_Nil,
			libelle,
			$elm$core$Maybe$Just(message));
	});
var $author$project$Main$db = function (n) {
	return ((n >= 0) ? '+' : '') + ($elm$core$String$fromInt(n) + ' dB');
};
var $elm$core$Dict$isEmpty = function (dict) {
	if (dict.$ === -2) {
		return true;
	} else {
		return false;
	}
};
var $elm$html$Html$Attributes$step = function (n) {
	return A2($elm$html$Html$Attributes$stringProperty, 'step', n);
};
var $author$project$MrJam$Donnees$saisie = F4(
	function (nature, libelle, valeur, modifier) {
		return A2(
			$mdgriffith$elm_ui$Element$Input$text,
			_Utils_ap(
				$author$project$MrJam$Theme$champ,
				_List_fromArray(
					[
						$mdgriffith$elm_ui$Element$htmlAttribute(
						$elm$html$Html$Attributes$type_(nature)),
						$mdgriffith$elm_ui$Element$htmlAttribute(
						$elm$html$Html$Attributes$step('any')),
						$mdgriffith$elm_ui$Element$htmlAttribute(
						A2($elm$html$Html$Attributes$style, 'min-height', '36px'))
					])),
			{
				au: A2(
					$mdgriffith$elm_ui$Element$Input$labelAbove,
					_List_fromArray(
						[
							$mdgriffith$elm_ui$Element$Font$size(14),
							$mdgriffith$elm_ui$Element$Font$semiBold,
							$mdgriffith$elm_ui$Element$paddingEach(
							{eF: 6, fr: 0, fZ: 0, gB: 0})
						]),
					$mdgriffith$elm_ui$Element$text(libelle)),
				aR: modifier,
				bG: $elm$core$Maybe$Nothing,
				bL: valeur
			});
	});
var $author$project$MrJam$Donnees$nombre = $author$project$MrJam$Donnees$saisie('number');
var $author$project$MrJam$Documents$section = F2(
	function (titre, contenu) {
		return A2(
			$mdgriffith$elm_ui$Element$column,
			_List_fromArray(
				[
					$mdgriffith$elm_ui$Element$width($mdgriffith$elm_ui$Element$fill),
					$mdgriffith$elm_ui$Element$spacing(12)
				]),
			A2(
				$elm$core$List$cons,
				A2(
					$mdgriffith$elm_ui$Element$paragraph,
					_List_fromArray(
						[
							$mdgriffith$elm_ui$Element$width($mdgriffith$elm_ui$Element$fill),
							$mdgriffith$elm_ui$Element$Region$heading(3),
							$mdgriffith$elm_ui$Element$Font$size(18),
							$mdgriffith$elm_ui$Element$Font$semiBold
						]),
					_List_fromArray(
						[
							$mdgriffith$elm_ui$Element$text(titre)
						])),
				contenu));
	});
var $author$project$Main$AfficherLiens = {$: 47};
var $author$project$Main$AnnulerEdition = {$: 34};
var $author$project$Main$AnnulerLigne = {$: 41};
var $author$project$Main$Archiver = function (a) {
	return {$: 4, a: a};
};
var $author$project$Main$ChercherLiens = {$: 49};
var $author$project$Main$Detacher = F3(
	function (a, b, c) {
		return {$: 5, a: a, b: b, c: c};
	});
var $author$project$Main$Editer = {$: 33};
var $author$project$Main$EditerLigne = function (a) {
	return {$: 38, a: a};
};
var $author$project$MrJam$Pictogrammes$Enregistrer = 2;
var $author$project$Main$Fermer = {$: 1};
var $author$project$MrJam$Pictogrammes$Fermer = 3;
var $author$project$Main$FiltreLiens = function (a) {
	return {$: 37, a: a};
};
var $author$project$MrJam$Pictogrammes$Filtrer = 5;
var $author$project$MrJam$Pictogrammes$Modifier = 1;
var $author$project$Main$OutilsLiens = function (a) {
	return {$: 35, a: a};
};
var $author$project$Main$PageLiens = function (a) {
	return {$: 51, a: a};
};
var $author$project$Main$Rattacher = function (a) {
	return {$: 50, a: a};
};
var $author$project$Main$RechercheLiens = function (a) {
	return {$: 48, a: a};
};
var $author$project$MrJam$Pictogrammes$Retour = 4;
var $author$project$Main$Saisir = F2(
	function (a, b) {
		return {$: 42, a: a, b: b};
	});
var $author$project$Main$SaisirLigne = function (a) {
	return {$: 39, a: a};
};
var $author$project$Main$Sauver = {$: 43};
var $author$project$Main$SauverLigne = {$: 40};
var $author$project$Main$TriLiens = function (a) {
	return {$: 36, a: a};
};
var $author$project$MrJam$Pictogrammes$Trier = 6;
var $author$project$MrJam$Documents$actionSur = F3(
	function (libelle, cible, message) {
		return A4(
			$author$project$MrJam$Controles$action,
			$author$project$MrJam$Controles$Discrete,
			_List_fromArray(
				[
					$mdgriffith$elm_ui$Element$htmlAttribute(
					A2($elm$html$Html$Attributes$attribute, 'aria-label', libelle + (' : ' + cible)))
				]),
			libelle,
			$elm$core$Maybe$Just(message));
	});
var $author$project$MrJam$Documents$actions = $author$project$MrJam$actions;
var $author$project$Contrat$autre = function (nature) {
	if (!nature) {
		return 1;
	} else {
		return 0;
	}
};
var $mdgriffith$elm_ui$Element$Input$HiddenLabel = function (a) {
	return {$: 1, a: a};
};
var $mdgriffith$elm_ui$Element$Input$labelHidden = $mdgriffith$elm_ui$Element$Input$HiddenLabel;
var $author$project$MrJam$Tableaux$celluleEditable = F3(
	function (libelle, valeur, modifier) {
		return A2(
			$mdgriffith$elm_ui$Element$Input$text,
			_Utils_ap(
				$author$project$MrJam$Theme$champ,
				_List_fromArray(
					[
						$mdgriffith$elm_ui$Element$width($mdgriffith$elm_ui$Element$fill),
						$mdgriffith$elm_ui$Element$htmlAttribute(
						A2($elm$html$Html$Attributes$attribute, 'aria-label', libelle))
					])),
			{
				au: $mdgriffith$elm_ui$Element$Input$labelHidden(libelle),
				aR: modifier,
				bG: $elm$core$Maybe$Nothing,
				bL: valeur
			});
	});
var $author$project$MrJam$Tableaux$Colonne = F3(
	function (a, b, c) {
		return {$: 0, a: a, b: b, c: c};
	});
var $author$project$MrJam$Tableaux$Souple = 0;
var $author$project$MrJam$Tableaux$colonne = $author$project$MrJam$Tableaux$Colonne(0);
var $author$project$MrJam$Tableaux$Actions = 3;
var $author$project$MrJam$Tableaux$commandes = A2($author$project$MrJam$Tableaux$Colonne, 3, 'Actions');
var $author$project$MrJam$texteSecondaire = function (contenu) {
	return A2(
		$mdgriffith$elm_ui$Element$paragraph,
		_List_fromArray(
			[
				$mdgriffith$elm_ui$Element$width($mdgriffith$elm_ui$Element$fill),
				$mdgriffith$elm_ui$Element$Font$size(14),
				$author$project$MrJam$Theme$police($author$project$MrJam$Theme$couleurs.eZ),
				$mdgriffith$elm_ui$Element$spacing(5)
			]),
		_List_fromArray(
			[
				$mdgriffith$elm_ui$Element$text(contenu)
			]));
};
var $author$project$Main$fenetre = function (f) {
	var etat = A2($author$project$Contrat$chaine, 'etat', f);
	var texte = function () {
		switch (etat) {
			case 'reference_inconnue':
				return 'Référence inconnue — aucune date de révision inventée.';
			case 'reference_future':
				return 'Date de référence future : à vérifier.';
			case 'hors_horizon':
				return 'Intervalle hors horizon d’affichage (100 ans).';
			case 'intervalle_tres_court':
				return 'Intervalle inférieur à une minute : réglage à vérifier.';
			case 'fenetre_depassee':
				return 'En retard — fenêtre terminée le ' + A2(
					$elm$core$String$left,
					10,
					A2($author$project$Contrat$chaine, 'fin', f));
			case 'dans_fenetre':
				return 'Dans la plage — jusqu’au ' + A2(
					$elm$core$String$left,
					10,
					A2($author$project$Contrat$chaine, 'fin', f));
			default:
				return 'Fenêtre : ' + (A2(
					$elm$core$String$left,
					10,
					A2($author$project$Contrat$chaine, 'debut', f)) + (' → ' + A2(
					$elm$core$String$left,
					10,
					A2($author$project$Contrat$chaine, 'fin', f))));
		}
	}();
	return $author$project$MrJam$texteSecondaire(texte);
};
var $author$project$Main$fenetreLigne = function (item) {
	var f = A2($author$project$Contrat$objet, 'fenetre', item);
	var _v0 = A2($author$project$Contrat$chaine, 'statut', item);
	switch (_v0) {
		case 'retard':
			return $author$project$MrJam$texteSecondaire(
				'En retard depuis le ' + A2(
					$elm$core$String$left,
					10,
					A2($author$project$Contrat$chaine, 'fin', f)));
		case 'dans_fenetre':
			return $author$project$MrJam$texteSecondaire(
				'Dans la plage jusqu’au ' + A2(
					$elm$core$String$left,
					10,
					A2($author$project$Contrat$chaine, 'fin', f)));
		case 'nouveau':
			return $author$project$MrJam$texteSecondaire('Non commencé');
		default:
			return $author$project$Main$fenetre(f);
	}
};
var $mdgriffith$elm_ui$Internal$Model$Bottom = 2;
var $mdgriffith$elm_ui$Element$alignBottom = $mdgriffith$elm_ui$Internal$Model$AlignY(2);
var $mdgriffith$elm_ui$Internal$Model$Max = F2(
	function (a, b) {
		return {$: 4, a: a, b: b};
	});
var $mdgriffith$elm_ui$Element$maximum = F2(
	function (i, l) {
		return A2($mdgriffith$elm_ui$Internal$Model$Max, i, l);
	});
var $author$project$MrJam$Documents$filtres = function (controles) {
	return A2(
		$mdgriffith$elm_ui$Element$wrappedRow,
		_List_fromArray(
			[
				$mdgriffith$elm_ui$Element$width($mdgriffith$elm_ui$Element$fill),
				$mdgriffith$elm_ui$Element$spacing(12),
				$mdgriffith$elm_ui$Element$alignBottom
			]),
		A2(
			$elm$core$List$map,
			$mdgriffith$elm_ui$Element$el(
				_List_fromArray(
					[
						$mdgriffith$elm_ui$Element$width(
						A2(
							$mdgriffith$elm_ui$Element$minimum,
							180,
							A2($mdgriffith$elm_ui$Element$maximum, 360, $mdgriffith$elm_ui$Element$fill))),
						$mdgriffith$elm_ui$Element$alignBottom
					])),
			controles));
};
var $author$project$Contrat$grandeur = function (nature) {
	if (!nature) {
		return 'priorite';
	} else {
		return 'stabilite';
	}
};
var $author$project$MrJam$Donnees$lecture = function (contenu) {
	return A2(
		$mdgriffith$elm_ui$Element$paragraph,
		_List_fromArray(
			[
				$mdgriffith$elm_ui$Element$width($mdgriffith$elm_ui$Element$fill),
				$mdgriffith$elm_ui$Element$htmlAttribute(
				A2($elm$html$Html$Attributes$style, 'white-space', 'pre-wrap')),
				$mdgriffith$elm_ui$Element$htmlAttribute(
				A2($elm$html$Html$Attributes$style, 'overflow-wrap', 'anywhere'))
			]),
		_List_fromArray(
			[
				$mdgriffith$elm_ui$Element$text(contenu)
			]));
};
var $author$project$Main$libelle = F2(
	function (nature, objet) {
		return (nature === 1) ? A2($author$project$Contrat$chaine, 'contenu', objet) : A2($author$project$Contrat$chaine, 'titre', objet);
	});
var $elm$html$Html$Attributes$href = function (url) {
	return A2(
		$elm$html$Html$Attributes$stringProperty,
		'href',
		_VirtualDom_noJavaScriptUri(url));
};
var $elm$html$Html$Attributes$rel = _VirtualDom_attribute('rel');
var $mdgriffith$elm_ui$Element$link = F2(
	function (attrs, _v0) {
		var url = _v0.gH;
		var label = _v0.au;
		return A4(
			$mdgriffith$elm_ui$Internal$Model$element,
			$mdgriffith$elm_ui$Internal$Model$asEl,
			$mdgriffith$elm_ui$Internal$Model$NodeName('a'),
			A2(
				$elm$core$List$cons,
				$mdgriffith$elm_ui$Internal$Model$Attr(
					$elm$html$Html$Attributes$href(url)),
				A2(
					$elm$core$List$cons,
					$mdgriffith$elm_ui$Internal$Model$Attr(
						$elm$html$Html$Attributes$rel('noopener noreferrer')),
					A2(
						$elm$core$List$cons,
						$mdgriffith$elm_ui$Element$width($mdgriffith$elm_ui$Element$shrink),
						A2(
							$elm$core$List$cons,
							$mdgriffith$elm_ui$Element$height($mdgriffith$elm_ui$Element$shrink),
							A2(
								$elm$core$List$cons,
								$mdgriffith$elm_ui$Internal$Model$htmlClass($mdgriffith$elm_ui$Internal$Style$classes.bZ + (' ' + ($mdgriffith$elm_ui$Internal$Style$classes.ar + (' ' + $mdgriffith$elm_ui$Internal$Style$classes.ds)))),
								attrs))))),
			$mdgriffith$elm_ui$Internal$Model$Unkeyed(
				_List_fromArray(
					[label])));
	});
var $author$project$MrJam$Theme$survolPolice = function (col) {
	return $mdgriffith$elm_ui$Element$htmlAttribute(
		$elm$html$Html$Attributes$class(
			'mrjam-survol-texte-' + $author$project$MrJam$Theme$nomCouleur(col)));
};
var $author$project$MrJam$Documents$lien = F2(
	function (titre, url) {
		return A2(
			$mdgriffith$elm_ui$Element$link,
			_List_fromArray(
				[
					$mdgriffith$elm_ui$Element$width($mdgriffith$elm_ui$Element$fill),
					$mdgriffith$elm_ui$Element$height(
					A2($mdgriffith$elm_ui$Element$minimum, 30, $mdgriffith$elm_ui$Element$shrink)),
					A2($mdgriffith$elm_ui$Element$paddingXY, 0, 4),
					$mdgriffith$elm_ui$Element$Font$semiBold,
					$author$project$MrJam$Theme$police($author$project$MrJam$Theme$couleurs.c8),
					$author$project$MrJam$Theme$survolPolice($author$project$MrJam$Theme$couleurs.a4)
				]),
			{
				au: A2(
					$mdgriffith$elm_ui$Element$paragraph,
					_List_fromArray(
						[
							$mdgriffith$elm_ui$Element$width($mdgriffith$elm_ui$Element$fill)
						]),
					_List_fromArray(
						[
							$mdgriffith$elm_ui$Element$text(titre)
						])),
				gH: url
			});
	});
var $author$project$Main$lienObjet = F2(
	function (nature, objet) {
		return A2(
			$author$project$MrJam$Documents$lien,
			A2($author$project$Main$libelle, nature, objet),
			A2(
				$author$project$Contrat$destination,
				nature,
				A2($author$project$Contrat$entier, 'id', objet)));
	});
var $elm$core$List$all = F2(
	function (isOkay, list) {
		return !A2(
			$elm$core$List$any,
			A2($elm$core$Basics$composeL, $elm$core$Basics$not, isOkay),
			list);
	});
var $elm$core$List$drop = F2(
	function (n, list) {
		drop:
		while (true) {
			if (n <= 0) {
				return list;
			} else {
				if (!list.b) {
					return list;
				} else {
					var x = list.a;
					var xs = list.b;
					var $temp$n = n - 1,
						$temp$list = xs;
					n = $temp$n;
					list = $temp$list;
					continue drop;
				}
			}
		}
	});
var $mdgriffith$elm_ui$Internal$Model$FontFamily = F2(
	function (a, b) {
		return {$: 1, a: a, b: b};
	});
var $mdgriffith$elm_ui$Internal$Flag$fontFamily = $mdgriffith$elm_ui$Internal$Flag$flag(5);
var $elm$core$String$toLower = _String_toLower;
var $elm$core$String$words = _String_words;
var $mdgriffith$elm_ui$Internal$Model$renderFontClassName = F2(
	function (font, current) {
		return _Utils_ap(
			current,
			function () {
				switch (font.$) {
					case 0:
						return 'serif';
					case 1:
						return 'sans-serif';
					case 2:
						return 'monospace';
					case 3:
						var name = font.a;
						return A2(
							$elm$core$String$join,
							'-',
							$elm$core$String$words(
								$elm$core$String$toLower(name)));
					case 4:
						var name = font.a;
						var url = font.b;
						return A2(
							$elm$core$String$join,
							'-',
							$elm$core$String$words(
								$elm$core$String$toLower(name)));
					default:
						var name = font.a.fB;
						return A2(
							$elm$core$String$join,
							'-',
							$elm$core$String$words(
								$elm$core$String$toLower(name)));
				}
			}());
	});
var $mdgriffith$elm_ui$Element$Font$family = function (families) {
	return A2(
		$mdgriffith$elm_ui$Internal$Model$StyleClass,
		$mdgriffith$elm_ui$Internal$Flag$fontFamily,
		A2(
			$mdgriffith$elm_ui$Internal$Model$FontFamily,
			A3($elm$core$List$foldl, $mdgriffith$elm_ui$Internal$Model$renderFontClassName, 'ff-', families),
			families));
};
var $mdgriffith$elm_ui$Element$Font$italic = $mdgriffith$elm_ui$Internal$Model$htmlClass($mdgriffith$elm_ui$Internal$Style$classes.fp);
var $mdgriffith$elm_ui$Internal$Model$Monospace = {$: 2};
var $mdgriffith$elm_ui$Element$Font$monospace = $mdgriffith$elm_ui$Internal$Model$Monospace;
var $elm$core$List$sortBy = _List_sortBy;
var $author$project$MrJam$Lecture$enLigne = function (contenu) {
	var marques = _List_fromArray(
		[
			_Utils_Tuple2(
			'`',
			$mdgriffith$elm_ui$Element$Font$family(
				_List_fromArray(
					[$mdgriffith$elm_ui$Element$Font$monospace]))),
			_Utils_Tuple2('**', $mdgriffith$elm_ui$Element$Font$bold),
			_Utils_Tuple2('*', $mdgriffith$elm_ui$Element$Font$italic)
		]);
	var candidates = A2(
		$elm$core$List$filterMap,
		function (_v4) {
			var marque = _v4.a;
			var style = _v4.b;
			return A2(
				$elm$core$Maybe$map,
				function (index) {
					return _Utils_Tuple3(index, marque, style);
				},
				$elm$core$List$head(
					A2($elm$core$String$indexes, marque, contenu)));
		},
		marques);
	var _v0 = $elm$core$List$head(
		A2(
			$elm$core$List$sortBy,
			function (_v1) {
				var index = _v1.a;
				return index;
			},
			candidates));
	if (_v0.$ === 1) {
		return _List_fromArray(
			[
				$mdgriffith$elm_ui$Element$text(contenu)
			]);
	} else {
		var _v2 = _v0.a;
		var index = _v2.a;
		var marque = _v2.b;
		var style = _v2.c;
		var reste = A2(
			$elm$core$String$dropLeft,
			index + $elm$core$String$length(marque),
			contenu);
		var _v3 = $elm$core$List$head(
			A2($elm$core$String$indexes, marque, reste));
		if (_v3.$ === 1) {
			return A2(
				$elm$core$List$cons,
				$mdgriffith$elm_ui$Element$text(
					A2(
						$elm$core$String$left,
						index + $elm$core$String$length(marque),
						contenu)),
				$author$project$MrJam$Lecture$enLigne(reste));
		} else {
			var fin = _v3.a;
			return _Utils_ap(
				_List_fromArray(
					[
						$mdgriffith$elm_ui$Element$text(
						A2($elm$core$String$left, index, contenu)),
						A2(
						$mdgriffith$elm_ui$Element$el,
						_List_fromArray(
							[style]),
						$mdgriffith$elm_ui$Element$text(
							A2($elm$core$String$left, fin, reste)))
					]),
				$author$project$MrJam$Lecture$enLigne(
					A2(
						$elm$core$String$dropLeft,
						fin + $elm$core$String$length(marque),
						reste)));
		}
	}
};
var $author$project$MrJam$Lecture$prose = function (contenu) {
	return A2(
		$mdgriffith$elm_ui$Element$paragraph,
		_List_fromArray(
			[
				$mdgriffith$elm_ui$Element$width($mdgriffith$elm_ui$Element$fill),
				$mdgriffith$elm_ui$Element$htmlAttribute(
				A2($elm$html$Html$Attributes$style, 'white-space', 'pre-wrap')),
				$mdgriffith$elm_ui$Element$htmlAttribute(
				A2($elm$html$Html$Attributes$style, 'overflow-wrap', 'anywhere'))
			]),
		$author$project$MrJam$Lecture$enLigne(contenu));
};
var $mdgriffith$elm_ui$Element$Border$widthXY = F2(
	function (x, y) {
		return A2(
			$mdgriffith$elm_ui$Internal$Model$StyleClass,
			$mdgriffith$elm_ui$Internal$Flag$borderWidth,
			A5(
				$mdgriffith$elm_ui$Internal$Model$BorderWidth,
				'b-' + ($elm$core$String$fromInt(x) + ('-' + $elm$core$String$fromInt(y))),
				y,
				x,
				y,
				x));
	});
var $mdgriffith$elm_ui$Element$Border$widthEach = function (_v0) {
	var bottom = _v0.eF;
	var top = _v0.gB;
	var left = _v0.fr;
	var right = _v0.fZ;
	return (_Utils_eq(top, bottom) && _Utils_eq(left, right)) ? (_Utils_eq(top, right) ? $mdgriffith$elm_ui$Element$Border$width(top) : A2($mdgriffith$elm_ui$Element$Border$widthXY, left, top)) : A2(
		$mdgriffith$elm_ui$Internal$Model$StyleClass,
		$mdgriffith$elm_ui$Internal$Flag$borderWidth,
		A5(
			$mdgriffith$elm_ui$Internal$Model$BorderWidth,
			'b-' + ($elm$core$String$fromInt(top) + ('-' + ($elm$core$String$fromInt(right) + ('-' + ($elm$core$String$fromInt(bottom) + ('-' + $elm$core$String$fromInt(left))))))),
			top,
			right,
			bottom,
			left));
};
var $author$project$MrJam$Lecture$bloc = function (contenu) {
	var titre = A2($elm$core$String$startsWith, '# ', contenu) || (A2($elm$core$String$startsWith, '## ', contenu) || (A2($elm$core$String$startsWith, '### ', contenu) || (A2($elm$core$String$startsWith, '#### ', contenu) || (A2($elm$core$String$startsWith, '##### ', contenu) || A2($elm$core$String$startsWith, '###### ', contenu)))));
	var sansMarque = A2(
		$elm$core$String$join,
		' ',
		A2(
			$elm$core$List$drop,
			1,
			A2($elm$core$String$split, ' ', contenu)));
	var lignes = $elm$core$String$lines(contenu);
	return titre ? A2(
		$mdgriffith$elm_ui$Element$paragraph,
		_List_fromArray(
			[
				$mdgriffith$elm_ui$Element$width($mdgriffith$elm_ui$Element$fill),
				$mdgriffith$elm_ui$Element$Region$heading(2),
				$mdgriffith$elm_ui$Element$Font$size(23),
				$mdgriffith$elm_ui$Element$Font$bold
			]),
		$author$project$MrJam$Lecture$enLigne(sansMarque)) : (A2(
		$elm$core$List$all,
		function (ligne) {
			return A2($elm$core$String$startsWith, '- ', ligne) || A2($elm$core$String$startsWith, '* ', ligne);
		},
		lignes) ? A2(
		$mdgriffith$elm_ui$Element$column,
		_List_fromArray(
			[
				$mdgriffith$elm_ui$Element$width($mdgriffith$elm_ui$Element$fill),
				$mdgriffith$elm_ui$Element$spacing(8),
				$mdgriffith$elm_ui$Element$htmlAttribute(
				A2($elm$html$Html$Attributes$attribute, 'role', 'list'))
			]),
		A2(
			$elm$core$List$map,
			function (ligne) {
				return A2(
					$mdgriffith$elm_ui$Element$paragraph,
					_List_fromArray(
						[
							$mdgriffith$elm_ui$Element$width($mdgriffith$elm_ui$Element$fill),
							$mdgriffith$elm_ui$Element$htmlAttribute(
							A2($elm$html$Html$Attributes$attribute, 'role', 'listitem'))
						]),
					A2(
						$elm$core$List$cons,
						$mdgriffith$elm_ui$Element$text('• '),
						$author$project$MrJam$Lecture$enLigne(
							A2($elm$core$String$dropLeft, 2, ligne))));
			},
			lignes)) : (A2($elm$core$String$startsWith, '> ', contenu) ? A2(
		$mdgriffith$elm_ui$Element$el,
		_List_fromArray(
			[
				$mdgriffith$elm_ui$Element$width($mdgriffith$elm_ui$Element$fill),
				$mdgriffith$elm_ui$Element$padding(14),
				$mdgriffith$elm_ui$Element$Border$widthEach(
				{eF: 0, fr: 3, fZ: 0, gB: 0}),
				$author$project$MrJam$Theme$bordure($author$project$MrJam$Theme$couleurs.a4)
			]),
		$author$project$MrJam$Lecture$prose(
			A2(
				$elm$core$String$join,
				'\n',
				A2(
					$elm$core$List$map,
					function (ligne) {
						return A2($elm$core$String$startsWith, '> ', ligne) ? A2($elm$core$String$dropLeft, 2, ligne) : ligne;
					},
					lignes)))) : $author$project$MrJam$Lecture$prose(contenu)));
};
var $author$project$MrJam$Lecture$blocs = F2(
	function (code, morceaux) {
		if (!morceaux.b) {
			return _List_Nil;
		} else {
			var morceau = morceaux.a;
			var suite = morceaux.b;
			return _Utils_ap(
				code ? _List_fromArray(
					[
						A2(
						$mdgriffith$elm_ui$Element$el,
						_List_fromArray(
							[
								$mdgriffith$elm_ui$Element$width($mdgriffith$elm_ui$Element$fill),
								$mdgriffith$elm_ui$Element$padding(14),
								$author$project$MrJam$Theme$fond($author$project$MrJam$Theme$couleurs.e$),
								$mdgriffith$elm_ui$Element$Font$family(
								_List_fromArray(
									[$mdgriffith$elm_ui$Element$Font$monospace]))
							]),
						$author$project$MrJam$Donnees$lecture(
							A2(
								$elm$core$String$join,
								'\n',
								A2(
									$elm$core$List$drop,
									1,
									A2($elm$core$String$split, '\n', morceau)))))
					]) : A2(
					$elm$core$List$map,
					$author$project$MrJam$Lecture$bloc,
					A2(
						$elm$core$List$filter,
						A2($elm$core$Basics$composeL, $elm$core$Basics$not, $elm$core$String$isEmpty),
						A2($elm$core$String$split, '\n\n', morceau))),
				A2($author$project$MrJam$Lecture$blocs, !code, suite));
		}
	});
var $author$project$MrJam$Theme$disposition = _List_fromArray(
	[
		$mdgriffith$elm_ui$Element$width($mdgriffith$elm_ui$Element$fill),
		$mdgriffith$elm_ui$Element$spacing(16)
	]);
var $author$project$MrJam$pile = $mdgriffith$elm_ui$Element$column($author$project$MrJam$Theme$disposition);
var $author$project$MrJam$Lecture$markdown = function (source) {
	return $author$project$MrJam$pile(
		A2(
			$author$project$MrJam$Lecture$blocs,
			false,
			A2($elm$core$String$split, '```', source)));
};
var $mdgriffith$elm_ui$Internal$Model$Empty = {$: 3};
var $mdgriffith$elm_ui$Element$none = $mdgriffith$elm_ui$Internal$Model$Empty;
var $author$project$MrJam$Documents$pagination = function (p) {
	return $author$project$MrJam$Documents$actions(
		_List_fromArray(
			[
				$author$project$MrJam$texteSecondaire(
				$elm$core$String$fromInt(p.a0) + ' résultats'),
				(p.a9 > 0) ? A2($author$project$MrJam$Documents$action, 'Précédent', p.fT) : A4($author$project$MrJam$Controles$action, $author$project$MrJam$Controles$Discrete, _List_Nil, 'Précédent', $elm$core$Maybe$Nothing),
				(_Utils_cmp(p.a9 + p.gl, p.a0) < 0) ? A2($author$project$MrJam$Documents$action, 'Suivant', p.gi) : A4($author$project$MrJam$Controles$action, $author$project$MrJam$Controles$Discrete, _List_Nil, 'Suivant', $elm$core$Maybe$Nothing)
			]));
};
var $author$project$MrJam$Tableaux$Titre = 1;
var $author$project$MrJam$Tableaux$principale = $author$project$MrJam$Tableaux$Colonne(1);
var $elm$html$Html$Attributes$id = $elm$html$Html$Attributes$stringProperty('id');
var $author$project$MrJam$Documents$repere = function (identifiant) {
	return $mdgriffith$elm_ui$Element$el(
		_List_fromArray(
			[
				$mdgriffith$elm_ui$Element$width($mdgriffith$elm_ui$Element$fill),
				$mdgriffith$elm_ui$Element$htmlAttribute(
				$elm$html$Html$Attributes$id(identifiant))
			]));
};
var $elm$html$Html$label = _VirtualDom_node('label');
var $elm$html$Html$option = _VirtualDom_node('option');
var $elm$html$Html$select = _VirtualDom_node('select');
var $elm$html$Html$Attributes$selected = $elm$html$Html$Attributes$boolProperty('selected');
var $author$project$MrJam$selecteur = F4(
	function (libelle, possibilites, valeur, modifier) {
		return $mdgriffith$elm_ui$Element$html(
			A2(
				$elm$html$Html$label,
				_List_fromArray(
					[
						A2($elm$html$Html$Attributes$style, 'display', 'grid'),
						A2($elm$html$Html$Attributes$style, 'gap', '6px'),
						A2($elm$html$Html$Attributes$style, 'width', '100%'),
						A2($elm$html$Html$Attributes$style, 'color', 'var(--mrjam-encre)'),
						A2($elm$html$Html$Attributes$style, 'font', 'inherit')
					]),
				_List_fromArray(
					[
						A2(
						$elm$html$Html$span,
						_List_fromArray(
							[
								A2($elm$html$Html$Attributes$style, 'font-size', '14px'),
								A2($elm$html$Html$Attributes$style, 'font-weight', '600')
							]),
						_List_fromArray(
							[
								$elm$html$Html$text(libelle)
							])),
						A2(
						$elm$html$Html$select,
						_List_fromArray(
							[
								$elm$html$Html$Attributes$value(valeur),
								A2($elm$html$Html$Attributes$attribute, 'aria-label', libelle),
								$elm$html$Html$Events$onInput(modifier),
								A2($elm$html$Html$Attributes$style, 'box-sizing', 'border-box'),
								A2($elm$html$Html$Attributes$style, 'width', '100%'),
								A2($elm$html$Html$Attributes$style, 'min-height', '36px'),
								A2($elm$html$Html$Attributes$style, 'padding', '6px 8px'),
								A2($elm$html$Html$Attributes$style, 'border', '1px solid var(--mrjam-controle)'),
								A2($elm$html$Html$Attributes$style, 'border-radius', '5px'),
								A2($elm$html$Html$Attributes$style, 'background', 'var(--mrjam-surface)'),
								A2($elm$html$Html$Attributes$style, 'color', 'var(--mrjam-encre)'),
								A2($elm$html$Html$Attributes$style, 'font', 'inherit')
							]),
						A2(
							$elm$core$List$map,
							function (_v0) {
								var cle = _v0.a;
								var nom = _v0.b;
								return A2(
									$elm$html$Html$option,
									_List_fromArray(
										[
											$elm$html$Html$Attributes$value(cle),
											$elm$html$Html$Attributes$selected(
											_Utils_eq(cle, valeur))
										]),
									_List_fromArray(
										[
											$elm$html$Html$text(nom)
										]));
							},
							possibilites))
					])));
	});
var $mdgriffith$elm_ui$Internal$Model$Top = 0;
var $mdgriffith$elm_ui$Element$alignTop = $mdgriffith$elm_ui$Internal$Model$AlignY(0);
var $mdgriffith$elm_ui$Element$fillPortion = $mdgriffith$elm_ui$Internal$Model$Fill;
var $author$project$MrJam$Tableaux$dimensions = function (taille) {
	switch (taille) {
		case 0:
			return _Utils_Tuple2(160, $mdgriffith$elm_ui$Element$fill);
		case 1:
			return _Utils_Tuple2(
				240,
				$mdgriffith$elm_ui$Element$fillPortion(3));
		case 2:
			return _Utils_Tuple2(
				128,
				$mdgriffith$elm_ui$Element$px(128));
		default:
			return _Utils_Tuple2(
				120,
				$mdgriffith$elm_ui$Element$px(120));
	}
};
var $author$project$MrJam$Tableaux$role = function (nom) {
	return $mdgriffith$elm_ui$Element$htmlAttribute(
		A2($elm$html$Html$Attributes$attribute, 'role', nom));
};
var $mdgriffith$elm_ui$Element$row = F2(
	function (attrs, children) {
		return A4(
			$mdgriffith$elm_ui$Internal$Model$element,
			$mdgriffith$elm_ui$Internal$Model$asRow,
			$mdgriffith$elm_ui$Internal$Model$div,
			A2(
				$elm$core$List$cons,
				$mdgriffith$elm_ui$Internal$Model$htmlClass($mdgriffith$elm_ui$Internal$Style$classes.bv + (' ' + $mdgriffith$elm_ui$Internal$Style$classes.ar)),
				A2(
					$elm$core$List$cons,
					$mdgriffith$elm_ui$Element$width($mdgriffith$elm_ui$Element$shrink),
					A2(
						$elm$core$List$cons,
						$mdgriffith$elm_ui$Element$height($mdgriffith$elm_ui$Element$shrink),
						attrs))),
			$mdgriffith$elm_ui$Internal$Model$Unkeyed(children));
	});
var $mdgriffith$elm_ui$Element$scrollbarX = A2($mdgriffith$elm_ui$Internal$Model$Class, $mdgriffith$elm_ui$Internal$Flag$overflow, $mdgriffith$elm_ui$Internal$Style$classes.f3);
var $elm$core$List$sum = function (numbers) {
	return A3($elm$core$List$foldl, $elm$core$Basics$add, 0, numbers);
};
var $author$project$MrJam$Tableaux$tableau = F3(
	function (libelle, colonnes, donnees) {
		var rangee = F2(
			function (attributs, cellules) {
				return A2(
					$mdgriffith$elm_ui$Element$row,
					_Utils_ap(
						_List_fromArray(
							[
								$author$project$MrJam$Tableaux$role('row'),
								$mdgriffith$elm_ui$Element$width($mdgriffith$elm_ui$Element$fill),
								$mdgriffith$elm_ui$Element$Border$widthEach(
								{eF: 1, fr: 0, fZ: 0, gB: 0}),
								$author$project$MrJam$Theme$bordure($author$project$MrJam$Theme$couleurs.fv)
							]),
						attributs),
					cellules);
			});
		var largeur = function (_v2) {
			var taille = _v2.a;
			return $author$project$MrJam$Tableaux$dimensions(taille).a;
		};
		var cellule = F3(
			function (nature, contenu, _v1) {
				var taille = _v1.a;
				var _v0 = $author$project$MrJam$Tableaux$dimensions(taille);
				var minimum = _v0.a;
				var longueur = _v0.b;
				return A2(
					$mdgriffith$elm_ui$Element$el,
					_List_fromArray(
						[
							$author$project$MrJam$Tableaux$role(nature),
							$mdgriffith$elm_ui$Element$width(
							A2($mdgriffith$elm_ui$Element$minimum, minimum, longueur)),
							A2($mdgriffith$elm_ui$Element$paddingXY, 10, 4),
							$mdgriffith$elm_ui$Element$height(
							A2($mdgriffith$elm_ui$Element$minimum, 38, $mdgriffith$elm_ui$Element$shrink)),
							$mdgriffith$elm_ui$Element$alignTop
						]),
					A2(
						$mdgriffith$elm_ui$Element$el,
						_List_fromArray(
							[
								$mdgriffith$elm_ui$Element$width($mdgriffith$elm_ui$Element$fill),
								$mdgriffith$elm_ui$Element$centerY
							]),
						contenu));
			});
		return $elm$core$List$isEmpty(colonnes) ? $mdgriffith$elm_ui$Element$none : A2(
			$mdgriffith$elm_ui$Element$column,
			_List_fromArray(
				[
					$mdgriffith$elm_ui$Element$width($mdgriffith$elm_ui$Element$fill),
					$mdgriffith$elm_ui$Element$spacing(10)
				]),
			_List_fromArray(
				[
					A2(
					$mdgriffith$elm_ui$Element$el,
					_List_fromArray(
						[
							$mdgriffith$elm_ui$Element$width($mdgriffith$elm_ui$Element$fill),
							$mdgriffith$elm_ui$Element$scrollbarX,
							$mdgriffith$elm_ui$Element$htmlAttribute(
							A2($elm$html$Html$Attributes$style, 'flex-basis', 'auto')),
							$author$project$MrJam$Tableaux$role('region'),
							$mdgriffith$elm_ui$Element$htmlAttribute(
							A2($elm$html$Html$Attributes$attribute, 'aria-label', libelle + ' — défilement horizontal')),
							$mdgriffith$elm_ui$Element$htmlAttribute(
							$elm$html$Html$Attributes$tabindex(0))
						]),
					A2(
						$mdgriffith$elm_ui$Element$column,
						_List_fromArray(
							[
								$mdgriffith$elm_ui$Element$width(
								A2(
									$mdgriffith$elm_ui$Element$minimum,
									$elm$core$List$sum(
										A2($elm$core$List$map, largeur, colonnes)),
									$mdgriffith$elm_ui$Element$fill)),
								$author$project$MrJam$Tableaux$role('table'),
								$mdgriffith$elm_ui$Element$htmlAttribute(
								A2($elm$html$Html$Attributes$attribute, 'aria-label', libelle)),
								$mdgriffith$elm_ui$Element$Font$size(14)
							]),
						A2(
							$elm$core$List$cons,
							A2(
								rangee,
								_List_fromArray(
									[
										$author$project$MrJam$Theme$police($author$project$MrJam$Theme$couleurs.eZ),
										$mdgriffith$elm_ui$Element$Font$size(13)
									]),
								A2(
									$elm$core$List$map,
									function (col) {
										var nom = col.b;
										return A3(
											cellule,
											'columnheader',
											A2(
												$mdgriffith$elm_ui$Element$paragraph,
												_List_fromArray(
													[
														$mdgriffith$elm_ui$Element$width($mdgriffith$elm_ui$Element$fill)
													]),
												_List_fromArray(
													[
														$mdgriffith$elm_ui$Element$text(nom)
													])),
											col);
									},
									colonnes)),
							A2(
								$elm$core$List$map,
								function (donnee) {
									return A2(
										rangee,
										_List_fromArray(
											[
												$author$project$MrJam$Theme$survol($author$project$MrJam$Theme$couleurs.fR)
											]),
										A2(
											$elm$core$List$map,
											function (col) {
												var afficher = col.c;
												return A3(
													cellule,
													'cell',
													afficher(donnee),
													col);
											},
											colonnes));
								},
								donnees)))),
					$elm$core$List$isEmpty(donnees) ? $author$project$MrJam$texteSecondaire('Aucune donnée.') : $mdgriffith$elm_ui$Element$none
				]));
	});
var $mdgriffith$elm_ui$Internal$Model$Right = 2;
var $mdgriffith$elm_ui$Element$alignRight = $mdgriffith$elm_ui$Internal$Model$AlignX(2);
var $author$project$MrJam$Tableaux$tableauAvecOutils = F4(
	function (libelle, commandesTable, colonnes, donnees) {
		return A2(
			$mdgriffith$elm_ui$Element$column,
			_List_fromArray(
				[
					$mdgriffith$elm_ui$Element$width($mdgriffith$elm_ui$Element$fill),
					$mdgriffith$elm_ui$Element$spacing(6)
				]),
			_List_fromArray(
				[
					A2(
					$mdgriffith$elm_ui$Element$el,
					_List_fromArray(
						[
							$author$project$MrJam$Tableaux$role('region'),
							$mdgriffith$elm_ui$Element$htmlAttribute(
							A2($elm$html$Html$Attributes$attribute, 'aria-label', 'Outils du tableau ' + libelle)),
							$mdgriffith$elm_ui$Element$width($mdgriffith$elm_ui$Element$fill)
						]),
					A2(
						$mdgriffith$elm_ui$Element$wrappedRow,
						_List_fromArray(
							[
								$mdgriffith$elm_ui$Element$spacing(4),
								$mdgriffith$elm_ui$Element$alignRight
							]),
						commandesTable)),
					A3($author$project$MrJam$Tableaux$tableau, libelle, colonnes, donnees)
				]));
	});
var $mdgriffith$elm_ui$Element$Input$multiline = F2(
	function (attrs, multi) {
		return A3(
			$mdgriffith$elm_ui$Element$Input$textHelper,
			{R: $elm$core$Maybe$Nothing, ad: multi.gc, gE: $mdgriffith$elm_ui$Element$Input$TextArea},
			attrs,
			{au: multi.au, aR: multi.aR, bG: multi.bG, bL: multi.bL});
	});
var $author$project$MrJam$zoneTexte = F3(
	function (libelle, valeur, modifier) {
		return A2(
			$mdgriffith$elm_ui$Element$Input$multiline,
			_Utils_ap(
				$author$project$MrJam$Theme$champ,
				_List_fromArray(
					[
						$mdgriffith$elm_ui$Element$height(
						A2($mdgriffith$elm_ui$Element$minimum, 120, $mdgriffith$elm_ui$Element$shrink)),
						$mdgriffith$elm_ui$Element$htmlAttribute(
						A2($elm$html$Html$Attributes$attribute, 'aria-label', libelle))
					])),
			{
				au: $author$project$MrJam$etiquette(libelle),
				aR: modifier,
				bG: $elm$core$Maybe$Nothing,
				gc: false,
				bL: valeur
			});
	});
var $author$project$Main$vueDetail = F2(
	function (m, d) {
		var estFiche = !m.a;
		var detacher = function (v) {
			return $author$project$Main$Naviguer(
				estFiche ? A3(
					$author$project$Main$Detacher,
					A2($author$project$Contrat$entier, 'id', d),
					A2($author$project$Contrat$entier, 'id', v),
					A2($author$project$Contrat$entier, 'version', d)) : A3(
					$author$project$Main$Detacher,
					A2($author$project$Contrat$entier, 'id', v),
					A2($author$project$Contrat$entier, 'id', d),
					A2($author$project$Contrat$entier, 'version', v)));
		};
		var autre = $author$project$Contrat$autre(m.a);
		var lies = A2(
			$author$project$Contrat$listes,
			$author$project$Contrat$nom(autre) + 's',
			d);
		var archive = !_Utils_eq(
			A2($author$project$Contrat$objet, 'archive_a', d),
			$elm$json$Json$Encode$null);
		return A2(
			$author$project$MrJam$Documents$repere,
			'detail',
			A2(
				$author$project$MrJam$Documents$document,
				A2($author$project$Main$libelle, m.a, d),
				_List_fromArray(
					[
						$author$project$MrJam$Documents$actions(
						_List_fromArray(
							[
								A3(
								$author$project$MrJam$Pictogrammes$action,
								4,
								'Retour à la liste',
								$author$project$Main$Naviguer($author$project$Main$Fermer)),
								m.i ? A3($author$project$MrJam$Pictogrammes$action, 2, 'Enregistrer', $author$project$Main$Sauver) : A3($author$project$MrJam$Pictogrammes$action, 1, 'Modifier', $author$project$Main$Editer),
								m.i ? A3($author$project$MrJam$Pictogrammes$action, 3, 'Annuler', $author$project$Main$AnnulerEdition) : $mdgriffith$elm_ui$Element$none,
								A2(
								$author$project$MrJam$Documents$action,
								archive ? 'Restaurer' : 'Archiver',
								$author$project$Main$Naviguer(
									$author$project$Main$Archiver(!archive)))
							])),
						(m.i && estFiche) ? A3(
						$author$project$MrJam$champ,
						'Titre',
						A2($author$project$Main$valeur, 'titre', m),
						$author$project$Main$Saisir('titre')) : $mdgriffith$elm_ui$Element$none,
						$author$project$MrJam$texteSecondaire(
						_Utils_ap(
							estFiche ? 'Priorité ' : 'Stabilité ',
							$author$project$Main$db(
								A2(
									$author$project$Contrat$entier,
									$author$project$Contrat$grandeur(m.a),
									d)))),
						estFiche ? $author$project$MrJam$texteSecondaire('Priorité positive : révisions avancées.') : $author$project$Main$fenetre(
						A2($author$project$Contrat$objet, 'fenetre', d)),
						m.i ? A3(
						$author$project$MrJam$zoneTexte,
						'Contenu de référence',
						A2($author$project$Main$valeur, 'contenu', m),
						$author$project$Main$Saisir('contenu')) : $author$project$MrJam$Lecture$markdown(
						A2($author$project$Contrat$chaine, 'contenu', d)),
						m.i ? A3(
						$author$project$MrJam$zoneTexte,
						'Alias (un par ligne)',
						A2($author$project$Main$valeur, 'alias', m),
						$author$project$Main$Saisir('alias')) : $mdgriffith$elm_ui$Element$none,
						((!estFiche) || ((!m.i) && (A2($author$project$Contrat$chaine, 'suivi', d) === ''))) ? $mdgriffith$elm_ui$Element$none : A2(
						$author$project$MrJam$Documents$section,
						'Suivi actuel',
						_List_fromArray(
							[
								m.i ? A3(
								$author$project$MrJam$zoneTexte,
								'Suivi actuel',
								A2($author$project$Main$valeur, 'suivi', m),
								$author$project$Main$Saisir('suivi')) : $author$project$MrJam$Donnees$lecture(
								A2($author$project$Contrat$chaine, 'suivi', d))
							])),
						(m.i && estFiche) ? A2(
						$author$project$MrJam$Documents$section,
						'Classement',
						_List_fromArray(
							[
								A3(
								$author$project$MrJam$zoneTexte,
								'Tags (un par ligne)',
								A2($author$project$Main$valeur, 'tags', m),
								$author$project$Main$Saisir('tags')),
								A3(
								$author$project$MrJam$Donnees$nombre,
								'Priorité P (dB, −20 à +20)',
								A2($author$project$Main$valeur, 'priorite', m),
								$author$project$Main$Saisir('priorite'))
							])) : $mdgriffith$elm_ui$Element$none,
						estFiche ? $mdgriffith$elm_ui$Element$none : $author$project$MrJam$texteSecondaire(
						(!A2($author$project$Contrat$vrai, 'evalue', d)) ? 'Cet item n’a pas été évalué.' : ('Dernière évaluation : ' + A2($author$project$Contrat$chaine, 'evalue_a', d))),
						A2(
						$author$project$MrJam$Documents$section,
						(!autre) ? 'Fiches associées' : 'Items associés',
						_List_fromArray(
							[
								A2($author$project$MrJam$Documents$action, 'Ajouter un rattachement', $author$project$Main$AfficherLiens),
								A4(
								$author$project$MrJam$Tableaux$tableauAvecOutils,
								'Rattachements',
								_List_fromArray(
									[
										A3(
										$author$project$MrJam$Pictogrammes$action,
										6,
										'Trier les items',
										$author$project$Main$OutilsLiens('tri')),
										A3(
										$author$project$MrJam$Pictogrammes$action,
										5,
										'Filtrer les items',
										$author$project$Main$OutilsLiens('filtre'))
									]),
								_List_fromArray(
									[
										A2(
										$author$project$MrJam$Tableaux$principale,
										estFiche ? 'Connaissance' : 'Titre',
										function (v) {
											return (estFiche && _Utils_eq(
												m.l,
												$elm$core$Maybe$Just(
													A2($author$project$Contrat$entier, 'id', v)))) ? A3($author$project$MrJam$Tableaux$celluleEditable, 'Connaissance de l’item', m.D, $author$project$Main$SaisirLigne) : A2($author$project$Main$lienObjet, autre, v);
										}),
										A2(
										$author$project$MrJam$Tableaux$colonne,
										estFiche ? 'Révision' : 'Contexte',
										function (v) {
											return estFiche ? $author$project$Main$fenetreLigne(v) : $author$project$MrJam$texteSecondaire(
												A2($author$project$Contrat$chaine, 'contexte', v));
										}),
										$author$project$MrJam$Tableaux$commandes(
										function (v) {
											return (estFiche && _Utils_eq(
												m.l,
												$elm$core$Maybe$Just(
													A2($author$project$Contrat$entier, 'id', v)))) ? $author$project$MrJam$actions(
												_List_fromArray(
													[
														A3($author$project$MrJam$Pictogrammes$action, 2, 'Enregistrer l’item', $author$project$Main$SauverLigne),
														A3($author$project$MrJam$Pictogrammes$action, 3, 'Annuler la modification de l’item', $author$project$Main$AnnulerLigne)
													])) : $author$project$MrJam$actions(
												_List_fromArray(
													[
														estFiche ? A3(
														$author$project$MrJam$Pictogrammes$action,
														1,
														'Modifier l’item : ' + A2($author$project$Main$libelle, autre, v),
														$author$project$Main$EditerLigne(
															A2($author$project$Contrat$entier, 'id', v))) : $mdgriffith$elm_ui$Element$none,
														A3(
														$author$project$MrJam$Documents$actionSur,
														'Détacher',
														A2($author$project$Main$libelle, autre, v),
														detacher(v))
													]));
										})
									]),
								lies),
								((!_Utils_eq(m.aT, $elm$core$Maybe$Nothing)) && estFiche) ? $author$project$MrJam$Documents$filtres(
								function () {
									var _v0 = m.aT;
									_v0$2:
									while (true) {
										if (!_v0.$) {
											switch (_v0.a) {
												case 'tri':
													return _List_fromArray(
														[
															A4(
															$author$project$MrJam$selecteur,
															'Trier les items',
															_List_fromArray(
																[
																	_Utils_Tuple2('echeance', 'Date due'),
																	_Utils_Tuple2('alphabetique', 'Ordre alphabétique'),
																	_Utils_Tuple2('ordre', 'Ordre de rattachement')
																]),
															m.bo,
															$author$project$Main$TriLiens)
														]);
												case 'filtre':
													return _List_fromArray(
														[
															A4(
															$author$project$MrJam$selecteur,
															'Filtrer les items par échéance',
															_List_fromArray(
																[
																	_Utils_Tuple2('tous', 'Tous'),
																	_Utils_Tuple2('retard', 'En retard'),
																	_Utils_Tuple2('dans_fenetre', 'Dans la plage'),
																	_Utils_Tuple2('nouveau', 'Non commencés'),
																	_Utils_Tuple2('a_venir', 'À venir')
																]),
															m.bd,
															$author$project$Main$FiltreLiens)
														]);
												default:
													break _v0$2;
											}
										} else {
											break _v0$2;
										}
									}
									return _List_Nil;
								}()) : $mdgriffith$elm_ui$Element$none,
								$author$project$MrJam$Documents$pagination(
								{
									a9: m.T,
									fT: $author$project$Main$PageLiens(-1),
									gi: $author$project$Main$PageLiens(1),
									gl: 20,
									a0: estFiche ? A2($author$project$Contrat$entier, 'nombre_items_filtres', d) : A2(
										$author$project$Contrat$entier,
										'nombre_' + ($author$project$Contrat$nom(autre) + 's'),
										d)
								})
							])),
						m.aj ? A2(
						$author$project$MrJam$Documents$section,
						'Rattacher un objet existant',
						_List_fromArray(
							[
								A3($author$project$MrJam$champ, 'Rechercher un objet à rattacher', m.bJ, $author$project$Main$RechercheLiens),
								A2($author$project$MrJam$Documents$action, 'Chercher', $author$project$Main$ChercherLiens),
								A3(
								$author$project$MrJam$Tableaux$tableau,
								'Objets disponibles',
								_List_fromArray(
									[
										A2(
										$author$project$MrJam$Tableaux$principale,
										'Contenu',
										A2(
											$elm$core$Basics$composeR,
											$author$project$Main$libelle(autre),
											$author$project$MrJam$paragraphe)),
										$author$project$MrJam$Tableaux$commandes(
										function (v) {
											return A3(
												$author$project$MrJam$Documents$actionSur,
												'Rattacher',
												A2($author$project$Main$libelle, autre, v),
												$author$project$Main$Rattacher(v));
										})
									]),
								m.bi)
							])) : $mdgriffith$elm_ui$Element$none
					])));
	});
var $author$project$Main$CreerDistinct = {$: 44};
var $author$project$Main$Reutiliser = function (a) {
	return {$: 45, a: a};
};
var $author$project$MrJam$boutonEnCours = function (libelle) {
	return A4(
		$author$project$MrJam$Controles$action,
		$author$project$MrJam$Controles$Secondaire,
		_List_fromArray(
			[
				$mdgriffith$elm_ui$Element$htmlAttribute(
				A2($elm$html$Html$Attributes$attribute, 'aria-disabled', 'true')),
				$mdgriffith$elm_ui$Element$htmlAttribute(
				A2($elm$html$Html$Attributes$attribute, 'aria-busy', 'true')),
				$mdgriffith$elm_ui$Element$htmlAttribute(
				$elm$html$Html$Attributes$tabindex(-1))
			]),
		libelle,
		$elm$core$Maybe$Nothing);
};
var $author$project$Main$vueEdition = function (m) {
	return A2(
		$author$project$MrJam$Documents$repere,
		'edition',
		A2(
			$author$project$MrJam$Documents$document,
			_Utils_eq(m.c, $elm$core$Maybe$Nothing) ? 'Créer' : 'Modifier',
			_Utils_ap(
				_List_fromArray(
					[
						A3(
						$author$project$MrJam$zoneTexte,
						'Contenu de référence',
						A2($author$project$Main$valeur, 'contenu', m),
						$author$project$Main$Saisir('contenu')),
						A3(
						$author$project$MrJam$zoneTexte,
						'Alias (un par ligne)',
						A2($author$project$Main$valeur, 'alias', m),
						$author$project$Main$Saisir('alias'))
					]),
				_Utils_ap(
					(!m.a) ? _List_fromArray(
						[
							A3(
							$author$project$MrJam$champ,
							'Titre',
							A2($author$project$Main$valeur, 'titre', m),
							$author$project$Main$Saisir('titre')),
							A3(
							$author$project$MrJam$zoneTexte,
							'Suivi qualitatif (facultatif)',
							A2($author$project$Main$valeur, 'suivi', m),
							$author$project$Main$Saisir('suivi')),
							A3(
							$author$project$MrJam$zoneTexte,
							'Tags (un par ligne)',
							A2($author$project$Main$valeur, 'tags', m),
							$author$project$Main$Saisir('tags')),
							A3(
							$author$project$MrJam$Donnees$nombre,
							'Priorité P (dB, −20 à +20)',
							A2($author$project$Main$valeur, 'priorite', m),
							$author$project$Main$Saisir('priorite')),
							$author$project$MrJam$texteSecondaire('Priorité positive : révisions avancées.')
						]) : (_Utils_eq(m.c, $elm$core$Maybe$Nothing) ? _List_fromArray(
						[
							A3(
							$author$project$MrJam$Donnees$nombre,
							'Stabilité initiale S (dB)',
							A2($author$project$Main$valeur, 'stabilite', m),
							$author$project$Main$Saisir('stabilite')),
							A3(
							$author$project$MrJam$champ,
							'Date de départ connue (ISO 8601, facultatif)',
							A2($author$project$Main$valeur, 'reference_a', m),
							$author$project$Main$Saisir('reference_a')),
							A3(
							$author$project$MrJam$champ,
							'Justification de l’estimation (si S ≠ −15)',
							A2($author$project$Main$valeur, 'justification', m),
							$author$project$Main$Saisir('justification'))
						]) : _List_fromArray(
						[
							$author$project$MrJam$texteSecondaire('La stabilité est actualisée par les évaluations ; cette édition conserve les dates de rappel.')
						])),
					_Utils_ap(
						_List_fromArray(
							[
								$author$project$MrJam$actions(
								_List_fromArray(
									[
										(!_Utils_eq(m.e, $elm$core$Maybe$Nothing)) ? $author$project$MrJam$boutonEnCours('Enregistrement…') : A2($author$project$MrJam$bouton, 'Enregistrer', $author$project$Main$Sauver),
										A2(
										$author$project$MrJam$boutonSecondaire,
										'Fermer la saisie',
										$author$project$Main$Naviguer($author$project$Main$Fermer))
									]))
							]),
						$elm$core$List$isEmpty(m.z) ? _List_Nil : _List_fromArray(
							[
								A2(
								$author$project$MrJam$Documents$section,
								'Items proches déjà présents',
								_Utils_ap(
									A2(
										$elm$core$List$map,
										function (v) {
											return $author$project$MrJam$pile(
												_List_fromArray(
													[
														$author$project$MrJam$paragraphe(
														A2($author$project$Contrat$chaine, 'contenu', v)),
														$author$project$MrJam$Donnees$lecture(
														A2($author$project$Contrat$chaine, 'contenu', v)),
														A2(
														$author$project$MrJam$boutonSecondaire,
														'Réutiliser cet item',
														$author$project$Main$Reutiliser(
															A2($author$project$Contrat$entier, 'id', v)))
													]));
										},
										m.z),
									_List_fromArray(
										[
											A3(
											$author$project$MrJam$champ,
											'Pourquoi s’agit-il d’une connaissance distincte ?',
											A2($author$project$Main$valeur, 'distinction', m),
											$author$project$Main$Saisir('distinction')),
											A2($author$project$MrJam$bouton, 'Créer cet item distinct', $author$project$Main$CreerDistinct)
										])))
							]))))));
};
var $author$project$Main$Etat = function (a) {
	return {$: 28, a: a};
};
var $author$project$Main$Filtrer = {$: 27};
var $author$project$Main$Filtres = {$: 18};
var $author$project$Main$Nouvelle = {$: 32};
var $author$project$Main$Pagination = function (a) {
	return {$: 30, a: a};
};
var $author$project$Main$Recherche = function (a) {
	return {$: 25, a: a};
};
var $author$project$Main$Tags = function (a) {
	return {$: 26, a: a};
};
var $author$project$Main$Tri = function (a) {
	return {$: 29, a: a};
};
var $author$project$MrJam$boutonDevoiler = F4(
	function (cible, libelle, ouvert, message) {
		return A4(
			$author$project$MrJam$Controles$action,
			$author$project$MrJam$Controles$Secondaire,
			_List_fromArray(
				[
					$mdgriffith$elm_ui$Element$htmlAttribute(
					A2($elm$html$Html$Attributes$attribute, 'aria-controls', cible)),
					$mdgriffith$elm_ui$Element$htmlAttribute(
					A2(
						$elm$html$Html$Attributes$attribute,
						'aria-expanded',
						ouvert ? 'true' : 'false'))
				]),
			libelle,
			$elm$core$Maybe$Just(message));
	});
var $elm$html$Html$Attributes$autocomplete = function (bool) {
	return A2(
		$elm$html$Html$Attributes$stringProperty,
		'autocomplete',
		bool ? 'on' : 'off');
};
var $elm$html$Html$Attributes$maxlength = function (n) {
	return A2(
		_VirtualDom_attribute,
		'maxlength',
		$elm$core$String$fromInt(n));
};
var $elm$html$Html$Attributes$placeholder = $elm$html$Html$Attributes$stringProperty('placeholder');
var $author$project$MrJam$champIdentifieAvec = F4(
	function (attributs, contrat, valeur, modifier) {
		return A2(
			$mdgriffith$elm_ui$Element$Input$text,
			_Utils_ap(
				$author$project$MrJam$Theme$champ,
				_Utils_ap(
					attributs,
					_Utils_ap(
						_List_fromArray(
							[
								$mdgriffith$elm_ui$Element$htmlAttribute(
								$elm$html$Html$Attributes$id(contrat.bg)),
								$mdgriffith$elm_ui$Element$htmlAttribute(
								$elm$html$Html$Attributes$spellcheck(false)),
								$mdgriffith$elm_ui$Element$htmlAttribute(
								$elm$html$Html$Attributes$autocomplete(false)),
								$mdgriffith$elm_ui$Element$htmlAttribute(
								A2($elm$html$Html$Attributes$attribute, 'autocapitalize', 'off'))
							]),
						_Utils_ap(
							A2(
								$elm$core$Maybe$withDefault,
								_List_Nil,
								A2(
									$elm$core$Maybe$map,
									function (exemple) {
										return _List_fromArray(
											[
												$mdgriffith$elm_ui$Element$htmlAttribute(
												$elm$html$Html$Attributes$placeholder(exemple))
											]);
									},
									contrat.cw)),
							_Utils_ap(
								A2(
									$elm$core$Maybe$withDefault,
									_List_Nil,
									A2(
										$elm$core$Maybe$map,
										function (repereAide) {
											return _List_fromArray(
												[
													$mdgriffith$elm_ui$Element$htmlAttribute(
													A2($elm$html$Html$Attributes$attribute, 'aria-describedby', repereAide))
												]);
										},
										contrat.eh)),
								A2(
									$elm$core$Maybe$withDefault,
									_List_Nil,
									A2(
										$elm$core$Maybe$map,
										function (limite) {
											return _List_fromArray(
												[
													$mdgriffith$elm_ui$Element$htmlAttribute(
													$elm$html$Html$Attributes$maxlength(
														A2($elm$core$Basics$max, 0, limite)))
												]);
										},
										contrat.fw))))))),
			{
				au: $author$project$MrJam$etiquette(contrat.fu),
				aR: modifier,
				bG: $elm$core$Maybe$Nothing,
				bL: valeur
			});
	});
var $author$project$MrJam$entree = function (message) {
	return A2(
		$elm$json$Json$Decode$andThen,
		function (touche) {
			return (touche === 'Enter') ? $elm$json$Json$Decode$succeed(
				_Utils_Tuple2(message, true)) : $elm$json$Json$Decode$fail('touche ignorée');
		},
		A2($elm$json$Json$Decode$field, 'key', $elm$json$Json$Decode$string));
};
var $author$project$MrJam$champIdentifieSoumis = F4(
	function (contrat, valeur, modifier, soumettre) {
		return A4(
			$author$project$MrJam$champIdentifieAvec,
			_List_fromArray(
				[
					$mdgriffith$elm_ui$Element$htmlAttribute(
					A2(
						$elm$html$Html$Events$preventDefaultOn,
						'keydown',
						$author$project$MrJam$entree(soumettre)))
				]),
			contrat,
			valeur,
			modifier);
	});
var $author$project$MrJam$Documents$entete = F2(
	function (titre, commandes) {
		return A2(
			$mdgriffith$elm_ui$Element$wrappedRow,
			_List_fromArray(
				[
					$mdgriffith$elm_ui$Element$width($mdgriffith$elm_ui$Element$fill),
					$mdgriffith$elm_ui$Element$spacing(12)
				]),
			_List_fromArray(
				[
					A2(
					$mdgriffith$elm_ui$Element$paragraph,
					_List_fromArray(
						[
							$mdgriffith$elm_ui$Element$Region$heading(2),
							$mdgriffith$elm_ui$Element$Font$size(26),
							$mdgriffith$elm_ui$Element$Font$bold,
							$mdgriffith$elm_ui$Element$width($mdgriffith$elm_ui$Element$shrink)
						]),
					_List_fromArray(
						[
							$mdgriffith$elm_ui$Element$text(titre)
						])),
					A2(
					$mdgriffith$elm_ui$Element$row,
					_List_fromArray(
						[
							$mdgriffith$elm_ui$Element$spacing(8)
						]),
					commandes)
				]));
	});
var $author$project$MrJam$Tableaux$Courte = 2;
var $author$project$MrJam$Tableaux$mesure = $author$project$MrJam$Tableaux$Colonne(2);
var $author$project$Contrat$pluriel = function (nature) {
	if (!nature) {
		return 'Fiches';
	} else {
		return 'Items';
	}
};
var $author$project$Main$vueListe = function (m) {
	return $author$project$MrJam$pile(
		_List_fromArray(
			[
				A2(
				$author$project$MrJam$Documents$entete,
				$author$project$Contrat$pluriel(m.a),
				_List_fromArray(
					[
						A2(
						$author$project$MrJam$bouton,
						(!m.a) ? 'Nouvelle fiche' : 'Nouvel item',
						$author$project$Main$Nouvelle)
					])),
				$author$project$MrJam$Documents$filtres(
				_List_fromArray(
					[
						A4(
						$author$project$MrJam$champIdentifieSoumis,
						{
							eh: $elm$core$Maybe$Nothing,
							cw: $elm$core$Maybe$Just(
								(m.a === 1) ? 'Rechercher une connaissance…' : 'Rechercher un titre…'),
							bg: 'recherche',
							fu: 'Recherche',
							fw: $elm$core$Maybe$Nothing
						},
						m.bI,
						$author$project$Main$Recherche,
						$author$project$Main$Filtrer),
						$author$project$MrJam$Documents$actions(
						_List_fromArray(
							[
								A2($author$project$MrJam$Documents$action, 'Rechercher', $author$project$Main$Filtrer),
								A4($author$project$MrJam$boutonDevoiler, 'filtres', 'Filtres et tri', m.be, $author$project$Main$Filtres)
							]))
					])),
				m.be ? A2(
				$author$project$MrJam$Documents$repere,
				'filtres',
				$author$project$MrJam$Documents$filtres(
					_Utils_ap(
						_List_fromArray(
							[
								A4(
								$author$project$MrJam$selecteur,
								'État',
								_List_fromArray(
									[
										_Utils_Tuple2('actif', 'Actifs'),
										_Utils_Tuple2('archive', 'Archivés'),
										_Utils_Tuple2('tous', 'Tous')
									]),
								m.by,
								$author$project$Main$Etat),
								A4(
								$author$project$MrJam$selecteur,
								'Tri',
								_List_fromArray(
									[
										_Utils_Tuple2(
										(!m.a) ? 'titre' : 'alphabetique',
										(!m.a) ? 'Titre' : 'Connaissance'),
										_Utils_Tuple2('modification', 'Modification récente'),
										_Utils_Tuple2(
										$author$project$Contrat$grandeur(m.a),
										(!m.a) ? 'Priorité' : 'Stabilité')
									]),
								m.bn,
								$author$project$Main$Tri)
							]),
						(!m.a) ? _List_fromArray(
							[
								A3($author$project$MrJam$champ, 'Tags (séparés par des virgules)', m.bK, $author$project$Main$Tags)
							]) : _List_Nil))) : $mdgriffith$elm_ui$Element$none,
				A4(
				$author$project$MrJam$Tableaux$tableauAvecOutils,
				'Résultats',
				_List_fromArray(
					[
						A3($author$project$MrJam$Pictogrammes$action, 6, 'Trier le tableau', $author$project$Main$Filtres),
						A3($author$project$MrJam$Pictogrammes$action, 5, 'Filtrer le tableau', $author$project$Main$Filtres)
					]),
				_List_fromArray(
					[
						A2(
						$author$project$MrJam$Tableaux$principale,
						(!m.a) ? 'Titre' : 'Connaissance',
						$author$project$Main$lienObjet(m.a)),
						A2(
						$author$project$MrJam$Tableaux$mesure,
						(!m.a) ? 'Priorité' : 'Stabilité',
						A2(
							$elm$core$Basics$composeR,
							$author$project$Contrat$entier(
								$author$project$Contrat$grandeur(m.a)),
							A2($elm$core$Basics$composeR, $author$project$Main$db, $mdgriffith$elm_ui$Element$text))),
						A2(
						$author$project$MrJam$Tableaux$mesure,
						(!m.a) ? 'Items' : 'Évaluation',
						function (v) {
							return $mdgriffith$elm_ui$Element$text(
								(!m.a) ? $elm$core$String$fromInt(
									A2($author$project$Contrat$entier, 'nombre_items', v)) : (A2($author$project$Contrat$vrai, 'evalue', v) ? 'Évalué' : 'Non évalué'));
						})
					]),
				m.bk),
				$author$project$MrJam$Documents$pagination(
				{
					a9: m.a9,
					fT: $author$project$Main$Pagination(-1),
					gi: $author$project$Main$Pagination(1),
					gl: 20,
					a0: m.a0
				})
			]));
};
var $author$project$Main$espace = function (m) {
	return _Utils_ap(
		_List_Nil,
		_Utils_ap(
			((!_Utils_eq(m.e, $elm$core$Maybe$Nothing)) && $elm$core$Dict$isEmpty(m.af)) ? _List_fromArray(
				[
					A2($author$project$MrJam$bouton, 'Réessayer la même écriture', $author$project$Main$Reessayer)
				]) : _List_Nil,
			_Utils_ap(
				m.aX ? _List_fromArray(
					[
						A2(
						$author$project$MrJam$Documents$section,
						'Politique de révision',
						_List_fromArray(
							[
								A3($author$project$MrJam$Donnees$nombre, 'Intervalle de référence (jours)', m.V, $author$project$Main$Intervalle),
								$author$project$MrJam$actions(
								A2(
									$elm$core$List$map,
									function (j) {
										return A2(
											$author$project$MrJam$boutonSecondaire,
											$elm$core$String$fromInt(j) + ' jours',
											$author$project$Main$Intervalle(
												$elm$core$String$fromInt(j)));
									},
									_List_fromArray(
										[7, 14, 30, 90]))),
								A3($author$project$MrJam$Donnees$nombre, 'Budget d’items par jour (facultatif)', m.N, $author$project$Main$Budget),
								A3($author$project$MrJam$Donnees$nombre, 'Nombre typique de questions (1 à 20)', m.aa, $author$project$Main$QuestionsTypiques),
								A3($author$project$MrJam$Donnees$nombre, 'Seuil de séance courte (minutes)', m.U, $author$project$Main$DureeSeanceCourte),
								$author$project$MrJam$paragraphe('Sous ce seuil strict, les dates manquantes peuvent être approximées à la clôture. À la borne ou au-delà, une clarification, une trace non datée ou votre accord explicite est nécessaire.'),
								$author$project$MrJam$paragraphe('Si davantage d’items évalués sont dans la fenêtre, Vision demandera combien en réviser ; les items non évalués peuvent compléter un petit lot.'),
								$author$project$MrJam$paragraphe(
								'Décalage de charge : ' + ($author$project$Main$db(
									A2($author$project$Contrat$entier, 'decalage', m._)) + '. Adaptation d’au plus 1 dB par semaine à partir des items distincts.')),
								A2($author$project$MrJam$bouton, 'Enregistrer la politique', $author$project$Main$SauverPolitique)
							]))
					]) : _List_Nil,
				function () {
					if (m.i && _Utils_eq(m.c, $elm$core$Maybe$Nothing)) {
						return _List_fromArray(
							[
								$author$project$Main$vueEdition(m)
							]);
					} else {
						var _v0 = m.c;
						if (!_v0.$) {
							var d = _v0.a;
							return _List_fromArray(
								[
									A2($author$project$Main$vueDetail, m, d)
								]);
						} else {
							return _List_fromArray(
								[
									$author$project$Main$vueListe(m)
								]);
						}
					}
				}())));
};
var $author$project$MrJam$Theme$identiteHtml = function (marque) {
	return _List_fromArray(
		[
			$elm$html$Html$Attributes$class(
			function () {
				switch (marque) {
					case 'Vision':
						return 'mrjam-identite-vision';
					case 'Xiaoping':
						return 'mrjam-identite-xiaoping';
					case 'Ydris':
						return 'mrjam-identite-ydris';
					case 'Zoé':
						return 'mrjam-identite-zoe';
					default:
						return 'mrjam-identite-commune';
				}
			}())
		]);
};
var $author$project$MrJam$Fenetres$avecModalePour = F3(
	function (marque, dialogue, contenu) {
		return A2(
			$elm$html$Html$div,
			A2(
				$elm$core$List$cons,
				A2($elm$html$Html$Attributes$style, 'font-family', 'Inter, Aptos, Segoe UI, sans-serif'),
				$author$project$MrJam$Theme$identiteHtml(marque)),
			_List_fromArray(
				[
					contenu,
					A2(
					$elm$core$Maybe$withDefault,
					$elm$html$Html$text(''),
					dialogue)
				]));
	});
var $author$project$MrJam$Theme$ecran = _List_fromArray(
	[
		$mdgriffith$elm_ui$Element$width($mdgriffith$elm_ui$Element$fill),
		$mdgriffith$elm_ui$Element$htmlAttribute(
		$elm$html$Html$Attributes$class('mrjam-ecran')),
		$mdgriffith$elm_ui$Element$htmlAttribute(
		A2($elm$html$Html$Attributes$style, 'min-width', '0')),
		$mdgriffith$elm_ui$Element$htmlAttribute(
		A2($elm$html$Html$Attributes$style, 'min-height', '100dvh')),
		$mdgriffith$elm_ui$Element$htmlAttribute(
		A2($elm$html$Html$Attributes$style, 'height', 'auto')),
		$mdgriffith$elm_ui$Element$htmlAttribute(
		A2($elm$html$Html$Attributes$style, 'max-width', '100%'))
	]);
var $mdgriffith$elm_ui$Internal$Model$FocusStyleOption = function (a) {
	return {$: 1, a: a};
};
var $mdgriffith$elm_ui$Element$focusStyle = $mdgriffith$elm_ui$Internal$Model$FocusStyleOption;
var $author$project$MrJam$Theme$focus = $mdgriffith$elm_ui$Element$focusStyle(
	{
		et: $elm$core$Maybe$Nothing,
		eB: $elm$core$Maybe$Just($author$project$MrJam$Theme$couleurs.a4),
		f7: $elm$core$Maybe$Nothing
	});
var $author$project$MrJam$Theme$identite = function (marque) {
	return A2(
		$elm$core$List$map,
		$mdgriffith$elm_ui$Element$htmlAttribute,
		$author$project$MrJam$Theme$identiteHtml(marque));
};
var $mdgriffith$elm_ui$Internal$Model$OnlyDynamic = F2(
	function (a, b) {
		return {$: 2, a: a, b: b};
	});
var $mdgriffith$elm_ui$Internal$Model$StaticRootAndDynamic = F2(
	function (a, b) {
		return {$: 1, a: a, b: b};
	});
var $mdgriffith$elm_ui$Internal$Model$AllowHover = 1;
var $mdgriffith$elm_ui$Internal$Model$Layout = 0;
var $mdgriffith$elm_ui$Internal$Model$focusDefaultStyle = {
	et: $elm$core$Maybe$Nothing,
	eB: $elm$core$Maybe$Nothing,
	f7: $elm$core$Maybe$Just(
		{
			a7: 0,
			a8: A4($mdgriffith$elm_ui$Internal$Model$Rgba, 155 / 255, 203 / 255, 1, 1),
			dC: _Utils_Tuple2(0, 0),
			aZ: 3
		})
};
var $mdgriffith$elm_ui$Internal$Model$optionsToRecord = function (options) {
	var combine = F2(
		function (opt, record) {
			switch (opt.$) {
				case 0:
					var hoverable = opt.a;
					var _v4 = record.fc;
					if (_v4.$ === 1) {
						return _Utils_update(
							record,
							{
								fc: $elm$core$Maybe$Just(hoverable)
							});
					} else {
						return record;
					}
				case 1:
					var focusStyle = opt.a;
					var _v5 = record.e8;
					if (_v5.$ === 1) {
						return _Utils_update(
							record,
							{
								e8: $elm$core$Maybe$Just(focusStyle)
							});
					} else {
						return record;
					}
				default:
					var renderMode = opt.a;
					var _v6 = record.fA;
					if (_v6.$ === 1) {
						return _Utils_update(
							record,
							{
								fA: $elm$core$Maybe$Just(renderMode)
							});
					} else {
						return record;
					}
			}
		});
	var andFinally = function (record) {
		return {
			e8: function () {
				var _v0 = record.e8;
				if (_v0.$ === 1) {
					return $mdgriffith$elm_ui$Internal$Model$focusDefaultStyle;
				} else {
					var focusable = _v0.a;
					return focusable;
				}
			}(),
			fc: function () {
				var _v1 = record.fc;
				if (_v1.$ === 1) {
					return 1;
				} else {
					var hoverable = _v1.a;
					return hoverable;
				}
			}(),
			fA: function () {
				var _v2 = record.fA;
				if (_v2.$ === 1) {
					return 0;
				} else {
					var actualMode = _v2.a;
					return actualMode;
				}
			}()
		};
	};
	return andFinally(
		A3(
			$elm$core$List$foldr,
			combine,
			{e8: $elm$core$Maybe$Nothing, fc: $elm$core$Maybe$Nothing, fA: $elm$core$Maybe$Nothing},
			options));
};
var $mdgriffith$elm_ui$Internal$Model$toHtml = F2(
	function (mode, el) {
		switch (el.$) {
			case 0:
				var html = el.a;
				return html($mdgriffith$elm_ui$Internal$Model$asEl);
			case 1:
				var styles = el.a.dY;
				var html = el.a.fd;
				return A2(
					html,
					mode(styles),
					$mdgriffith$elm_ui$Internal$Model$asEl);
			case 2:
				var text = el.a;
				return $mdgriffith$elm_ui$Internal$Model$textElement(text);
			default:
				return $mdgriffith$elm_ui$Internal$Model$textElement('');
		}
	});
var $mdgriffith$elm_ui$Internal$Model$renderRoot = F3(
	function (optionList, attributes, child) {
		var options = $mdgriffith$elm_ui$Internal$Model$optionsToRecord(optionList);
		var embedStyle = function () {
			var _v0 = options.fA;
			if (_v0 === 1) {
				return $mdgriffith$elm_ui$Internal$Model$OnlyDynamic(options);
			} else {
				return $mdgriffith$elm_ui$Internal$Model$StaticRootAndDynamic(options);
			}
		}();
		return A2(
			$mdgriffith$elm_ui$Internal$Model$toHtml,
			embedStyle,
			A4(
				$mdgriffith$elm_ui$Internal$Model$element,
				$mdgriffith$elm_ui$Internal$Model$asEl,
				$mdgriffith$elm_ui$Internal$Model$div,
				attributes,
				$mdgriffith$elm_ui$Internal$Model$Unkeyed(
					_List_fromArray(
						[child]))));
	});
var $mdgriffith$elm_ui$Internal$Model$SansSerif = {$: 1};
var $mdgriffith$elm_ui$Internal$Model$Typeface = function (a) {
	return {$: 3, a: a};
};
var $mdgriffith$elm_ui$Internal$Model$rootStyle = function () {
	var families = _List_fromArray(
		[
			$mdgriffith$elm_ui$Internal$Model$Typeface('Open Sans'),
			$mdgriffith$elm_ui$Internal$Model$Typeface('Helvetica'),
			$mdgriffith$elm_ui$Internal$Model$Typeface('Verdana'),
			$mdgriffith$elm_ui$Internal$Model$SansSerif
		]);
	return _List_fromArray(
		[
			A2(
			$mdgriffith$elm_ui$Internal$Model$StyleClass,
			$mdgriffith$elm_ui$Internal$Flag$bgColor,
			A3(
				$mdgriffith$elm_ui$Internal$Model$Colored,
				'bg-' + $mdgriffith$elm_ui$Internal$Model$formatColorClass(
					A4($mdgriffith$elm_ui$Internal$Model$Rgba, 1, 1, 1, 0)),
				'background-color',
				A4($mdgriffith$elm_ui$Internal$Model$Rgba, 1, 1, 1, 0))),
			A2(
			$mdgriffith$elm_ui$Internal$Model$StyleClass,
			$mdgriffith$elm_ui$Internal$Flag$fontColor,
			A3(
				$mdgriffith$elm_ui$Internal$Model$Colored,
				'fc-' + $mdgriffith$elm_ui$Internal$Model$formatColorClass(
					A4($mdgriffith$elm_ui$Internal$Model$Rgba, 0, 0, 0, 1)),
				'color',
				A4($mdgriffith$elm_ui$Internal$Model$Rgba, 0, 0, 0, 1))),
			A2(
			$mdgriffith$elm_ui$Internal$Model$StyleClass,
			$mdgriffith$elm_ui$Internal$Flag$fontSize,
			$mdgriffith$elm_ui$Internal$Model$FontSize(20)),
			A2(
			$mdgriffith$elm_ui$Internal$Model$StyleClass,
			$mdgriffith$elm_ui$Internal$Flag$fontFamily,
			A2(
				$mdgriffith$elm_ui$Internal$Model$FontFamily,
				A3($elm$core$List$foldl, $mdgriffith$elm_ui$Internal$Model$renderFontClassName, 'font-', families),
				families))
		]);
}();
var $mdgriffith$elm_ui$Element$layoutWith = F3(
	function (_v0, attrs, child) {
		var options = _v0.dD;
		return A3(
			$mdgriffith$elm_ui$Internal$Model$renderRoot,
			options,
			A2(
				$elm$core$List$cons,
				$mdgriffith$elm_ui$Internal$Model$htmlClass(
					A2(
						$elm$core$String$join,
						' ',
						_List_fromArray(
							[$mdgriffith$elm_ui$Internal$Style$classes.f0, $mdgriffith$elm_ui$Internal$Style$classes.er, $mdgriffith$elm_ui$Internal$Style$classes.f8]))),
				_Utils_ap($mdgriffith$elm_ui$Internal$Model$rootStyle, attrs)),
			child);
	});
var $elm$html$Html$Attributes$alt = $elm$html$Html$Attributes$stringProperty('alt');
var $elm$html$Html$Attributes$src = function (url) {
	return A2(
		$elm$html$Html$Attributes$stringProperty,
		'src',
		_VirtualDom_noJavaScriptOrHtmlUri(url));
};
var $mdgriffith$elm_ui$Element$image = F2(
	function (attrs, _v0) {
		var src = _v0.dW;
		var description = _v0.cu;
		var imageAttributes = A2(
			$elm$core$List$filter,
			function (a) {
				switch (a.$) {
					case 7:
						return true;
					case 8:
						return true;
					default:
						return false;
				}
			},
			attrs);
		return A4(
			$mdgriffith$elm_ui$Internal$Model$element,
			$mdgriffith$elm_ui$Internal$Model$asEl,
			$mdgriffith$elm_ui$Internal$Model$div,
			A2(
				$elm$core$List$cons,
				$mdgriffith$elm_ui$Internal$Model$htmlClass($mdgriffith$elm_ui$Internal$Style$classes.ff),
				attrs),
			$mdgriffith$elm_ui$Internal$Model$Unkeyed(
				_List_fromArray(
					[
						A4(
						$mdgriffith$elm_ui$Internal$Model$element,
						$mdgriffith$elm_ui$Internal$Model$asEl,
						$mdgriffith$elm_ui$Internal$Model$NodeName('img'),
						_Utils_ap(
							_List_fromArray(
								[
									$mdgriffith$elm_ui$Internal$Model$Attr(
									$elm$html$Html$Attributes$src(src)),
									$mdgriffith$elm_ui$Internal$Model$Attr(
									$elm$html$Html$Attributes$alt(description))
								]),
							imageAttributes),
						$mdgriffith$elm_ui$Internal$Model$Unkeyed(_List_Nil))
					])));
	});
var $author$project$MrJam$Identite$logo = A2(
	$mdgriffith$elm_ui$Element$image,
	_List_fromArray(
		[
			$mdgriffith$elm_ui$Element$width(
			$mdgriffith$elm_ui$Element$px(44)),
			$mdgriffith$elm_ui$Element$height(
			$mdgriffith$elm_ui$Element$px(44))
		]),
	{cu: 'Logo MrJ.am', dW: 'assets/mrjam/Echologo.svg'});
var $author$project$MrJam$Identite$logoPour = function (nom) {
	return (nom === 'Vision') ? A2(
		$mdgriffith$elm_ui$Element$image,
		_List_fromArray(
			[
				$mdgriffith$elm_ui$Element$width(
				$mdgriffith$elm_ui$Element$px(44)),
				$mdgriffith$elm_ui$Element$height(
				$mdgriffith$elm_ui$Element$px(44))
			]),
		{cu: 'Logo Vision', dW: 'assets/mrjam/palette/Palette-Visio.svg'}) : $author$project$MrJam$Identite$logo;
};
var $mdgriffith$elm_ui$Internal$Model$Main = {$: 0};
var $mdgriffith$elm_ui$Element$Region$mainContent = $mdgriffith$elm_ui$Internal$Model$Describe($mdgriffith$elm_ui$Internal$Model$Main);
var $mdgriffith$elm_ui$Internal$Model$Serif = {$: 0};
var $mdgriffith$elm_ui$Element$Font$serif = $mdgriffith$elm_ui$Internal$Model$Serif;
var $mdgriffith$elm_ui$Element$Font$typeface = $mdgriffith$elm_ui$Internal$Model$Typeface;
var $author$project$MrJam$Identite$pointMarque = A2(
	$mdgriffith$elm_ui$Element$el,
	_List_fromArray(
		[
			$mdgriffith$elm_ui$Element$htmlAttribute(
			$elm$html$Html$Attributes$class('echo-point mrjam-marque-point')),
			$mdgriffith$elm_ui$Element$htmlAttribute(
			A2($elm$html$Html$Attributes$style, 'line-height', '0')),
			$mdgriffith$elm_ui$Element$htmlAttribute(
			A2($elm$html$Html$Attributes$style, 'vertical-align', '-0.005em')),
			$mdgriffith$elm_ui$Element$Font$family(
			_List_fromArray(
				[
					$mdgriffith$elm_ui$Element$Font$typeface('EchoPoint'),
					$mdgriffith$elm_ui$Element$Font$serif
				])),
			$mdgriffith$elm_ui$Element$Font$size(56)
		]),
	$mdgriffith$elm_ui$Element$text('.'));
var $author$project$MrJam$Identite$marque = function (nom) {
	return A2(
		$mdgriffith$elm_ui$Element$paragraph,
		_List_fromArray(
			[
				$mdgriffith$elm_ui$Element$width($mdgriffith$elm_ui$Element$shrink),
				$mdgriffith$elm_ui$Element$spacing(0),
				$mdgriffith$elm_ui$Element$htmlAttribute(
				$elm$html$Html$Attributes$class('mrjam-marque')),
				A2($mdgriffith$elm_ui$Element$paddingXY, 0, 3),
				$mdgriffith$elm_ui$Element$Font$family(
				_List_fromArray(
					[
						$mdgriffith$elm_ui$Element$Font$typeface('MrJamEcriture'),
						$mdgriffith$elm_ui$Element$Font$serif
					])),
				$mdgriffith$elm_ui$Element$Font$size(28),
				$mdgriffith$elm_ui$Element$htmlAttribute(
				A2($elm$html$Html$Attributes$style, 'line-height', '1.183'))
			]),
		_List_fromArray(
			[
				$mdgriffith$elm_ui$Element$text(nom),
				$author$project$MrJam$Identite$pointMarque,
				A2(
				$mdgriffith$elm_ui$Element$el,
				_List_fromArray(
					[
						$mdgriffith$elm_ui$Element$htmlAttribute(
						$elm$html$Html$Attributes$class('mrjam')),
						$mdgriffith$elm_ui$Element$Font$family(
						_List_fromArray(
							[
								$mdgriffith$elm_ui$Element$Font$typeface('MrJamSignature'),
								$mdgriffith$elm_ui$Element$Font$serif
							])),
						$mdgriffith$elm_ui$Element$Font$size(28)
					]),
				$mdgriffith$elm_ui$Element$text('MrJ.am'))
			]));
};
var $mdgriffith$elm_ui$Internal$Model$Navigation = {$: 1};
var $mdgriffith$elm_ui$Element$Region$navigation = $mdgriffith$elm_ui$Internal$Model$Describe($mdgriffith$elm_ui$Internal$Model$Navigation);
var $author$project$MrJam$Identite$signature = A2(
	$mdgriffith$elm_ui$Element$paragraph,
	_List_fromArray(
		[
			$mdgriffith$elm_ui$Element$width($mdgriffith$elm_ui$Element$shrink),
			$mdgriffith$elm_ui$Element$spacing(0),
			$mdgriffith$elm_ui$Element$htmlAttribute(
			$elm$html$Html$Attributes$class('mrjam')),
			$mdgriffith$elm_ui$Element$htmlAttribute(
			A2($elm$html$Html$Attributes$style, 'line-height', '1.183')),
			$mdgriffith$elm_ui$Element$Font$family(
			_List_fromArray(
				[
					$mdgriffith$elm_ui$Element$Font$typeface('MrJamSignature'),
					$mdgriffith$elm_ui$Element$Font$serif
				])),
			$mdgriffith$elm_ui$Element$Font$size(28)
		]),
	_List_fromArray(
		[
			$mdgriffith$elm_ui$Element$text('MrJ.am')
		]));
var $author$project$MrJam$Identite$piedDePage = A2(
	$mdgriffith$elm_ui$Element$wrappedRow,
	_List_fromArray(
		[
			$mdgriffith$elm_ui$Element$width($mdgriffith$elm_ui$Element$fill),
			$mdgriffith$elm_ui$Element$centerX,
			$mdgriffith$elm_ui$Element$spacing(8),
			A2($mdgriffith$elm_ui$Element$paddingXY, 0, 12),
			$mdgriffith$elm_ui$Element$Font$size(14),
			$author$project$MrJam$Theme$police($author$project$MrJam$Theme$couleurs.eZ)
		]),
	_List_fromArray(
		[
			A2(
			$mdgriffith$elm_ui$Element$el,
			_List_Nil,
			$mdgriffith$elm_ui$Element$text('Une application de')),
			$author$project$MrJam$Identite$signature
		]));
var $mdgriffith$elm_ui$Element$Font$sansSerif = $mdgriffith$elm_ui$Internal$Model$SansSerif;
var $elm$html$Html$node = $elm$virtual_dom$VirtualDom$node;
var $author$project$MrJam$OKLab$css = function (col) {
	return 'oklch(' + ($elm$core$String$fromFloat(col.bA) + (' ' + ($elm$core$String$fromFloat(col.bT) + (' ' + ($elm$core$String$fromFloat(col.b5) + ')')))));
};
var $author$project$MrJam$Theme$variables = function (h) {
	return A2(
		$elm$core$String$join,
		';',
		A2(
			$elm$core$List$map,
			function (_v0) {
				var nom = _v0.a;
				var col = _v0.b;
				return '--mrjam-' + (nom + (':' + $author$project$MrJam$OKLab$css(col)));
			},
			$author$project$MrJam$Theme$palette(h)));
};
var $author$project$MrJam$Theme$styles = A3(
	$elm$html$Html$node,
	'style',
	_List_Nil,
	_List_fromArray(
		[
			$elm$html$Html$text(
			':root{' + ($author$project$MrJam$Theme$variables(137.50776405003785) + ('}' + ($elm$core$String$concat(
				A2(
					$elm$core$List$map,
					function (_v0) {
						var marque = _v0.a;
						var teinte = _v0.b;
						return '.mrjam-identite-' + (marque + ('{' + ($author$project$MrJam$Theme$variables(teinte) + '}')));
					},
					_List_fromArray(
						[
							_Utils_Tuple2('commune', 137.50776405003785),
							_Utils_Tuple2('vision', 227.50776405003785),
							_Utils_Tuple2('xiaoping', 92.50776405003785),
							_Utils_Tuple2('ydris', 182.50776405003785),
							_Utils_Tuple2('zoe', 272.50776405003785)
						]))) + ($elm$core$String$concat(
				A2(
					$elm$core$List$map,
					function (_v1) {
						var nom = _v1.a;
						return '.mrjam-survol-' + (nom + (':hover{background-color:var(--mrjam-' + (nom + (')!important}.mrjam-survol-texte-' + (nom + (':hover{color:var(--mrjam-' + (nom + ')!important}')))))));
					},
					$author$project$MrJam$Theme$palette(137.50776405003785))) + 'button:focus-visible,a:focus-visible,input:focus-visible,textarea:focus-visible,select:focus-visible{outline:3px solid var(--mrjam-accent);outline-offset:2px}')))))
		]));
var $author$project$MrJam$Documents$cadre = F5(
	function (marque, titre, navigation, dialogue, contenu) {
		return A3(
			$author$project$MrJam$Fenetres$avecModalePour,
			titre,
			dialogue,
			A3(
				$mdgriffith$elm_ui$Element$layoutWith,
				{
					dD: _List_fromArray(
						[$author$project$MrJam$Theme$focus])
				},
				_Utils_ap(
					$author$project$MrJam$Theme$ecran,
					_Utils_ap(
						$author$project$MrJam$Theme$identite(titre),
						_List_fromArray(
							[
								$author$project$MrJam$Theme$fond($author$project$MrJam$Theme$couleurs.d_),
								$author$project$MrJam$Theme$police($author$project$MrJam$Theme$couleurs.c8),
								$mdgriffith$elm_ui$Element$Font$size(15),
								$mdgriffith$elm_ui$Element$Font$family(
								_List_fromArray(
									[
										$mdgriffith$elm_ui$Element$Font$typeface('Inter'),
										$mdgriffith$elm_ui$Element$Font$typeface('Aptos'),
										$mdgriffith$elm_ui$Element$Font$typeface('Segoe UI'),
										$mdgriffith$elm_ui$Element$Font$sansSerif
									]))
							]))),
				A2(
					$mdgriffith$elm_ui$Element$column,
					_List_fromArray(
						[
							$mdgriffith$elm_ui$Element$width($mdgriffith$elm_ui$Element$fill),
							$mdgriffith$elm_ui$Element$spacing(0)
						]),
					_List_fromArray(
						[
							$mdgriffith$elm_ui$Element$html($author$project$MrJam$Theme$styles),
							A2(
							$mdgriffith$elm_ui$Element$wrappedRow,
							_List_fromArray(
								[
									$mdgriffith$elm_ui$Element$width($mdgriffith$elm_ui$Element$fill),
									A2($mdgriffith$elm_ui$Element$paddingXY, 20, 12),
									$mdgriffith$elm_ui$Element$spacing(18),
									$author$project$MrJam$Theme$fond($author$project$MrJam$Theme$couleurs.fR),
									$mdgriffith$elm_ui$Element$Border$widthEach(
									{eF: 1, fr: 0, fZ: 0, gB: 0}),
									$author$project$MrJam$Theme$bordure($author$project$MrJam$Theme$couleurs.fv),
									$mdgriffith$elm_ui$Element$htmlAttribute(
									A2($elm$html$Html$Attributes$attribute, 'role', 'banner'))
								]),
							_Utils_ap(
								marque ? _List_fromArray(
									[
										$author$project$MrJam$Identite$logoPour(titre),
										A2(
										$mdgriffith$elm_ui$Element$link,
										_List_fromArray(
											[
												$mdgriffith$elm_ui$Element$htmlAttribute(
												A2($elm$html$Html$Attributes$attribute, 'aria-label', titre + '.MrJ.am — accueil'))
											]),
										{
											au: $author$project$MrJam$Identite$marque(titre),
											gH: './'
										})
									]) : _List_fromArray(
									[
										$author$project$MrJam$Identite$logo,
										A2(
										$mdgriffith$elm_ui$Element$paragraph,
										_List_fromArray(
											[
												$mdgriffith$elm_ui$Element$Region$heading(1),
												$mdgriffith$elm_ui$Element$Font$size(20),
												$mdgriffith$elm_ui$Element$Font$bold
											]),
										_List_fromArray(
											[
												$mdgriffith$elm_ui$Element$text(titre)
											]))
									]),
								_List_fromArray(
									[
										marque ? A2(
										$mdgriffith$elm_ui$Element$el,
										_List_fromArray(
											[
												$mdgriffith$elm_ui$Element$width(
												A2($mdgriffith$elm_ui$Element$minimum, 200, $mdgriffith$elm_ui$Element$fill))
											]),
										A2(
											$mdgriffith$elm_ui$Element$wrappedRow,
											_List_fromArray(
												[
													$mdgriffith$elm_ui$Element$spacing(12),
													$mdgriffith$elm_ui$Element$alignRight,
													$mdgriffith$elm_ui$Element$Region$navigation
												]),
											navigation)) : A2(
										$mdgriffith$elm_ui$Element$wrappedRow,
										_List_fromArray(
											[
												$mdgriffith$elm_ui$Element$spacing(12),
												$mdgriffith$elm_ui$Element$width(
												A2($mdgriffith$elm_ui$Element$minimum, 200, $mdgriffith$elm_ui$Element$fill)),
												$mdgriffith$elm_ui$Element$Region$navigation
											]),
										navigation)
									]))),
							A2(
							$mdgriffith$elm_ui$Element$column,
							_List_fromArray(
								[
									$mdgriffith$elm_ui$Element$width(
									A2($mdgriffith$elm_ui$Element$maximum, 1280, $mdgriffith$elm_ui$Element$fill)),
									$mdgriffith$elm_ui$Element$centerX,
									$mdgriffith$elm_ui$Element$padding(24),
									$mdgriffith$elm_ui$Element$spacing(20),
									$mdgriffith$elm_ui$Element$Region$mainContent,
									$mdgriffith$elm_ui$Element$htmlAttribute(
									$elm$html$Html$Attributes$id('contenu-principal'))
								]),
							contenu),
							marque ? $mdgriffith$elm_ui$Element$none : A2(
							$mdgriffith$elm_ui$Element$el,
							_List_fromArray(
								[
									$mdgriffith$elm_ui$Element$width($mdgriffith$elm_ui$Element$fill),
									A2($mdgriffith$elm_ui$Element$paddingXY, 24, 0)
								]),
							$author$project$MrJam$Identite$piedDePage)
						]))));
	});
var $author$project$MrJam$Documents$espaceMarque = F4(
	function (titre, navigation, dialogue, contenu) {
		return A5($author$project$MrJam$Documents$cadre, true, titre, navigation, dialogue, contenu);
	});
var $mdgriffith$elm_ui$Element$Font$underline = $mdgriffith$elm_ui$Internal$Model$htmlClass($mdgriffith$elm_ui$Internal$Style$classes.gF);
var $author$project$MrJam$navigationLien = F3(
	function (attributs, libelle, adresse) {
		return A2(
			$mdgriffith$elm_ui$Element$link,
			_Utils_ap(
				attributs,
				_List_fromArray(
					[
						$author$project$MrJam$Theme$police($author$project$MrJam$Theme$couleurs.a4),
						$mdgriffith$elm_ui$Element$Font$underline,
						A2($mdgriffith$elm_ui$Element$paddingXY, 0, 10),
						$mdgriffith$elm_ui$Element$height(
						A2($mdgriffith$elm_ui$Element$minimum, 44, $mdgriffith$elm_ui$Element$shrink))
					])),
			{
				au: $author$project$MrJam$paragraphe(libelle),
				gH: adresse
			});
	});
var $author$project$MrJam$lien = F2(
	function (libelle, adresse) {
		return A3($author$project$MrJam$navigationLien, _List_Nil, libelle, adresse);
	});
var $elm$virtual_dom$VirtualDom$map = _VirtualDom_map;
var $mdgriffith$elm_ui$Internal$Model$map = F2(
	function (fn, el) {
		switch (el.$) {
			case 1:
				var styled = el.a;
				return $mdgriffith$elm_ui$Internal$Model$Styled(
					{
						fd: F2(
							function (add, context) {
								return A2(
									$elm$virtual_dom$VirtualDom$map,
									fn,
									A2(styled.fd, add, context));
							}),
						dY: styled.dY
					});
			case 0:
				var html = el.a;
				return $mdgriffith$elm_ui$Internal$Model$Unstyled(
					A2(
						$elm$core$Basics$composeL,
						$elm$virtual_dom$VirtualDom$map(fn),
						html));
			case 2:
				var str = el.a;
				return $mdgriffith$elm_ui$Internal$Model$Text(str);
			default:
				return $mdgriffith$elm_ui$Internal$Model$Empty;
		}
	});
var $mdgriffith$elm_ui$Element$map = $mdgriffith$elm_ui$Internal$Model$map;
var $author$project$MrJam$mapper = $mdgriffith$elm_ui$Element$map;
var $author$project$MrJam$Documents$menu = F3(
	function (ouvert, basculer, contenu) {
		return A2(
			$mdgriffith$elm_ui$Element$column,
			_List_fromArray(
				[
					$mdgriffith$elm_ui$Element$width(
					A2($mdgriffith$elm_ui$Element$maximum, 280, $mdgriffith$elm_ui$Element$shrink)),
					$mdgriffith$elm_ui$Element$spacing(8),
					$mdgriffith$elm_ui$Element$htmlAttribute(
					A2(
						$elm$html$Html$Events$on,
						'keydown',
						A2(
							$elm$json$Json$Decode$andThen,
							function (touche) {
								return ((touche === 'Escape') && ouvert) ? $elm$json$Json$Decode$succeed(basculer) : $elm$json$Json$Decode$fail('Autre touche');
							},
							A2($elm$json$Json$Decode$field, 'key', $elm$json$Json$Decode$string))))
				]),
			_List_fromArray(
				[
					A4(
					$author$project$MrJam$Controles$action,
					$author$project$MrJam$Controles$Icone,
					_List_fromArray(
						[
							$mdgriffith$elm_ui$Element$htmlAttribute(
							A2($elm$html$Html$Attributes$attribute, 'aria-label', 'Ouvrir le menu')),
							$mdgriffith$elm_ui$Element$htmlAttribute(
							A2($elm$html$Html$Attributes$attribute, 'aria-controls', 'menu-application')),
							$mdgriffith$elm_ui$Element$htmlAttribute(
							A2(
								$elm$html$Html$Attributes$attribute,
								'aria-expanded',
								ouvert ? 'true' : 'false'))
						]),
					'☰',
					$elm$core$Maybe$Just(basculer)),
					ouvert ? A2(
					$author$project$MrJam$Documents$repere,
					'menu-application',
					$author$project$MrJam$Documents$actions(contenu)) : $mdgriffith$elm_ui$Element$none
				]));
	});
var $mdgriffith$elm_ui$Element$Input$currentPassword = F2(
	function (attrs, pass) {
		return A3(
			$mdgriffith$elm_ui$Element$Input$textHelper,
			{
				R: $elm$core$Maybe$Just('current-password'),
				ad: false,
				gE: $mdgriffith$elm_ui$Element$Input$TextInputNode(
					pass.dT ? 'text' : 'password')
			},
			attrs,
			{au: pass.au, aR: pass.aR, bG: pass.bG, bL: pass.bL});
	});
var $author$project$MrJam$motDePasse = F3(
	function (libelle, valeur, modifier) {
		return A2(
			$mdgriffith$elm_ui$Element$Input$currentPassword,
			$author$project$MrJam$Theme$champ,
			{
				au: $author$project$MrJam$etiquette(libelle),
				aR: modifier,
				bG: $elm$core$Maybe$Nothing,
				dT: false,
				bL: valeur
			});
	});
var $author$project$MrJam$Documents$onglet = F3(
	function (actif, libelle, message) {
		return A2(
			$mdgriffith$elm_ui$Element$el,
			_List_fromArray(
				[
					$mdgriffith$elm_ui$Element$Border$widthEach(
					{eF: 2, fr: 0, fZ: 0, gB: 0}),
					$author$project$MrJam$Theme$bordure(
					actif ? $author$project$MrJam$Theme$couleurs.a4 : $author$project$MrJam$Theme$couleurs.d_),
					$mdgriffith$elm_ui$Element$htmlAttribute(
					A2(
						$elm$html$Html$Attributes$attribute,
						'aria-current',
						actif ? 'page' : 'false'))
				]),
			A2($author$project$MrJam$Documents$action, libelle, message));
	});
var $author$project$Admission$Age = function (a) {
	return {$: 2, a: a};
};
var $author$project$Admission$Courriel = function (a) {
	return {$: 0, a: a};
};
var $author$project$Admission$Parent = function (a) {
	return {$: 3, a: a};
};
var $author$project$Admission$Pays = function (a) {
	return {$: 1, a: a};
};
var $author$project$Admission$Pseudonyme = function (a) {
	return {$: 4, a: a};
};
var $author$project$Admission$vue = function (m) {
	return A2(
		$author$project$MrJam$Documents$section,
		'Demander mon accès',
		_List_fromArray(
			[
				A3($author$project$MrJam$champ, 'Votre adresse de courrier', m.bw, $author$project$Admission$Courriel),
				A3($author$project$MrJam$champ, 'Pseudonyme (facultatif)', m.bH, $author$project$Admission$Pseudonyme),
				A3($author$project$MrJam$champ, 'Pays de résidence', m.bF, $author$project$Admission$Pays),
				A4(
				$author$project$MrJam$selecteur,
				'Votre tranche d’âge',
				_List_fromArray(
					[
						_Utils_Tuple2('', 'Choisir'),
						_Utils_Tuple2('moins15', 'Moins de 15 ans'),
						_Utils_Tuple2('15a17', '15 à 17 ans'),
						_Utils_Tuple2('majeur', '18 ans ou plus')
					]),
				m.aC,
				$author$project$Admission$Age),
				((m.aC !== 'majeur') && (m.aC !== '')) ? A3($author$project$MrJam$champ, 'Adresse d’un représentant légal (obligatoire avant 15 ans en France)', m.aV, $author$project$Admission$Parent) : $mdgriffith$elm_ui$Element$none,
				$author$project$MrJam$paragraphe('Nous vérifions votre adresse avant toute ouverture de compte. Si vous avez déjà un compte MrJ.am avec cette adresse vérifiée, vous conservez le même compte et le même mot de passe.'),
				$author$project$MrJam$paragraphe('En France, avant 15 ans, un représentant légal doit confirmer son accord par courrier, puis sa qualité doit être vérifiée manuellement. Les demandes de mineurs et celles provenant d’autres pays sont examinées avant admission, selon les règles applicables. Le seuil français ne constitue pas un âge minimum universel.'),
				$author$project$MrJam$texteSecondaire('La date de naissance et une pièce d’identité ne sont pas demandées dans ce formulaire. Ne communiquez pas de document spontanément. Votre pays, votre tranche d’âge et les informations de vérification ne sont pas accessibles à l’administration Vision. Une place est réservée pendant sept jours.')
			]));
};
var $author$project$MrJam$Avertissement = 2;
var $author$project$Compte$Choisir = F2(
	function (a, b) {
		return {$: 2, a: a, b: b};
	});
var $author$project$Compte$Effacer = {$: 5};
var $author$project$Compte$Exporter = {$: 4};
var $author$project$Compte$Format = function (a) {
	return {$: 0, a: a};
};
var $author$project$Compte$Page = function (a) {
	return {$: 3, a: a};
};
var $author$project$Compte$Toutes = function (a) {
	return {$: 1, a: a};
};
var $author$project$MrJam$Controles$Destructive = {$: 2};
var $author$project$MrJam$boutonDestructif = F2(
	function (libelle, message) {
		return A4(
			$author$project$MrJam$Controles$action,
			$author$project$MrJam$Controles$Destructive,
			_List_Nil,
			libelle,
			$elm$core$Maybe$Just(message));
	});
var $author$project$MrJam$boutonInactif = function (libelle) {
	return A4(
		$author$project$MrJam$Controles$action,
		$author$project$MrJam$Controles$Secondaire,
		_List_fromArray(
			[
				$mdgriffith$elm_ui$Element$htmlAttribute(
				A2($elm$html$Html$Attributes$attribute, 'aria-disabled', 'true')),
				$mdgriffith$elm_ui$Element$htmlAttribute(
				$elm$html$Html$Attributes$tabindex(-1))
			]),
		libelle,
		$elm$core$Maybe$Nothing);
};
var $author$project$Compte$vue = F4(
	function (usage, identite, exportEnCours, _export) {
		var mo = function (cle) {
			return $elm$core$String$fromFloat(
				A2($author$project$Contrat$entier, cle, usage) / 1000000);
		};
		var limites = A2($author$project$Contrat$objet, 'limites', usage);
		var n = function (cle) {
			return $elm$core$String$fromInt(
				A2($author$project$Contrat$entier, cle, limites));
		};
		return _List_fromArray(
			[
				A2(
				$author$project$MrJam$Documents$document,
				'Mon compte et mes limites',
				_List_fromArray(
					[
						$author$project$MrJam$paragraphe(
						mo('utilise_octets') + (' Mo utilisés sur ' + (mo('quota_octets') + ' Mo autorisés. 1 Mo = 1 000 000 octets.'))),
						A2($author$project$Contrat$vrai, 'depassement', usage) ? A2($author$project$MrJam$avis, 2, 'Votre allocation a diminué. Vos données sont conservées ; les ajouts sont bloqués jusqu’au retour sous le quota. La lecture, l’export et l’effacement restent disponibles.') : $mdgriffith$elm_ui$Element$none,
						$author$project$MrJam$paragraphe(
						$elm$core$String$fromInt(
							A2($author$project$Contrat$entier, 'fiches', usage)) + (' fiches et ' + ($elm$core$String$fromInt(
							A2($author$project$Contrat$entier, 'items', usage)) + ' items, archives incluses.'))),
						$author$project$MrJam$paragraphe(
						'Jusqu’à ' + (n('fiches') + (' fiches et ' + (n('items_par_fiche') + ' items par fiche.')))),
						$author$project$MrJam$paragraphe(
						'Un item : ' + (n('mots_item') + (' mots et ' + (n('octets_item') + (' octets au maximum. Une fiche : ' + (n('mots_fiche') + (' mots et ' + (n('octets_fiche') + ' octets au maximum.')))))))),
						$author$project$MrJam$paragraphe(
						'Une note : ' + (n('mots_note') + (' mots et ' + (n('octets_note') + ' octets au maximum. Les assistants sont invités à viser 80 à 120 mots.')))),
						$author$project$MrJam$texteSecondaire('Les deux plafonds de texte s’appliquent ensemble. Les mots sont séparés par des espaces. L’UTF-8 peut utiliser plusieurs octets par caractère.'),
						$author$project$MrJam$paragraphe('L’espace comprend les textes, les notes, les historiques, les copies temporaires et les données dérivées, y compris les vecteurs. Il est compté en UTF-8 non compressé avec un forfait de 256 octets par ligne. L’archivage conserve les données et l’espace utilisé.'),
						$author$project$MrJam$texteSecondaire('Ce quota mesure vos données selon une règle stable. Les fichiers physiques de la base, ses index et ses sauvegardes occupent aussi un espace partagé, surveillé séparément par l’exploitation.')
					])),
				A2(
				$author$project$MrJam$Documents$section,
				'Mes données',
				_List_fromArray(
					[
						$author$project$MrJam$paragraphe('Choisissez le format de l’export. JSON et XML contiennent toutes vos données personnelles Vision, y compris les historiques. Le Markdown conserve les connaissances, sans le suivi ni les données de révision. Suspendez les modifications et les assistants pendant l’export.'),
						A4(
						$author$project$MrJam$selecteur,
						'Format de l’export',
						_List_fromArray(
							[
								_Utils_Tuple2('json', 'JSON — toutes mes données'),
								_Utils_Tuple2('xml', 'XML — toutes mes données'),
								_Utils_Tuple2('markdown', 'Markdown — mes connaissances')
							]),
						_export.bf,
						$author$project$Compte$Format),
						(_export.bf === 'markdown') ? A2(
						$author$project$MrJam$Documents$section,
						'Fiches à exporter',
						_Utils_ap(
							_List_fromArray(
								[
									A3($author$project$MrJam$caseACocher, 'Toutes mes fiches et tous mes items', _export.bm, $author$project$Compte$Toutes)
								]),
							_export.bm ? _List_Nil : _Utils_ap(
								A2(
									$elm$core$List$map,
									function (f) {
										return A3(
											$author$project$MrJam$caseACocher,
											A2($author$project$Contrat$chaine, 'titre', f),
											A2(
												$elm$core$List$member,
												A2($author$project$Contrat$entier, 'id', f),
												_export.ay),
											$author$project$Compte$Choisir(
												A2($author$project$Contrat$entier, 'id', f)));
									},
									_export.bz),
								_List_fromArray(
									[
										$author$project$MrJam$texteSecondaire(
										$elm$core$String$fromInt(
											$elm$core$List$length(_export.ay)) + ' fiches sélectionnées.'),
										(_export.a9 > 0) ? A2(
										$author$project$MrJam$bouton,
										'Fiches précédentes',
										$author$project$Compte$Page(_export.a9 - 100)) : $mdgriffith$elm_ui$Element$none,
										_export.cf ? A2(
										$author$project$MrJam$bouton,
										'Fiches suivantes',
										$author$project$Compte$Page(_export.a9 + 100)) : $mdgriffith$elm_ui$Element$none
									])))) : $mdgriffith$elm_ui$Element$none,
						exportEnCours ? $author$project$MrJam$boutonInactif('Export en cours…') : (((_export.bf === 'markdown') && ((!_export.bm) && $elm$core$List$isEmpty(_export.ay))) ? $author$project$MrJam$boutonInactif('Sélectionnez au moins une fiche') : A2($author$project$MrJam$bouton, 'Exporter mes données', $author$project$Compte$Exporter)),
						A2($author$project$MrJam$lien, 'Notice de confidentialité et droits', '/privacy'),
						(identite === '') ? $mdgriffith$elm_ui$Element$none : A2($author$project$MrJam$lien, 'Sécurité et identité de mon compte commun', identite),
						$author$project$MrJam$paragraphe('Effacer Vision supprime vos contenus et votre accès à cet outil. Votre identité commune et les données des autres outils sont conservées. Pour fermer vous-même votre compte commun, ouvrez Sécurité et identité, puis la suppression du compte : une nouvelle authentification et une confirmation explicite sont nécessaires. Exportez d’abord les données souhaitées.'),
						A2($author$project$MrJam$boutonDestructif, 'Effacer mon compte Vision', $author$project$Compte$Effacer)
					])),
				function () {
				var preavis = A2($author$project$Contrat$objet, 'suppression', usage);
				return ((!_Utils_eq(preavis, $elm$json$Json$Encode$null)) && (A2($author$project$Contrat$chaine, 'annule_a', preavis) === '')) ? A2(
					$author$project$MrJam$Documents$section,
					'Préavis de suppression',
					_List_fromArray(
						[
							A2(
							$author$project$MrJam$avis,
							2,
							(A2($author$project$Contrat$chaine, 'echeance_a', preavis) === '') ? 'Une suppression administrative a été demandée. Le courriel de préavis n’est pas encore confirmé ; le délai n’a pas commencé. Vous pouvez exporter vos données.' : ('Une suppression administrative est prévue à partir du ' + (A2($author$project$Contrat$chaine, 'echeance_a', preavis) + '. Vous conservez la lecture et l’export pendant le préavis. Pour contester ou demander de l’aide, utilisez le contact de la notice.')))
						])) : $mdgriffith$elm_ui$Element$none;
			}()
			]);
	});
var $author$project$Gestion$Choisir = function (a) {
	return {$: 2, a: a};
};
var $author$project$Gestion$Nouveau = {$: 3};
var $author$project$Gestion$Page = function (a) {
	return {$: 1, a: a};
};
var $author$project$Gestion$Revoquer = {$: 6};
var $author$project$Gestion$Saisir = F2(
	function (a, b) {
		return {$: 4, a: a, b: b};
	});
var $author$project$Gestion$Sauver = {$: 5};
var $author$project$Gestion$Volet = function (a) {
	return {$: 0, a: a};
};
var $author$project$MrJam$Donnees$dateHeure = $author$project$MrJam$Donnees$saisie('datetime-local');
var $author$project$Gestion$AnnulerPreavis = {$: 9};
var $author$project$Gestion$ConfirmerPreavis = {$: 8};
var $author$project$Gestion$Preavis = {$: 7};
var $author$project$Gestion$suppression = F2(
	function (compte, confirmer) {
		var preavis = A2($author$project$Contrat$objet, 'suppression', compte);
		var actif = (!_Utils_eq(preavis, $elm$json$Json$Encode$null)) && (A2($author$project$Contrat$chaine, 'annule_a', preavis) === '');
		return A2(
			$author$project$MrJam$Documents$section,
			'Suppression avec préavis',
			actif ? _List_fromArray(
				[
					$author$project$MrJam$paragraphe(
					(A2($author$project$Contrat$chaine, 'etat_courriel', preavis) === 'accepte_relais') ? ('Courriel accepté par le relais le ' + (A2($author$project$Contrat$chaine, 'envoye_a', preavis) + ('. Suppression prévue à partir du ' + (A2($author$project$Contrat$chaine, 'echeance_a', preavis) + '. Ce statut ne prouve pas la réception en boîte.')))) : ((A2($author$project$Contrat$chaine, 'etat_courriel', preavis) === 'erreur') ? 'L’envoi du préavis a échoué et sera réessayé. Aucun délai de suppression n’a commencé.' : 'Le courriel de préavis est en attente. Aucun délai de suppression n’a commencé.')),
					$author$project$MrJam$paragraphe('La personne conserve la lecture et l’export de ses données pendant le préavis.'),
					A2($author$project$MrJam$bouton, 'Annuler la suppression prévue', $author$project$Gestion$AnnulerPreavis)
				]) : (confirmer ? _List_fromArray(
				[
					A2(
					$author$project$MrJam$avis,
					2,
					'Engager la suppression de Vision pour « ' + (A2($author$project$Contrat$chaine, 'affichage', compte) + ' » ? Un courriel prévient la personne ; elle dispose ensuite d’au moins trente jours pour exporter ses données. Vous pouvez annuler pendant ce délai. Son identité commune est conservée.')),
					A2($author$project$MrJam$boutonDestructif, 'Confirmer le préavis de trente jours', $author$project$Gestion$ConfirmerPreavis)
				]) : _List_fromArray(
				[
					$author$project$MrJam$paragraphe('Cette procédure prévient la personne par courriel et lui laisse au moins trente jours pour exporter ses données. Elle ne donne accès à aucun contenu. Le compte doit rester actif pour conserver cet accès.'),
					A2($author$project$MrJam$boutonDestructif, 'Préparer la suppression de ce compte Vision', $author$project$Gestion$Preavis)
				])));
	});
var $author$project$Gestion$vue = function (m) {
	return _List_fromArray(
		[
			A2(
			$author$project$MrJam$Documents$document,
			'Administration',
			_List_fromArray(
				[
					$author$project$MrJam$paragraphe('Vous gérez les droits et les allocations. Seuls le nombre de fiches, le nombre d’items et l’espace utilisé sont accessibles ici.'),
					$author$project$MrJam$actions(
					_List_fromArray(
						[
							A3(
							$author$project$MrJam$Documents$onglet,
							m.x === 'comptes',
							'Comptes',
							$author$project$Gestion$Volet('comptes')),
							A3(
							$author$project$MrJam$Documents$onglet,
							m.x === 'invitations',
							'Invitations',
							$author$project$Gestion$Volet('invitations'))
						])),
					(m.x === 'invitations') ? A2($author$project$MrJam$bouton, 'Créer une invitation', $author$project$Gestion$Nouveau) : $mdgriffith$elm_ui$Element$none,
					A3(
					$author$project$MrJam$Tableaux$tableau,
					(m.x === 'comptes') ? 'Utilisateurs et utilisatrices' : 'Historique des invitations',
					(m.x === 'comptes') ? _List_fromArray(
						[
							A2(
							$author$project$MrJam$Tableaux$principale,
							'Compte',
							A2(
								$elm$core$Basics$composeR,
								$author$project$Contrat$chaine('affichage'),
								$mdgriffith$elm_ui$Element$text)),
							A2(
							$author$project$MrJam$Tableaux$mesure,
							'Fiches / items',
							function (v) {
								return $mdgriffith$elm_ui$Element$text(
									$elm$core$String$fromInt(
										A2($author$project$Contrat$entier, 'fiches', v)) + (' / ' + $elm$core$String$fromInt(
										A2($author$project$Contrat$entier, 'items', v))));
							}),
							A2(
							$author$project$MrJam$Tableaux$mesure,
							'Utilisé / quota (Mo)',
							function (v) {
								return $mdgriffith$elm_ui$Element$text(
									$elm$core$String$fromFloat(
										A2($author$project$Contrat$entier, 'utilise_octets', v) / 1000000) + (' / ' + $elm$core$String$fromFloat(
										A2($author$project$Contrat$entier, 'quota_octets', v) / 1000000)));
							}),
							A2(
							$author$project$MrJam$Tableaux$colonne,
							'Droits',
							function (v) {
								return $mdgriffith$elm_ui$Element$text(
									A2($author$project$Contrat$vrai, 'administrateur', v) ? 'Administration' : 'Utilisateur / utilisatrice');
							}),
							$author$project$MrJam$Tableaux$commandes(
							function (v) {
								return A2(
									$author$project$MrJam$Documents$action,
									'Modifier',
									$author$project$Gestion$Choisir(v));
							})
						]) : _List_fromArray(
						[
							A2(
							$author$project$MrJam$Tableaux$principale,
							'Intitulé',
							A2(
								$elm$core$Basics$composeR,
								$author$project$Contrat$chaine('intitule'),
								$mdgriffith$elm_ui$Element$text)),
							A2(
							$author$project$MrJam$Tableaux$mesure,
							'Inscriptions / maximum',
							function (v) {
								return $mdgriffith$elm_ui$Element$text(
									$elm$core$String$fromInt(
										A2($author$project$Contrat$entier, 'utilise', v)) + (' / ' + $elm$core$String$fromInt(
										A2($author$project$Contrat$entier, 'maximum', v))));
							}),
							A2(
							$author$project$MrJam$Tableaux$mesure,
							'Demandes en attente',
							function (v) {
								return $mdgriffith$elm_ui$Element$text(
									$elm$core$String$fromInt(
										A2($author$project$Contrat$entier, 'en_attente', v)));
							}),
							A2(
							$author$project$MrJam$Tableaux$mesure,
							'Quota par compte (Mo)',
							function (v) {
								return $mdgriffith$elm_ui$Element$text(
									$elm$core$String$fromFloat(
										A2($author$project$Contrat$entier, 'quota_octets', v) / 1000000));
							}),
							A2(
							$author$project$MrJam$Tableaux$colonne,
							'Expiration (UTC)',
							A2(
								$elm$core$Basics$composeR,
								$author$project$Contrat$chaine('expire_a'),
								A2(
									$elm$core$Basics$composeR,
									$elm$core$String$left(16),
									A2(
										$elm$core$Basics$composeR,
										A2($elm$core$String$replace, 'T', ' '),
										$mdgriffith$elm_ui$Element$text)))),
							$author$project$MrJam$Tableaux$commandes(
							function (v) {
								return A2(
									$author$project$MrJam$Documents$action,
									'Modifier',
									$author$project$Gestion$Choisir(v));
							})
						]),
					m.aP),
					$author$project$MrJam$Documents$pagination(
					{
						a9: m.a9,
						fT: $author$project$Gestion$Page(m.a9 - 100),
						gi: $author$project$Gestion$Page(m.a9 + 100),
						gl: 100,
						a0: m.a0
					})
				])),
			function () {
			var _v0 = m.ay;
			if (_v0.$ === 1) {
				return $mdgriffith$elm_ui$Element$none;
			} else {
				var v = _v0.a;
				return A2(
					$author$project$MrJam$Documents$document,
					'Droits et limites',
					_Utils_ap(
						(m.x === 'comptes') ? _List_fromArray(
							[
								A4(
								$author$project$MrJam$selecteur,
								'Administrateur / administratrice',
								_List_fromArray(
									[
										_Utils_Tuple2('non', 'Non'),
										_Utils_Tuple2('oui', 'Oui')
									]),
								A2($author$project$Gestion$valeur, 'administrateur', m),
								$author$project$Gestion$Saisir('administrateur')),
								A4(
								$author$project$MrJam$selecteur,
								'Compte actif',
								_List_fromArray(
									[
										_Utils_Tuple2('oui', 'Oui'),
										_Utils_Tuple2('non', 'Non')
									]),
								A2($author$project$Gestion$valeur, 'actif', m),
								$author$project$Gestion$Saisir('actif'))
							]) : _List_fromArray(
							[
								A3(
								$author$project$MrJam$champ,
								'Intitulé, par exemple Instagram',
								A2($author$project$Gestion$valeur, 'intitule', m),
								$author$project$Gestion$Saisir('intitule')),
								A3(
								$author$project$MrJam$champ,
								'Nombre maximal d’inscriptions',
								A2($author$project$Gestion$valeur, 'maximum', m),
								$author$project$Gestion$Saisir('maximum')),
								A3(
								$author$project$MrJam$Donnees$dateHeure,
								'Date et heure d’expiration (UTC)',
								A2($author$project$Gestion$valeur, 'expire_a', m),
								$author$project$Gestion$Saisir('expire_a')),
								_Utils_eq(v, $elm$json$Json$Encode$null) ? $mdgriffith$elm_ui$Element$none : A4(
								$author$project$MrJam$selecteur,
								'Appliquer les quotas aux comptes déjà inscrits par ce lien',
								_List_fromArray(
									[
										_Utils_Tuple2('oui', 'Oui'),
										_Utils_Tuple2('non', 'Seulement aux prochaines inscriptions')
									]),
								A2($author$project$Gestion$valeur, 'retroactif', m),
								$author$project$Gestion$Saisir('retroactif'))
							]),
						_Utils_ap(
							_List_fromArray(
								[
									A3(
									$author$project$MrJam$champ,
									'Quota strict en Mo (1 Mo = 1 000 000 octets)',
									A2($author$project$Gestion$valeur, 'quota', m),
									$author$project$Gestion$Saisir('quota')),
									$author$project$MrJam$paragraphe('Un quota inférieur à l’espace déjà utilisé conserve les données et bloque les ajouts. L’archivage conserve l’espace.')
								]),
							_Utils_ap(
								A2(
									$elm$core$List$map,
									function (_v1) {
										var k = _v1.a;
										var titre = _v1.b;
										return A3(
											$author$project$MrJam$champ,
											titre,
											A2($author$project$Gestion$valeur, k, m),
											$author$project$Gestion$Saisir(k));
									},
									$author$project$Gestion$limites),
								_Utils_ap(
									_List_fromArray(
										[
											$author$project$MrJam$actions(
											_List_fromArray(
												[
													A2($author$project$MrJam$bouton, 'Enregistrer les limites', $author$project$Gestion$Sauver),
													((m.x === 'invitations') && (!_Utils_eq(v, $elm$json$Json$Encode$null))) ? A2($author$project$MrJam$boutonDestructif, 'Révoquer le lien', $author$project$Gestion$Revoquer) : $mdgriffith$elm_ui$Element$none
												]))
										]),
									(m.x === 'comptes') ? _List_fromArray(
										[
											A2($author$project$Gestion$suppression, v, m.aJ)
										]) : _List_Nil)))));
			}
		}(),
			(m.bh === '') ? $mdgriffith$elm_ui$Element$none : A2(
			$author$project$MrJam$Documents$section,
			'Votre lien d’invitation',
			_List_fromArray(
				[
					$author$project$MrJam$paragraphe(m.bh),
					$author$project$MrJam$texteSecondaire('Le secret du lien est affiché une seule fois. Copiez-le avant de quitter cette page. Son historique restera disponible ici.')
				]))
		]);
};
var $author$project$MrJam$Pictogrammes$Bouclier = 17;
var $author$project$MrJam$Pictogrammes$Dialogue = 15;
var $author$project$MrJam$Pictogrammes$Horloge = 9;
var $author$project$MrJam$Vitrine$texte = function (contenu) {
	return A2(
		$mdgriffith$elm_ui$Element$paragraph,
		_List_fromArray(
			[
				$mdgriffith$elm_ui$Element$width($mdgriffith$elm_ui$Element$fill),
				$mdgriffith$elm_ui$Element$spacing(8),
				$mdgriffith$elm_ui$Element$Font$size(17)
			]),
		_List_fromArray(
			[
				$mdgriffith$elm_ui$Element$text(contenu)
			]));
};
var $author$project$MrJam$Vitrine$benefices = function (contenus) {
	return A2(
		$mdgriffith$elm_ui$Element$wrappedRow,
		_List_fromArray(
			[
				$mdgriffith$elm_ui$Element$width($mdgriffith$elm_ui$Element$fill),
				$mdgriffith$elm_ui$Element$spacing(24),
				A2($mdgriffith$elm_ui$Element$paddingXY, 0, 24)
			]),
		A2(
			$elm$core$List$map,
			function (contenu) {
				return A2(
					$mdgriffith$elm_ui$Element$column,
					_List_fromArray(
						[
							$mdgriffith$elm_ui$Element$width(
							A2($mdgriffith$elm_ui$Element$minimum, 240, $mdgriffith$elm_ui$Element$fill)),
							$mdgriffith$elm_ui$Element$spacing(14),
							A2($mdgriffith$elm_ui$Element$paddingXY, 0, 10)
						]),
					_List_fromArray(
						[
							A2(
							$mdgriffith$elm_ui$Element$el,
							_List_fromArray(
								[
									$author$project$MrJam$Theme$police($author$project$MrJam$Theme$couleurs.a4)
								]),
							$author$project$MrJam$Pictogrammes$vue(contenu.cD)),
							A2(
							$mdgriffith$elm_ui$Element$paragraph,
							_List_fromArray(
								[
									$mdgriffith$elm_ui$Element$Region$heading(2),
									$mdgriffith$elm_ui$Element$Font$size(20),
									$mdgriffith$elm_ui$Element$Font$bold
								]),
							_List_fromArray(
								[
									$mdgriffith$elm_ui$Element$text(contenu.Q)
								])),
							$author$project$MrJam$Vitrine$texte(contenu.a$)
						]));
			},
			contenus));
};
var $author$project$MrJam$Pictogrammes$Loupe = 18;
var $author$project$MrJam$Pictogrammes$lien = F3(
	function (icone, libelle, url) {
		return A2(
			$mdgriffith$elm_ui$Element$link,
			_List_fromArray(
				[
					$mdgriffith$elm_ui$Element$width(
					$mdgriffith$elm_ui$Element$px(44)),
					$mdgriffith$elm_ui$Element$height(
					$mdgriffith$elm_ui$Element$px(44)),
					$mdgriffith$elm_ui$Element$htmlAttribute(
					A2($elm$html$Html$Attributes$attribute, 'aria-label', libelle)),
					$mdgriffith$elm_ui$Element$htmlAttribute(
					$elm$html$Html$Attributes$title(libelle)),
					$author$project$MrJam$Theme$police($author$project$MrJam$Theme$couleurs.c8),
					$author$project$MrJam$Theme$survolPolice($author$project$MrJam$Theme$couleurs.a4)
				]),
			{
				au: A2(
					$mdgriffith$elm_ui$Element$el,
					_List_fromArray(
						[$mdgriffith$elm_ui$Element$centerX, $mdgriffith$elm_ui$Element$centerY]),
					$author$project$MrJam$Pictogrammes$vue(icone)),
				gH: url
			});
	});
var $author$project$MrJam$Vitrine$capture = function (contenu) {
	return A2(
		$mdgriffith$elm_ui$Element$column,
		_List_fromArray(
			[
				$mdgriffith$elm_ui$Element$width($mdgriffith$elm_ui$Element$fill),
				$mdgriffith$elm_ui$Element$spacing(10)
			]),
		_List_fromArray(
			[
				A2(
				$mdgriffith$elm_ui$Element$link,
				_List_fromArray(
					[
						$mdgriffith$elm_ui$Element$width($mdgriffith$elm_ui$Element$fill),
						$mdgriffith$elm_ui$Element$htmlAttribute(
						$elm$html$Html$Attributes$title('Agrandir la capture'))
					]),
				{
					au: A2(
						$mdgriffith$elm_ui$Element$image,
						_List_fromArray(
							[
								$mdgriffith$elm_ui$Element$width($mdgriffith$elm_ui$Element$fill),
								$mdgriffith$elm_ui$Element$Border$rounded(12),
								$mdgriffith$elm_ui$Element$Border$width(1),
								$author$project$MrJam$Theme$bordure($author$project$MrJam$Theme$couleurs.fv)
							]),
						{cu: contenu.cu, dW: contenu.cE}),
					gH: contenu.cE
				}),
				A2(
				$mdgriffith$elm_ui$Element$wrappedRow,
				_List_fromArray(
					[
						$mdgriffith$elm_ui$Element$width($mdgriffith$elm_ui$Element$fill),
						$mdgriffith$elm_ui$Element$spacing(12)
					]),
				_List_fromArray(
					[
						$author$project$MrJam$texteSecondaire(contenu.dr),
						A3($author$project$MrJam$Pictogrammes$lien, 18, 'Agrandir la capture', contenu.cE)
					]))
			]));
};
var $author$project$MrJam$Vitrine$classe = function (nom) {
	return $mdgriffith$elm_ui$Element$htmlAttribute(
		$elm$html$Html$Attributes$class('mrjam-vitrine-' + nom));
};
var $author$project$MrJam$Vitrine$conclusion = F3(
	function (titre, description, actions) {
		return A2(
			$mdgriffith$elm_ui$Element$column,
			_List_fromArray(
				[
					$mdgriffith$elm_ui$Element$width($mdgriffith$elm_ui$Element$fill),
					$mdgriffith$elm_ui$Element$spacing(22),
					$mdgriffith$elm_ui$Element$padding(32),
					$author$project$MrJam$Theme$fond($author$project$MrJam$Theme$couleurs.fR),
					$mdgriffith$elm_ui$Element$Border$rounded(20),
					$author$project$MrJam$Vitrine$classe('conclusion')
				]),
			_List_fromArray(
				[
					A2(
					$mdgriffith$elm_ui$Element$paragraph,
					_List_fromArray(
						[
							$mdgriffith$elm_ui$Element$width($mdgriffith$elm_ui$Element$fill),
							$mdgriffith$elm_ui$Element$Region$heading(2),
							$mdgriffith$elm_ui$Element$Font$size(32),
							$mdgriffith$elm_ui$Element$Font$bold
						]),
					_List_fromArray(
						[
							$mdgriffith$elm_ui$Element$text(titre)
						])),
					$author$project$MrJam$Vitrine$texte(description),
					A2(
					$mdgriffith$elm_ui$Element$wrappedRow,
					_List_fromArray(
						[
							$mdgriffith$elm_ui$Element$width($mdgriffith$elm_ui$Element$fill),
							$mdgriffith$elm_ui$Element$spacing(18)
						]),
					actions)
				]));
	});
var $elm$html$Html$details = _VirtualDom_node('details');
var $mdgriffith$elm_ui$Internal$Model$NoStaticStyleSheet = 1;
var $mdgriffith$elm_ui$Internal$Model$RenderModeOption = function (a) {
	return {$: 2, a: a};
};
var $mdgriffith$elm_ui$Element$noStaticStyleSheet = $mdgriffith$elm_ui$Internal$Model$RenderModeOption(1);
var $elm$html$Html$summary = _VirtualDom_node('summary');
var $author$project$MrJam$Vitrine$details = F2(
	function (titre, contenu) {
		return A2(
			$mdgriffith$elm_ui$Element$el,
			_List_fromArray(
				[
					$mdgriffith$elm_ui$Element$width($mdgriffith$elm_ui$Element$fill)
				]),
			$mdgriffith$elm_ui$Element$html(
				A2(
					$elm$html$Html$details,
					_List_fromArray(
						[
							$elm$html$Html$Attributes$class('mrjam-vitrine-details')
						]),
					_List_fromArray(
						[
							A2(
							$elm$html$Html$summary,
							_List_Nil,
							_List_fromArray(
								[
									$elm$html$Html$text(titre)
								])),
							A3(
							$mdgriffith$elm_ui$Element$layoutWith,
							{
								dD: _List_fromArray(
									[$mdgriffith$elm_ui$Element$noStaticStyleSheet])
							},
							_List_Nil,
							A2(
								$mdgriffith$elm_ui$Element$column,
								_List_fromArray(
									[
										$mdgriffith$elm_ui$Element$width($mdgriffith$elm_ui$Element$fill),
										$mdgriffith$elm_ui$Element$spacing(18),
										A2($mdgriffith$elm_ui$Element$paddingXY, 0, 20),
										$mdgriffith$elm_ui$Element$Font$family(
										_List_fromArray(
											[
												$mdgriffith$elm_ui$Element$Font$typeface('Inter'),
												$mdgriffith$elm_ui$Element$Font$sansSerif
											])),
										$mdgriffith$elm_ui$Element$Font$size(16),
										$author$project$MrJam$Theme$police($author$project$MrJam$Theme$couleurs.c8)
									]),
								contenu))
						]))));
	});
var $author$project$MrJam$Vitrine$illustration = function (contenu) {
	return A2(
		$mdgriffith$elm_ui$Element$column,
		_List_fromArray(
			[
				$mdgriffith$elm_ui$Element$width($mdgriffith$elm_ui$Element$fill),
				$mdgriffith$elm_ui$Element$spacing(12)
			]),
		_List_fromArray(
			[
				A2(
				$mdgriffith$elm_ui$Element$image,
				_List_fromArray(
					[
						$mdgriffith$elm_ui$Element$width($mdgriffith$elm_ui$Element$fill),
						$mdgriffith$elm_ui$Element$Border$rounded(12),
						$mdgriffith$elm_ui$Element$Border$width(1),
						$author$project$MrJam$Theme$bordure($author$project$MrJam$Theme$couleurs.fv),
						$author$project$MrJam$Vitrine$classe('capture')
					]),
				{cu: contenu.cu, dW: contenu.cE}),
				$author$project$MrJam$texteSecondaire(contenu.dr)
			]));
};
var $author$project$Visuels$espacement = $author$project$MrJam$Vitrine$illustration(
	{cu: 'Exemple d’intervalles qui doublent : 7 jours puis 14 puis 28.', cE: 'assets/mrjam/vision/espacement.svg', dr: 'Exemple fictif. Vos intervalles dépendent de vos réponses et de vos réglages.'});
var $author$project$MrJam$Vitrine$etapes = function (contenus) {
	return A2(
		$mdgriffith$elm_ui$Element$wrappedRow,
		_List_fromArray(
			[
				$mdgriffith$elm_ui$Element$width($mdgriffith$elm_ui$Element$fill),
				$mdgriffith$elm_ui$Element$spacing(28)
			]),
		A2(
			$elm$core$List$indexedMap,
			F2(
				function (numero, contenu) {
					return A2(
						$mdgriffith$elm_ui$Element$column,
						_List_fromArray(
							[
								$mdgriffith$elm_ui$Element$width(
								A2($mdgriffith$elm_ui$Element$minimum, 240, $mdgriffith$elm_ui$Element$fill)),
								$mdgriffith$elm_ui$Element$spacing(12)
							]),
						_List_fromArray(
							[
								A2(
								$mdgriffith$elm_ui$Element$el,
								_List_fromArray(
									[
										$author$project$MrJam$Theme$police($author$project$MrJam$Theme$couleurs.a4),
										$mdgriffith$elm_ui$Element$Font$size(32),
										$mdgriffith$elm_ui$Element$Font$bold
									]),
								$mdgriffith$elm_ui$Element$text(
									'0' + $elm$core$String$fromInt(numero + 1))),
								A2(
								$mdgriffith$elm_ui$Element$paragraph,
								_List_fromArray(
									[
										$mdgriffith$elm_ui$Element$Region$heading(3),
										$mdgriffith$elm_ui$Element$Font$size(22),
										$mdgriffith$elm_ui$Element$Font$bold
									]),
								_List_fromArray(
									[
										$mdgriffith$elm_ui$Element$text(contenu.Q)
									])),
								$author$project$MrJam$Vitrine$texte(contenu.a$)
							]));
				}),
			contenus));
};
var $mdgriffith$elm_ui$Internal$Flag$letterSpacing = $mdgriffith$elm_ui$Internal$Flag$flag(16);
var $mdgriffith$elm_ui$Element$Font$letterSpacing = function (offset) {
	return A2(
		$mdgriffith$elm_ui$Internal$Model$StyleClass,
		$mdgriffith$elm_ui$Internal$Flag$letterSpacing,
		A3(
			$mdgriffith$elm_ui$Internal$Model$Single,
			'ls-' + $mdgriffith$elm_ui$Internal$Model$floatClass(offset),
			'letter-spacing',
			$elm$core$String$fromFloat(offset) + 'px'));
};
var $author$project$MrJam$Vitrine$etiquette = function (contenu) {
	return A2(
		$mdgriffith$elm_ui$Element$paragraph,
		_List_fromArray(
			[
				$mdgriffith$elm_ui$Element$Font$size(12),
				$mdgriffith$elm_ui$Element$Font$letterSpacing(1.5),
				$mdgriffith$elm_ui$Element$Font$bold,
				$author$project$MrJam$Theme$police($author$project$MrJam$Theme$couleurs.a4)
			]),
		_List_fromArray(
			[
				$mdgriffith$elm_ui$Element$text(contenu)
			]));
};
var $author$project$MrJam$Vitrine$hero = F2(
	function (contenu, actions) {
		return A2(
			$mdgriffith$elm_ui$Element$wrappedRow,
			_List_fromArray(
				[
					$mdgriffith$elm_ui$Element$width($mdgriffith$elm_ui$Element$fill),
					$mdgriffith$elm_ui$Element$spacing(40),
					A2($mdgriffith$elm_ui$Element$paddingXY, 0, 32),
					$author$project$MrJam$Vitrine$classe('hero')
				]),
			_List_fromArray(
				[
					A2(
					$mdgriffith$elm_ui$Element$column,
					_List_fromArray(
						[
							$mdgriffith$elm_ui$Element$width(
							A2($mdgriffith$elm_ui$Element$minimum, 260, $mdgriffith$elm_ui$Element$fill)),
							$mdgriffith$elm_ui$Element$spacing(26),
							$mdgriffith$elm_ui$Element$centerY
						]),
					_List_fromArray(
						[
							$author$project$MrJam$Vitrine$etiquette(contenu.fX),
							A2(
							$mdgriffith$elm_ui$Element$paragraph,
							_List_fromArray(
								[
									$mdgriffith$elm_ui$Element$width($mdgriffith$elm_ui$Element$fill),
									$mdgriffith$elm_ui$Element$Region$heading(1),
									$mdgriffith$elm_ui$Element$Font$size(58),
									$mdgriffith$elm_ui$Element$Font$bold,
									$author$project$MrJam$Vitrine$classe('titre')
								]),
							_List_fromArray(
								[
									$mdgriffith$elm_ui$Element$text(contenu.Q)
								])),
							$author$project$MrJam$Vitrine$texte(contenu.a$),
							A2(
							$mdgriffith$elm_ui$Element$wrappedRow,
							_List_fromArray(
								[
									$mdgriffith$elm_ui$Element$spacing(14),
									$mdgriffith$elm_ui$Element$width($mdgriffith$elm_ui$Element$fill)
								]),
							actions)
						])),
					A2(
					$mdgriffith$elm_ui$Element$image,
					_List_fromArray(
						[
							$mdgriffith$elm_ui$Element$width(
							A2(
								$mdgriffith$elm_ui$Element$minimum,
								260,
								A2($mdgriffith$elm_ui$Element$maximum, 560, $mdgriffith$elm_ui$Element$fill))),
							$mdgriffith$elm_ui$Element$Border$rounded(28),
							$author$project$MrJam$Vitrine$classe('hero-image')
						]),
					{cu: contenu.cu, dW: contenu.cE})
				]));
	});
var $author$project$MrJam$Pictogrammes$Fleche = 14;
var $author$project$MrJam$Vitrine$navigation = F2(
	function (libelle, url) {
		return A2(
			$mdgriffith$elm_ui$Element$link,
			_List_fromArray(
				[
					A2($mdgriffith$elm_ui$Element$paddingXY, 20, 13),
					$mdgriffith$elm_ui$Element$Border$rounded(8),
					$author$project$MrJam$Theme$fond($author$project$MrJam$Theme$couleurs.a4),
					$author$project$MrJam$Theme$police($author$project$MrJam$Theme$couleurs.d_),
					$mdgriffith$elm_ui$Element$Font$semiBold,
					$author$project$MrJam$Theme$survol($author$project$MrJam$Theme$couleurs.ee)
				]),
			{
				au: A2(
					$mdgriffith$elm_ui$Element$row,
					_List_fromArray(
						[
							$mdgriffith$elm_ui$Element$spacing(12)
						]),
					_List_fromArray(
						[
							$mdgriffith$elm_ui$Element$text(libelle),
							$author$project$MrJam$Pictogrammes$vue(14)
						])),
				gH: url
			});
	});
var $author$project$Visuels$partage = $author$project$MrJam$Vitrine$illustration(
	{cu: 'Les fiches Capitales de l’Asie et Voyage en Arménie partagent l’item Erevan est la capitale de l’Arménie. Cet item garde une seule stabilité.', cE: 'assets/mrjam/vision/partage.svg', dr: 'Exemple fictif. Une même connaissance peut servir dans plusieurs contextes.'});
var $author$project$MrJam$Vitrine$partie = F3(
	function (repere, titre, contenu) {
		return A2(
			$mdgriffith$elm_ui$Element$column,
			_List_fromArray(
				[
					$mdgriffith$elm_ui$Element$width($mdgriffith$elm_ui$Element$fill),
					$mdgriffith$elm_ui$Element$spacing(24),
					A2($mdgriffith$elm_ui$Element$paddingXY, 0, 36),
					$author$project$MrJam$Vitrine$classe('partie')
				]),
			_Utils_ap(
				_List_fromArray(
					[
						$author$project$MrJam$Vitrine$etiquette(repere),
						A2(
						$mdgriffith$elm_ui$Element$paragraph,
						_List_fromArray(
							[
								$mdgriffith$elm_ui$Element$width(
								A2($mdgriffith$elm_ui$Element$maximum, 780, $mdgriffith$elm_ui$Element$fill)),
								$mdgriffith$elm_ui$Element$Region$heading(2),
								$mdgriffith$elm_ui$Element$Font$size(36),
								$mdgriffith$elm_ui$Element$Font$bold,
								$author$project$MrJam$Vitrine$classe('titre-secondaire')
							]),
						_List_fromArray(
							[
								$mdgriffith$elm_ui$Element$text(titre)
							]))
					]),
				contenu));
	});
var $author$project$Informations$accueil = _List_fromArray(
	[
		A2(
		$author$project$MrJam$Vitrine$hero,
		{cu: 'Une lumière verte accompagne des feuilles reliées par un chemin de souvenirs.', cE: 'assets/mrjam/vision/memoire.webp', fX: 'APPRENDRE AVEC VOTRE ASSISTANT IA', a$: 'Transformez vos conversations en connaissances qui restent. Vision organise vos révisions avec votre assistant IA. Vous gardez la liberté de vos exercices.', Q: 'Apprenez aujourd’hui. Retrouvez-le demain.'},
		_List_fromArray(
			[
				A2($author$project$MrJam$Vitrine$navigation, 'Découvrir Vision', '/docs#connexion-mcp'),
				A2($author$project$MrJam$lien, 'J’ai déjà un compte', '/connexion')
			])),
		$author$project$MrJam$Vitrine$benefices(
		_List_fromArray(
			[
				{cD: 15, a$: 'Expliquez une idée. Traduisez une phrase. Résolvez un problème. Votre assistant adapte l’exercice à votre objectif.', Q: 'Des exercices vivants'},
				{cD: 9, a$: 'Retrouvez vos connaissances après la conversation. Vision conserve leur suivi et propose les prochaines révisions.', Q: 'Un suivi qui dure'},
				{cD: 7, a$: 'Comprenez les dates proposées. Réglez votre période cible ou votre budget quotidien. Vous gardez la main.', Q: 'Votre propre rythme'}
			])),
		A3(
		$author$project$MrJam$Vitrine$partie,
		'VOS CONNAISSANCES',
		'Un savoir peut servir partout.',
		_List_fromArray(
			[
				$author$project$MrJam$Vitrine$texte('Les items contiennent ce que vous voulez retenir. Les fiches donnent un contexte et une manière de le travailler. Un même item peut servir dans plusieurs fiches sans repartir de zéro.'),
				$author$project$Visuels$partage
			])),
		A3(
		$author$project$MrJam$Vitrine$partie,
		'LE PRODUIT EN UN COUP D’ŒIL',
		'Retrouvez tout au même endroit.',
		_List_fromArray(
			[
				$author$project$MrJam$Vitrine$texte('Consultez vos fiches sur le site. Retrouvez les items à travailler et l’état de chacun. Votre assistant utilise ces mêmes connaissances pendant la révision.'),
				$author$project$MrJam$Vitrine$capture(
				{cu: 'Capture de Vision avec la fiche fictive Capitales de l’Asie et ses items. Les plages de révision apparaissent à côté des connaissances.', cE: 'assets/mrjam/vision/fiche.webp', dr: 'Capture de Vision. Toutes les connaissances affichées sont fictives.'})
			])),
		A3(
		$author$project$MrJam$Vitrine$partie,
		'DANS LA CONVERSATION',
		'Cherchez la réponse. Recevez juste l’aide utile.',
		_List_fromArray(
			[
				$author$project$MrJam$Vitrine$texte('Vous répondez avec vos mots. L’assistant signale ce qui manque puis donne un indice à la fois. Vous pouvez demander la correction ou passer. Le bilan distingue ce que vous avez retrouvé seul et ce qui a demandé de l’aide.'),
				$author$project$MrJam$Vitrine$etapes(
				_List_fromArray(
					[
						{a$: 'Votre première réponse compte. Une reformulation qui garde le bon sens est acceptée.', Q: 'Vous essayez'},
						{a$: 'Un indice vous aide à retrouver le sens. La correction arrive lorsque vous la demandez ou qu’elle devient nécessaire.', Q: 'Vous comprenez'},
						{a$: 'Vision conserve le bilan. Votre prochaine séance repart de ce suivi.', Q: 'Vous retrouvez'}
					]))
			])),
		A3(
		$author$project$MrJam$Vitrine$partie,
		'RÉPÉTITIONS ESPACÉES',
		'Revenez au bon moment pour vous.',
		_List_fromArray(
			[
				$author$project$MrJam$Vitrine$texte('Vision calcule une plage de révision pour chaque item. Les intervalles évoluent avec les évaluations. Le modèle reste simple et ses réglages sont consultables.'),
				$author$project$Visuels$espacement,
				$author$project$MrJam$Vitrine$capture(
				{cu: 'Capture de Vision avec trois items fictifs. Leur stabilité et leur état de révision sont visibles.', cE: 'assets/mrjam/vision/items.webp', dr: 'Capture de Vision. Le suivi appartient à chaque item. Les données sont fictives.'}),
				A2($author$project$MrJam$lien, 'Comprendre la planification', '/docs#planification')
			])),
		A3(
		$author$project$MrJam$Vitrine$conclusion,
		'Votre prochaine conversation peut devenir une séance.',
		'Le tutoriel vous guide pour connecter votre assistant et commencer. Un compte Vision est nécessaire. Ce service ne propose pas d’inscription publique.',
		_List_fromArray(
			[
				A2($author$project$MrJam$Vitrine$navigation, 'Connecter mon assistant', '/docs#connexion-mcp'),
				A2($author$project$MrJam$lien, 'Ouvrir mon compte', '/connexion')
			])),
		A2(
		$author$project$MrJam$Vitrine$details,
		'Pourquoi le nom Vision ?',
		_List_fromArray(
			[
				$author$project$MrJam$Vitrine$texte('Vision joue avec le mot révision. Le nom fait aussi un clin d’œil au personnage qui porte une pierre lumineuse au front. Ce projet n’a aucune affiliation officielle avec ce personnage.')
			]))
	]);
var $author$project$MrJam$lienActif = F3(
	function (actif, libelle, adresse) {
		return A3(
			$author$project$MrJam$navigationLien,
			actif ? _List_fromArray(
				[
					$mdgriffith$elm_ui$Element$htmlAttribute(
					A2($elm$html$Html$Attributes$attribute, 'aria-current', 'page')),
					$mdgriffith$elm_ui$Element$Font$semiBold
				]) : _List_Nil,
			libelle,
			adresse);
	});
var $author$project$MrJam$Pictogrammes$Copier = 13;
var $author$project$MrJam$Vitrine$chapitre = F3(
	function (identifiant, titre, contenu) {
		return A2(
			$mdgriffith$elm_ui$Element$column,
			_List_fromArray(
				[
					$mdgriffith$elm_ui$Element$width(
					A2($mdgriffith$elm_ui$Element$maximum, 900, $mdgriffith$elm_ui$Element$fill)),
					$mdgriffith$elm_ui$Element$spacing(20),
					A2($mdgriffith$elm_ui$Element$paddingXY, 0, 24),
					$mdgriffith$elm_ui$Element$htmlAttribute(
					$elm$html$Html$Attributes$id(identifiant))
				]),
			_Utils_ap(
				_List_fromArray(
					[
						A2(
						$mdgriffith$elm_ui$Element$paragraph,
						_List_fromArray(
							[
								$mdgriffith$elm_ui$Element$Region$heading(2),
								$mdgriffith$elm_ui$Element$Font$size(30),
								$mdgriffith$elm_ui$Element$Font$bold,
								$mdgriffith$elm_ui$Element$width($mdgriffith$elm_ui$Element$fill),
								$mdgriffith$elm_ui$Element$htmlAttribute(
								$elm$html$Html$Attributes$tabindex(-1))
							]),
						_List_fromArray(
							[
								$mdgriffith$elm_ui$Element$text(titre)
							]))
					]),
				contenu));
	});
var $author$project$MrJam$Vitrine$introduction = F3(
	function (repere, titre, description) {
		return A2(
			$mdgriffith$elm_ui$Element$column,
			_List_fromArray(
				[
					$mdgriffith$elm_ui$Element$width(
					A2($mdgriffith$elm_ui$Element$maximum, 760, $mdgriffith$elm_ui$Element$fill)),
					$mdgriffith$elm_ui$Element$spacing(16),
					A2($mdgriffith$elm_ui$Element$paddingXY, 0, 28)
				]),
			_List_fromArray(
				[
					$author$project$MrJam$Vitrine$etiquette(repere),
					A2(
					$mdgriffith$elm_ui$Element$paragraph,
					_List_fromArray(
						[
							$mdgriffith$elm_ui$Element$width($mdgriffith$elm_ui$Element$fill),
							$mdgriffith$elm_ui$Element$Region$heading(1),
							$mdgriffith$elm_ui$Element$Font$size(42),
							$mdgriffith$elm_ui$Element$Font$bold,
							$author$project$MrJam$Vitrine$classe('titre-secondaire')
						]),
					_List_fromArray(
						[
							$mdgriffith$elm_ui$Element$text(titre)
						])),
					$author$project$MrJam$Vitrine$texte(description)
				]));
	});
var $elm$html$Html$Attributes$target = $elm$html$Html$Attributes$stringProperty('target');
var $author$project$MrJam$lienExterne = F2(
	function (libelle, adresse) {
		return A3(
			$author$project$MrJam$navigationLien,
			_List_fromArray(
				[
					$mdgriffith$elm_ui$Element$htmlAttribute(
					$elm$html$Html$Attributes$target('_blank')),
					$mdgriffith$elm_ui$Element$htmlAttribute(
					$elm$html$Html$Attributes$rel('noopener noreferrer')),
					$mdgriffith$elm_ui$Element$htmlAttribute(
					A2($elm$html$Html$Attributes$attribute, 'aria-label', libelle + ' — nouvel onglet'))
				]),
			libelle,
			adresse);
	});
var $author$project$Tutoriel$sections = _List_fromArray(
	[
		{
		cS: 'Choisissez le chapitre de votre assistant. Terminez la connexion puis demandez-lui de lire vos réglages. Vérifiez qu’il obtient une réponse de Vision.',
		cp: '',
		cr: 'Un assistant connecté peut lire vos connaissances et réaliser les changements que vous lui demandez. Vérifiez les confirmations proposées. Vous pouvez retirer un accès depuis la page « Accès des assistants ». Déconnecter le site ne retire pas ces accès. Si la connexion échoue, vérifiez l’adresse copiée et les options disponibles dans votre assistant. Ne partagez jamais votre mot de passe ou un token dans une conversation.',
		cv: _List_fromArray(
			[
				{a$: 'Vous avez besoin d’un compte Vision. Ce service ne propose pas d’inscription publique. Utilisez les identifiants qui vous ont été remis.', Q: 'Préparez votre compte'},
				{a$: 'Utilisez l’adresse affichée ci-dessus. Elle appartient à cette installation de Vision. Ne remplacez pas cette adresse par celle de la page d’accueil.', Q: 'Copiez l’adresse MCP'},
				{a$: 'Ajoutez Vision dans votre assistant puis connectez-vous à votre compte Vision dans la page qui s’ouvre. Lisez la demande d’accès avant de l’accepter.', Q: 'Connectez et autorisez'}
			]),
		cw: 'Une fois la connexion activée, demandez : « Lis le tutoriel de Vision et aide-moi à commencer. » Vous pouvez aussi demander : « Quels sont mes réglages ? » Cette consultation ne change rien.',
		db: 'MCP permet à votre assistant de retrouver vos fiches et de conserver le résultat de vos révisions dans Vision. Vous continuez à discuter dans votre assistant habituel. Le site Vision vous permet de consulter et d’organiser vos connaissances.',
		at: 'connexion-mcp',
		cM: _List_Nil,
		Q: 'Connecter votre assistant'
	},
		{
		cS: 'Commencez par une consultation. Demandez une modification seulement lorsque vous avez vérifié que le bon compte Vision est connecté.',
		cp: '',
		cr: 'Les intitulés et les offres peuvent évoluer. Si Create ou Developer mode manque, consultez le guide officiel et les droits de votre espace. La création de l’application ne suffit pas : elle doit être sélectionnée dans la conversation.',
		cv: _List_fromArray(
			[
				{a$: 'Dans Settings → Apps → Advanced Settings, activez Developer mode si votre compte le permet. Dans un espace géré, l’administrateur peut devoir autoriser cette option. Pour Business, seuls les administrateurs ou propriétaires peuvent créer l’application.', Q: 'Ouvrez les réglages des applications'},
				{a$: 'Dans Apps, choisissez Create. Indiquez le nom « Vision » et l’adresse MCP affichée au début de ce tutoriel. Choisissez OAuth pour l’authentification. N’ajoutez pas de secret client si aucun n’est demandé par votre installation.', Q: 'Créez l’application Vision'},
				{a$: 'Lancez Scan Tools. Connectez-vous à Vision lorsque la page d’autorisation s’ouvre puis acceptez l’accès souhaité. Attendez la découverte des outils et terminez avec Create.', Q: 'Connectez votre compte'},
				{a$: 'Ouvrez une nouvelle conversation. Sélectionnez Vision dans le menu des outils ou des applications. Un administrateur peut devoir publier l’application dans votre espace.', Q: 'Activez Vision dans votre conversation'}
			]),
		cw: 'Après avoir activé Vision dans une nouvelle conversation, demandez : « Donne-moi mes réglages de Vision. » Ensuite : « Montre-moi les fiches à réviser. » Si les outils ne sont pas disponibles, vérifiez que Vision est bien activé pour cette conversation.',
		db: 'Utilisez ChatGPT sur le web. Votre offre et les règles de votre espace doivent autoriser les applications MCP personnalisées. Les actions d’écriture sont actuellement proposées aux espaces Business, Enterprise et Edu. Certains comptes ne disposent que de la lecture. Une séance de Vision nécessite aussi l’enregistrement de son bilan.',
		at: 'connexion-chatgpt',
		cM: _List_fromArray(
			[
				{Q: 'Guide officiel OpenAI', gH: 'https://help.openai.com/en/articles/12584461-developer-mode-and-mcp-apps-in-chatgpt'}
			]),
		Q: 'ChatGPT · OpenAI'
	},
		{
		cS: 'Consultez une fiche avant de lancer votre première révision. Vous pouvez revenir au site Vision pour retrouver la même fiche.',
		cp: '',
		cr: 'Les options disponibles dépendent de votre offre et des droits de votre espace. Si vous utilisez Claude Code, sa configuration est distincte de celle des connecteurs de Claude. Ne recopiez pas votre mot de passe dans le chat.',
		cv: _List_fromArray(
			[
				{a$: 'Dans Customize → Connectors, choisissez + Add puis Add custom connector. Dans un espace géré, le connecteur est d’abord ajouté dans Organization settings → Connectors.', Q: 'Ajoutez un connecteur'},
				{a$: 'Nommez le connecteur « Vision ». Collez l’adresse MCP affichée au début du tutoriel puis choisissez Continue.', Q: 'Indiquez le nom et l’adresse'},
				{a$: 'Conservez une connexion avec authentification. Si le choix OAuth client apparaît, utilisez Register automatically. Terminez l’ajout puis connectez-vous à votre compte Vision dans la page d’autorisation.', Q: 'Connectez-vous à Vision'},
				{a$: 'Dans la conversation, ouvrez le bouton + puis Connectors. Activez Vision. Pour un connecteur ajouté par votre organisation, utilisez d’abord Connect dans sa liste.', Q: 'Activez le connecteur'}
			]),
		cw: 'Une fois le connecteur activé, demandez : « Retrouve mes fiches dans Vision. » Claude doit utiliser les outils de Vision pour obtenir votre contenu.',
		db: 'Claude est l’assistant d’Anthropic. La connexion passe par les connecteurs de votre compte Claude. Dans un espace Team ou Enterprise, une personne autorisée doit d’abord ajouter Vision pour l’organisation.',
		at: 'connexion-claude',
		cM: _List_fromArray(
			[
				{Q: 'Guide officiel Claude', gH: 'https://support.claude.com/en/articles/11175166-get-started-with-custom-connectors-using-remote-mcp'}
			]),
		Q: 'Claude · Anthropic'
	},
		{
		cS: 'Après l’autorisation, utilisez /mcp pour vérifier les outils puis demandez : « Lis mes réglages dans Vision. »',
		cp: '',
		cr: 'Si vous travaillez sur une machine sans navigateur accessible, cette procédure de connexion interactive peut échouer. Gemini CLI propose aussi des en-têtes d’authentification. Réservez cette option aux clients qui ne peuvent pas utiliser la connexion de compte ; le chapitre « Autres clients » explique les tokens.',
		cv: _List_fromArray(
			[
				{a$: 'Suivez le guide officiel de Gemini CLI si vous ne l’utilisez pas encore. Connectez votre compte Google selon ce guide.', Q: 'Installez et ouvrez Gemini CLI'},
				{a$: 'Exécutez la commande ci-dessous. L’option --scope user rend Vision disponible dans vos différentes conversations locales.', Q: 'Ajoutez Vision'},
				{a$: 'Lancez Gemini CLI puis /mcp auth vision. Connectez-vous à Vision dans la page qui s’ouvre et acceptez l’accès. Revenez au terminal.', Q: 'Autorisez la connexion'}
			]),
		cw: 'Dans un terminal, ajoutez le service :\n\n```sh\ngemini mcp add --transport http --scope user vision \"{{url_mcp}}\"\n```\n\nLancez ensuite Gemini CLI. Dans la conversation, utilisez :\n\n```text\n/mcp auth vision\n```',
		db: 'Ce parcours concerne Gemini CLI sur votre ordinateur. Il ne décrit pas une connexion dans le site web Gemini. Vous devez pouvoir ouvrir un navigateur sur cet ordinateur pour autoriser votre compte Vision.',
		at: 'connexion-gemini',
		cM: _List_fromArray(
			[
				{Q: 'Guide officiel Gemini CLI', gH: 'https://geminicli.com/docs/tools/mcp-server/'}
			]),
		Q: 'Gemini CLI · Google'
	},
		{
		cS: 'Demandez : « Lis le tutoriel de Vision sur les fiches et les items. » Cette lecture ne crée pas de fiche.',
		cp: '',
		cr: '',
		cv: _List_fromArray(
			[
				{a$: 'Dans votre terminal, exécutez la première commande ci-dessous avec l’adresse de cette installation.', Q: 'Ajoutez le service'},
				{a$: 'Exécutez la seconde commande. Connectez-vous dans la page qui s’ouvre et acceptez l’accès.', Q: 'Connectez votre compte Vision'},
				{a$: 'Lancez Codex puis /mcp. Vision doit apparaître parmi les services disponibles.', Q: 'Vérifiez les outils'}
			]),
		cw: 'Ajoutez Vision puis lancez la connexion :\n\n```sh\ncodex mcp add vision --url \"{{url_mcp}}\"\ncodex mcp login vision\n```\n\nDans Codex, /mcp affiche les services actifs.',
		db: 'Codex CLI peut utiliser un service MCP distant. Sa configuration est distincte de celle des applications dans ChatGPT. Installez Codex CLI selon le guide OpenAI avant de suivre ces étapes.',
		at: 'connexion-codex',
		cM: _List_fromArray(
			[
				{Q: 'Guide officiel Codex', gH: 'https://developers.openai.com/codex/mcp/'}
			]),
		Q: 'Codex CLI · OpenAI'
	},
		{
		cS: 'Donnez un nom différent à chaque accès. Vous pourrez ainsi retirer l’accès d’un assistant sans couper les autres.',
		cp: '',
		cr: 'Un client qui ne propose ni connexion de compte ni en-tête d’authentification ne peut pas utiliser ce parcours. Évitez les accès partagés entre plusieurs personnes. Vision conserve la séparation entre votre compte et celui des autres utilisateurs.',
		cv: _List_fromArray(
			[
				{a$: 'Connectez-vous à Vision puis ouvrez la page « Accès des assistants ». Vous pouvez aussi la retrouver par le lien « Tokens d’accès » dans le menu de l’application.', Q: 'Ouvrez les accès des assistants'},
				{a$: 'Choisissez un nom qui permet de reconnaître le client. Le secret n’est montré qu’à la création. Copiez-le dans le champ privé prévu par le client.', Q: 'Créez un token seulement si nécessaire'},
				{a$: 'Renseignez l’adresse MCP affichée au début du tutoriel et l’en-tête Authorization demandé par le client. Aucun token ne doit apparaître dans l’URL.', Q: 'Configurez le client'},
				{a$: 'Sur la page des accès, vous pouvez révoquer chaque token et chaque application autorisée. Les tokens expirent au bout d’un an.', Q: 'Gardez le contrôle'}
			]),
		cw: 'Un client qui demande un en-tête d’accès reçoit la valeur « Bearer » suivie du token. Ce token est un secret. Saisissez-le uniquement dans les réglages privés du client. Ne le mettez pas dans l’adresse MCP, une capture ou un message à l’assistant.',
		db: 'Utilisez un client qui accepte les services MCP distants en HTTP. Si le client propose OAuth, privilégiez la connexion à votre compte Vision. Sinon, il doit permettre un en-tête Authorization pour utiliser un token personnel.',
		at: 'connexion-autres',
		cM: _List_Nil,
		Q: 'Autres clients et tokens'
	},
		{cS: 'Où placer la consigne « Interroge-moi dans les deux sens » ? Dans la fiche. L’item décrit le savoir que vous voulez retenir.', cp: '', cr: 'La stabilité appartient aux items. Une fiche ne possède pas de stabilité mémorielle. Ses consignes, son objectif et ses observations vous aident à donner du sens aux exercices.', cv: _List_Nil, cw: 'Démonstration fictive.\n\nItem : « Erevan est la capitale de l’Arménie. »\n\nLa fiche « Capitales de l’Asie » demande de retrouver la capitale à partir du pays et le pays à partir de la capitale. Ces consignes appartiennent à la fiche.\n\nLa fiche « Voyage en Arménie » utilise le même item pour préparer un itinéraire. Il n’y a toujours qu’un seul suivi de cette connaissance.', db: 'Un item contient une seule connaissance. Il doit être compréhensible seul. Une fiche rassemble des items et explique comment les travailler. Vous pouvez retrouver le même item dans plusieurs fiches. Sa stabilité et ses observations restent communes.', at: 'fiches-items', cM: _List_Nil, Q: 'Fiches et items'},
		{cS: 'Imaginez une situation où vous voulez emprunter un objet. Formulez une phrase avec borrow. Le but est-il le sens du mot ou aussi une structure grammaticale ? Précisez-le avant l’exercice.', cp: '', cr: 'Une reformulation correcte est acceptée. Vous n’avez pas à réciter la fiche mot pour mot. Si le contenu de référence est ambigu, l’assistant doit le signaler au lieu de vous pénaliser.', cv: _List_Nil, cw: 'Démonstration fictive.\n\nItem : « Le verbe anglais borrow signifie emprunter. On reçoit quelque chose pour un temps puis on le rend. »\n\nLa fiche « Emprunter au quotidien » demande d’utiliser borrow dans une phrase nouvelle. L’assistant peut vous faire demander un livre puis un parapluie. Il peut aussi travailler le contraste avec lend, qui signifie prêter, si cet objectif est prévu dans la fiche.', db: 'Votre assistant peut varier les exercices. Il garde le même objectif. Pour apprendre un mot, vous pouvez créer des phrases nouvelles et l’utiliser dans plusieurs situations. Il ne doit pas ajouter une difficulté qui ne fait pas partie de l’objectif annoncé.', at: 'langues', cM: _List_Nil, Q: 'Des exercices en contexte'},
		{cS: 'Votre planning est trop chargé ? Consultez vos réglages avant de les modifier. Une période cible plus longue peut espacer les révisions. Un budget quotidien peut mieux répondre à une limite de temps.', cp: 'Le calcul utilisé est I = T × 10^((S − P + G)/10). I est en jours. S est la stabilité de l’item. P est la priorité de la fiche. G est le décalage automatique lié au budget. La plage va de I × 10^(−0,1) à I × 10^(0,1) après le dernier rappel daté retenu.\n\nAvec T = 90, S = −10, P = 0 et G = 0, I = 9 jours. Une priorité P = +3 divise l’intervalle par environ 1,995. Un nouvel item commence à S = −15. Son intervalle central serait d’environ 2,846 jours dans ces conditions. Sans rappel daté, aucune date de révision n’est calculée.\n\nUne évaluation applique S ← S + Q. Q est un ajustement contextualisé. Les aides et les rappels rapprochés limitent les gains. Une réponse trouvée après correction ne devient pas une réussite autonome.\n\nL’adaptation au budget ajoute au plus +1 dB par semaine. G reste entre 0 et 30. La largeur relative demeure ±1 dB.', cr: 'Augmenter la période cible allonge les intervalles. Modifier la priorité déplace les dates d’une fiche. La largeur relative des plages reste fixée : elle n’est pas un réglage personnel. Leur largeur en jours augmente avec l’intervalle.\n\nLe budget représente un nombre d’items distincts par jour. S’il est dépassé, Vision peut espacer progressivement les révisions avec un décalage automatique G. Ce décalage ne change pas la stabilité. Sans budget, cette adaptation est désactivée.\n\nLes durées se comparent naturellement par multiplication. Entre 7, 14 et 28 jours, chaque étape double. Les décibels représentent ces rapports par des écarts additifs. Un doublement correspond à environ +3,010 dB. Vision utilise des entiers ; +3 est donc une approximation.\n\nLe modèle est volontairement simple. Ce n’est pas une loi universelle de l’oubli. Il ne donne pas une probabilité de rappel scientifiquement garantie.', cv: _List_Nil, cw: 'La période cible T vaut 90 jours par défaut. Cela ne signifie pas que chaque item revient tous les 90 jours. Avec les réglages par défaut, un item à S = −10 a un intervalle central de 9 jours. Sa plage de révision va d’environ 7,149 à 11,330 jours après son dernier rappel daté. À S = 0, l’intervalle central est de 90 jours. À S = +10, il est de 900 jours.', db: 'La stabilité S décrit le suivi d’un item. Une évaluation peut la faire évoluer. Une stabilité plus élevée conduit à un intervalle plus long avec les mêmes réglages. La priorité d’une fiche peut rapprocher ses révisions. Vision propose une plage de dates autour de l’intervalle calculé.', at: 'planification', cM: _List_Nil, Q: 'Trouver votre rythme'},
		{cS: 'Demandez : « Quelles fiches dois-je réviser ? » Choisissez-en une puis : « Commence une séance courte. » À la fin, demandez le bilan et la clôture.', cp: '', cr: 'Le bilan conserve la réponse initiale, l’erreur ou le manque, les aides données et le résultat final. Une réussite après un indice ou une correction reste une réussite aidée. Elle n’est pas enregistrée comme un rappel autonome.\n\nUne séance de moins de 60 minutes peut dater les rappels sans date au moment de la clôture. Cette approximation est visible. Vous pouvez modifier ce seuil dans vos réglages. Une séance de exactement 60 minutes est déjà une séance longue avec le seuil par défaut.\n\nSi vous reprenez plusieurs jours après, l’assistant utilise seulement les dates réellement disponibles. Vous pouvez préciser les dates par groupes : « Les trois premières lundi, les deux suivantes mercredi. » Une date approximative est identifiée comme telle. Une date civile avec fuseau est retenue à midi si elle reste dans les bornes de la séance. Les rappels peuvent aussi rester non datés. Ils ne déplacent pas la référence mémorielle.\n\nPour une séance longue, utiliser la clôture comme date de rappel exige votre accord explicite. Une date incohérente est refusée. L’assistant ne doit pas en inventer une autre. Une rectification garde les dates historiques. Rejouer une clôture ne donne pas un second gain.\n\nDemandez « Reprends ma séance ». Vision retrouve son contexte enregistré. Il ne connaît pas automatiquement les messages d’une autre conversation.', cv: _List_Nil, cw: 'Démonstration fictive.\n\nVous donnez une réponse incomplète. L’assistant dit : « Il manque un élément. » Il vous invite d’abord à chercher. Il peut ensuite donner un indice sur le sens. Il ne dit pas « Oui, c’est bon » si une partie nécessaire manque.\n\nSi la réponse est fausse, il le dit clairement. Si elle est ambiguë, il demande une précision. Il propose les aides une par une. Vous pouvez passer, demander la correction ou arrêter.', db: 'Demandez les révisions dues puis choisissez une fiche. Votre assistant lit la référence et les observations avant de poser une question. Il évalue votre première réponse sans aide. Il accepte une reformulation qui garde le même sens.', at: 'seances', cM: _List_Nil, Q: 'Votre première révision'},
		{cS: 'Demandez vos réglages. Choisissez ensuite un changement précis si vous en avez besoin. Lire l’aide ou ce tutoriel n’autorise aucune modification.', cp: '', cr: 'Le site permet de créer et modifier les fiches, de rattacher les items et d’archiver. L’archivage est réversible. Avant de créer un item, Vision recherche les connaissances proches pour vous aider à réutiliser un item existant.\n\nUne observation conserve un constat. Elle ne change pas la stabilité. Une évaluation ponctuelle demande un ajustement explicite. Les dates inconnues et les items non évalués restent signalés. Le dernier rappel est distinct du dernier enregistrement.\n\nUn lien privé ne rend pas une fiche publique. La personne qui l’ouvre doit se connecter avec un compte qui a accès à cette fiche.', cv: _List_Nil, cw: 'Quelques demandes utiles :\n\n- « Donne-moi le lien de cette fiche. »\n- « Affiche cette fiche en Markdown avec tous ses items. »\n- « Fais le bilan de mes fiches puis approfondis celle-ci. »\n- « Ajoute une observation sur cette confusion. »\n- « Rattache cet item à ma fiche de voyage. »\n- « Mets mon seuil de séance courte à 45 minutes. »', db: 'Vous pouvez chercher une fiche, lire son contenu et obtenir son lien privé. Vous pouvez demander ses items et leurs stabilités ou un compte rendu complet en Markdown. Les fiches volumineuses sont lues par pages ; votre assistant doit parcourir toutes les pages avant d’annoncer un export complet.', at: 'actions', cM: _List_Nil, Q: 'Consulter et organiser'}
	]);
var $author$project$Informations$tutoriel = F3(
	function (contexte, copier, choisir) {
		var resoudre = A2($elm$core$String$replace, '{{url_mcp}}', contexte.bQ);
		var identifiant = A2($elm$core$String$dropLeft, 1, contexte.cV);
		var section = A2(
			$elm$core$Maybe$withDefault,
			A2(
				$elm$core$Maybe$withDefault,
				{cS: '', cp: '', cr: '', cv: _List_Nil, cw: '', db: '', at: '', cM: _List_Nil, Q: ''},
				$elm$core$List$head($author$project$Tutoriel$sections)),
			$elm$core$List$head(
				A2(
					$elm$core$List$filter,
					function (s) {
						return _Utils_eq(s.at, identifiant);
					},
					$author$project$Tutoriel$sections)));
		var connexion = A2($elm$core$String$startsWith, 'connexion-', section.at);
		return _List_fromArray(
			[
				A3($author$project$MrJam$Vitrine$introduction, 'LE TUTORIEL', 'Découvrir Vision', 'Connectez votre assistant. Découvrez ensuite comment organiser vos connaissances et commencer vos révisions. Ce tutoriel ne crée aucune donnée personnelle.'),
				A4(
				$author$project$MrJam$selecteur,
				'Chapitre',
				A2(
					$elm$core$List$map,
					function (s) {
						return _Utils_Tuple2(s.at, s.Q);
					},
					$author$project$Tutoriel$sections),
				section.at,
				choisir),
				connexion ? A2(
				$author$project$MrJam$Documents$section,
				'L’adresse MCP de votre Vision',
				$elm$core$String$isEmpty(contexte.bQ) ? _List_fromArray(
					[
						A2($author$project$MrJam$avis, 0, 'L’adresse de connexion n’est pas disponible pour le moment. Rechargez cette page avant de configurer votre assistant.')
					]) : _List_fromArray(
					[
						$author$project$MrJam$Lecture$markdown('```text\n' + (contexte.bQ + '\n```')),
						$author$project$MrJam$actions(
						_List_fromArray(
							[
								A3($author$project$MrJam$Pictogrammes$action, 13, 'Copier l’adresse MCP', copier),
								$elm$core$String$isEmpty(contexte.cy) ? $mdgriffith$elm_ui$Element$none : A2($author$project$MrJam$lien, 'Accès des assistants', contexte.cy)
							])),
						contexte.c2 ? A2($author$project$MrJam$avis, 1, 'Adresse copiée.') : $mdgriffith$elm_ui$Element$none
					])) : $mdgriffith$elm_ui$Element$none,
				A3(
				$author$project$MrJam$Vitrine$chapitre,
				section.at,
				section.Q,
				_Utils_ap(
					_List_fromArray(
						[
							$author$project$MrJam$Vitrine$texte(section.db),
							$elm$core$List$isEmpty(section.cv) ? $mdgriffith$elm_ui$Element$none : $author$project$MrJam$Vitrine$etapes(section.cv),
							(A2($elm$core$String$contains, '{{url_mcp}}', section.cw) && $elm$core$String$isEmpty(contexte.bQ)) ? A2($author$project$MrJam$avis, 0, 'Les commandes de connexion apparaîtront lorsque l’adresse MCP sera disponible.') : $author$project$MrJam$Lecture$markdown(
							resoudre(section.cw)),
							(section.at === 'fiches-items') ? $author$project$Visuels$partage : $mdgriffith$elm_ui$Element$none,
							(section.at === 'planification') ? $author$project$Visuels$espacement : $mdgriffith$elm_ui$Element$none,
							A2(
							$author$project$MrJam$Documents$section,
							'À essayer',
							_List_fromArray(
								[
									$author$project$MrJam$Vitrine$texte(section.cS)
								])),
							$elm$core$String$isEmpty(section.cr) ? $mdgriffith$elm_ui$Element$none : A2(
							$author$project$MrJam$Vitrine$details,
							'En savoir plus',
							_List_fromArray(
								[
									$author$project$MrJam$Lecture$markdown(section.cr)
								])),
							$elm$core$String$isEmpty(section.cp) ? $mdgriffith$elm_ui$Element$none : A2(
							$author$project$MrJam$Vitrine$details,
							'Voir le calcul et les exemples',
							_List_fromArray(
								[
									$author$project$MrJam$Lecture$markdown(section.cp)
								]))
						]),
					$elm$core$List$isEmpty(section.cM) ? _List_Nil : _List_fromArray(
						[
							$author$project$MrJam$texteSecondaire('Procédure vérifiée le 6 octobre 2026. Les options de votre assistant peuvent évoluer.'),
							$author$project$MrJam$actions(
							A2(
								$elm$core$List$map,
								function (s) {
									return A2($author$project$MrJam$lienExterne, s.Q, s.gH);
								},
								section.cM))
						]))),
				$author$project$MrJam$actions(
				_List_fromArray(
					[
						A2($author$project$MrJam$lien, 'Connecter mon assistant', '/docs#connexion-mcp'),
						A2($author$project$MrJam$lien, 'Comprendre les fiches', '/docs#fiches-items'),
						A2($author$project$MrJam$lien, 'Ouvrir Vision', '/connexion')
					]))
			]);
	});
var $author$project$Confidentialite$vue = function (notice) {
	return _List_fromArray(
		[
			A3(
			$author$project$MrJam$Vitrine$introduction,
			'VOS DONNÉES',
			'Confidentialité',
			'Notice ' + A2($author$project$Contrat$chaine, 'version', notice)),
			A2(
			$author$project$MrJam$Documents$section,
			'Responsable et contact',
			(A2($author$project$Contrat$chaine, 'responsable', notice) === '') ? _List_fromArray(
				[
					A2($author$project$MrJam$avis, 0, 'Les inscriptions publiques restent fermées tant que l’identité du responsable, son contact et les conditions d’hébergement ne sont pas renseignés et vérifiés.')
				]) : _List_fromArray(
				[
					$author$project$MrJam$paragraphe(
					'Responsable : ' + A2($author$project$Contrat$chaine, 'responsable', notice)),
					$author$project$MrJam$paragraphe(
					'Contact pour vos droits : ' + A2($author$project$Contrat$chaine, 'contact', notice)),
					$author$project$MrJam$paragraphe(
					'Pays d’hébergement : ' + A2($author$project$Contrat$chaine, 'pays_hebergement', notice))
				])),
			A2(
			$author$project$MrJam$Documents$section,
			'Données personnelles sensibles',
			_List_fromArray(
				[
					A2($author$project$MrJam$avis, 2, 'N’utilisez pas Vision pour stocker des données personnelles sensibles concernant une personne identifiable, telles que des informations médicales, des convictions religieuses ou des données relatives à la vie sexuelle. Les fiches d’apprentissage générales sur ces sujets restent possibles.')
				])),
			A2(
			$author$project$MrJam$Documents$section,
			'Données et finalités',
			_List_fromArray(
				[
					$author$project$MrJam$paragraphe('Le compte commun conserve un identifiant technique, les informations nécessaires à la connexion et à la récupération du compte, ainsi que ses moyens de sécurité. Vision conserve vos fiches, items, liens, notes, évaluations et bilans pour organiser vos révisions. Les invitations conservent leur intitulé, leurs plafonds, leur origine et leurs utilisations.'),
					$author$project$MrJam$paragraphe('La fourniture du service repose sur l’exécution de la relation de service (article 6.1.b du RGPD). Les mesures nécessaires de sécurité et leurs journaux reposent sur l’intérêt légitime à protéger le service (article 6.1.f). Aucun usage publicitaire, aucune vente de données et aucun suivi commercial ne sont prévus.'),
					$author$project$MrJam$paragraphe('Vision aide aux révisions. Ses calculs ne prennent aucune décision juridique ni décision produisant un effet significatif sur votre situation.')
				])),
			A2(
			$author$project$MrJam$Documents$section,
			'Admission et personnes mineures',
			_List_fromArray(
				[
					$author$project$MrJam$paragraphe('L’accès exige une invitation, la lecture de cette notice et une adresse de courrier vérifiée. Le formulaire recueille le pays de résidence, une tranche d’âge déclarée et, si nécessaire, le courriel d’un représentant légal. Il ne demande ni date de naissance, ni nom légal, ni pièce d’identité.'),
					$author$project$MrJam$paragraphe('En France, avant quinze ans, un représentant légal doit confirmer son accord, puis sa qualité doit être vérifiée manuellement avant admission. Ce seuil n’est pas un âge minimum universel. Au lancement, les demandes de mineurs et celles provenant d’autres pays sont examinées manuellement selon les règles applicables. Une confirmation de courriel ne suffit pas à prouver l’autorité parentale.'),
					$author$project$MrJam$paragraphe('L’exploitation chargée de l’admission peut consulter ces informations de vérification ; l’administration Vision n’y a pas accès. Une demande inachevée expire après sept jours et son dossier est retiré après trente jours supplémentaires. Les courriels et pseudonymes du dossier d’admission aboutie sont retirés après trente jours ; le pays, la tranche déclarée, la version de notice, les confirmations et la référence minimale du contrôle restent pendant la relation de service. Le compte commun conserve son adresse de connexion.'),
					$author$project$MrJam$paragraphe('Si tu es mineur : Vision garde tes fiches et tes progrès pour t’aider à apprendre. Les administrateurs de Vision ne peuvent pas lire tes fiches. Les personnes qui exploitent techniquement le serveur peuvent cependant avoir accès aux textes. N’écris pas d’informations personnelles sensibles et vérifie avec un adulte ce que ton assistant peut transmettre. Tu peux récupérer et supprimer tes données. Pour poser une question, demander une correction ou retirer un accord parental, utilise le contact indiqué en haut de cette notice.')
				])),
			A2(
			$author$project$MrJam$Documents$section,
			'Qui peut accéder à quoi',
			_List_fromArray(
				[
					$author$project$MrJam$paragraphe('Vous accédez aux données de votre compte. Un administrateur ou une administratrice Vision voit les droits, les quotas, les nombres de fiches et d’items et l’espace utilisé. Ce statut ne donne aucun accès aux titres, textes, notes, historiques, exports ou vecteurs d’autres personnes. Il ne permet pas de prendre leur identité ni de réinitialiser leur mot de passe.'),
					$author$project$MrJam$paragraphe('Le serveur traite les contenus en clair pour fournir le service. L’exploitant technique et l’hébergeur peuvent être en mesure d’y accéder avec des droits techniques privilégiés. Cette version ne propose pas de chiffrement de bout en bout. Cet accès technique doit être restreint et encadré par les engagements du responsable et de ses sous-traitants.')
				])),
			A2(
			$author$project$MrJam$Documents$section,
			'Chiffrement et assistants',
			_List_fromArray(
				[
					$author$project$MrJam$paragraphe('Les communications avec le site utilisent HTTPS/TLS. Les mots de passe du nouveau fournisseur d’identité sont hachés avec Argon2id ; ils ne sont pas chiffrés de façon réversible. Les secrets servant aux codes de double authentification doivent être récupérables par le fournisseur d’identité et accessibles à son exploitation technique privilégiée. Les contenus de la base de données ne sont pas chiffrés individuellement par Vision. Le chiffrement des sauvegardes et leur stockage doivent être constatés lors de l’activation ; HTTPS ne chiffre pas les fichiers du serveur.'),
					$author$project$MrJam$paragraphe('Les représentations sémantiques sont calculées localement sur le serveur. Vision n’envoie pas de contenu à un fournisseur de LLM de sa propre initiative. Un assistant que vous autorisez par MCP peut lire et modifier vos données. Son fournisseur peut traiter ces données selon ses propres conditions, éventuellement hors de l’Espace économique européen. Vérifiez ces conditions avant de connecter l’assistant.'),
					A2($author$project$MrJam$lien, 'Retirer les autorisations d’un assistant', '/auth/mcp')
				])),
			A2(
			$author$project$MrJam$Documents$section,
			'Conservation et effacement',
			_List_fromArray(
				[
					$author$project$MrJam$paragraphe('Vos connaissances et observations sont conservées jusqu’à votre demande d’effacement. L’archivage conserve leur contenu. Les preuves de création, caches de requête et traces de recherche sont bornés ; les caches de requête sont nettoyés après 35 jours, les épisodes temporaires après 90 jours, les journaux métier après 180 jours. Certains bilans et observations restent dans votre historique personnel.'),
					$author$project$MrJam$paragraphe('Une session expire après 12 heures, ou après 2 heures sans activité. Les états de connexion OIDC expirent après 10 minutes. Les événements applicatifs de sécurité et d’administration sont limités à trente jours ; le journal HTTP conserve son plafond distinct de quatorze jours. Ces journaux ne doivent contenir ni contenus pédagogiques ni secrets. Les liens d’invitation expirent à la date indiquée et peuvent être révoqués.'),
					$author$project$MrJam$paragraphe(
					'L’effacement retire les données de la base active. ' + (((A2($author$project$Contrat$entier, 'sauvegardes_jours', notice) > 0) ? ('Les copies locales nouvelles expirent sous ' + ($elm$core$String$fromInt(
						A2($author$project$Contrat$entier, 'sauvegardes_jours', notice)) + ' jours. La conservation et la purge des anciennes copies, snapshots et copies externes doivent être documentées séparément. ')) : 'Le délai d’expiration des sauvegardes doit être vérifié avant l’ouverture des inscriptions. ') + 'Un registre d’effacement sans contenu est prévu pour empêcher leur réapparition lors d’une restauration. Les procédures de restauration doivent appliquer ce registre avant de rouvrir le service.'))
				])),
			A2(
			$author$project$MrJam$Documents$section,
			'Courriels et préavis',
			_List_fromArray(
				[
					$author$project$MrJam$paragraphe('Proton fournit les courriels transactionnels nécessaires à la récupération du compte et aux procédures de suppression. TLS protège la soumission SMTP ; ces courriels ne sont pas tous chiffrés de bout en bout. Le registre minimal d’effacement est chiffré avant son envoi à la boîte de l’exploitant et ne contient aucune connaissance.'),
					$author$project$MrJam$paragraphe('Selon sa politique de confidentialité, Proton Mail stocke les messages sur des serveurs en Suisse, Allemagne ou Norvège et peut traiter les métadonnées d’envoi : adresses, dates, objet et nom de pièce jointe. Cette localisation est distincte de celle du serveur de Vision affichée en haut de la notice. Le pays exact d’une boîte n’est pas déduit de cette liste. La Suisse bénéficie d’une décision européenne d’adéquation ; les contrats et éventuels autres transferts doivent également être vérifiés.'),
					A2($author$project$MrJam$lienExterne, 'Politique de confidentialité de Proton Mail', 'https://proton.me/mail/privacy-policy'),
					$author$project$MrJam$paragraphe('Une suppression engagée par l’administration laisse au moins trente jours après l’envoi du préavis pour exporter les données. Elle peut être annulée avant le début de l’effacement. Un échec d’envoi ne démarre pas le délai. L’acceptation par le relais SMTP ne prouve ni la réception en boîte ni la lecture du message. Aucune suppression automatique pour inactivité n’est prévue.')
				])),
			A2(
			$author$project$MrJam$Documents$section,
			'Vos droits',
			_List_fromArray(
				[
					$author$project$MrJam$paragraphe('Vous pouvez accéder à vos données, les rectifier, les exporter et effacer votre compte Vision depuis Mon compte. Vous pouvez demander la limitation d’un traitement, vous opposer à un traitement fondé sur l’intérêt légitime, et exercer vos droits sur l’identité commune auprès du contact indiqué. Une réponse est apportée dans le délai réglementaire d’un mois, sous réserve des prolongations motivées prévues par le RGPD.'),
					A2($author$project$MrJam$lien, 'Mon compte, export et effacement', '/#compte'),
					$author$project$MrJam$paragraphe('La fermeture autonome du compte MrJ.am se fait dans Sécurité et identité du compte commun, après une nouvelle authentification et une confirmation explicite. Elle supprime l’identité, ses moyens de connexion et les données des outils qui l’ont adoptée (actuellement Vision). Un registre chiffré ne conserve que les identifiants techniques, la date et les outils concernés pour empêcher leur réintroduction lors d’une restauration. Un envoi en attente peut retarder la suppression ; la demande confirmée reprend automatiquement.'),
					A2($author$project$MrJam$lienExterne, 'Déposer une réclamation auprès de la CNIL', 'https://www.cnil.fr/fr/adresser-une-plainte')
				])),
			A2(
			$author$project$MrJam$Documents$section,
			'Service et licence',
			_List_fromArray(
				[
					$author$project$MrJam$paragraphe('Le code de Vision est proposé sous licence AGPL version 3 ou ultérieure. L’accès à cette instance est un service bénévole, limité par les capacités et quotas annoncés. Conservez vos propres exports : une panne peut entraîner une indisponibilité ou une perte de données, notamment entre deux copies externes mensuelles. Les droits et obligations impératifs applicables à l’hébergement et à vos données personnelles demeurent applicables.'),
					A2($author$project$MrJam$lien, 'Télécharger le code source de cette version de Vision', '/code-source/vision.tar.gz'),
					A2($author$project$MrJam$lien, 'Télécharger le code des services d’identité et de gestion MrJ.am', '/code-source/services-mrjam.tar.gz')
				])),
			A2(
			$author$project$MrJam$Documents$section,
			'Cookies nécessaires',
			_List_fromArray(
				[
					$author$project$MrJam$paragraphe('Les cookies servent uniquement à l’authentification, à la sécurité de la connexion et au maintien de la session. Les sessions de chaque outil restent attachées à son hôte. Aucun traceur publicitaire ni mesure d’audience tiers n’est ajouté par Vision. Les brouillons restent en mémoire dans la page et ne sont pas sauvegardés dans localStorage ou sessionStorage.')
				]))
		]);
};
var $author$project$Informations$vue = F4(
	function (contexte, copier, choisir, menu) {
		return A4(
			$author$project$MrJam$Documents$espaceMarque,
			'Vision',
			_List_fromArray(
				[
					A3($author$project$MrJam$lienActif, contexte.bV === '/docs', 'Tutoriel', '/docs'),
					A3($author$project$MrJam$Pictogrammes$lien, 17, 'Confidentialité', '/privacy'),
					A3(
					$author$project$MrJam$Documents$menu,
					contexte.du,
					menu,
					_List_fromArray(
						[
							A2(
							$author$project$MrJam$lien,
							contexte.cs ? 'Mon compte' : 'Se connecter',
							contexte.cs ? '/#compte' : '/connexion'),
							A2($author$project$MrJam$lien, 'Confidentialité', '/privacy')
						]))
				]),
			$elm$core$Maybe$Nothing,
			(contexte.bV === '/privacy') ? $author$project$Confidentialite$vue(contexte.dB) : ((contexte.bV === '/') ? $author$project$Informations$accueil : A3($author$project$Informations$tutoriel, contexte, copier, choisir)));
	});
var $author$project$Main$Confirmer = {$: 23};
var $author$project$Main$Rester = {$: 24};
var $author$project$Main$SaisirEffacement = function (a) {
	return {$: 6, a: a};
};
var $elm$virtual_dom$VirtualDom$Custom = function (a) {
	return {$: 3, a: a};
};
var $elm$html$Html$Events$custom = F2(
	function (event, decoder) {
		return A2(
			$elm$virtual_dom$VirtualDom$on,
			event,
			$elm$virtual_dom$VirtualDom$Custom(decoder));
	});
var $author$project$MrJam$Theme$panneau = _Utils_ap(
	$author$project$MrJam$Theme$disposition,
	_List_fromArray(
		[
			$mdgriffith$elm_ui$Element$padding(16),
			$author$project$MrJam$Theme$fond($author$project$MrJam$Theme$couleurs.d_),
			$author$project$MrJam$Theme$bordure($author$project$MrJam$Theme$couleurs.fv),
			$mdgriffith$elm_ui$Element$Border$width(1),
			$mdgriffith$elm_ui$Element$Border$rounded(6)
		]));
var $author$project$MrJam$carte = $mdgriffith$elm_ui$Element$column($author$project$MrJam$Theme$panneau);
var $author$project$MrJam$sousTitre = function (libelle) {
	return A2(
		$mdgriffith$elm_ui$Element$paragraph,
		_List_fromArray(
			[
				$mdgriffith$elm_ui$Element$Region$heading(2),
				$mdgriffith$elm_ui$Element$Font$size(24),
				$mdgriffith$elm_ui$Element$Font$bold
			]),
		_List_fromArray(
			[
				$mdgriffith$elm_ui$Element$text(libelle)
			]));
};
var $author$project$MrJam$section = F2(
	function (libelle, contenu) {
		return $author$project$MrJam$carte(
			A2(
				$elm$core$List$cons,
				$author$project$MrJam$sousTitre(libelle),
				contenu));
	});
var $author$project$MrJam$Fenetres$modale = F4(
	function (identifiant, titre, fermer, contenu) {
		return A3(
			$elm$html$Html$node,
			'dialog',
			_List_fromArray(
				[
					$elm$html$Html$Attributes$id(identifiant),
					A2($elm$html$Html$Attributes$attribute, 'data-mrjam-modale', ''),
					A2($elm$html$Html$Attributes$attribute, 'aria-label', titre),
					A2($elm$html$Html$Attributes$style, 'border', '0'),
					A2($elm$html$Html$Attributes$style, 'padding', '0'),
					A2($elm$html$Html$Attributes$style, 'border-radius', '6px'),
					A2($elm$html$Html$Attributes$style, 'max-width', 'min(680px, calc(100vw - 24px))'),
					A2($elm$html$Html$Attributes$style, 'width', '680px'),
					A2($elm$html$Html$Attributes$style, 'max-height', 'calc(100dvh - 24px)'),
					A2(
					$elm$html$Html$Events$preventDefaultOn,
					'cancel',
					$elm$json$Json$Decode$succeed(
						_Utils_Tuple2(fermer, true))),
					A2(
					$elm$html$Html$Events$custom,
					'keydown',
					A2(
						$elm$json$Json$Decode$andThen,
						function (touche) {
							return (touche === 'Escape') ? $elm$json$Json$Decode$succeed(
								{H: fermer, fU: true, gf: true}) : $elm$json$Json$Decode$fail('Autre touche');
						},
						A2($elm$json$Json$Decode$field, 'key', $elm$json$Json$Decode$string)))
				]),
			_List_fromArray(
				[
					A3(
					$mdgriffith$elm_ui$Element$layoutWith,
					{
						dD: _List_fromArray(
							[$mdgriffith$elm_ui$Element$noStaticStyleSheet, $author$project$MrJam$Theme$focus])
					},
					_List_fromArray(
						[
							$mdgriffith$elm_ui$Element$htmlAttribute(
							A2($elm$html$Html$Attributes$style, 'min-height', '0'))
						]),
					A2($author$project$MrJam$section, titre, contenu))
				]));
	});
var $author$project$Main$vueConfirmation = function (m) {
	var _v0 = m.aI;
	if (_v0.$ === 1) {
		return $elm$core$Maybe$Nothing;
	} else {
		var c = _v0.a;
		return $elm$core$Maybe$Just(
			A4(
				$author$project$MrJam$Fenetres$modale,
				'confirmation',
				'Confirmer',
				$author$project$Main$Rester,
				_List_fromArray(
					[
						$author$project$MrJam$paragraphe(
						function () {
							switch (c.$) {
								case 3:
									return 'Cet effacement supprime définitivement vos données Vision. Exportez-les auparavant. Votre identité commune et vos autres outils sont conservés.';
								case 4:
									return 'L’archivage est réversible et conserve les connaissances et leurs liens.';
								case 5:
									return 'Détacher conserve cet item et ses autres rattachements.';
								default:
									return 'Quitter abandonnera la saisie non enregistrée.';
							}
						}()),
						_Utils_eq(c, $author$project$Main$EffacerVision) ? A3($author$project$MrJam$champ, 'Saisissez EFFACER VISION', m.aK, $author$project$Main$SaisirEffacement) : $mdgriffith$elm_ui$Element$none,
						$author$project$MrJam$actions(
						_List_fromArray(
							[
								A2($author$project$MrJam$boutonDestructif, 'Confirmer', $author$project$Main$Confirmer),
								A2($author$project$MrJam$boutonSecondaire, 'Continuer', $author$project$Main$Rester)
							]))
					])));
	}
};
var $author$project$Main$vue = function (m) {
	return $author$project$Informations$publique(m.f.bV) ? A4(
		$author$project$Informations$vue,
		{
			cV: m.f.cV,
			bV: m.f.bV,
			cs: !_Utils_eq(m.E, $elm$core$Maybe$Nothing),
			c2: m.c2,
			cy: m.cy,
			du: m.du,
			dB: m.dB,
			bQ: m.bQ
		},
		$author$project$Main$CopierAdresse,
		$author$project$Main$ChoisirChapitre,
		$author$project$Main$Menu) : ((_Utils_eq(m.E, $elm$core$Maybe$Nothing) && ((!m.an) && ((m.f.bV === '/') && _Utils_eq(
		$author$project$Contrat$depuisAdresse(m.f.cV),
		$elm$core$Maybe$Nothing)))) ? A4(
		$author$project$Informations$vue,
		{
			cV: '',
			bV: '/',
			cs: !_Utils_eq(m.E, $elm$core$Maybe$Nothing),
			c2: m.c2,
			cy: m.cy,
			du: m.du,
			dB: m.dB,
			bQ: m.bQ
		},
		$author$project$Main$CopierAdresse,
		$author$project$Main$ChoisirChapitre,
		$author$project$Main$Menu) : ((m.f.bV === '/admission') ? A4(
		$author$project$MrJam$Documents$espaceMarque,
		'Vision',
		_List_fromArray(
			[
				A2($author$project$MrJam$lien, 'Confidentialité', '/privacy')
			]),
		$elm$core$Maybe$Nothing,
		_List_fromArray(
			[
				A2(
				$author$project$MrJam$Documents$document,
				'Confirmer la demande',
				_List_fromArray(
					[
						A2(
						$elm$core$Maybe$withDefault,
						$mdgriffith$elm_ui$Element$none,
						A2(
							$elm$core$Maybe$map,
							function (_v0) {
								var niveau = _v0.a;
								var texte = _v0.b;
								return A2($author$project$MrJam$avis, niveau, texte);
							},
							m.H)),
						(A2($author$project$Contrat$chaine, 'type', m.aB) === 'parent') ? $author$project$MrJam$paragraphe('Vous confirmez autoriser le jeune concerné à utiliser Vision et être son représentant légal. Cette confirmation sera suivie d’une vérification manuelle avant admission. Vous pouvez retirer cet accord auprès de RGPD@MrJ.am.') : $author$project$MrJam$paragraphe('Confirmez uniquement une demande que vous avez faite avec votre adresse de courrier.'),
						A2($author$project$MrJam$lien, 'Lire la notice de confidentialité', '/privacy'),
						(A2($author$project$Contrat$chaine, 'type', m.aB) !== '') ? $author$project$MrJam$pile(
						_List_fromArray(
							[
								A3(
								$author$project$MrJam$caseACocher,
								(A2($author$project$Contrat$chaine, 'type', m.aB) === 'parent') ? 'J’ai lu la notice, je suis le représentant légal et j’autorise cet usage.' : 'Je confirme mon adresse et ma demande d’accès.',
								m.a5,
								$author$project$Main$AccordAdmission),
								A2($author$project$MrJam$bouton, 'Enregistrer ma confirmation', $author$project$Main$ConfirmerLienAdmission)
							])) : A2($author$project$MrJam$avis, 0, 'Ce lien n’est plus disponible, ou sa vérification est en cours.')
					]))
			])) : ((m.f.bV === '/invitation') ? A4(
		$author$project$MrJam$Documents$espaceMarque,
		'Vision',
		_List_fromArray(
			[
				A2($author$project$MrJam$lien, 'Confidentialité', '/privacy'),
				A2($author$project$MrJam$lien, 'Se connecter', '/connexion')
			]),
		$elm$core$Maybe$Nothing,
		_List_fromArray(
			[
				A2(
				$author$project$MrJam$Documents$document,
				'Invitation à Vision',
				_List_fromArray(
					[
						A2(
						$elm$core$Maybe$withDefault,
						$mdgriffith$elm_ui$Element$none,
						A2(
							$elm$core$Maybe$map,
							function (_v1) {
								var niveau = _v1.a;
								var texte = _v1.b;
								return A2($author$project$MrJam$avis, niveau, texte);
							},
							m.H)),
						$author$project$MrJam$paragraphe('Votre compte MrJ.am sera commun aux outils auxquels vous aurez accès. Chaque outil garde ses propres données et droits.'),
						A2($author$project$Contrat$vrai, 'disponible', m.W) ? $author$project$MrJam$paragraphe(
						'Ce lien accorde ' + ($elm$core$String$fromFloat(
							A2($author$project$Contrat$entier, 'quota_octets', m.W) / 1000000) + (' Mo par compte, au maximum ' + ($elm$core$String$fromInt(
							A2(
								$author$project$Contrat$entier,
								'fiches',
								A2($author$project$Contrat$objet, 'limites', m.W))) + (' fiches et ' + ($elm$core$String$fromInt(
							A2(
								$author$project$Contrat$entier,
								'items_par_fiche',
								A2($author$project$Contrat$objet, 'limites', m.W))) + (' items par fiche. Un item est limité à ' + ($elm$core$String$fromInt(
							A2(
								$author$project$Contrat$entier,
								'mots_item',
								A2($author$project$Contrat$objet, 'limites', m.W))) + (' mots et ' + ($elm$core$String$fromInt(
							A2(
								$author$project$Contrat$entier,
								'octets_item',
								A2($author$project$Contrat$objet, 'limites', m.W))) + ' octets. Ces quotas peuvent être modifiés ; une baisse conserve vos données et bloque les ajouts au-delà du plafond.')))))))))) : A2($author$project$MrJam$avis, 0, 'Ce lien n’est pas disponible, ou sa vérification est en cours.'),
						A2($author$project$MrJam$lien, 'Lire la notice de confidentialité', '/privacy'),
						A2(
						$author$project$MrJam$mapper,
						$author$project$Main$AdmissionMessage,
						$author$project$Admission$vue(m.aA)),
						A3($author$project$MrJam$caseACocher, 'J’ai pris connaissance de la notice de confidentialité.', m.bE, $author$project$Main$AccepterNotice),
						(A2($author$project$Contrat$vrai, 'inscriptions_ouvertes', m.dB) && A2($author$project$Contrat$vrai, 'disponible', m.W)) ? A2($author$project$MrJam$bouton, 'Demander mon accès', $author$project$Main$Inscription) : A2($author$project$MrJam$avis, 0, 'Les inscriptions sont actuellement fermées.')
					]))
			])) : A4(
		$author$project$MrJam$Documents$espaceMarque,
		'Vision',
		_Utils_eq(m.E, $elm$core$Maybe$Nothing) ? _List_Nil : _List_fromArray(
			[
				A3(
				$author$project$MrJam$Documents$onglet,
				!m.a,
				'Fiches',
				$author$project$Main$Naviguer(
					$author$project$Main$Changer(0))),
				A3(
				$author$project$MrJam$Documents$onglet,
				m.a === 1,
				'Items',
				$author$project$Main$Naviguer(
					$author$project$Main$Changer(1))),
				A3($author$project$MrJam$Pictogrammes$action, 7, 'Réglages', $author$project$Main$Reglages),
				A3(
				$author$project$MrJam$Documents$menu,
				m.du,
				$author$project$Main$Menu,
				_List_fromArray(
					[
						A2($author$project$MrJam$Documents$action, 'Mon compte et mes limites', $author$project$Main$MonCompte),
						A2(
						$elm$core$Maybe$withDefault,
						false,
						A2(
							$elm$core$Maybe$map,
							function ($) {
								return $.cU;
							},
							m.E)) ? A2($author$project$MrJam$Documents$action, 'Administration', $author$project$Main$Administration) : $mdgriffith$elm_ui$Element$none,
						A2($author$project$MrJam$lien, 'Tutoriel', '/docs'),
						A2($author$project$MrJam$lien, 'Tokens d’accès', '/auth/mcp'),
						A3(
						$author$project$MrJam$Pictogrammes$action,
						12,
						'Se déconnecter',
						$author$project$Main$Naviguer($author$project$Main$Quitter))
					]))
			]),
		$author$project$Main$vueConfirmation(m),
		_Utils_ap(
			A2(
				$elm$core$Maybe$withDefault,
				_List_Nil,
				A2(
					$elm$core$Maybe$map,
					function (_v2) {
						var niveau = _v2.a;
						var texte = _v2.b;
						return _List_fromArray(
							[
								A2($author$project$MrJam$avis, niveau, texte)
							]);
					},
					m.H)),
			function () {
				if (m.an) {
					return _List_fromArray(
						[
							$author$project$MrJam$texteSecondaire('Vérification de la session…')
						]);
				} else {
					var _v3 = m.E;
					if (_v3.$ === 1) {
						return _List_fromArray(
							[
								A2(
								$author$project$MrJam$Documents$document,
								'Connexion',
								(m.a6 === 'oidc') ? _List_fromArray(
									[
										$author$project$MrJam$paragraphe('Connectez-vous avec votre compte commun MrJ.am.'),
										A2($author$project$MrJam$lien, 'Se connecter', '/auth/connexion')
									]) : _List_fromArray(
									[
										A3($author$project$MrJam$champ, 'Identifiant', m.bg, $author$project$Main$Identifiant),
										A3($author$project$MrJam$motDePasse, 'Mot de passe', m.aY, $author$project$Main$Secret),
										A2($author$project$MrJam$bouton, 'Se connecter', $author$project$Main$Connexion)
									]))
							]);
					} else {
						var s = _v3.a;
						return m.aG ? A2(
							$elm$core$List$map,
							$author$project$MrJam$mapper($author$project$Main$CompteMessage),
							A4($author$project$Compte$vue, m.bB, m.aH, m.bc, m.ah)) : (m.aM ? ((!s.d3) ? _List_fromArray(
							[
								A2(
								$author$project$MrJam$Documents$document,
								'Vérification de sécurité',
								_List_fromArray(
									[
										$author$project$MrJam$paragraphe('L’administration nécessite votre mot de passe et un second facteur vérifiés il y a moins de cinq minutes. Activez la double authentification depuis votre compte commun, puis reconnectez-vous.'),
										A2($author$project$MrJam$lien, 'Sécurité de mon compte', m.aH),
										A2($author$project$MrJam$lien, 'Vérifier mon identité', '/auth/connexion?verification=renforcee&retour=%2F%23administration')
									]))
							]) : A2(
							$elm$core$List$map,
							function (e) {
								return A2($author$project$MrJam$mapper, $author$project$Main$GestionMessage, e);
							},
							$author$project$Gestion$vue(m.as))) : $author$project$Main$espace(m));
					}
				}
			}())))));
};
var $author$project$Main$main = $elm$browser$Browser$element(
	{
		fj: function (flags) {
			return (flags.bV === '/admission') ? A4(
				$author$project$Main$envoyer,
				$author$project$Main$ApercuAdmission,
				'/auth/admission/apercu',
				$elm$json$Json$Encode$object(
					_List_fromArray(
						[
							_Utils_Tuple2(
							'token',
							$elm$json$Json$Encode$string(
								A2($elm$core$String$dropLeft, 1, flags.cV)))
						])),
				$author$project$Main$initial(flags)) : ((flags.bV === '/invitation') ? A4(
				$author$project$Main$envoyer,
				$author$project$Main$ApercuInvitation,
				'/auth/invitation',
				$elm$json$Json$Encode$object(
					_List_fromArray(
						[
							_Utils_Tuple2(
							'invitation',
							$elm$json$Json$Encode$string(
								A2($elm$core$String$dropLeft, 1, flags.cV)))
						])),
				$author$project$Main$initial(flags)) : A4(
				$author$project$Main$envoyer,
				$author$project$Main$SessionInitiale,
				'/auth/session',
				$elm$json$Json$Encode$null,
				$author$project$Main$initial(flags)));
		},
		gh: $elm$core$Basics$always(
			$elm$core$Platform$Sub$batch(
				_List_fromArray(
					[
						$author$project$Main$reponse($author$project$Main$Recevoir),
						$author$project$Main$adresse($author$project$Main$Adresse),
						$author$project$Main$configuration($author$project$Main$Configuration),
						$author$project$Main$copie($author$project$Main$CopieTerminee),
						$author$project$Main$exportation($author$project$Main$ExportTermine)
					]))),
		gG: F2(
			function (msg, m) {
				var _v0 = A2($author$project$Main$actualiser, msg, m);
				var n = _v0.a;
				var cmd = _v0.b;
				return _Utils_Tuple2(
					n,
					$elm$core$Platform$Cmd$batch(
						_List_fromArray(
							[
								cmd,
								A2(
								$author$project$Main$effet,
								'proteger',
								$elm$json$Json$Encode$bool(
									n.g || (n.m || ((!_Utils_eq(n.e, $elm$core$Maybe$Nothing)) || (!_Utils_eq(n.a_, $elm$core$Maybe$Nothing))))))
							])));
			}),
		gI: $author$project$Main$vue
	});
_Platform_export({'Main':{'init':$author$project$Main$main(
	A2(
		$elm$json$Json$Decode$andThen,
		function (instant) {
			return A2(
				$elm$json$Json$Decode$andThen,
				function (cle) {
					return A2(
						$elm$json$Json$Decode$andThen,
						function (chemin) {
							return A2(
								$elm$json$Json$Decode$andThen,
								function (adresse) {
									return $elm$json$Json$Decode$succeed(
										{cV: adresse, bV: chemin, cq: cle, b8: instant});
								},
								A2($elm$json$Json$Decode$field, 'adresse', $elm$json$Json$Decode$string));
						},
						A2($elm$json$Json$Decode$field, 'chemin', $elm$json$Json$Decode$string));
				},
				A2($elm$json$Json$Decode$field, 'cle', $elm$json$Json$Decode$string));
		},
		A2($elm$json$Json$Decode$field, 'instant', $elm$json$Json$Decode$string)))(0)}});}(this));
;
/* Formats de portabilité : aucune révision dans le Markdown des connaissances. */
const ExportsVision = (() => {
  'use strict';
  function markdown(tables, selection = null) {
    const ids = selection === null ? null : new Set(selection);
    const fiches = (tables.vision_fiches || []).filter(f => ids === null || ids.has(f.id));
    if (ids && fiches.length !== ids.size) throw new Error('selection_introuvable');
    const items = new Map((tables.vision_items || []).map(i => [i.id, i]));
    const lies = new Set();
    const titre = t => String(t || 'Sans titre').replace(/[\r\n]+/g, ' ');
    const puce = i => '- **' + titre(i.titre) + '**\n' + String(i.contenu || '').split('\n').map(l => '  ' + l).join('\n');
    const lignes = ['# Mes connaissances Vision'];
    for (const fiche of fiches) {
      lignes.push('', '## ' + titre(fiche.titre), '', fiche.contenu || '');
      const liens = (tables.vision_liens || []).filter(l => l.fiche_id === fiche.id)
        .sort((a,b) => a.ordre - b.ordre || a.item_id - b.item_id);
      for (const lien of liens) {
        const item = items.get(lien.item_id);
        if (!item) throw new Error('item_manquant');
        lies.add(item.id);
        lignes.push('', puce(item));
      }
    }
    if (ids === null) {
      const seuls = [...items.values()].filter(i => !lies.has(i.id));
      if (seuls.length) lignes.push('', '## Items sans fiche', ...seuls.flatMap(i => ['', puce(i)]));
    }
    return lignes.join('\n') + '\n';
  }
  function xml(donnees) {
    const echapper = s => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
    function valeur(v) {
      if (v === null) return '<valeur type="null"/>';
      if (Array.isArray(v)) return '<valeur type="tableau">' + v.map(x => '<element>' + valeur(x) + '</element>').join('') + '</valeur>';
      if (typeof v === 'object') return '<valeur type="objet">' + Object.entries(v).map(([k,x]) => '<champ nom="' + echapper(k) + '">' + valeur(x) + '</champ>').join('') + '</valeur>';
      // XML 1.0 interdit certains contrôles : le codage base64 préserve ces textes.
      if (typeof v === 'string' && /[\x00-\x08\x0B\x0C\x0E-\x1F]/.test(v)) {
        const octets = new TextEncoder().encode(v);
        return '<valeur type="string" encodage="base64-utf8">' + btoa(Array.from(octets, c => String.fromCharCode(c)).join('')) + '</valeur>';
      }
      return '<valeur type="' + typeof v + '">' + echapper(v) + '</valeur>';
    }
    return '<?xml version="1.0" encoding="UTF-8"?>\n<vision version="1">' + valeur(donnees) + '</vision>\n';
  }
  return {markdown, xml};
})();

;
/* Transport de l'interface : aucune présentation, donnée persistée ou règle pédagogique. */
(() => {
  'use strict';
  if (location.pathname === '/docs/') history.replaceState(null, '', '/docs' + location.hash);
  const application = Elm.Main.init({node: document.getElementById('application'),
    flags: {cle: crypto.randomUUID(), instant: new Date().toISOString(), adresse: location.hash, chemin: location.pathname}});
  window.addEventListener("hashchange", () => application.ports.adresse.send(location.hash));
  const requetes = new Map();
  const chemins = new Set(['/auth/session', '/auth/login', '/auth/logout', '/auth/inscription', '/auth/invitation', '/auth/admission', '/auth/admission/apercu', '/auth/admission/confirmer',
    ...['lister_comptes','lister_invitations','modifier_compte','creer_invitation','modifier_invitation','demander_suppression','annuler_suppression'].map(n => `/api/gestion/${n}`),
    '/api/web/effacer_compte', '/api/web/exporter_compte',
    ...['rechercher', 'lire', 'preparer_creation_item', 'preparer_revision', 'enregistrer_fiche', 'enregistrer_item',
      'lire_limites', 'lire_politique', 'lier_item', 'evaluer_items', 'enregistrer_contexte', 'regler_politique'].map(n => `/api/web/${n}`)]);
  let protege = false;
  fetch('/auth/configuration', {credentials: 'omit', cache: 'no-store', redirect: 'error'})
    .then(r => r.ok ? r.json() : {}).then(auth => application.ports.configuration.send({auth}))
    .catch(() => {});
  if (['/docs', '/docs/'].includes(location.pathname)) {
    // Cette lecture publique ne consulte ni la session ni les données du compte.
    fetch('/mcp-config.json', {credentials: 'omit', cache: 'no-store', redirect: 'error'})
      .then(r => r.ok ? r.json() : {}).then(c => application.ports.configuration.send(c))
      .catch(() => application.ports.configuration.send({}));
  }

  application.ports.requete.subscribe(async demande => {
    const numero = demande.numero;
    const controle = new AbortController();
    requetes.set(numero, controle);
    const minuterie = setTimeout(() => controle.abort(), 30000);
    let statut = 0;
    let corps = {error: 'transport_indisponible'};
    try {
      if (!chemins.has(demande.chemin)
          || demande.methode !== (demande.chemin === '/auth/session' ? 'GET' : 'POST')) {
        throw new Error('contrat_invalide');
      }
      if (demande.chemin.startsWith('/api/web/') && !demande.csrf) throw new Error('csrf_required');
      const entetes = {Accept: 'application/json'};
      if (demande.methode === 'POST') entetes['Content-Type'] = 'application/json';
      if (demande.csrf) entetes['X-CSRF-Token'] = demande.csrf;
      const resultat = await fetch(demande.chemin, {
        method: demande.methode, credentials: 'same-origin', cache: 'no-store',
        redirect: 'error', headers: entetes, signal: controle.signal,
        body: demande.methode === 'POST' ? JSON.stringify(demande.corps) : undefined
      });
      statut = resultat.status;
      try { corps = await resultat.json(); }
      catch { corps = {error: 'reponse_inattendue'}; if (resultat.ok) statut = 502; }
    } catch (erreur) {
      if (['date_invalide', 'csrf_required', 'contrat_invalide'].includes(erreur.message)) {
        statut = 400;
        corps = {error: erreur.message};
      }
    } finally {
      clearTimeout(minuterie);
      // Une expiration/déconnexion retire les requêtes, y compris leurs réponses tardives.
      if (requetes.delete(numero)) application.ports.reponse.send({numero, statut, corps});
    }
  });

  application.ports.effets.subscribe(({nom, valeur}) => {
    if (nom === 'redirection') {
      const cible = new URL(valeur, location.origin);
      if (cible.origin === location.origin && cible.pathname === '/') location.assign(cible.href);
      else if (cible.origin === 'https://log.mrj.am' && cible.pathname === '/realms/mrjam/protocol/openid-connect/auth') location.assign(cible.href);
    }
    if (nom === 'exporter') exporter(valeur);
    if (nom === 'adresse') history.replaceState(null, '', location.pathname + location.search + valeur);
    if (nom === 'proteger') protege = valeur === true;
    if (nom === 'annulerRequetes') {
      for (const controle of requetes.values()) controle.abort();
      requetes.clear();
    }
    if (nom === 'copier') {
      if (typeof valeur === 'string' && /^https?:\/\//.test(valeur) && navigator.clipboard) {
        navigator.clipboard.writeText(valeur).then(() => application.ports.copie.send(true))
          .catch(() => application.ports.copie.send(false));
      } else application.ports.copie.send(false);
    }
    if (nom === 'focus') {
      requestAnimationFrame(() => requestAnimationFrame(() => {
        const zone = document.getElementById(valeur);
        // Ne pas voler le focus si la personne a déjà commencé sa saisie.
        if (!zone || zone.contains(document.activeElement)) return;
        const cible = ['connexion', 'edition', 'correction'].includes(valeur)
          ? zone.querySelector('input,textarea') || zone
          : zone.querySelector('[role="heading"],h1,h2,h3') || zone;
        cible.focus();
      }));
    }
  });

  async function exporter(options) {
    const controle = new AbortController();
    requetes.set('export', controle);
    const tables = ['vision_profils','vision_fiches','vision_items','vision_liens','vision_episodes',
      'vision_journal','vision_requetes','vision_recherches','vision_contextes','vision_migrations_metier',
      'vision_seances','vision_observations','vision_embeddings','vision_preparations_items',
      'vision_memory_sheets','vision_memory_observations','vision_observation_corrections','vision_sheet_edits','vision_scheduler_settings','comptes','identites'];
    const donnees = {format: 'Vision — export personnel', date: new Date().toISOString(), tables: {}};
    let version;
    try {
      if (!options || !['json','xml','markdown'].includes(options.format) || !options.csrf) throw new Error('export_invalide');
      const aLire = options.format === 'markdown' ? ['vision_fiches','vision_items','vision_liens'] : tables;
      for (const table of aLire) {
        donnees.tables[table] = [];
        for (let debut = 0; ; debut += 100) {
          const response = await fetch('/api/web/exporter_compte', {method: 'POST',credentials: 'same-origin',
            redirect: 'error',cache: 'no-store', signal: controle.signal,
            headers: {'Content-Type':'application/json','X-CSRF-Token':options.csrf},
            body: JSON.stringify({table,debut,...(version ? {donnees_version:version} : {})})});
          if (!response.ok) throw new Error('export_refuse');
          const page = await response.json();
          if (page.erreur || !Array.isArray(page.lignes) || !Number.isSafeInteger(page.donnees_version)) throw new Error('export_refuse');
          version = page.donnees_version;
          donnees.tables[table].push(...page.lignes);
          if (!page.suite) break;
        }
      }
      const type = options.format === 'markdown' ? 'md' : options.format;
      const contenu = type === 'md' ? ExportsVision.markdown(donnees.tables,options.toutes ? null : options.fiches)
        : type === 'xml' ? ExportsVision.xml(donnees) : JSON.stringify(donnees,null,2);
      {
        const url = URL.createObjectURL(new Blob([contenu],{type:(type === 'xml' ? 'application/xml' : type === 'json' ? 'application/json' : 'text/markdown') + ';charset=utf-8'}));
        const lien = document.createElement('a');lien.href=url;lien.download=`vision-${donnees.date.slice(0,10)}.${type}`;
        lien.click();setTimeout(() => URL.revokeObjectURL(url),1000);
      }
      application.ports.exportation.send({reussi:true});
    } catch { if (!controle.signal.aborted) application.ports.exportation.send({reussi:false}); }
    finally { requetes.delete('export'); }
  }
  window.addEventListener('beforeunload', evenement => {
    if (protege) { evenement.preventDefault(); evenement.returnValue = ''; }
  });
})();


;
/* Cycle de vie du dialogue natif ; aucune donnée ni décision applicative. */
(() => {
  const ouverts = new Map();
  const synchroniser = () => {
    for (const [dialogue, cible] of ouverts) {
      if (!dialogue.isConnected) {
        ouverts.delete(dialogue);
        if (cible?.isConnected && !cible.closest('[inert]')) cible.focus();
      }
    }
    for (const dialogue of document.querySelectorAll('dialog[data-mrjam-modale]')) {
      if (!dialogue.open) {
        ouverts.set(dialogue, document.activeElement);
        dialogue.showModal();
        dialogue.addEventListener('keydown', evenement => {
          if (evenement.key !== 'Tab') return;
          const cibles = [...dialogue.querySelectorAll('button, input, textarea, select, a[href], [tabindex]')]
            .filter(cible => cible.tabIndex >= 0 && !cible.disabled && !cible.closest('[inert]') && cible.getClientRects().length);
          const premiere = cibles[0], derniere = cibles.at(-1);
          if (evenement.shiftKey && document.activeElement === premiere) {
            evenement.preventDefault(); derniere?.focus();
          } else if (!evenement.shiftKey && document.activeElement === derniere) {
            evenement.preventDefault(); premiere?.focus();
          }
        });
      }
    }
  };
  new MutationObserver(synchroniser).observe(document.body, {childList: true, subtree: true});
  synchroniser();
})();
