#!/usr/bin/env python3
import importlib.util,json,os,subprocess
from pathlib import Path
s=importlib.util.spec_from_file_location('refonte',Path(__file__).resolve().parents[1]/'scripts/refonte.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
# Données synthétiques propres à cette base isolée, sans copie de production.
m.sql("""INSERT INTO vision_memory_sheets(id,title,body,importance) OVERRIDING SYSTEM VALUE VALUES
(100000,'Capitales européennes','Objectif : deux sens.\n- Arménie → Erevan\n- Belgique → Bruxelles\n- Albanie → Tirana',3);
SELECT jsonb_build_object('ok',true);""")
m.sql("""INSERT INTO vision_memory_observations(sheet_id,outcome,note,reviewed_at)
SELECT id,'forgotten','Albanie → Tirana : oubli.','2026-01-01T10:00:00Z' FROM vision_memory_sheets WHERE title='Capitales européennes';
INSERT INTO vision_memory_observations(sheet_id,outcome,note,reviewed_at)
SELECT id,'recalled','Albanie → Tirana : rappel correct.','2026-01-01T10:10:00Z' FROM vision_memory_sheets WHERE title='Capitales européennes';
SELECT jsonb_build_object('ok',true);""")
plan=m.preparer();assert plan['rapport']['items_prevus']==3;assert plan['rapport']['sans_evaluation']==2
albanie=next(i for i in plan['fiches'][0]['items'] if 'Albanie' in i['titre'])
assert albanie['stabilite']==-17 and albanie['evalue_a'].startswith('2026-01-01T10:10')
# Une simulation ne laisse ni objets ni archivage.
r=m.appliquer('migration_test',plan,True);assert r['items_apres']==3
assert m.sql("SELECT to_jsonb(count(*)) FROM vision_items WHERE utilisateur='migration_test'")==0
r=m.appliquer('migration_test',plan);r2=m.appliquer('migration_test',plan)
assert r['items_apres']==r2['items_apres']==3 and r2['rejeu']
assert m.sql("SELECT to_jsonb(count(*)) FROM vision_migrations_metier")==1
# Le démarrage réexécute tous les SQL : une reformulation déjà publiée ne doit pas se rejouer.
m.sql("""INSERT INTO vision_fiches(utilisateur,titre,contenu)
VALUES ('migration_test','TSD — Théorie des situations didactiques','Contexte de révision.');
INSERT INTO vision_items(utilisateur,titre,contenu,objectifs,sens)
VALUES ('migration_test','Dans la théorie des situations didactiques de Guy Brousseau, le terme « milieu » désigne :','Dans la théorie des situations didactiques de Guy Brousseau, le terme « milieu » désigne : environnement. ',ARRAY['Connaissance'],ARRAY['direct']);
INSERT INTO vision_liens(utilisateur,fiche_id,item_id)
SELECT 'migration_test',f.id,i.id FROM vision_fiches f CROSS JOIN vision_items i
WHERE f.utilisateur='migration_test' AND f.titre='TSD — Théorie des situations didactiques'
AND i.utilisateur='migration_test' AND i.contenu LIKE '%milieu%';
SELECT jsonb_build_object('ok',true);""")
avant=m.sql("SELECT jsonb_build_object('contenu',contenu,'version',version) FROM vision_items WHERE utilisateur='migration_test' AND contenu LIKE '%milieu%'")
for numero in (13,14):
 subprocess.run(['psql','-X','-v','ON_ERROR_STOP=1','-f',str(Path(__file__).resolve().parents[1]/'migrations'/f"{numero:03d}_{'observations_seances' if numero==13 else 'items_contenu'}.sql")],check=True,stdout=subprocess.DEVNULL)
apres=m.sql("SELECT jsonb_build_object('contenu',contenu,'version',version) FROM vision_items WHERE utilisateur='migration_test' AND contenu LIKE '%milieu%'")
assert apres==avant,(avant,apres)
observations_apres_premier_rejeu=m.sql("SELECT to_jsonb(count(*)) FROM vision_observations")
for numero,nom in ((13,'observations_seances'),(14,'items_contenu')):
 subprocess.run(['psql','-X','-v','ON_ERROR_STOP=1','-f',str(Path(__file__).resolve().parents[1]/'migrations'/f'{numero:03d}_{nom}.sql')],check=True,stdout=subprocess.DEVNULL)
assert m.sql("SELECT to_jsonb(count(*)) FROM vision_observations")==observations_apres_premier_rejeu
m.sql("""INSERT INTO vision_observations(utilisateur,item_id,texte,source,evenement_a)
SELECT i.utilisateur,i.id,'Rappel historique identique.','evaluation_historique','2026-01-01T10:00:00Z'
FROM vision_items i CROSS JOIN generate_series(1,2)
WHERE i.utilisateur='migration_test' AND i.contenu LIKE '%milieu%';
SELECT jsonb_build_object('ok',true);""")
assert len(m.sql("""SELECT vision_observations_objet('migration_test','item',id)
FROM vision_items WHERE utilisateur='migration_test' AND contenu LIKE '%milieu%'"""))==1
assert m.sql("SELECT to_jsonb(bool_and(evalue_a IS NULL AND reference_a IS NULL)) FROM vision_items WHERE utilisateur='migration_test' AND titre NOT LIKE '%Albanie%'")
try:m.sql("UPDATE vision_memory_sheets SET body='écriture obsolète';SELECT '{}'::jsonb;")
except RuntimeError:pass
else:raise AssertionError('Le retour à un ancien client doit conserver les nouvelles écritures.')
print('Migration : simulation annulée, dates conservées, relance idempotente et ancien modèle protégé.')
assert m.sql('SELECT to_jsonb(vision_revision_contrat())')==0,'Un ancien SQL doit invalider le contrat actif'
# La réexécution volontaire des anciens fichiers ci-dessus est un test historique,
# pas le démarrage normal : rétablir le dernier contrat puis tester le vrai runner.
subprocess.run(['psql','-X','-v','ON_ERROR_STOP=1','-f',str(Path(__file__).resolve().parents[1]/'migrations/015_cloture_coherente.sql')],check=True,stdout=subprocess.DEVNULL)
assert m.sql('SELECT to_jsonb(vision_creation_contrat())')==0
subprocess.run(['psql','-X','-v','ON_ERROR_STOP=1','-f',str(Path(__file__).resolve().parents[1]/'migrations/016_creation_semantique.sql')],check=True,stdout=subprocess.DEVNULL)
assert m.sql('SELECT to_jsonb(vision_creation_contrat())')==1
def empreinte():
 return m.sql("""SELECT jsonb_build_object(
 'fonctions',(SELECT md5(string_agg(pg_get_functiondef(oid),'' ORDER BY oid::regprocedure::text))
   FROM pg_proc WHERE pronamespace='public'::regnamespace AND proname LIKE 'vision_%'),
 'items',(SELECT md5(jsonb_agg(to_jsonb(i) ORDER BY id)::text) FROM vision_items i),
 'seances',(SELECT md5(jsonb_agg(to_jsonb(s) ORDER BY id)::text) FROM vision_seances s),
 'observations',(SELECT md5(jsonb_agg(to_jsonb(o) ORDER BY id)::text) FROM vision_observations o))""")
etat=empreinte()
for _ in range(2):
 subprocess.run(['sh','scripts/migrate.sh'],check=True,stdout=subprocess.DEVNULL)
 assert empreinte()==etat,'Un redémarrage a modifié les fonctions ou les données'
assert m.sql('SELECT to_jsonb(vision_revision_contrat())')==6
print('Contrat SQL 6 cohérent ; deux démarrages sans réécriture de données ni de fonctions.')

