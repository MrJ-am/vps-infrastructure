# External synthetic system contract, not a VPS host definition.
# Root prepares and runs this suite; it is not an independently signed approval.
{ nixpkgs, infrastructure ? /workspace/vps-infrastructure }:
let
  pkgs = import nixpkgs { system = "x86_64-linux"; };
  observer = pkgs.callPackage (infrastructure + "/operations/bootstrap-provenance/package.nix") { };
  revision = "1111111111111111111111111111111111111111";
  nixpkgsRevision = "2222222222222222222222222222222222222222";
  fixtureSystem = name: command:
    let
      program = pkgs.writeShellScriptBin "nixos-version" command;
      # machine.execute itself uses timeout/base64 from the system profile.
      # Preserve the test transport tools while replacing only the metadata tool.
      profile = pkgs.buildEnv {
        name = "synthetic-provenance-${name}-profile";
        paths = [ program pkgs.coreutils pkgs.systemd pkgs.bashInteractive pkgs.util-linux ];
      };
    in pkgs.runCommand "nixos-system-synthetic-${name}" { } ''
      mkdir -p "$out"
      ln -s ${profile} "$out/sw"
    '';
  missing = fixtureSystem "missing" ''
    echo SYNTHETIC_PRIVATE_MARKER
    echo SYNTHETIC_PRIVATE_MARKER >&2
    exit 1
  '';
  invalid = fixtureSystem "invalid" ''
    echo SYNTHETIC_PRIVATE_MARKER
  '';
  flood = fixtureSystem "flood" ''
    printf '%4096s\n' SYNTHETIC_PRIVATE_MARKER
  '';
in pkgs.testers.runNixOSTest {
  name = "mrjam-provenance-systemd-contract";
  requiredFeatures.kvm = false;
  qemu.forceAccel = false;
  globalTimeout = 900;
  nodes.machine = { ... }: {
    system.stateVersion = "26.05"; # Synthetic only; report must never infer it.
    system.configurationRevision = revision;
    # nixos-test-base forces "constant-nixos-revision" at priority 50.
    # Override that test-only substitution to exercise the explicit 40-hex
    # fixture. Keep the assertions and the candidate filter unchanged.
    system.nixos.revision = pkgs.lib.mkOverride 40 nixpkgsRevision;
    virtualisation.memorySize = 1024;
    virtualisation.cores = 2;
    virtualisation.qemu.options = [ "-machine accel=tcg" ];
    users.groups.mrjam-inventory.gid = 980;
    users.users.mrjam-inventory = {
      uid = 980;
      isSystemUser = true;
      group = "mrjam-inventory";
      extraGroups = [ ];
      hashedPassword = "!";
      home = "/var/lib/mrjam-inventory-access/home";
      createHome = false;
      shell = "/var/lib/mrjam-inventory-access/login";
    };
    environment.systemPackages = [ observer pkgs.python3 pkgs.util-linux ];
  };
  testScript = ''
    import json
    import os
    from pathlib import Path

    start_all()
    machine.wait_for_unit("multi-user.target")
    original = machine.succeed("readlink /run/current-system").strip()
    executable = "${observer}/bin/mrjam-observe-provenance"
    groups = []

    def inactive():
        # Synthetic tests replace /run/current-system temporarily; the harness
        # must keep its own systemctl independent of that tested profile.
        machine.wait_until_succeeds("test \"$(${pkgs.systemd}/bin/systemctl show -p LoadState --value mrjam-observe-provenance.service)\" = not-found", timeout=60)

    def observe():
        inactive()
        status, output = machine.execute(executable)
        assert status == 0, "fixed observer failed in synthetic VM: " + str(status)
        assert len(output.encode()) <= 2048 and "SYNTHETIC_PRIVATE_MARKER" not in output
        report = json.loads(output)
        assert set(report) == {"schema_version", "operation", "authority", "generation_store_hash", "configuration_revision", "nixpkgs_revision", "state_version"}
        assert report["authority"] == "unverified_observation" and report["state_version"] is None
        assert report["operation"] == "mrjam-system-provenance-v1"
        return report

    def refused(command):
        status, _ = machine.execute(command + " >/tmp/refusal.out 2>/tmp/refusal.err")
        assert status == 65, "wrong refusal code: " + str(status)
        machine.succeed("test ! -s /tmp/refusal.out")
        assert machine.succeed("cat /tmp/refusal.err").strip() == "PROVENANCE_OBSERVATION_FAILED"

    with subtest("caller cannot select command or launch as inventory account"):
        refused(executable + " SYNTHETIC_PRIVATE_MARKER")
        refused("runuser -u mrjam-inventory -- " + executable)
        inactive()
        groups.append("arguments-and-unprivileged-entry-refused")

    with subtest("mutable root wrapper is refused"):
        machine.succeed("cp -r ${observer}/libexec /tmp/mutable-provenance")
        refused("${pkgs.python3}/bin/python3 -I -S /tmp/mutable-provenance/observe.py")
        groups.append("mutable-wrapper-refused")

    with subtest("actual installed nixos-version returns the two configured revisions"):
        report = observe()
        if report["configuration_revision"]["state"] != "observed" or report["nixpkgs_revision"]["state"] != "observed":
            # Public, invented metadata in this VM only; never a production log.
            print("SYNTHETIC_PROVENANCE_REPORT", report)
            print(machine.execute("runuser -u mrjam-inventory -- ${pkgs.coreutils}/bin/env -i LANG=C LC_ALL=C PATH=/no-path /run/current-system/sw/bin/nixos-version --configuration-revision"))
            print(machine.execute("runuser -u mrjam-inventory -- ${pkgs.coreutils}/bin/env -i LANG=C LC_ALL=C PATH=/no-path /run/current-system/sw/bin/nixos-version --revision"))
        assert report["configuration_revision"] == {"state": "observed", "code": "OK", "value": "${revision}"}, repr(report)
        assert report["nixpkgs_revision"] == {"state": "observed", "code": "OK", "value": "${nixpkgsRevision}"}, repr(report)
        assert report["generation_store_hash"] == original.split("/")[-1].split("-")[0]
        inactive()
        machine.succeed("test ! -e /etc/systemd/system/mrjam-observe-provenance.service")
        groups.append("actual-transient-observation-and-no-persistent-unit")

    with subtest("unavailable metadata cannot produce partial success or raw output"):
        machine.succeed("${pkgs.coreutils}/bin/ln -sfn ${missing} /run/current-system")
        report = observe()
        for field in ("configuration_revision", "nixpkgs_revision"):
            assert report[field] == {"state": "unknown", "code": "UNAVAILABLE", "value": None}
        machine.succeed("${pkgs.coreutils}/bin/ln -sfn " + original + " /run/current-system")
        groups.append("failed-metadata-command-stays-unknown")

    with subtest("invalid free text is not echoed"):
        machine.succeed("${pkgs.coreutils}/bin/ln -sfn ${invalid} /run/current-system")
        report = observe()
        for field in ("configuration_revision", "nixpkgs_revision"):
            assert report[field] == {"state": "unknown", "code": "INVALID_OUTPUT", "value": None}
        machine.succeed("${pkgs.coreutils}/bin/ln -sfn " + original + " /run/current-system")
        groups.append("arbitrary-metadata-text-filtered")

    with subtest("output flood is bounded and becomes unknown"):
        machine.succeed("${pkgs.coreutils}/bin/ln -sfn ${flood} /run/current-system")
        report = observe()
        for field in ("configuration_revision", "nixpkgs_revision"):
            assert report[field] == {"state": "unknown", "code": "UNAVAILABLE", "value": None}
        machine.succeed("${pkgs.coreutils}/bin/ln -sfn " + original + " /run/current-system")
        groups.append("oversized-metadata-output-refused")

    with subtest("preexisting unit remains active and cannot be replaced"):
        inactive()
        machine.succeed("systemd-run --quiet --unit=mrjam-observe-provenance ${pkgs.coreutils}/bin/sleep 60")
        refused(executable)
        machine.succeed("systemctl is-active --quiet mrjam-observe-provenance.service")
        machine.succeed("systemctl stop mrjam-observe-provenance.service")
        groups.append("existing-unit-preserved")

    with subtest("safe repetition preserves the installed account and generation"):
        report = observe()
        assert report["configuration_revision"]["value"] == "${revision}"
        assert machine.succeed("id -u mrjam-inventory").strip() == "980"
        assert machine.succeed("id -g mrjam-inventory").strip() == "980"
        assert machine.succeed("readlink /run/current-system").strip() == original
        groups.append("repetition-without-account-or-generation-mutation")

    Path(os.environ["out"], "groups.json").write_text(json.dumps({
        "groups_passed": groups, "package": "${observer}",
        "production_access": False,
    }, indent=2) + "\n")
  '';
}
